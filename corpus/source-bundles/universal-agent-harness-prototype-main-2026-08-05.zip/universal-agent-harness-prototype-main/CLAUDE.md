# Claude Adapter Instructions

Thin vendor shim (SPEC-170 Q3): the canonical contract is `AGENTS.md` and
role discipline lives in the playbook chain (`harness.py playbook <role>
--list`). This file carries ONLY Claude-specific adapter guidance.

Claude Code should treat `.harness/` as the canonical harness layer.

- Use `.claude/agents/` only as Claude-specific spawn profiles.
- Do not store canonical state in `.claude/`.
- Follow `AGENTS.md` and `.harness/prompts/subagent-contract.md`.
- If a task appears under-scoped or risky, return a structured escalation request rather than expanding scope silently.


## Graphify

Claude must follow the mandatory Graphify-code-AST-first Graphify policy in `AGENTS.md`. If a `PreToolUse` hook reminds you before `Glob`/`Grep`, treat that hook as a search guardrail, not as canonical state. Prefer the Graphify code AST graph before API-assisted discovery; Gemini API use is opt-in, text/image-only, and free-tier-only. For bulk text/image discovery prefer `python scripts/harness.py discover <paths>` (cheap chain: Gemini, then NVIDIA Build) over direct bulk reads. `.harness/` remains the source of truth.

When spawning exploration subagents, seed their prompts with the cheap entry points first — `graphify-out/GRAPH_REPORT.md`, `python scripts/harness.py doc-find <terms>`, and CLI `--help` output — and reserve raw fan-out reads for what those cannot answer. Prefer the repo's `scanner` agent profile over generic exploration agents.

## Agent-tool spawn model economy (cost incident 2026-07-15)

The Agent tool resolves a subagent's model as: explicit `model` param > the agent
definition's `model:` frontmatter > **inherit the caller's model**. The repo's
`.claude/agents/*` profiles are pinned, but the BUILT-IN types — `Explore`, `Plan`,
`general-purpose`, `claude` (the FleetView default), `claude-code-guide` — have no pin,
so a Fable/Opus session spawning them bare runs every one at the caller's model and
effort. That is how read-only fan-outs ended up on Fable 5 high.

Rule: NEVER spawn a built-in agent type bare from an expensive session. Either use the
pinned repo profile (`scanner` for discovery, `planner` for plan drafts) or pass an
explicit `model` — `haiku` for read fan-out and lookups, `sonnet` for synthesis-heavy
reads. This applies inside plan mode too: its workflow names `Explore`/`Plan`, and the
`model` param is the way to comply cheaply.

## Validation gate (SPEC-137)

Run the staged gate ONLY via `python scripts/harness.py gate-staged` — detached, writes log + completion marker under `.harness/runs/`; agent-shell foreground `validate --staged` is hook-denied (a timeout hard-kill mid-gate strands the gate-hold with the owner's live `.harness` state). Typical duration ~5-6 min since the 2026-07-21 parallel-default flip, contention outliers ~20+. Never write to `.harness/` or commit while a gate run is in flight. Commits join gate ‖ reckon (SPEC-157): check `harness.py verify-status` before committing. Inline/single-demand closure: `.harness/prompts/overseer-playbook.md`.

## Protected files

Canonical-file protection (registry, SPEC-148 OS locks, installer/sync
checks) is defined in AGENTS.md — this shim adds nothing to it. Reviewed
edits go through `tools/hooks/protect_canonical_files.py edit`.
