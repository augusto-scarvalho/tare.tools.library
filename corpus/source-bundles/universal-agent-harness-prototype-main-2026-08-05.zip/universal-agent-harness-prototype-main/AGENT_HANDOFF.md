# Agent Handoff

Canonical handoff lives in `.harness/handoff/handoff.md` and `.harness/handoff/handoff.json`.

This root-level file exists as a stable entry point for any executor. Do not add task state here; regenerate the canonical handoff with `scripts/harness.py handoff` when the task or routing context changes.
