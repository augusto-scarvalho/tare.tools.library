# Codex Roadmap Compatibility Wrapper

Codex should use `AGENT_IMPLEMENTATION_ROADMAP.md`, `tasks/`, `specs/`, and `.harness/` for roadmap and task state.

This file is intentionally a wrapper so older Codex workflows do not break.
