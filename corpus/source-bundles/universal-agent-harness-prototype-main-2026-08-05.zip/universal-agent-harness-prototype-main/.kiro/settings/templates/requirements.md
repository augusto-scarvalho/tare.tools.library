# Requirements Template

Use this template when a project wants Kiro/cc-sdd compatible requirements.

## Goal

Describe the user or system outcome.

## Requirements

- The system shall ...

## Non-functional requirements

- Security/privacy:
- Performance:
- Reliability:
- Observability:

## Acceptance criteria

- [ ] ...
