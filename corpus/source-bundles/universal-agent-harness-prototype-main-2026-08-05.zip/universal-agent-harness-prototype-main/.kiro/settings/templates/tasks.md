# Tasks — {{FEATURE_NAME}}

## Status

draft | needs-human-review | approved

## Implementation notes

Record learnings from each task here so later `/kiro-impl` iterations inherit them.

## Task list

### P0 — Foundation

- [ ] T-001 Title
  - _Boundary:_ runtime/module/files owned by this task.
  - _Depends:_ none | T-...
  - _Spec refs:_ REQ-..., DESIGN section ...
  - _Feature flag:_ required? name?
  - _Tests:_ `./scripts/harness-test.sh feature --task TASK-XXX --spec SPEC-XXX`
  - _Coverage:_ not applicable | manual | `./scripts/harness-test.sh coverage --task TASK-XXX`
  - _Done when:_ ...

### P1 — Feature behavior

- [ ] T-002 Title
  - _Boundary:_ ...
  - _Depends:_ T-001
  - _Spec refs:_ ...
  - _Tests:_ ...
  - _Done when:_ ...

### P2 — Hardening and release

- [ ] T-003 Title
  - _Boundary:_ ...
  - _Depends:_ T-002
  - _Tests:_ `./scripts/harness-test.sh release --manifest testing/release-scope.example.yaml`
  - _Coverage:_ follow `testing/COVERAGE_POLICY.md`
  - _Done when:_ ...
