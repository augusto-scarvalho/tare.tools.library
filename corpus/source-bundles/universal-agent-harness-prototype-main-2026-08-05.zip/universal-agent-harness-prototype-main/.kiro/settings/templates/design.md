# Design Template

Use this template when a project wants Kiro/cc-sdd compatible design notes.

## Context

- Project:
- Component/service/module:
- Related specs/tasks:

## Design

Describe the proposed architecture, data flow, interfaces, risks, and validation approach.

## Validation

List build, test, lint, or manual checks.
