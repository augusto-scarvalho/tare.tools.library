# Kiro / cc-sdd Compatibility

This optional directory contains minimal templates for projects that also use Kiro-style or cc-sdd-style workflows.

The canonical harness layer remains `.harness/`; Kiro templates should not become a second source of truth.

## Usage

- Use these templates only when the adopted project needs compatibility with Kiro/cc-sdd tooling.
- Keep templates stack-neutral unless the adopted project intentionally customizes them.
- Do not store active task state, execution logs, or long summaries here.
- Link back to specs/tasks/handoff rather than duplicating them.
