@echo off
rem One-time setup: create the project venv (if missing), install the REQUIRED deps
rem (requirements.txt - keyring, the OS key vault backend), then provision the OPTIONAL
rem syntax-highlighting assets - native deps (tree-sitter) + the tree-sitter WASM
rem grammars fetched ^& sha256-verified into vendor\tree-sitter\. Safe to re-run.
rem Highlighting is optional and degrades; the required install is NOT - since
rem keys-keyring v2 the vault is the sole secret backend, so a harness without
rem keyring cannot resolve any vendor key.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo creating .venv ^(uv venv --python 3.13^) ...
  uv venv --python 3.13 || (echo error: install uv from https://docs.astral.sh/uv/ then re-run setup.bat & exit /b 1)
)
echo installing required deps ^(requirements.txt^) ...
uv pip install --python ".venv\Scripts\python.exe" -r requirements.txt || (echo error: could not install required deps; the OS key vault backend ^(keyring^) is mandatory & exit /b 1)
".venv\Scripts\python.exe" "tools\bootstrap_local.py" || exit /b 1
".venv\Scripts\python.exe" "tools\wire_harness_python.py" || exit /b 1
".venv\Scripts\python.exe" "scripts\setup_highlight.py" %*
