@echo off
rem Start the harness operator chat REPL (menu appears if no --engine given).
rem SPEC-147 zero-touch (extended to chat, keys-keyring v2): a missing venv OR a
rem missing REQUIRED dep runs setup first. The dep probe is `import keyring` - the
rem sole entry in requirements.txt since the OS vault became the only secret
rem backend. Widen the probe if requirements.txt grows.
set "_HARNESS_READY=0"
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" -c "import keyring" >nul 2>&1 && set "_HARNESS_READY=1"
)
if "%_HARNESS_READY%"=="0" (
  echo [chat] venv or required deps missing -- running setup.bat first ^(one-time^)
  call "%~dp0setup.bat" || exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0scripts\harness.py" chat %*
