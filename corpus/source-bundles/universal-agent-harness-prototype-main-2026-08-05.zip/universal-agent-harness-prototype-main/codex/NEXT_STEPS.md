# Codex Compatibility Wrapper — NEXT_STEPS.md

Canonical content lives in `.harness/context/NEXT_STEPS.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
