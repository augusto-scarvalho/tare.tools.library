# Codex Compatibility Wrapper — STATE.md

Canonical content lives in `.harness/context/STATE.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
