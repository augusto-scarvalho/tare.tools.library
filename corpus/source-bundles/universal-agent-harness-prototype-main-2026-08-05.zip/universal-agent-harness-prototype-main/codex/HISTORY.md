# Codex Compatibility Wrapper — HISTORY.md

Canonical content lives in `.harness/context/HISTORY.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
