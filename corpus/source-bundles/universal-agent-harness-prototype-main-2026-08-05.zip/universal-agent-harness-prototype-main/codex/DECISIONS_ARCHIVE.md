# Codex Compatibility Wrapper — DECISIONS_ARCHIVE.md

Canonical content lives in `.harness/context/DECISIONS_ARCHIVE.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
