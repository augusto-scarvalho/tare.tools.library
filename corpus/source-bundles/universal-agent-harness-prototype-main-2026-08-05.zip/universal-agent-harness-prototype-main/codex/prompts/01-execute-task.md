# Codex Prompt Wrapper — Execute Task

Execute the active task using canonical harness context under `.harness/`. Keep the diff scoped and end with `HARNESS_RESULT`.
