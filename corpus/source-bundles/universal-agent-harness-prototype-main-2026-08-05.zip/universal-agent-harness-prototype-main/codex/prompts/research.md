# research (hand-authored parity adapter)

`agents pair` renders codex adapters from USER-scope Claude skills; the `research`
skill is REPO-scoped (`.claude/skills/research/SKILL.md`), which `pair` does not
render (documented SPEC-119 ceiling). Keep this file in sync with the Claude
SKILL.md by hand when either changes.

---

Evidence-driven Double Diamond research for the harness: prospecting options,
investigating trade-offs, running an ideation round, or a "what should we adopt
from X" study. Triggers: pesquisar, prospectar, investigar opções, rodada de
ideação, deep research, "o que devemos adotar de".

Read the canonical playbook `.harness/prompts/research-playbook.md` and follow it
exactly. You are the ORCHESTRATOR, not a worker: you frame the question, drive the
harness fork-join/map-reduce waves, and synthesize — you never fabricate a source
(claim -> source + date + confidence; unverifiable = `judgment`).
