# overseer-loop

Run an autonomous backlog loop as OVERSEER. Follow the canonical playbook at
`.harness/prompts/overseer-loop-playbook.md`: plan briefs with hard file
footprints (overseer plans, workers implement), parallel lanes only with
disjoint footprints, mandatory per-completion review ritual (arithmetic
sanity, HEAD-attributed mojibake sweep, gaming hunt, rerun all verification
yourself), escalate instead of deciding on protected/OWNER-GATED/novel-fraud
cases, checkpoint at every transition, wind-down with an owner summary.
