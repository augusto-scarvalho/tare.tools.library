# Codex Prompt Wrapper — Start Here

Read `AGENTS.md` and `.harness/handoff/handoff.md` before working. Prefer canonical prompts under `.harness/prompts/task/`.
