# Codex Prompt Wrapper — Review

Review the current diff against `.harness/state/task-state.json`, `.harness/state/quality-state.json`, and applicable specs. End with `HARNESS_RESULT`.
