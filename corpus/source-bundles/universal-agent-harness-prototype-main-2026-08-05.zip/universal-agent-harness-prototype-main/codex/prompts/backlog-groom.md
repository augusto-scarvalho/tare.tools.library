# backlog-groom

Periodic backlog/spec archaeology. Follow the canonical playbook at
`.harness/prompts/backlog-groom-playbook.md` — mine (cheap background
workers per corpus slice) → audit (verify H/M claims against primary
sources; live-code claims are untrusted until read) → triage with the owner
(`harness.py intake add` / `intake decide`) → consolidate (SPEC-116 doors +
scenario checks, CLOSED log in `docs/spec-recovery/INDEX.md`).
