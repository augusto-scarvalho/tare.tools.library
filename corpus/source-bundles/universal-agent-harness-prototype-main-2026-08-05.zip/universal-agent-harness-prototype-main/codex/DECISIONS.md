# Codex Compatibility Wrapper — DECISIONS.md

Canonical content lives in `.harness/context/DECISIONS.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
