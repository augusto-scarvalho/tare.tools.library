# Codex Compatibility Wrapper — CONTEXT.md

Canonical content lives in `.harness/context/CONTEXT.md`.

Read the canonical file instead of adding or editing state here. The `codex/` directory is an adapter layer only.
