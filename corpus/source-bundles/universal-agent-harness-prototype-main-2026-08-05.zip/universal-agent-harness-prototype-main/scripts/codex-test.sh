#!/usr/bin/env bash
# Codex compatibility wrapper. Prefer scripts/harness-test.sh or
# `python scripts/harness-test.py` for cross-platform usage.
set -euo pipefail
exec "$(dirname "$0")/harness-test.sh" "$@"
