"""SPEC-147 chat workspace front-end module (CM6 vibe/copilot surface).

Split out of harness_ui_page.py (MD_JS precedent — file budget): WS_CSS is
spliced at ``/*__WS_CSS__*/`` inside the page <style>, WS_JS at ``/*__WS_JS__*/``
near the end of the main <script>, so the IIFE shares scope with esc()/
colorizeDiff()/colorizeNumDiff()/el()/curSession/TOKEN.

Vendoring contract (SPEC-147 inv 2-3): CM6_PACKAGES below mirrors
vendor/codemirror/manifest.json — WS_IMPORTMAP is a STATIC <script
type="importmap"> in the page <head> (spliced at ``/*__WS_IMPORTMAP__*/``),
because a dynamically inserted map is ignored once any module has loaded
(Chromium: "import map added after module script load"). Its URLs carry the
literal __HARNESS_TOKEN__, resolved by harness_ui._send_page's global replace.
All CM6 loads are lazy dynamic imports; any failure degrades to the chip's
capped colorized diff. m_workspace.py asserts list==manifest + head ordering.
"""

import json as _json

# Mirrors vendor/codemirror/manifest.json "packages" keys (m_workspace ws-sync).
CM6_PACKAGES = [
    "@codemirror/autocomplete", "@codemirror/commands", "@codemirror/lang-css",
    "@codemirror/lang-html", "@codemirror/lang-javascript", "@codemirror/lang-json",
    "@codemirror/lang-markdown", "@codemirror/lang-python", "@codemirror/language",
    "@codemirror/lint", "@codemirror/merge", "@codemirror/search",
    "@codemirror/state", "@codemirror/theme-one-dark", "@codemirror/view",
    "@lezer/common", "@lezer/css",
    "@lezer/highlight", "@lezer/html", "@lezer/javascript", "@lezer/json",
    "@lezer/lr", "@lezer/markdown", "@lezer/python",
    "@marijn/find-cluster-break", "crelt", "style-mod", "w3c-keyname",
]

def _flat(pkg: str) -> str:
    return pkg.replace("@", "").replace("/", "-") + ".js"


WS_IMPORTMAP = _json.dumps({"imports": {
    pkg: f"/vendor/codemirror/{_flat(pkg)}?token=__HARNESS_TOKEN__"
    for pkg in CM6_PACKAGES}}, indent=1)

WS_CSS = r"""
/* -- SPEC-147 chat workspace: vibe (diff pane) / copilot (IDE pane) -------- */
#wsSplit { flex: 0 0 6px; cursor: col-resize; background: var(--surface-2);
           border-left: 1px solid var(--border); border-right: 1px solid var(--border); }
#wsSplit:hover { background: var(--accent); }
/* v3 (owner): both modes split the screen equally — chat 1/2, IDE 1/2 */
#wsPane { flex: 0 0 50%; min-width: 14rem; max-width: 72vw; display: flex;
          flex-direction: column; background: var(--bg-base); overflow: hidden; }
#wsSplit[hidden], #wsPane[hidden] { display: none !important; }
.wsbar { display: flex; align-items: center; gap: 0.4rem; padding: 0.3rem 0.5rem;
         background: var(--surface-2); border-bottom: 1px solid var(--border); flex: 0 0 auto; }
#wsTitle { font-size: var(--text-sm); overflow: hidden; text-overflow: ellipsis;
           white-space: nowrap; min-width: 0; }
#wsBody { flex: 1 1 auto; min-height: 0; overflow: auto; }
#wsBody .cm-editor { height: 100%; font-size: var(--text-sm); }
#wsBody .cm-merge-view, #wsBody .cm-mergeView { height: 100%; }
#wsBody pre.wsfall { margin: 0; padding: 0.5rem 0.6rem; font-size: var(--text-sm);
                     white-space: pre-wrap; overflow-wrap: anywhere; }
.wsnotice { padding: 0.35rem 0.6rem; font-size: var(--text-sm); color: var(--warning);
            background: var(--warning-bg); border-bottom: 1px solid var(--warning-bg); }
.wsopen { margin-left: 0.4rem; border: 1px solid var(--border); background: var(--surface-3);
          color: var(--accent); border-radius: var(--radius-xs); font-size: var(--text-xs); cursor: pointer;
          padding: 0 0.35rem; }
.wsopen:hover { border-color: var(--accent); }
#wsFileBar { display: flex; align-items: center; gap: 0.35rem; padding: 0.3rem 0.5rem;
             background: var(--surface-1); border-bottom: 1px solid var(--border-subtle); flex: 0 0 auto; }
#wsFileBar[hidden] { display: none !important; }
#wsPath { flex: 1 1 auto; min-width: 0; font-size: var(--text-sm); }
#wsEdState { font-size: var(--text-sm); min-width: 1.2rem; text-align: center; }
#wsEdState.dirty { color: var(--warning); }
/* M3 floating explorer: toggle rides the pane's left inner edge; the overlay is
   a fixed 25vw sheet floating over the chat side (position set at open time). */
#wsPane { position: relative; }
#wsTreeBtn { position: absolute; left: 4px; top: 50%; transform: translateY(-50%);
             z-index: 7; background: var(--surface-3); border: 1px solid var(--border); color: var(--accent);
             border-radius: var(--radius-sm); padding: 0.45rem 0.28rem; cursor: pointer; font: inherit; }
#wsTreeBtn:hover { border-color: var(--accent); }
#wsTreeBtn[hidden] { display: none !important; }
#wsTree { position: fixed; width: 25vw; min-width: 16rem; z-index: 8;
          background: var(--surface-1); border: 1px solid var(--border); border-radius: var(--radius-md) 0 0 var(--radius-md);
          box-shadow: var(--shadow-overlay); display: flex; flex-direction: column; }
#wsTree[hidden] { display: none !important; }
.wstbar { display: flex; align-items: center; gap: 0.4rem; padding: 0.3rem 0.5rem;
          background: var(--surface-2); border-bottom: 1px solid var(--border); flex: 0 0 auto; }
#wsTreeBody { flex: 1 1 auto; overflow: auto; font-size: var(--text-sm); padding: 0.3rem; }
.wstfile, .wstdir > summary { cursor: pointer; padding: 0.1rem 0.3rem; border-radius: var(--radius-xs);
                              display: flex; gap: 0.3rem; align-items: center; }
.wstfile:hover, .wstdir > summary:hover { background: var(--surface-hover); }
.wstact { margin-left: auto; visibility: hidden; display: flex; gap: 0.15rem; }
.wstfile:hover .wstact { visibility: visible; }
.wstact button { background: none; border: none; color: var(--text-muted); cursor: pointer;
                 font-size: var(--text-xs); padding: 0 0.15rem; }
.wstact button:hover { color: var(--danger); }
.wstkids { margin-left: 0.9rem; }
/* -- SPEC-147 v2 split mode selector (authored by gpt-5.6-sol xhigh) -------- */
#wsModeSel {
  display: inline-grid;
  grid-template-columns: 1fr 1fr;
  height: 1.6rem;
  overflow: hidden;
  border: 1px solid var(--border);
  border-radius: var(--radius-pill);
  background: var(--surface-2);
}
#wsModeSel > button {
  min-width: 3.8rem;
  padding: 0 0.55rem;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  font: 600 var(--text-sm)/1 var(--font-ui);
  white-space: nowrap;
  cursor: pointer;
  transition: background-color 150ms ease, color 150ms ease, box-shadow 150ms ease;
}
#wsModeSel > button + button { border-left: 1px solid var(--border); }
#wsModeSel > button:not(.is-active):hover { background: var(--surface-hover); color: var(--text-primary); }
#wsModeSel > button[data-mode="vibe"].is-active { background: var(--stream); color: var(--accent-contrast); }
#wsModeSel > button[data-mode="copilot"].is-active { background: var(--accent); color: var(--accent-contrast); }
#wsModeSel > button:focus-visible {
  position: relative;
  z-index: 1;
  outline: 0;
  box-shadow: inset 0 0 0 2px var(--text-primary);
}
#wsModeSel > button:active { filter: brightness(0.92); }
@media (prefers-reduced-motion: reduce) {
  #wsModeSel > button { transition: none; }
}
/* v3 owner tweak on the Sol selector: the split is DIAGONAL, not straight —
   a pill sliced at an angle; the container background shows through the
   slanted seam. Overlap replaces the straight border divider. */
#wsModeSel { display: inline-flex; }
#wsModeSel > button { flex: 1 1 auto; }
#wsModeSel > button + button { border-left: 0; margin-left: -0.5rem; }
#wsModeSel > button[data-mode="vibe"] {
  padding-right: 0.8rem;
  clip-path: polygon(0 0, 100% 0, calc(100% - 0.55rem) 100%, 0 100%);
}
#wsModeSel > button[data-mode="copilot"] {
  padding-left: 0.8rem;
  clip-path: polygon(0.55rem 0, 100% 0, 100% 100%, 0 100%);
}
"""

WS_JS = r"""
// -- SPEC-147 chat workspace (CM6): modes + diff pane. Degrades on ANY failure. --
const WS = (function(){
  const MODES = ["chat", "vibe", "copilot"];
  let mode = "chat", sbs = false, cur = null, views = [];
  let ed = null, edFile = null, edSha = null, lintOn = true;  // M2 editor state
  let edStash = null;  // v3: unsaved edits survive a vibe round-trip

  // Bare specifiers resolve via the STATIC importmap in <head> (SPEC-147 inv 3).
  let modsP = null;
  function mods(){
    if (!modsP) modsP = Promise.all([
      import("@codemirror/state"), import("@codemirror/view"),
      import("@codemirror/merge"), import("@codemirror/language"),
      import("@codemirror/commands"), import("@codemirror/lint"),
      import("@codemirror/search"), import("@codemirror/autocomplete"),
      import("@codemirror/theme-one-dark"),
    ]).then(([state, view, merge, language, commands, lint, search, autocomplete, oneDark]) =>
            ({state, view, merge, language, commands, lint, search, autocomplete, oneDark}));
    return modsP;
  }
  const LANGS = {py: () => import("@codemirror/lang-python").then(m => m.python()),
    js: () => import("@codemirror/lang-javascript").then(m => m.javascript()),
    mjs: () => import("@codemirror/lang-javascript").then(m => m.javascript()),
    ts: () => import("@codemirror/lang-javascript").then(m => m.javascript({typescript: true})),
    tsx: () => import("@codemirror/lang-javascript").then(m => m.javascript({typescript: true, jsx: true})),
    jsx: () => import("@codemirror/lang-javascript").then(m => m.javascript({jsx: true})),
    json: () => import("@codemirror/lang-json").then(m => m.json()),
    css: () => import("@codemirror/lang-css").then(m => m.css()),
    html: () => import("@codemirror/lang-html").then(m => m.html()),
    md: () => import("@codemirror/lang-markdown").then(m => m.markdown())};
  async function langExt(file){
    const ext = (file || "").split(".").pop().toLowerCase();
    try { return LANGS[ext] ? await LANGS[ext]() : []; } catch(e){ return []; }
  }
  function theme(view){  // minimal dark theme; the page is dark-only
    return view.EditorView.theme({
      "&": {backgroundColor: "var(--bg-base)", color: "var(--text-primary)"},
      ".cm-gutters": {backgroundColor: "var(--surface-1)", color: "var(--text-muted)", border: "none"},
    }, {dark: true});
  }

  function setMode(m){
    mode = MODES.includes(m) ? m : "chat";
    document.body.dataset.wsMode = mode;
    const on = mode !== "chat";
    el("wsSplit").hidden = !on; el("wsPane").hidden = !on;
    el("wsFileBar").hidden = mode !== "copilot";
    el("wsTreeBtn").hidden = mode !== "copilot";
    if (mode !== "copilot") treeClose();
    localStorage.setItem("harness.panel.wsMode", mode);
    if (on){
      localStorage.setItem("harness.panel.wsLast", mode);  // togglePane restores this
      if (typeof syncModeSel === "function") syncModeSel(mode);  // Sol's split selector
      // v3 (owner): strict surfaces — vibe is READ-ONLY diffs (never an editable
      // editor left over from copilot); copilot owns the editor (never a stale
      // diff). Unsaved edits are stashed on the way out and restored on return —
      // the flip must never silently discard work.
      if (mode === "vibe" && ed){
        if (el("wsEdState").classList.contains("dirty"))
          edStash = {path: edFile, content: ed.state.doc.toString(), sha: edSha};
        clear();
      }
      if (mode === "copilot" && cur) clear();
      if (mode === "vibe" && !cur)
        hint("read-only diff view — click ⧉ on a chat chip to load a diff.");
      if (mode === "copilot" && !ed && edStash){
        const s = edStash; edStash = null;
        openFile(s.path).then(() => {
          if (ed && edFile === s.path && ed.state.doc.toString() !== s.content){
            ed.dispatch({changes: {from: 0, to: ed.state.doc.length, insert: s.content}});
            edSha = s.sha;  // conflict detection keeps the ORIGINAL baseline
            markDirty(true);
          }
        });
      }
    }
    // v3.1 (owner): ONE shared width for both modes — per-mode memory made the
    // split visibly jump on vibe<->copilot flips (stale 60/40-era values).
    const saved = localStorage.getItem("harness.panel.wsW");
    el("wsPane").style.flexBasis = saved || "";
    if (mode === "copilot" && !ed) hint("type a relative path above and Open to edit (Ctrl+S saves).");
    if (mode === "chat") clear();
  }
  // SPEC-147 v2: the Chat tab toggles the pane; the split selector picks the mode.
  function togglePane(){
    setMode(mode === "chat" ? (localStorage.getItem("harness.panel.wsLast") || "vibe") : "chat");
  }

  function clear(){
    views.forEach(v => { try { v.destroy(); } catch(e){} });
    views = []; cur = null; ed = null; edFile = null;
    el("wsEdState").textContent = ""; el("wsEdState").classList.remove("dirty");
    el("wsBody").innerHTML = ""; el("wsTitle").textContent = "diff";
  }
  function hint(msg){ clear(); el("wsBody").innerHTML = `<div class="wsnotice">${esc(msg)}</div>`; }

  function fallback(det, notice){
    clear();
    const body = el("wsBody");
    body.innerHTML = `<div class="wsnotice">${esc(notice)}</div>`;
    const src = det && (det.querySelector(".tchip-in") || det.querySelector(".tchip-out"));
    const pre = document.createElement("pre");
    pre.className = "wsfall mono";
    pre.innerHTML = src ? src.innerHTML : "(no diff on the chip)";
    body.appendChild(pre);
  }

  async function render(full, det){
    const body = el("wsBody");
    body.innerHTML = "";
    try {
      const m = await mods();
      const ro = m.view.EditorView.editable.of(false);
      const th = theme(m.view);
      // v3: diffs get per-language syntax colors too
      const hl = m.language.syntaxHighlighting(m.oneDark.oneDarkHighlightStyle, {fallback: true});
      if (typeof full.old === "string" && typeof full.new === "string"){
        const lang = await langExt(full.file);
        if (sbs){
          const mv = new m.merge.MergeView({
            a: {doc: full.old, extensions: [ro, th, hl, lang]},
            b: {doc: full.new, extensions: [ro, th, hl, lang]},
            parent: body});
          views.push(mv);
        } else {
          const v = new m.view.EditorView({
            doc: full.new,
            extensions: [m.merge.unifiedMergeView({original: full.old, mergeControls: false}),
                         ro, th, hl, lang],
            parent: body});
          views.push(v);
        }
      } else if (full.unified){
        // codex multi-file change: colorized unified text (no old/new pair)
        const pre = document.createElement("pre");
        pre.className = "wsfall mono";
        pre.innerHTML = colorizeDiff(full.unified);
        body.appendChild(pre);
      } else {
        return fallback(det, "empty diff payload — showing the chip's capped diff.");
      }
    } catch(e){
      return fallback(det, "CM6 unavailable (run ./setup.sh) — showing the chip's capped diff.");
    }
  }

  // -- M2 copilot editor: open / lint / conflict-safe save --------------------
  // v3: per-language linters — python via the server's ruff, JSON via the
  // lang-json parser; other languages have none yet (ceiling: LSP, fase 2).
  async function langLint(m, path){
    if (path.endsWith(".py")) return lintExt(m, path);
    if (path.endsWith(".json")){
      const j = await import("@codemirror/lang-json");
      return m.lint.linter(j.jsonParseLinter());
    }
    return [];
  }
  // v3: formatting — python via the server's `ruff format`; other languages
  // reindent the current selection (CM6 language indentation).
  async function formatDoc(){
    if (!ed || !edFile) return;
    if (edFile.endsWith(".py")){
      let r = null;
      try { r = await jpost("/api/format", {path: edFile, content: ed.state.doc.toString()}); }
      catch(e){ r = null; }
      if (r && r.ok && typeof r.content === "string" && r.content !== ed.state.doc.toString())
        ed.dispatch({changes: {from: 0, to: ed.state.doc.length, insert: r.content}});
      return;
    }
    const m = await mods();
    m.commands.indentSelection({state: ed.state, dispatch: t => ed.dispatch(t)});
  }
  // SPEC-147 inv 11: ALL editor capabilities assemble here (the fase-2
  // autocomplete seam adds one more entry to this list, nothing else).
  async function buildExtensions(m, path){
    const lang = await langExt(path);
    const lint = await langLint(m, path);
    return [
      m.view.lineNumbers(), m.view.highlightActiveLine(),
      m.commands.history(),
      m.language.indentUnit.of("    "),  // 4-space indent (repo/python convention)
      m.language.bracketMatching(), m.language.indentOnInput(),
      m.language.foldGutter(),
      m.autocomplete.closeBrackets(),
      m.search.highlightSelectionMatches(),
      m.view.keymap.of([
        {key: "Mod-s", run: () => { save(false); return true; }},
        // both spellings: Chromium delivers the SHIFTED char ("F") as event.key
        {key: "Mod-Shift-f", run: () => { formatDoc(); return true; }},
        {key: "Mod-Shift-F", run: () => { formatDoc(); return true; }},
        m.commands.indentWithTab,                 // Tab indents, Shift-Tab dedents
        ...m.search.searchKeymap,                 // Mod-f find/replace panel (text + regex)
        ...m.commands.defaultKeymap, ...m.commands.historyKeymap,
        ...m.language.foldKeymap, ...m.autocomplete.closeBracketsKeymap,
        ...m.lint.lintKeymap]),
      m.view.EditorView.updateListener.of(u => { if (u.docChanged) markDirty(true); }),
      lint, m.lint.lintGutter(),
      m.language.syntaxHighlighting(m.oneDark.oneDarkHighlightStyle, {fallback: true}),
      theme(m.view), lang];
  }
  function lintExt(m, path){
    return m.lint.linter(async view => {
      if (!lintOn || !path.endsWith(".py")) return [];
      let r = null;
      try { r = await jpost("/api/lint", {path, content: view.state.doc.toString()}); }
      catch(e){ r = null; }
      if (!r || !r.ok){ lintOn = false; return []; }  // inv 9: ruff absent => lint off
      const doc = view.state.doc;
      return (r.diagnostics || []).map(d => {
        const l1 = doc.line(Math.min(d.line || 1, doc.lines));
        const l2 = doc.line(Math.min(d.endLine || d.line || 1, doc.lines));
        const from = Math.min(l1.from + Math.max((d.col || 1) - 1, 0), l1.to);
        return {from, to: Math.max(from, Math.min(l2.from + Math.max((d.endCol || 1) - 1, 0), l2.to)),
                severity: "warning", message: (d.code ? d.code + " " : "") + d.message};
      });
    }, {delay: 700});
  }
  function markDirty(on){
    el("wsEdState").textContent = on ? "●" : "✓";
    el("wsEdState").classList.toggle("dirty", on);
  }
  async function openFile(path){
    if (mode !== "copilot") setMode("copilot");
    let r = null;
    try { r = await fetch(`/api/ws/file?path=${encodeURIComponent(path)}&token=${encodeURIComponent(TOKEN)}`)
      .then(x => x.json()); } catch(e){ r = null; }
    if (!r || !r.ok) return hint(`could not open: ${(r && r.error) || "network error"}`);
    try {
      const m = await mods();
      clear();
      ed = new m.view.EditorView({
        doc: r.content,
        extensions: await buildExtensions(m, r.path),
        parent: el("wsBody")});
      views.push(ed);
      edFile = r.path; edSha = r.sha256;
      el("wsTitle").textContent = r.path; el("wsPath").value = r.path;
      markDirty(false);
    } catch(e){
      hint("CM6 unavailable (run ./setup.sh) — editor disabled.");
    }
  }
  async function save(overwrite){
    if (!ed || !edFile) return;
    const content = ed.state.doc.toString();
    if (!overwrite && !(await confirmModal(`Save ${edFile}?`))) return;
    let r = null;
    try {
      r = await jpost("/api/action", {action: "ws-file-save",
        params: {path: edFile, content, baseSha: edSha,
                 overwrite: overwrite === true, confirm: true}});
    } catch(e){ r = null; }
    if (r && r.conflict){
      const ow = await confirmModal(
        `${edFile} changed on disk since it was opened (likely an agent edit).\n` +
        `Confirm = OVERWRITE with your version; Cancel = reload from disk.`);
      if (ow) return save(true);   // inv 8: explicit second confirm
      return openFile(edFile);
    }
    if (!r || !r.ok) return hint(`save failed: ${(r && (r.error || r.refused)) || "network error"}`);
    edSha = r.sha256;
    markDirty(false);
  }

  // -- M3 floating explorer: lazy one-level tree + confined file ops ----------
  function treeClose(){ el("wsTree").hidden = true; }
  function treeOpen(){
    const t = el("wsTree"), pane = el("wsPane").getBoundingClientRect();
    // the sheet floats over the CHAT side: its right edge hugs the pane's left edge
    t.style.right = (window.innerWidth - pane.left) + "px";
    t.style.top = pane.top + "px";
    t.style.height = pane.height + "px";
    t.hidden = false;
    loadDir("", el("wsTreeBody"));
  }
  async function fetchDir(p){
    try {
      return await fetch(`/api/ws/tree?path=${encodeURIComponent(p)}&token=${encodeURIComponent(TOKEN)}`)
        .then(r => r.json());
    } catch(e){ return null; }
  }
  async function loadDir(p, box){
    box.innerHTML = "";  // clear BEFORE the fetch: stale rows must never be interactable
    const r = await fetchDir(p);
    if (!r || !r.ok){
      box.innerHTML = `<div class="wsnotice">${esc((r && r.error) || "network error")}</div>`;
      return;
    }
    for (const d of r.dirs){
      const det = document.createElement("details");
      det.className = "wstdir";
      det.innerHTML = `<summary>📁 ${esc(d)}</summary><div class="wstkids"></div>`;
      det.addEventListener("toggle", () => {
        if (det.open && !det.dataset.loaded){
          det.dataset.loaded = "1";
          loadDir(p ? `${p}/${d}` : d, det.querySelector(".wstkids"));
        }
      });
      box.appendChild(det);
    }
    for (const f of r.files){
      const fp = p ? `${p}/${f.name}` : f.name;
      const row = document.createElement("div");
      row.className = "wstfile";
      row.dataset.path = fp;
      row.innerHTML = `📄 <span>${esc(f.name)}</span><span class="wstact">` +
        `<button data-op="rename" title="rename">✎</button>` +
        `<button data-op="delete" title="delete">🗑</button></span>`;
      row.addEventListener("click", e => {
        const op = e.target.dataset && e.target.dataset.op;
        if (op === "rename") return renameFile(fp);
        if (op === "delete") return deleteFile(fp);
        openFile(fp); treeClose();
      });
      box.appendChild(row);
    }
    if (!r.dirs.length && !r.files.length)
      box.innerHTML = `<div class="dim" style="padding:0.3rem">(empty)</div>`;
  }
  function treeRefresh(){ loadDir("", el("wsTreeBody")); }  // ponytail: root reload; per-dir refresh if it ever matters
  async function wsAction(action, params){
    let r = null;
    try { r = await jpost("/api/action", {action, params: {...params, confirm: true}}); }
    catch(e){ r = null; }
    if (!r || !r.ok) await alertModal(`${action} failed: ${(r && (r.error || r.refused)) || "network error"}`);
    return !!(r && r.ok);
  }
  async function newFile(){
    const p = await promptModal("new file path (repo-relative):");
    if (!p) return;
    if (await wsAction("ws-file-create", {path: p})){ treeClose(); openFile(p); }  // same close-on-open as a row click
  }
  async function renameFile(fp){
    const np = await promptModal(`rename ${fp} to (repo-relative):`);
    if (!np) return;
    if (await wsAction("ws-file-rename", {path: fp, newPath: np})) treeRefresh();
  }
  async function deleteFile(fp){
    if (!(await confirmModal(`Delete ${fp}?`))) return;
    if (await wsAction("ws-file-delete", {path: fp})) treeRefresh();
  }

  async function openDiff(tid, det){
    if (mode !== "vibe") setMode("vibe");  // v3: diffs live in vibe, from ANY mode
    el("wsTitle").textContent = "loading…";
    let d = null;
    try {
      d = await fetch(`/api/chat/diff?session=${encodeURIComponent(curSession)}&id=${encodeURIComponent(tid || "")}&token=${encodeURIComponent(TOKEN)}`)
        .then(r => r.json());
    } catch(e){ d = null; }
    if (!d || !d.ok){
      el("wsTitle").textContent = "diff (truncated)";
      return fallback(det, "full diff unavailable (evicted from the session ring) — showing the chip's capped diff.");
    }
    clear();
    cur = d;
    el("wsTitle").textContent = d.file || "diff";
    await render(d, det);
  }

  // divider drag (per-mode width, localStorage persist; dblclick = CSS default)
  (function(){
    const split = el("wsSplit"), pane = el("wsPane");
    let sx = 0, sw = 0, drag = false;
    split.addEventListener("pointerdown", e => {
      drag = true; sx = e.clientX; sw = pane.getBoundingClientRect().width;
      split.setPointerCapture(e.pointerId);
    });
    split.addEventListener("pointermove", e => {
      if (!drag) return;
      const w = Math.max(224, Math.min(window.innerWidth * 0.72, sw - (e.clientX - sx)));
      pane.style.flexBasis = w + "px";
    });
    split.addEventListener("pointerup", e => {
      drag = false; split.releasePointerCapture(e.pointerId);
      localStorage.setItem("harness.panel.wsW", pane.style.flexBasis);
    });
    split.addEventListener("dblclick", () => {
      pane.style.flexBasis = ""; localStorage.removeItem("harness.panel.wsW");
    });
  })();

  el("wsClose").addEventListener("click", () => setMode("chat"));
  el("wsTreeBtn").addEventListener("click", () => {
    el("wsTree").hidden ? treeOpen() : treeClose();
  });
  el("wsTreeClose").addEventListener("click", treeClose);
  el("wsNew").addEventListener("click", newFile);
  document.addEventListener("click", e => {  // click-outside closes the overlay
    if (el("wsTree").hidden) return;
    if (e.target.closest("#wsTree") || e.target.closest("#wsTreeBtn")
        || e.target.closest("#confirmDlg")) return;
    treeClose();
  });
  el("wsOpen").addEventListener("click", () => { const p = el("wsPath").value.trim(); if (p) openFile(p); });
  el("wsPath").addEventListener("keydown", e => {
    if (e.key === "Enter"){ const p = el("wsPath").value.trim(); if (p) openFile(p); }
  });
  el("wsSave").addEventListener("click", () => save(false));
  el("wsFmt").addEventListener("click", () => formatDoc());
  el("wsSbs").addEventListener("click", () => {
    sbs = !sbs;
    if (cur) render(cur, null);
  });
  // chip ⧉ delegation (button lives inside <summary>; keep the details closed-state)
  transcript.addEventListener("click", e => {
    const b = e.target.closest(".wsopen");
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const det = b.closest("details");
    openDiff(det && det.dataset.tid, det);
  });
  // v3.1 (owner): the panel BOOTS in vibe mode — the workspace opens with the
  // GUI (chat-tab toggle and X still close it for a full-width chat).
  setMode("vibe");
  return {setMode, togglePane, openDiff, openFile, save};
})();

// -- SPEC-147 v2 split mode selector wiring (authored by gpt-5.6-sol xhigh) --
// v3.1 (owner): the selector is a true TOGGLE — clicking EITHER half (active or
// not) alternates vibe<->copilot, like a physical switch; visuals unchanged.
el("wsModeSel").addEventListener("click", function (event) {
  if (event.target.closest("[data-mode]")) {
    WS.setMode(document.body.dataset.wsMode === "vibe" ? "copilot" : "vibe");
  }
});
el("wsModeSel").addEventListener("keydown", function (event) {
  if ((event.key === "Enter" || event.key === " ") && event.target.dataset.mode) {
    event.preventDefault();
    event.target.click();
  }
});
window.syncModeSel = function syncModeSel(mode) {
  el("wsModeSel").querySelectorAll("[data-mode]").forEach(function (button) {
    const active = button.dataset.mode === mode;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", String(active));
  });
};
// boot sync: WS booted before this wiring existed — reflect the current (or
// default) mode so the selector never renders with both halves inactive.
syncModeSel(document.body.dataset.wsMode === "copilot" ? "copilot" : "vibe");
"""

