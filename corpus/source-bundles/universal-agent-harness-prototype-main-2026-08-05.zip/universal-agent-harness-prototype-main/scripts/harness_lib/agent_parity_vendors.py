"""SPEC-113 vendor collectors + codex agent-profile rendering (extracted from
agent_parity.py for the QA.3 self-lib-file-budget).

Pure, read-only helpers that read each vendor's real on-disk surface
(.claude / .codex) and derive the codex agent-profile toml / exec params from
the canonical .claude/agents/*.md frontmatter. Every collector
try/except-degrades to {}/[] so a missing or corrupt vendor file never sinks the
audit that imports these. No harness-bound state: each function takes root/home
Paths explicitly, so this stays a pure module (no bind(env)). agent_parity.py
re-exports these names, so external callers keep using
agent_parity.collect_claude(...) etc. unchanged.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

try:
    import tomllib  # py>=3.11
except ImportError:  # pragma: no cover - codex profiles/mcp just degrade to {}
    tomllib = None

try:
    from .common import read_json, read_text
except ImportError:  # run directly / flat sys.path
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from harness_lib.common import read_json, read_text


CLAUDE_SETTINGS_REL = ".claude/settings.json"
CODEX_HOOKS_REL = ".codex/hooks.json"
CODEX_CONFIG_REL = ".codex/config.toml"
CLAUDE_AGENTS_REL = ".claude/agents"
# SPEC-113 aposta E: Claude effort labels pass through to codex
# `model_reasoning_effort` unchanged except the single non-codex label.
_EFFORT_MAP = {"max": "xhigh"}
# A trust key is "<abs hooks.json>:<event>:<i>:<j>"; the path holds the drive
# colon, so we rsplit off exactly the trailing event:i:j. Only drive-letter /
# POSIX-absolute paths are real filesystem hooks.json locations — plugin keys
# like "ponytail@ponytail:hooks/..." are not files and must be ignored.
_ABS_HOOK_PATH_RE = re.compile(r"^(?:[A-Za-z]:[\\/]|/)")


def _command_for(hook: dict[str, Any], vendor: str = "codex") -> str:
    """Reconstruct the full hook command string for one vendor.

    The invocation form is VENDOR wiring, not per-hook data (the manifest's old
    per-hook `runner` strings were 18 copies of the same fact and are ignored):
    - claude: the bash wrapper, cwd-robust $CLAUDE_PROJECT_DIR-absolute — hook
      commands run in the session shell's drifting cwd (2026-07-22 guard-layer
      skip; hcs-3/hcs-4 pin this form).
    - codex: bash-free — NO bash can start inside codex's Windows
      restricted-token sandbox (System32 bash is the WSL launcher, dies with
      E_ACCESSDENIED; Git Bash dies in CreateFileMapping; measured 2026-07-27/28,
      row codex-stop-hook-fails-silently), so every hook routes through the
      py-run.sh twin tools/agent-sync/py_run.py (HARNESS_PYTHON-first).
    """
    script = str(hook.get("script") or "").strip()
    args = [str(a) for a in (hook.get("args") or [])]
    if vendor == "claude":
        parts = ['bash "$CLAUDE_PROJECT_DIR/tools/agent-sync/py-run.sh"',
                 f'"$CLAUDE_PROJECT_DIR/{script}"', *args]
    else:
        parts = ["python tools/agent-sync/py_run.py", script, *args]
    return " ".join(p for p in parts if p)


def _script_of(command: Any) -> str:
    """Last .py path token in a hook command — the identity used for matching.
    Tokens are unquoted and a $CLAUDE_PROJECT_DIR/ prefix canonicalizes to the
    repo-relative form: hook commands went cwd-robust-absolute on 2026-07-22
    (owner-reported guard-layer skip), and the parity identity must not change
    with the invocation form."""
    toks = [t.strip('"\'') for t in str(command or "").replace("\\", "/").split()]
    py = [t for t in toks if t.endswith(".py")]
    if not py:
        return ""
    script = py[-1]
    for pref in ("$CLAUDE_PROJECT_DIR/", "${CLAUDE_PROJECT_DIR}/"):
        if script.startswith(pref):
            return script[len(pref):]
    return script


# --------------------------------------------------------------------------- #
# collectors (all never-crash)
# --------------------------------------------------------------------------- #
def _normalize_settings_hooks(data: Any) -> list[dict[str, Any]]:
    """Flatten a Claude/Codex hooks file into {event, matcher, script} rows."""
    out: list[dict[str, Any]] = []
    hooks = (data or {}).get("hooks") if isinstance(data, dict) else None
    if not isinstance(hooks, dict):
        return out
    for event, entries in hooks.items():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            matcher = entry.get("matcher")
            for hk in entry.get("hooks") or []:
                if not isinstance(hk, dict):
                    continue
                script = _script_of(hk.get("command"))
                if script:
                    out.append({"event": event, "matcher": matcher, "script": script})
    return out


def _claude_user_skills(home: Path) -> list[dict[str, str]]:
    """User-scope Claude skills (name + SKILL.md path). Layout varies, so we
    glob recursively under plugins/ and skills/ and dedupe by skill name,
    preferring the canonical copy (fewest hidden dirs, then shortest path) over
    alternate packagings like `.openclaw/`."""
    base = home / ".claude"
    cands: dict[str, list[Path]] = {}
    for pattern in ("plugins/**/skills/*/SKILL.md", "skills/*/SKILL.md"):
        try:
            for p in base.glob(pattern):
                if p.is_file() and p.parent.name:
                    cands.setdefault(p.parent.name, []).append(p)
        except OSError:
            continue

    def rank(p: Path) -> tuple[int, int, str]:
        parts = p.relative_to(base).parts
        return (sum(1 for s in parts if s.startswith(".")), len(parts), str(p))

    return [{"name": n, "path": str(min(ps, key=rank))} for n, ps in sorted(cands.items())]


def collect_claude(root: Path, home: Path | None = None) -> dict[str, Any]:
    home = home or Path.home()
    out: dict[str, Any] = {"hooks": [], "agents": [], "userSkills": [], "userPlugins": []}
    try:
        out["hooks"] = _normalize_settings_hooks(read_json(root / CLAUDE_SETTINGS_REL, {}))
    except Exception:  # noqa: BLE001
        pass
    try:
        out["agents"] = sorted(p.stem for p in (root / ".claude" / "agents").glob("*.md"))
    except OSError:
        pass
    try:
        out["userSkills"] = _claude_user_skills(home)
    except Exception:  # noqa: BLE001
        pass
    try:
        plug = home / ".claude" / "plugins"
        out["userPlugins"] = sorted(d.name for d in plug.iterdir() if d.is_dir()) if plug.is_dir() else []
    except OSError:
        pass
    return out


def _toml(root_path: Path) -> dict[str, Any]:
    if tomllib is None or not root_path.is_file():
        return {}
    try:
        with root_path.open("rb") as fh:
            return tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError, ValueError):  # type: ignore[union-attr]
        return {}


def collect_codex(root: Path, home: Path | None = None) -> dict[str, Any]:
    home = home or Path.home()
    out: dict[str, Any] = {"hooks": [], "profiles": [], "mcpServers": {}, "prompts": [], "userSkills": []}
    try:
        out["hooks"] = _normalize_settings_hooks(read_json(root / CODEX_HOOKS_REL, {}))
    except Exception:  # noqa: BLE001
        pass
    cfg = _toml(root / CODEX_CONFIG_REL)
    if isinstance(cfg.get("profiles"), dict):
        out["profiles"] = sorted(cfg["profiles"].keys())
    if isinstance(cfg.get("mcp_servers"), dict):
        out["mcpServers"] = cfg["mcp_servers"]
    try:
        out["prompts"] = sorted(p.name for p in (root / "codex" / "prompts").glob("*.md"))
    except OSError:
        pass
    try:
        codex_home = home / ".codex"
        if codex_home.is_dir():
            out["userSkills"] = sorted({p.parent.name for p in codex_home.rglob("SKILL.md")})
    except Exception:  # noqa: BLE001
        pass
    return out


def _trust_key_path(key: str) -> str:
    """Extract the hooks.json path from a "<path>:<event>:<i>:<j>" trust key."""
    return str(key).rsplit(":", 3)[0]


def collect_codex_trust(root: Path, home: Path) -> list[dict[str, Any]]:
    """Machine-local, ADVISORY-ONLY codex hook-trust staleness findings.

    Codex 0.144 trusts a project's hooks per ABSOLUTE hooks.json PATH + per HASH
    in `~/.codex/config.toml` [hooks.state]. A repo folder move silently breaks
    that trust: the new path has no entry (hooks never fire) while the old path's
    entries rot as orphans. We detect ABSENCE and ORPHANHOOD only — NOT
    trusted_hash correctness: the hash recipe is undocumented, so a present entry
    is assumed fine and absence/orphanhood is the reliable signal.

    Every failure degrades silently to no findings (codex not installed, config
    missing/unparseable) so this never sinks the audit. Findings carry
    scope="machine-local": they are advisory and must never fail a CI/fresh-clone
    audit exit code.
    """
    cfg = _toml(home / ".codex" / "config.toml")
    state = cfg.get("hooks", {}).get("state") if isinstance(cfg.get("hooks"), dict) else None
    if not isinstance(state, dict):
        return []
    norm = lambda s: str(s).replace("\\", "/").lower()  # noqa: E731
    findings: list[dict[str, Any]] = []

    hooks_json = (root / CODEX_HOOKS_REL).resolve()
    if hooks_json.is_file() and not any(norm(_trust_key_path(k)) == norm(hooks_json) for k in state):
        findings.append({
            "severity": "medium", "vendor": "codex", "capability": "codex-trust-missing",
            "kind": "trust", "status": "advisory", "scope": "machine-local",
            "detail": f"no codex hook-trust entry for this repo's {CODEX_HOOKS_REL} ({hooks_json}); "
                      "codex hooks were likely never trusted at this location (e.g. after a repo folder move)",
            "fix": "open one interactive codex session in this repo and accept the hooks trust prompt",
        })

    orphans = sorted({p for k in state
                      if _ABS_HOOK_PATH_RE.match(p := _trust_key_path(k)) and not Path(p).is_file()})
    if orphans:
        findings.append({
            "severity": "medium", "vendor": "codex", "capability": "codex-trust-orphan",
            "kind": "trust", "status": "advisory", "scope": "machine-local",
            "detail": "codex hook-trust entries point at hooks.json paths that no longer exist "
                      "(stale ghosts from old repo locations): " + "; ".join(orphans),
            "fix": "harmless; codex re-prompts at the live path — optionally remove the stale "
                   "[hooks.state.'<path>...'] blocks from ~/.codex/config.toml",
        })
    return findings


def collect_instruction_files(root: Path) -> dict[str, list[str]]:
    """Per market-registry family (knownAgentInstructionFiles): which listed
    files actually exist in this repo."""
    try:
        from harness_lib import protected_files
        sources = protected_files.known_agent_instruction_sources(root)
    except Exception:  # noqa: BLE001
        return {}
    out: dict[str, list[str]] = {}
    for src in sources if isinstance(sources, list) else []:
        if not isinstance(src, dict):
            continue
        present: list[str] = []
        for f in src.get("files", []) or []:
            f = str(f)
            try:
                if any(ch in f for ch in "*?["):
                    if any(root.glob(f)):
                        present.append(f)
                elif (root / f).is_file():
                    present.append(f)
            except OSError:
                continue
        out[str(src.get("tool", ""))] = present
    return out


# --------------------------------------------------------------------------- #
# agent profiles (SPEC-113 aposta E): .claude/agents/*.md -> .codex/agents/*.toml
#
# Canon = the Claude frontmatter files; codex surfaces are RENDERED (same
# render-from-canonical invariant as the hook wiring). EXP-19 measured that
# .toml profiles do NOT load under `codex exec`, so on that surface parity rides
# in call params (`codex_exec_call_params`); the tomls serve interactive/
# app-server codex. Agent names are lowercase/digits/underscores only — a hyphen
# is rejected by codex (the invisible blocker of EXP-19 v1-v3).
# --------------------------------------------------------------------------- #
def _parse_agent_md(text: str) -> dict[str, Any] | None:
    """Parse a `.claude/agents/*.md`: simple `key: value` frontmatter + body.
    stdlib-only (no YAML dep) — the frontmatter is a flat scalar block. Returns
    None when there is no `---` frontmatter or no `name` (caller degrades)."""
    m = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n?(.*)$", text or "", re.DOTALL)
    if not m:
        return None
    fm: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            fm[key.strip()] = val.strip()
    if not fm.get("name"):
        return None
    tools = [t.strip() for t in fm.get("tools", "").split(",") if t.strip()]
    return {"name": fm["name"], "description": fm.get("description", ""),
            "model": fm.get("model", ""), "effort": fm.get("effort", ""),
            "tools": tools, "body": m.group(2)}


def collect_claude_agents(root: Path) -> list[dict[str, Any]]:
    """Parse every `.claude/agents/*.md` (canonical agent profiles). Never-crash:
    a missing dir yields []; an unparseable file yields a `{'degraded': ...}` row
    (skipped, not fatal) — same degrade-not-die stance as the other collectors."""
    out: list[dict[str, Any]] = []
    try:
        files = sorted((root / CLAUDE_AGENTS_REL).glob("*.md"))
    except OSError:
        return out
    for f in files:
        try:
            profile = _parse_agent_md(read_text(f, ""))
        except Exception:  # noqa: BLE001 — a corrupt profile must not sink the audit
            profile = None
        if profile:
            profile["source"] = f.name
            out.append(profile)
        else:
            out.append({"name": f.stem, "source": f.name, "degraded": "no parseable frontmatter"})
    return out


def _normalize_body(body: str) -> str:
    """Markdown body verbatim, whitespace-normalized at LINE ENDS only (no
    reflow): rstrip each line, drop leading/trailing blank lines."""
    return "\n".join(ln.rstrip() for ln in str(body).splitlines()).strip("\n")


def codex_agent_profile(profile: dict[str, Any]) -> dict[str, Any]:
    """The ONE shared canonical->codex derivation used by both legs (toml render
    and exec call params) so they are parity by construction. Emits, in order:
    name (codex naming law), description, developer_instructions, optional
    model_reasoning_effort, sandbox_mode. NO `model` key (see _AGENT_UNPORTABLE)."""
    name = re.sub(r"[^a-z0-9_]", "_", str(profile.get("name", "")).lower())
    tools = profile.get("tools") or []
    writes = any(t in ("Edit", "Write") for t in tools)  # S3 sandbox derivation
    out: dict[str, Any] = {
        "name": name,
        "description": str(profile.get("description", "")),
        "developer_instructions": _normalize_body(profile.get("body", "")),
    }
    effort = str(profile.get("effort", "")).strip()
    if effort:
        out["model_reasoning_effort"] = _EFFORT_MAP.get(effort, effort)
    out["sandbox_mode"] = "workspace-write" if writes else "read-only"
    return out


def _toml_basic(value: Any) -> str:
    """A TOML basic string. json.dumps escaping IS valid TOML basic-string
    escaping (\\\", \\\\, \\n, \\uXXXX) — stdlib has no toml writer to lean on."""
    return json.dumps(str(value), ensure_ascii=False)


def _toml_dev_instructions(value: str) -> str:
    """Single-line -> basic string; multiline -> a `\"\"\"` multiline basic string
    with backslashes and quotes escaped (raw newlines preserved). TOML trims the
    one newline right after the opening delimiter, so the leading `\\n` here is
    not part of the value — round-trips exactly (asserted in the self-check)."""
    text = str(value)
    if "\n" not in text:
        return _toml_basic(text)
    escaped = text.replace("\\", "\\\\").replace('"', '\\"')
    return '"""\n' + escaped + '"""'


def render_codex_agent_toml(cp: dict[str, Any]) -> str:
    """Deterministic, byte-stable TOML text for a codex agent profile dict (the
    output of `codex_agent_profile`). Field order mirrors the .codex/agents
    convention: name, description, developer_instructions, [model_reasoning_effort],
    sandbox_mode."""
    lines = [
        f"name = {_toml_basic(cp['name'])}",
        f"description = {_toml_basic(cp.get('description', ''))}",
        f"developer_instructions = {_toml_dev_instructions(cp.get('developer_instructions', ''))}",
    ]
    if "model_reasoning_effort" in cp:
        lines.append(f"model_reasoning_effort = {_toml_basic(cp['model_reasoning_effort'])}")
    lines.append(f"sandbox_mode = {_toml_basic(cp.get('sandbox_mode', 'read-only'))}")
    return "\n".join(lines) + "\n"


def codex_exec_call_params(root: Path, agent_name: str) -> dict[str, Any] | None:
    """SPEC-113 exec-surface bridge: the call-params translation a `codex exec`
    fork-join spawn would pass (tomls don't load under exec, EXP-19). Same
    `codex_agent_profile` derivation as the toml, minus `description`. Matches on
    the codex-legal (derived) name. Returns None if no such profile exists."""
    for profile in collect_claude_agents(root):
        if profile.get("degraded"):
            continue
        cp = codex_agent_profile(profile)
        if cp["name"] == agent_name:
            params = {"name": cp["name"],
                      "developer_instructions": cp["developer_instructions"],
                      "sandbox_mode": cp["sandbox_mode"]}
            if "model_reasoning_effort" in cp:
                params["model_reasoning_effort"] = cp["model_reasoning_effort"]
            return params
    return None
