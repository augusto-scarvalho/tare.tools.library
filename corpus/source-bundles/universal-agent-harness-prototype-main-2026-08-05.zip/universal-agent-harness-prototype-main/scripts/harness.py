#!/usr/bin/env python3
"""Universal Agent Harness router and continuity helper.

This script is intentionally language-agnostic. It classifies tasks, builds
handoffs, prints executor spawn commands, validates HARNESS_RESULT blocks, and
records simple events. It does not depend on Codex or Claude as sources of
truth; those are adapters only.
"""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import signal
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from harness_lib import token_economics, token_calibration, tracing, state_store, observability_exporters, graphify_adapter, handoff as handoff_lib, workflow_ids, workflow_state as workflow_state_lib, graphify_code_ast, protected_files, controlled_writes, async_runtime, async_state, workflow_token_audit as workflow_token_audit_lib, workflow_reduce as workflow_reduce_lib, context_digest, seed_context
from harness_lib import chat_operator, cost_metrics, discovery, result_contracts, escalations_lib, status_html, self_review as self_review_lib, targets as targets_lib, records, agent_parity, model_routing, cli_registry, cli_workflow_tree
from harness_lib import workflow_spawn
from harness_lib import packet_economy
from harness_lib import workflow_writes as workflow_writes_lib, workflow_lifecycle as workflow_lifecycle_lib, workflow_plan as workflow_plan_lib, workflow_run as workflow_run_lib, stream_json, secret_scan, workflow_schema, topology_router, processes, evidence_bundle, workflow_observability as workflow_observability_lib, worker_prompt as worker_prompt_lib
from harness_lib import context_diet, route_dispatcher, route_tuple, sandbox_spawn, epoch, spawn_guard, scenario_isolation
from harness_lib import workflow_config as workflow_config_lib
from harness_lib.common import HarnessError, bounded_timeout, emit, enforce_declared_python, load_ambient_keys, normalize, now, parse_iso_datetime, read_json, read_text, replay_class, rmtree_robust, truncate_text, write_json, write_text
from harness_lib.processes import run_process_tree_bounded, filter_spawn_env

# Windows consoles default to cp1252, which cannot encode non-ASCII output
# (same guard the gate uses; surfaced by SPEC-110 target findings).
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8")
        except Exception:
            pass

try:
    import jsonschema  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    jsonschema = None

ROOT = Path(__file__).resolve().parents[1]
HARNESS = ROOT / ".harness"
PROJECT_FILE = HARNESS / "project.json"
PROFILES_FILE = HARNESS / "routing" / "task-profiles.json"
EXECUTORS_FILE = HARNESS / "routing" / "executors.json"
RUNTIME_FILE = HARNESS / "runtime" / "executor-state.json"
HANDOFF_MD = HARNESS / "handoff" / "handoff.md"
HANDOFF_JSON = HARNESS / "handoff" / "handoff.json"
NEXT_PROMPT = HARNESS / "handoff" / "next-agent-prompt.md"
EVENTS = HARNESS / "runs" / "events.jsonl"
GRAPHIFY_REPORT = ROOT / "graphify-out" / "GRAPH_REPORT.md"
GRAPHIFY_GRAPH = ROOT / "graphify-out" / "graph.json"
GRAPHIFY_HTML = ROOT / "graphify-out" / "graph.html"
WORKFLOWS_DIR = Path(os.environ["HARNESS_WORKFLOWS_ROOT"]) if os.environ.get("HARNESS_WORKFLOWS_ROOT") else HARNESS / "workflows"
ACTIVE_WORKFLOWS_DIR = WORKFLOWS_DIR / "active"
STATE_STORE_DIR = HARNESS / "state-store"

def load_project() -> dict[str, Any]:
    return read_json(PROJECT_FILE, {}) or {}

def load_profiles() -> dict[str, Any]:
    """Task profiles, metamodel-first (SPEC-173 rule 7).

    The unified role metamodel projects the legacy task-profiles view, so
    build_prompt/token_economy_line/classify read the same taxonomy the chain
    assemblers do; the direct PROFILES_FILE read stays as the fallback for roots
    without a metamodel and retires in Phase 4. The root is derived FROM
    PROFILES_FILE rather than from ROOT so a fixture that repoints the module
    constant still steers both paths.
    """
    from harness_lib import role_metamodel

    parents = PROFILES_FILE.parents  # <root>/.harness/routing/task-profiles.json
    doc = role_metamodel.load(parents[2]) if len(parents) > 2 else None
    if doc is not None:
        return role_metamodel.profiles_view(doc)
    data = read_json(PROFILES_FILE, None)
    if not data or "profiles" not in data:
        raise HarnessError(f"Missing profiles in {PROFILES_FILE}")
    return data

def load_executors() -> dict[str, Any]:
    data = read_json(EXECUTORS_FILE, None)
    if not data or "executors" not in data:
        raise HarnessError(f"Missing executors in {EXECUTORS_FILE}")
    return data

def git(args: list[str]) -> str:
    try:
        p = subprocess.run(
            ["git", *args],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=bounded_timeout("HARNESS_GIT_TIMEOUT", 30),
        )
        return p.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""

def changed_files(scope: str = "working-tree", base: str | None = None, diff_range: str | None = None) -> list[str]:
    """Return changed files for a configurable diff scope."""
    out = ""
    if diff_range:
        out = git(["diff", "--name-only", diff_range])
        return [line.strip() for line in out.splitlines() if line.strip()]
    if base:
        out = git(["diff", "--name-only", f"{base}...HEAD"])
        if not out:
            out = git(["diff", "--name-only", base])
        return [line.strip() for line in out.splitlines() if line.strip()]
    if scope == "staged":
        out = git(["diff", "--name-only", "--cached"])
        return [line.strip() for line in out.splitlines() if line.strip()]
    if scope == "unstaged":
        out = git(["diff", "--name-only"])
        return [line.strip() for line in out.splitlines() if line.strip()]
    # working-tree includes staged, unstaged, and untracked paths from status.
    out = git(["status", "--porcelain"])
    files: list[str] = []
    for line in out.splitlines():
        if len(line) >= 4:
            path = line[3:].strip()
            if " -> " in path:
                path = path.split(" -> ", 1)[1].strip()
            files.append(path)
    return files

def current_commit() -> str | None:
    out = git(["rev-parse", "--short", "HEAD"])
    return out or None

# --- Trajectory tamper-evidence: hash-chain over CRITICAL event rows ----------
# article Section 8.1 ir4. Each critical row gains an additive `prevHash` (chain
# link to the previous critical row) + `hash` (sha256 of this canonical row).
# Reorder / edit / removal of a critical row breaks the chain -> tamper-EVIDENT.
# Ceiling (declared in specs/00-universal/observability-and-operability.md): NO
# signature, so an attacker who can rewrite the whole file can recompute the
# chain; that lifts only behind a key-infra trigger. NON-critical rows stay
# byte-identical (fully additive, zero regression). `append_event` is the ONLY
# hasher: direct events.jsonl writers (security_routing, decision_inbox, epoch,
# subagent_gate_wait) emit UN-hashed rows the verifier transparently skips --
# they are outside the chain by design. CLOSED, NAMED set = the
# security/approval/authority decisions routed through this chokepoint.
_CRITICAL_EVENTS = frozenset({
    "escalation_resolved",
    "route_escalation",
    "route_withheld_escalation",
    "security_routing_escalation",
    "epoch_fence_overridden",
    "workflow_budget_overridden",
})
_CHAIN_GENESIS = "0" * 64  # prevHash of the first critical row


def _chain_hash(row: dict[str, Any]) -> str:
    """sha256 over the canonical row EXCLUDING its own `hash` (prevHash included).
    Shared by the appender and `verify_event_chain` so they can never drift."""
    canonical = json.dumps({k: v for k, v in row.items() if k != "hash"},
                           sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# --- Causal DAG: parent ids on events (article Section 8.1) --------------------
# The trajectory order is a causal DAG, not wall-clock: an event may name the
# eventId of the event that CAUSED it (`parentEventId`), additive. ONE identity
# per row: a critical row already carries the T-HASHCHAIN `hash`, so that IS its
# eventId; a non-critical row (no hash) gets a short deterministic sha over its
# canonical form. `append_event` returns the row's eventId so a caller can pass
# it as the `parent` of a later event; `orphan_events` recomputes ids the SAME
# way, so the two can never drift.
def _event_id(row: dict[str, Any]) -> str:
    h = row.get("hash")
    if isinstance(h, str):
        return h  # reuse the T-HASHCHAIN hash -- one identity, never two
    canonical = json.dumps({k: v for k, v in row.items() if k != "hash"},
                           sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    # ponytail: 16 hex (64 bits) is ample for the transient log's row count;
    # widen if a corpus ever grows enough for a birthday collision to matter.
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def orphan_events(events: list[dict[str, Any]]) -> list[str]:
    """DAG integrity (article Section 8.1, advisory): the `parentEventId` values
    that point at no event present in `events`. Deterministic, stdlib. It only
    DETECTS dangling causal parents (a doctor follow-up); it does NOT quarantine
    -- active quarantine changes behavior and stays owner-gated. Missing ids are
    returned in first-seen order."""
    known = {_event_id(r) for r in events if isinstance(r, dict)}
    missing: list[str] = []
    seen: set[str] = set()
    for r in events:
        if not isinstance(r, dict):
            continue
        pid = r.get("parentEventId")
        if isinstance(pid, str) and pid not in known and pid not in seen:
            missing.append(pid)
            seen.add(pid)
    return missing


def append_event(event: str, payload: dict[str, Any] | None = None,
                 subject: str | None = None, parent: str | None = None) -> str:
    payload = dict(payload or {})
    payload.setdefault("timestamp", now())
    payload["event"] = event
    payload["replayClass"] = replay_class(event)  # article Section 8.2, additive
    # Causal DAG parent (article Section 8.1): additive. When a caller passes the
    # eventId of the CAUSING event, record it -- events without a parent stay
    # byte-identical. Set BEFORE the hash below so a critical row's parentEventId
    # is part of its T-HASHCHAIN evidence (Q3: causal link is signed content).
    if parent:
        payload["parentEventId"] = str(parent)
    # subject-tagged-events (isolation Phase 4): every event row is subject-
    # attributable as a FIELD, not a name-prefix convention. Precedence:
    # explicit param > a subject/target the payload already carries > self.
    if subject:
        payload["subject"] = str(subject)
    else:
        payload.setdefault("subject", str(payload.get("target") or "self"))
    # Tamper-evidence hash-chain (article Section 8.1 ir4): critical rows only,
    # fully additive -- non-critical rows below stay byte-identical. prevHash is
    # read from the current tail, so parallel un-hashed writers interleaving rows
    # never affect the chain.
    if event in _CRITICAL_EVENTS:
        prev = _CHAIN_GENESIS
        try:
            for line in EVENTS.read_text(encoding="utf-8").splitlines():
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(row, dict) and isinstance(row.get("hash"), str):
                    prev = row["hash"]  # ponytail: transient gate-wiped log stays small
        except FileNotFoundError:
            pass
        payload["prevHash"] = prev
        payload["hash"] = _chain_hash(payload)
    EVENTS.parent.mkdir(parents=True, exist_ok=True)
    # Self-heal a truncated tail: a prior restore_logs/truncate (scenario isolation)
    # can cut mid-line, leaving no trailing newline -- the next append would then
    # FUSE two records into one malformed line (2026-07-21 wind-down probe: m5's
    # events tail read count=1/skipped=2 off exactly this). Prepend a newline when
    # the existing tail lacks one so an append-only log stays line-parseable.
    heal = ""
    try:
        if EVENTS.stat().st_size > 0:
            with EVENTS.open("rb") as chk:
                chk.seek(-1, os.SEEK_END)
                if chk.read(1) != b"\n":
                    heal = "\n"
    except (OSError, ValueError):
        pass
    with EVENTS.open("a", encoding="utf-8") as f:
        f.write(heal + json.dumps(payload, ensure_ascii=False) + "\n")
    # Trace-first product observability: every event also becomes an
    # OpenTelemetry-shaped span in a workflow-local trace.jsonl when a
    # workflowId is available, or in .harness/runs/harness-trace.jsonl for
    # global harness events. Exporters can transform these JSONL spans later.
    try:
        tracing.append_event_span(ROOT, event, payload)
    except Exception:
        # Event logging must never fail the workflow runtime.
        pass
    return _event_id(payload)  # so a caller can name this row as a later event's parent


def verify_event_chain(events: list[dict[str, Any]], genesis: str = _CHAIN_GENESIS,
                       seal: dict[str, Any] | None = None) -> dict[str, Any]:
    """Reconstruct the critical-event hash-chain; point at the FIRST break.

    Deterministic, stdlib-only. Walks only rows carrying a string `hash` (the
    critical subsequence written by `append_event`); non-critical and
    parallel-writer rows are transparently skipped. Returns
    ``{"ok", "brokenAt", "reason", "chainLength"}`` where `brokenAt` is the index
    into `events` of the first row failing linkage or content.

    `genesis` overrides the prevHash the first hashed row must link to (default
    `_CHAIN_GENESIS`, back-compat).

    `seal` (SPEC-164 v2 — the C+ replacement for the abandoned `allow_gaps`,
    ratified 2026-07-21 round-3 consolidation): compaction removes SCATTERED
    critical rows while KEEPING others, so the LIVE chain has real gaps — a strict
    prevHash walk false-reads a legitimate compaction as tamper (the kept row
    preceding a folded one links to a now-removed hash). The old `allow_gaps=True`
    over-corrected: it tolerated EVERY mismatch, abandoning the chain property.
    C+ tolerates a gap ONLY when the seal's `removed` map ({removed_hash:
    successor_hash}, written by `compact_supervision_events`) BINDS the removed
    hash the current row links across to THIS row as its recorded successor. That
    keeps reorder/removal detection alive (an unexplained gap still breaks) and
    kills forge-by-citation (a forged row citing a removed hash it isn't bound to
    breaks). `seal=None` → strict walk (no compaction gaps expected). Ceiling
    (declared): the seal lives in the durable ledger, self-chained (see
    `compact_supervision_events`) — an attacker who rewrites BOTH the live log and
    the seal-carrying ledger can still forge; that is the no-key T-HASHCHAIN
    ceiling, honestly bounded, not hidden."""
    removed = seal["removed"] if isinstance(seal, dict) and isinstance(seal.get("removed"), dict) else {}
    prev = genesis
    length = 0
    seen: set[str] = set()
    for idx, row in enumerate(events):
        if not isinstance(row, dict) or not isinstance(row.get("hash"), str):
            continue
        h = row["hash"]
        if _chain_hash(row) != h:
            return {"ok": False, "brokenAt": idx,
                    "reason": "hash mismatch (edited content)", "chainLength": length}
        if h in seen:
            # a repeated row hash is the SAME row twice — never legitimate (every
            # append carries a distinct timestamp+prevHash). Closes the exact-duplicate
            # replay a bare content-equality binding would otherwise wave through.
            return {"ok": False, "brokenAt": idx,
                    "reason": "duplicate row hash (replay)", "chainLength": length}
        seen.add(h)
        ph = row.get("prevHash")
        if ph != prev:
            # C+ gap: legitimate iff the seal binds the removed hash we link across
            # to THIS row as its successor. Anything else is a real break.
            if not (isinstance(ph, str) and removed.get(ph) == h):
                return {"ok": False, "brokenAt": idx,
                        "reason": "prevHash mismatch (unexplained gap: reorder/removal/forgery)",
                        "chainLength": length}
            # explained compaction gap: re-anchor on this content-verified row
        prev = h
        length += 1
    return {"ok": True, "brokenAt": None, "reason": "chain intact", "chainLength": length}


def score_profile(profile: dict[str, Any], task: str, files: list[str], risk_terms: dict[str, list[str]]) -> int:
    text = normalize(task)
    score = 0
    for trig in profile.get("triggers", []):
        trig_n = normalize(str(trig))
        if trig_n and re.search(rf"\b{re.escape(trig_n)}\b", text):
            score += 3
    for glob in profile.get("fileGlobs", []):
        pattern = str(glob)
        for file in files:
            if Path(file).match(pattern) or re.fullmatch(pattern.replace("**", ".*").replace("*", "[^/]*"), file):
                score += 2
    return score

def project_risk_score(profile_name: str, task: str, risk_terms: dict[str, list[str]]) -> int:
    text = normalize(task)
    score = 0
    for term in risk_terms.get(profile_name, []) or []:
        term_n = normalize(str(term))
        if term_n and re.search(rf"\b{re.escape(term_n)}\b", text):
            score += 4
    return score

def classify(task: str, files: list[str] | None = None) -> tuple[str, dict[str, Any], dict[str, int]]:
    data = load_profiles()
    project = load_project()
    files = files if files is not None else changed_files()
    risk_terms = project.get("riskTerms", {}) if isinstance(project.get("riskTerms", {}), dict) else {}
    scores: dict[str, int] = {}
    for name, profile in data["profiles"].items():
        scores[name] = score_profile(profile, task, files, risk_terms) + project_risk_score(name, task, risk_terms)
    # Tie-breaker favors safety first, then cheaper/specific work before broad implementation.
    # This avoids classifying low-risk README/typo/doc tasks as implementation when
    # words like "fix" appear alongside documentation signals.
    priority = ["security", "debug", "review", "cheap", "scan", "docs", "ui-delivery", "plan", "implementation"]
    priority_rank = {name: len(priority) - i for i, name in enumerate(priority)}
    default = data.get("defaultProfile", "plan")
    best = max(scores, key=lambda n: (scores[n], priority_rank.get(n, 0)))
    workflow_terms = ("map-reduce", "map reduce", "fork-join", "fork join", "workflow packet", "context window", "worker result", "reduce result")
    if any(term in normalize(task) for term in workflow_terms) and "plan" in data["profiles"]:
        best = "plan"
    elif scores[best] <= 0:
        best = default
    return best, data["profiles"][best], scores

WORKFLOW_LARGE_TASK_TERMS = [
    "whole repo", "entire repo", "entire repository", "all files", "all specs", "all docs",
    "full audit", "full review", "repository-wide", "repo-wide", "large volume", "many documents",
    "context window", "context limit", "too much context", "cross-file", "cross cutting",
    "across the repository", "across docs", "across specs", "coverage gaps", "impact map",
    "migration impact", "pre-release", "release review", "security triage",
]

def workflow_suggestion(task: str, *, files: list[str] | None = None) -> dict[str, Any]:
    """Return a non-binding workflow recommendation for large/cross-cutting tasks."""
    files = files if files is not None else changed_files()
    text = normalize(task)
    reasons: list[str] = []
    if any(term in text for term in WORKFLOW_LARGE_TASK_TERMS):
        reasons.append("large or cross-cutting task wording")
    cfg = workflow_config() if isinstance(workflow_config(), dict) else {}
    threshold = int(cfg.get("workflowCandidateChangedFileThreshold", 12))
    if len(files) >= threshold:
        reasons.append(f"changed-file count is {len(files)}")
    profile = None
    split = "roots"
    wtype = "map-reduce"
    if any(term in text for term in ["pre-release", "release review", "release readiness"]):
        profile = "pre-release-review"; wtype = "fork-join"; split = "roots"
    elif any(term in text for term in ["security triage", "security review", "threat", "secrets", "privacy"]):
        profile = "security-triage"; wtype = "fork-join"; split = "roots"
    elif any(term in text for term in ["diff", "changed files", "current changes", "current diff"]):
        profile = "diff-review"; split = "changed-files"
    elif any(term in text for term in ["spec consistency", "docs consistency", "documentation consistency", "specs and tasks"]):
        profile = "spec-consistency-review"; split = "specs-tasks-docs"
    elif any(term in text for term in ["graph", "graphify", "impact map", "dependency path", "architecture map"]):
        profile = "graph-impact-map"; split = "graphify"
    elif reasons:
        profile = "repository-review"; split = "roots"
    workflow_profiles = (load_workflow_profiles().get("profiles", {}) if WORKFLOWS_DIR.exists() else {})
    valid_profile = isinstance(workflow_profiles, dict) and profile in workflow_profiles
    if profile and valid_profile:
        cfg = workflow_profiles.get(profile, {})
        wtype = str(cfg.get("type", wtype))
        split = str(cfg.get("splitStrategy", split))
    return {
        "workflowCandidate": bool(profile and valid_profile and reasons),
        "recommendedWorkflowType": wtype if profile and valid_profile else None,
        "recommendedWorkflowProfile": profile if profile and valid_profile else None,
        "recommendedSplitStrategy": split if profile and valid_profile else None,
        "reason": "; ".join(reasons) if reasons else "No large-task workflow signal detected.",
        "changedFiles": len(files),
    }

def active_executor(explicit: str | None = None) -> str:
    if explicit:
        return explicit
    runtime = read_json(RUNTIME_FILE, {}) or {}
    executors = load_executors()
    return runtime.get("activeExecutor") or executors.get("defaultExecutor") or "generic"

def graphify_status() -> dict[str, Any]:
    project = load_project()
    cfg = project.get("knowledgeGraph", {}) if isinstance(project.get("knowledgeGraph"), dict) else {}
    enabled = bool(cfg.get("enabled", False))
    report_exists = GRAPHIFY_REPORT.exists()
    graph_exists = GRAPHIFY_GRAPH.exists()
    html_exists = GRAPHIFY_HTML.exists()
    graphify_ast_cfg = cfg.get("graphifyAst", {}) if isinstance(cfg.get("graphifyAst"), dict) else {}
    gemini_cfg = cfg.get("llmAssisted", {}) if isinstance(cfg.get("llmAssisted"), dict) else {}
    discovery_order = cfg.get("discoveryOrder") if isinstance(cfg.get("discoveryOrder"), list) else ["graphify-code-ast", "graphify-artifacts", "gemini-text-image-free-tier-assisted", "focused-raw-search"]
    status = "not_configured"
    if enabled:
        status = "available" if graph_exists or report_exists else "not_available"
    preferred_source = "graphify-code-ast" if bool(graphify_ast_cfg.get("enabled", True)) else "graphify-artifacts"
    return {
        "enabled": enabled,
        "requiredSkill": cfg.get("requiredSkill", "graphify"),
        "policy": cfg.get("policy", "graphify-code-ast-first-source-verified"),
        "discoveryOrder": discovery_order,
        "preferredSource": preferred_source,
        "outputDir": cfg.get("outputDir", "graphify-out"),
        "reportPath": cfg.get("reportPath", "graphify-out/GRAPH_REPORT.md"),
        "graphPath": cfg.get("graphPath", "graphify-out/graph.json"),
        "mustCheckBeforeBroadSearch": bool(cfg.get("mustCheckBeforeBroadSearch", enabled)),
        "commitGeneratedArtifacts": bool(cfg.get("commitGeneratedArtifacts", False)),
        "graphifyAst": {
            "enabled": bool(graphify_ast_cfg.get("enabled", True)),
            "preferred": bool(graphify_ast_cfg.get("preferred", True)),
            "autoBuildWhenMissing": bool(graphify_ast_cfg.get("autoBuildWhenMissing", True)),
            "inputKinds": graphify_ast_cfg.get("inputKinds", ["code"]),
            "languages": graphify_ast_cfg.get("languages", ["python"]),
            "maxFiles": int(graphify_ast_cfg.get("maxFiles", 1000)),
            "parserPolicy": graphify_ast_cfg.get("parserPolicy", "pure-ast-no-llm-for-code"),
            "dependencyPolicy": graphify_ast_cfg.get("dependencyPolicy", "stdlib-only"),
        },
        "llmAssisted": {
            "enabled": bool(gemini_cfg.get("enabled", False)),
            "provider": gemini_cfg.get("provider", "gemini-api"),
            "usagePolicy": gemini_cfg.get("usagePolicy", "free-tier-only"),
            "networkDefault": bool(gemini_cfg.get("networkDefault", False)),
            "models": gemini_cfg.get("models", ["gemini-3.1-flash-lite-preview", "gemini-2.5-flash-lite", "gemini-2.5-flash"]),
            "inputKinds": gemini_cfg.get("inputKinds", ["text", "image"]),
            "forbiddenInputKinds": gemini_cfg.get("forbiddenInputKinds", ["code-graph-primary", "source-code-ast-generation", "source-code-authority"]),
            "sourceVerificationRequired": bool(gemini_cfg.get("sourceVerificationRequired", True)),
        },
        "apiAssistedProviders": cfg.get("apiAssistedProviders", {}),
        "status": status,
        "reportExists": report_exists,
        "graphExists": graph_exists,
        "htmlExists": html_exists,
        # T2 (plan-graph-round2): freshness answered by CONTENT on the surface an operator
        # already uses. ADDITIVE — every pre-existing key above is untouched. Reuses the
        # ONE freshness computation `doctor` uses; never a second comparison. Exit code
        # stays 0 in every state: staleness is a report, not a failure (the graph is a
        # navigation aid, not a correctness oracle).
        "freshness": graphify_code_ast.freshness(ROOT),
        # basename/None only — never the absolute PATH hit, which is a machine-local
        # home path that leaks into pasted state (see local-absolute-paths gate).
        "externalGraphifyTool": (Path(w).name if (w := shutil.which("graphify")) else None),
    }

def normalize_graphify_graph(graph: Any) -> dict[str, Any]:
    """Compatibility wrapper for the modular Graphify adapter."""
    return graphify_adapter.normalize_graphify_graph(graph)


def acceptance_contract_required(profile_name: str) -> bool:
    """SPEC-103 M3.2: pre-implementation contracts, gated by existing task classification.

    Derived from the profile's risk (medium+ requires it); a profile can override
    with an explicit requiresAcceptanceContract flag. Small/low-risk tasks skip it.
    """
    try:
        profile = load_profiles()["profiles"].get(profile_name, {}) or {}
    except HarnessError:
        return False
    risk = str(profile.get("risk", "low"))
    return bool(profile.get("requiresAcceptanceContract", risk in {"medium", "high", "critical"}))

# SPEC-103 M3.5: over-detailed planner specs cause cascading errors downstream
# (Anthropic long-running-apps); planners set direction, executors see the code live.
PLANNER_GUARDRAIL_PROMPT = (
    "Planner guardrail: plan at the level of product context and architecture — components, "
    "boundaries, contracts, acceptance criteria, and ordering. Do not specify implementation "
    "detail (function bodies, exact code, line-level edits) for other agents; over-detailed "
    "plans cascade errors onto executors who see the live code. "
)

ACCEPTANCE_CONTRACT_PROMPT = (
    "Pre-implementation contract: your FIRST deliverable is a short list of proposed acceptance "
    "criteria for this task; do not implement until they are approved by a human or reviewer. "
    'Record the round-trip in HARNESS_RESULT.acceptanceCriteria: {"proposed": ["..."], '
    '"approvedBy": "human|reviewer", "graded": [{"criterion": "...", "verdict": "pass|fail"}]}. '
    "If no approval channel is available, return status blocked with requiresEscalation true "
    "instead of implementing. "
)

def token_economy_line(profile_name: str) -> str:
    """SPEC-140: render the profile's per-role resource allowlist as ONE contract line.

    Absent tokenEconomy block -> "" -> byte-identical prompt (the contextDiscovery/
    TE.5 precedent). Enforcement is contractual (prompt text) for external executors;
    claude workers additionally enforce via agent frontmatter.
    """
    try:
        profile = load_profiles()["profiles"].get(profile_name, {}) or {}
    except HarnessError:
        return ""
    te = profile.get("tokenEconomy")
    if not isinstance(te, dict) or not ("allowedSkills" in te or "allowedMcp" in te):
        return ""
    skills = ", ".join(str(s) for s in (te.get("allowedSkills") or []))
    mcp = ", ".join(str(m) for m in (te.get("allowedMcp") or []))
    return f"Resources for this role: skills=[{skills}]; mcp=[{mcp}] - do not load others. "

def build_prompt(task: str, profile: str) -> str:
    contract = ACCEPTANCE_CONTRACT_PROMPT if acceptance_contract_required(profile) else ""
    guardrail = PLANNER_GUARDRAIL_PROMPT if profile == "plan" else ""
    resources = token_economy_line(profile)
    return (
        "You are executing a bounded task through the Universal Agent Harness. "
        "Read .harness/handoff/handoff.md, AGENTS.md, and .harness/prompts/subagent-contract.md. "
        "Use Graphify before broad repository search when applicable, then verify findings in source files. "
        "Do not restart from scratch. Do not change your own model/reasoning. "
        f"{guardrail}{contract}{resources}"
        f"Task profile: {profile}. Task: {task}"
    )

def render_template(parts: list[str], values: dict[str, Any]) -> list[str]:
    rendered: list[str] = []
    for part in parts:
        out = str(part)
        fragment = values.get(out[1:-1]) if out.startswith("{") and out.endswith("}") else None
        if isinstance(fragment, list):
            rendered.extend(str(item) for item in fragment)
            continue
        for key, value in values.items():
            if not isinstance(value, list):
                out = out.replace("{" + key + "}", value)
        rendered.append(out)
    return rendered

def _resolve_argv0(argv: list[str]) -> list[str]:
    """Resolve argv[0] through PATH/PATHEXT. Windows CLI shims (claude.cmd, npm
    wrappers) are not found by CreateProcess without a shell; both spawn paths
    (blocking and async) execute these argvs directly.

    Stale-launcher-PATH fallback (nt): a long-lived parent (service/IDE/shell
    started before an installer edited PATH) hands children a PATH snapshot that
    predates the edit, so a correctly-installed executor misses on the process
    PATH. When that happens, retry against the registry's effective PATH (what a
    fresh process sees) before giving up — resolving argv[0] to an absolute path
    so the spawn no longer depends on the inherited PATH."""
    if argv:
        resolved = shutil.which(str(argv[0]))
        if not resolved and os.name == "nt":
            extra = processes.registry_path_windows()
            if extra:
                resolved = shutil.which(str(argv[0]), path=os.environ.get("PATH", "") + os.pathsep + extra)
        if resolved:
            argv = [resolved, *argv[1:]]
    return argv

def spawn_command(task: str, executor_name: str | None = None, profile_name: str | None = None,
                  prompt_file: Path | None = None, resume: str | None = None, spawn_override: dict | None = None) -> tuple[list[str], str, str, dict[str, str]]:
    if profile_name:  # SPEC-144 v5: honor a ROUTED profile -> skip classify (which re-derives off the dirty tree)
        profile = load_profiles()["profiles"].get(profile_name)
        if profile is None:
            raise HarnessError(f"Unknown workflow profile {profile_name!r}")
    else:
        profile_name, profile, _ = classify(task)
    model_routing.enforce_spawn(ROOT, profile_name)  # SPEC-170 rule 6: ungoverned role -> typed refusal (rule 7 skips when no registry)
    executor_name = active_executor(executor_name)
    spawn = profile.get("spawn", {}).get(executor_name)
    if not spawn:
        raise HarnessError(f"Profile {profile_name!r} has no spawn mapping for executor {executor_name!r}")
    spawn = model_routing.route_spawn(ROOT, profile_name, executor_name, spawn, override=spawn_override)  # SPEC-115: byte-identical under canonical; override = audit-seat-sizing pin, outranks the card
    executors = load_executors().get("executors", {})
    executor = executors.get(executor_name)
    if not executor:
        raise HarnessError(f"Unknown executor {executor_name!r}")
    prompt = build_prompt(task, profile_name)
    # SPEC-141/142: compose the packet-economy levers (compact-output env,
    # per-delegation budget, output-cap contract line). Absent tokenEconomy ->
    # {env:{}, over False, promptSuffix ""} -> byte-identical spawn. The suffix
    # folds into the prompt string BEFORE the argv is rendered (SPEC-142: "" when
    # uncapped -> byte-identical argv; no change to the 4-tuple signature).
    composed = packet_economy.compose_spawn(ROOT, profile_name, profile, prompt)
    prompt += composed["promptSuffix"]
    if prompt_file is not None:
        # SPEC-144 v6: claude.CMD (npm shim) runs through cmd.exe on Windows, which dies
        # on a multi-line prompt argv ("The filename ... syntax is incorrect"). Same cure
        # as workflow workers (workflow_spawn_command_for_prompt): packet to a file, argv
        # carries a one-line pointer.
        prompt_file.parent.mkdir(parents=True, exist_ok=True)
        write_text(prompt_file, prompt)
        try: shown = prompt_file.relative_to(ROOT)
        except ValueError: shown = prompt_file
        prompt = f"Read `{shown}` and execute that packet exactly."
    values = {
        "prompt": prompt,
        "profileName": profile_name,
        "profile": str(spawn.get("profile", profile_name)),
        "model": str(spawn.get("model", "")),
        "effort": str(spawn.get("effort", spawn.get("reasoning", ""))),
        "reasoning": str(spawn.get("reasoning", spawn.get("effort", ""))),
        "agent": str(spawn.get("agent", profile_name)),
        "python": sys.executable,
        "root": str(ROOT),
        "mcpConfig": [],
        # S3 (ref-arch round, codex-parity leg): dispatched/classified spawns are
        # implementer-class — codex gets workspace-write so a write role can
        # actually write (claude parity: its template carries no sandbox flag;
        # its ceiling is the agent frontmatter). Read-only lanes set their own.
        "sandbox": "workspace-write",
    }
    argv = model_routing.apply_resume(_resolve_argv0(render_template(executor.get("commandTemplate", []), values)), executor, resume)
    budget = composed["budget"]
    if budget["over"]:  # owner Q1: WARN on stderr, never block
        print(f"WARN packet-economy: est {budget['estTokens']} tokens exceeds delegation "
              f"budget {budget['budgetTokens']} for profile {profile_name}; proceeding",
              file=sys.stderr)
    return argv, profile_name, executor_name, composed["env"]

def generate_handoff(task: str | None = None, executor_name: str | None = None, subject: str | None = None) -> None:
    # handoff-subject-confinement: a TARGET workflow's regenerated handoff/state land in
    # the target's per-subject scope (state_dir), never the harness global. subject
    # None/"self" -> global (byte-identical, every existing caller unchanged).
    if subject and subject != "self":
        scope = targets_lib.state_dir(subject)
        state_base = scope
        handoff_md = scope / "handoff" / "handoff.md"
        handoff_json = scope / "handoff" / "handoff.json"
        next_prompt = scope / "handoff" / "next-agent-prompt.md"
    else:
        state_base = HARNESS / "state"
        handoff_md, handoff_json, next_prompt = HANDOFF_MD, HANDOFF_JSON, NEXT_PROMPT
    project = load_project()
    task_state = read_json(state_base / "task-state.json", {}) or {}
    workflow = read_json(state_base / "workflow-state.json", {}) or {}
    quality = read_json(state_base / "quality-state.json", {}) or {}
    task_text = task or task_state.get("nextStep") or workflow.get("nextRecommendedAction") or "Continue the current task."
    profile_name, profile, scores = classify(task_text)
    executor = active_executor(executor_name)
    # handoff-subject-confinement: stamp handoff_generated with the SUBJECT it was
    # generated for, so a target's regen is not mis-attributed to "self" in the event
    # log. self (None/"self") -> bare append_event (byte-identical, every caller unchanged).
    subj = subject if (subject and subject != "self") else None
    handoff_event = (lambda ev, pl=None: append_event(ev, pl, subject=subj)) if subj else append_event
    handoff_lib.generate_handoff(
        root=ROOT,
        handoff_md=handoff_md,
        handoff_json=handoff_json,
        next_prompt=next_prompt,
        project=project,
        task_state=task_state,
        workflow=workflow,
        quality=quality,
        task_text=task_text,
        profile_name=profile_name,
        profile=profile,
        scores=scores,
        executor=executor,
        files=changed_files(),
        commit=current_commit(),
        graph=graphify_status(),
        workflow_budget=workflow_budget_config(),
        token_budget=workflow_token_budget_config(None, None),
        build_prompt=build_prompt,
        workflow_suggestion=workflow_suggestion,
        write_text=write_text,
        write_json=write_json,
        now=now,
        append_event=handoff_event,
    )



# --- Workflow config/budget/lock/event domain (MF.1 round 2) -----------------
# Extracted to harness_lib.workflow_config; re-exported here so every existing
# caller keeps working, including external consumers (import harness;
# harness.workflow_limits(...)) and the globals()-bound helper modules. The
# domain needs harness-bound names (load_project, workflow_dir,
# workflow_profile_config, append_event, WORKFLOWS_DIR); workflow_config_lib.bind
# runs below, after those are defined (same shape as the async_state split).
for _wfcfg_name in workflow_config_lib.EXPORTED_FUNCTIONS:
    globals()[_wfcfg_name] = getattr(workflow_config_lib, _wfcfg_name)
del _wfcfg_name

WORKFLOW_TRANSITIONS: dict[str, set[str]] = {
    "planned": {"running", "reducing", "blocked", "failed", "cancelled"},
    "running": {"reducing", "done", "partial", "blocked", "failed", "cancelled"},
    "reducing": {"done", "partial", "blocked", "failed"},
    "partial": {"running", "reducing", "done", "blocked", "failed"},
    "blocked": {"running", "partial", "failed"},
    "failed": {"running", "partial", "blocked"},
    "cancelled": {"running", "partial", "blocked"},
    "done": set(),
}

WORKER_TRANSITIONS: dict[str, set[str]] = {
    "pending": {"queued", "running", "skipped", "blocked", "missing", "cancelled"},
    "queued": {"running", "failed", "skipped", "missing", "cancelled"},
    "running": {"done", "partial", "blocked", "failed", "missing", "skipped", "cancelled"},
    "done": {"pending"},
    "partial": {"pending", "done", "blocked", "failed"},
    "blocked": {"pending", "failed"},
    "failed": {"pending", "blocked"},
    "missing": {"pending", "failed", "blocked"},
    "skipped": {"pending"},
    "cancelled": {"pending"},
}

TERMINAL_WORKER_STATES = {"done", "partial", "blocked", "failed", "missing", "skipped", "cancelled"}

ASYNC_TASK_TERMINAL_STATES = {"fulfilled", "rejected", "cancelled", "timeout", "orphaned"}
ASYNC_GROUP_TERMINAL_STATES = {"settled", "partial", "failed", "cancelled", "timeout"}
AWAIT_MODES = {"all", "all-settled", "race", "first-success", "quorum"}

def schema_path_for(name: str) -> Path | None:
    schemas = workflow_config().get("schemas", {}) if isinstance(workflow_config().get("schemas"), dict) else {}
    raw = schemas.get(name)
    defaults = {
        "harnessResult": "schemas/harness-result.schema.json",
        "workerResult": "schemas/worker-result.schema.json",
        "reduceResult": "schemas/reduce-result.schema.json",
        "reviewerResult": "schemas/reviewer-result.schema.json",
        "workflow": "schemas/workflow.schema.json",
        "asyncTask": "schemas/async-task.schema.json",
        "asyncGroup": "schemas/async-group.schema.json",
        "awaitResult": "schemas/await-result.schema.json",
    }
    if not raw:
        raw = defaults.get(name)
    if not raw:
        return None
    path = ROOT / str(raw)
    return path if path.exists() else None

def schema_validation_status() -> str:
    """SPEC-108 H1: surface whether runtime JSON Schema validation actually runs."""
    return "active" if jsonschema is not None else "inactive"

def validate_json_schema(data: dict[str, Any], schema_name: str) -> list[str]:
    """Validate against JSON Schema when the optional dependency is installed."""
    if jsonschema is None:
        return []
    schema_file = schema_path_for(schema_name)
    if schema_file is None:
        return []
    try:
        schema = read_json(schema_file, {}) or {}
        jsonschema.Draft202012Validator(schema).validate(data)
        return []
    except Exception as exc:
        return [f"schema validation failed: {exc}"]

def existing_rel_path(value: str) -> bool:
    if str(value).strip().startswith(("http://", "https://", "mailto:")):
        return False  # URL guard must run before the ":line" split eats the scheme
    raw = str(value).split(":", 1)[0].strip()
    # Remove an explicit "./" prefix only — lstrip("./") strips the LEADING DOT of
    # dot-dirs (".harness/x" -> "harness/x"), failing every dot-dir path.
    while raw.startswith("./"):
        raw = raw[2:]
    if not raw:
        return False
    candidate = (ROOT / raw).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError:
        return False
    return candidate.exists()

def executor_concurrency_limit(executor_name: str) -> int | None:
    cfg = workflow_runtime_limits()
    key = "maxConcurrent" + executor_name[:1].upper() + executor_name[1:]
    if key not in cfg:
        return None
    try:
        return max(1, int(cfg[key]))
    except Exception:
        return None

def executor_profile_spawn(profile_name: str, executor_name: str) -> dict[str, Any] | None:
    profiles = load_profiles()["profiles"]
    profile = profiles.get(profile_name) or profiles.get("scan") or {}
    spawn = profile.get("spawn", {}) if isinstance(profile.get("spawn", {}), dict) else {}
    configured = spawn.get(executor_name)
    if isinstance(configured, dict):
        return model_routing.route_spawn(ROOT, profile_name, executor_name, configured)  # SPEC-115
    executor = executor_config(executor_name)
    default_spawn = executor.get("defaultSpawn")
    if isinstance(default_spawn, dict):
        return model_routing.route_spawn(ROOT, profile_name, executor_name, default_spawn)  # SPEC-115
    fallback = executor.get("profileFallbacks", {}) if isinstance(executor.get("profileFallbacks", {}), dict) else {}
    configured = fallback.get(profile_name) or fallback.get("default")
    return model_routing.route_spawn(ROOT, profile_name, executor_name, configured) if isinstance(configured, dict) else None

def validate_executor_adapter(executor_name: str) -> dict[str, Any]:
    executor = executor_config(executor_name)
    profiles = load_profiles().get("profiles", {})
    missing: list[str] = []
    uses_default: list[str] = []
    for profile_name in sorted(profiles):
        direct = (profiles.get(profile_name) or {}).get("spawn", {})
        has_direct = isinstance(direct, dict) and executor_name in direct
        if has_direct:
            continue
        if executor_profile_spawn(profile_name, executor_name):
            uses_default.append(profile_name)
        else:
            missing.append(profile_name)
    return {
        "executor": executor_name,
        "known": True,
        "runnable": bool(executor.get("runnable", True)),
        "placeholder": bool(executor.get("placeholder", False)),
        "profilesMissingSpawn": missing,
        "profilesUsingDefaultSpawn": uses_default,
        "valid": not missing,
        "nextStep": None if not missing else "Add profile spawn mappings or executor.defaultSpawn in .harness/routing/executors.json.",
    }

def rate_limit_detected(stdout: str = "", stderr: str = "") -> bool:
    text = normalize((stdout or "") + "\n" + (stderr or ""))
    needles = [
        "rate limit", "ratelimit", "too many requests", "quota exceeded", "credits exhausted",
        "payment", "credit error", "authentication failed", "unauthorized", "forbidden",
        "billing", "insufficient quota", "temporarily unavailable"
    ]
    return any(n in text for n in needles)

def has_active_or_queued_workers(workflow: dict[str, Any]) -> list[str]:
    active_states = {"queued", "running"}
    return [str(w.get("workerId")) for w in workflow.get("workers", []) if w.get("status") in active_states]

def token_budget_status(value: int, limit: int | None, warn_ratio: float) -> str:
    return token_economics.token_budget_status(value, limit, warn_ratio)

def token_budget_limit(cfg: dict[str, Any], key: str, default: int) -> int:
    return token_economics.token_budget_limit(cfg, key, default)

def token_audit_rollup_by_type(summaries: list[dict[str, Any]]) -> dict[str, Any]:
    return token_economics.rollup_by_type(summaries)

def worker_event(wfid: str, worker_id: str, event: str, payload: dict[str, Any] | None = None) -> None:
    payload = dict(payload or {})
    payload.setdefault("workflowId", wfid)
    payload.setdefault("workerId", worker_id)
    append_event(event, payload)

def ensure_transition(kind: str, current: str, target: str, *, force: bool = False) -> None:
    if force or current == target:
        return
    table = WORKER_TRANSITIONS if kind == "worker" else WORKFLOW_TRANSITIONS
    allowed = table.get(current, set())
    if target not in allowed:
        raise HarnessError(f"Invalid {kind} transition {current!r} -> {target!r}")

def executor_config(name: str) -> dict[str, Any]:
    executor = load_executors().get("executors", {}).get(name)
    if not isinstance(executor, dict):
        raise HarnessError(f"Unknown executor {name!r}")
    return executor

def ensure_executor_runnable(name: str, *, allow_placeholder: bool = False) -> None:
    executor = executor_config(name)
    if executor.get("runnable", True) is False and not allow_placeholder:
        raise HarnessError(f"Executor {name!r} is a placeholder. Configure .harness/routing/executors.json or use --allow-placeholder for testing.")

def workflow_id() -> str:
    """Return a collision-resistant workflow id for rapid multi-agent planning."""
    try:
        return workflow_ids.allocate_workflow_id(lambda candidate: workflow_dir(candidate).exists())
    except workflow_ids.WorkflowIdAllocationError as exc:
        raise HarnessError(str(exc)) from exc

def workflow_dir(wfid: str) -> Path:
    return workflow_ids.safe_workflow_path(ACTIVE_WORKFLOWS_DIR, wfid)

def async_group_id(wfid: str) -> str:
    """Return a collision-resistant async group id for workflow-local launches."""
    try:
        return workflow_ids.allocate_async_group_id(read_json(workflow_async_group_path(wfid), {}) or {})
    except workflow_ids.WorkflowIdAllocationError as exc:
        raise HarnessError(str(exc)) from exc

def workflow_state_store_config() -> dict[str, Any]:
    """Return workflow state-store mirror configuration."""
    return workflow_state_lib.state_store_config(workflow_config())

def workflow_state_store_enabled() -> bool:
    return workflow_state_lib.state_store_enabled(workflow_state_store_config())

def workflow_state_store() -> state_store.StateStore:
    return workflow_state_lib.open_state_store(ROOT, workflow_state_store_config())

def workflow_state_key(wfid: str, name: str) -> str:
    return workflow_state_lib.state_key(wfid, name)

def workflow_state_put(wfid: str, name: str, value: dict[str, Any]) -> None:
    workflow_state_lib.put_state(ROOT, workflow_state_store_config(), wfid, name, value, on_error=append_event)

def workflow_state_get(wfid: str, name: str) -> dict[str, Any] | None:
    return workflow_state_lib.get_state(ROOT, workflow_state_store_config(), wfid, name)

def workflow_state_artifact_specs(wfid: str) -> dict[str, str]:
    return workflow_state_lib.artifact_specs()

def workflow_state_put_artifact(wfid: str, name: str, path: Path) -> bool:
    return workflow_state_lib.put_artifact(ROOT, workflow_state_store_config(), wfid, name, path, on_error=append_event)

def workflow_state_mirror_known_artifacts(wfid: str) -> dict[str, Any]:
    return workflow_state_lib.mirror_known_artifacts(ROOT, workflow_state_store_config(), wfid, workflow_dir(wfid), on_error=append_event)

def workflow_state_recover_artifacts(wfid: str, *, names: list[str] | None = None) -> dict[str, Any]:
    return workflow_state_lib.recover_artifacts(ROOT, workflow_state_store_config(), wfid, workflow_dir(wfid), names=names, on_recovered=append_event)

def workflow_state_summary(wfid: str, *, mirror: bool = False, recover_artifacts: bool = False) -> dict[str, Any]:
    return workflow_state_lib.summary(ROOT, workflow_state_store_config(), wfid, workflow_dir(wfid), mirror=mirror, recover=recover_artifacts, on_event=append_event)

def rel(path: Path | str) -> str:
    try:
        return str(Path(path).relative_to(ROOT))
    except Exception:
        return str(path)

def path_is_excluded(path: str, includes: list[str] | None = None, excludes: list[str] | None = None) -> bool:
    p = path.strip().lstrip("./")
    if not p:
        return True
    if any(part in {".git", "node_modules", "__pycache__"} for part in Path(p).parts):
        return True
    if includes:
        included = any(Path(p).match(i) or p.startswith(i.rstrip("/") + "/") or p == i.rstrip("/") for i in includes)
        if not included:
            return True
    if excludes:
        for e in excludes:
            e = e.strip().lstrip("./")
            if Path(p).match(e) or p.startswith(e.rstrip("/") + "/") or p == e.rstrip("/"):
                return True
    return False

def top_level_group(path: str) -> str:
    p = path.strip().lstrip("./")
    parts = Path(p).parts
    if not parts:
        return "root"
    if parts[0].startswith(".") and len(parts) > 1:
        return "/".join(parts[:2])
    return parts[0]

def known_roots() -> list[str]:
    configured = workflow_config().get("partitionRoots")
    if isinstance(configured, list) and configured:
        roots = [str(x) for x in configured]
    else:
        roots = ["specs", "tasks", "docs", "schemas", "testing", "scripts", "tools", ".harness"]
    return [r for r in roots if (ROOT / r).exists()]

def default_map_shards(max_workers: int | None = None) -> list[dict[str, Any]]:
    max_workers = max_workers or workflow_limits()["maxWorkers"]
    shards: list[dict[str, Any]] = []
    for idx, item in enumerate(known_roots(), start=1):
        shards.append({
            "shardId": f"shard-{idx:03d}",
            "title": f"Review {item}",
            "paths": [item],
            "workerRole": "map-worker",
            "taskProfile": "review" if item in {"scripts", "tools", ".harness"} else "scan",
            "splitStrategy": "roots",
        })
    return shards[:max_workers]

def changed_file_shards(max_workers: int, includes: list[str] | None = None, excludes: list[str] | None = None, *, diff_scope: str = "working-tree", diff_base: str | None = None, diff_range: str | None = None) -> list[dict[str, Any]]:
    files = changed_files(diff_scope, diff_base, diff_range)
    if not files and diff_scope == "working-tree" and not diff_base and not diff_range:
        out = git(["diff", "--name-only", "HEAD"])
        files = [line.strip() for line in out.splitlines() if line.strip()]
    grouped: dict[str, list[str]] = {}
    for file in files:
        if path_is_excluded(file, includes, excludes):
            continue
        grouped.setdefault(top_level_group(file), []).append(file)
    shards: list[dict[str, Any]] = []
    for idx, (group, paths) in enumerate(sorted(grouped.items()), start=1):
        shards.append({
            "shardId": f"shard-{idx:03d}",
            "title": f"Review changed files under {group}",
            "paths": sorted(paths),
            "workerRole": "map-worker",
            "taskProfile": "review",
            "splitStrategy": "changed-files",
            "diffSource": {"scope": diff_scope, "base": diff_base, "range": diff_range},
        })
    if not shards:
        raise HarnessError("changed-files split found no files for the requested diff source")
    return shards[:max_workers]


def graphify_shards(max_workers: int, includes: list[str] | None = None, excludes: list[str] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    status = graphify_status()
    if not GRAPHIFY_GRAPH.exists() and status.get("graphifyAst", {}).get("enabled") and status.get("graphifyAst", {}).get("autoBuildWhenMissing"):
        try:
            from harness_lib import graph_providers  # active provider builds (loud fallback)
            ast_meta = graph_providers.build(ROOT, output_dir=ROOT / str(status.get("outputDir", "graphify-out")), max_files=int(status.get("graphifyAst", {}).get("maxFiles", 1000)))
            status["graphifyAstBuild"] = {"status": "built", **ast_meta}
        except Exception as exc:
            status["graphifyAstBuild"] = {"status": "error", "reason": str(exc)[:300]}
    if not GRAPHIFY_GRAPH.exists():
        status.update({"partitioning": "fallback-roots", "actualStrategy": "fallback-roots", "graphStatus": "not_available", "fallbackReason": "graphify-out/graph.json missing after Graphify code AST attempt"})
        return default_map_shards(max_workers), status
    try:
        graph = read_json(GRAPHIFY_GRAPH, {}) or {}
    except Exception as exc:
        status.update({"partitioning": "fallback-roots", "actualStrategy": "fallback-roots", "graphStatus": "error", "fallbackReason": str(exc)})
        return default_map_shards(max_workers), status

    grouped, actual, god_nodes, normalized_graph = graphify_adapter.group_graphify_paths(
        ROOT,
        graph,
        includes=includes,
        excludes=excludes,
        path_is_excluded=path_is_excluded,
        top_level_group=top_level_group,
    )

    shards: list[dict[str, Any]] = []
    for idx, (group, group_paths) in enumerate(sorted(grouped.items()), start=1):
        label = group.replace("community:", "")
        shards.append({
            "shardId": f"shard-{idx:03d}",
            "title": f"Review Graphify {label}",
            "paths": sorted(dict.fromkeys(group_paths))[:200],
            "contextPaths": god_nodes,
            "workerRole": "map-worker",
            "taskProfile": "review",
            "splitStrategy": "graphify",
            "graphLabel": label,
        })
    status.update({
        "partitioning": actual if shards else "fallback-roots",
        "requestedStrategy": "graphify",
        "actualStrategy": actual if shards else "fallback-roots",
        "graphStatus": "used" if shards else "fallback",
        "fallbackReason": None if shards else "no usable graph paths found",
        "graphAdapter": normalized_graph.get("adapter"),
        "graphNormalizer": normalized_graph,
        "normalizationStatus": normalized_graph.get("normalizationStatus"),
        "godNodes": god_nodes,
    })
    return (shards[:max_workers] if shards else default_map_shards(max_workers)), status

def explicit_shards(items: list[str], max_workers: int, includes: list[str] | None = None, excludes: list[str] | None = None) -> list[dict[str, Any]]:
    shards: list[dict[str, Any]] = []
    for idx, raw in enumerate(items[:max_workers], start=1):
        parts = [p.strip() for p in raw.split(",") if p.strip()]
        filtered = [p for p in parts if not path_is_excluded(p, includes, excludes)] or parts
        title = raw if len(raw) < 80 else raw[:77] + "..."
        shards.append({
            "shardId": f"shard-{idx:03d}",
            "title": title,
            "paths": filtered,
            "workerRole": "map-worker",
            "taskProfile": "scan",
            "splitStrategy": "explicit",
        })
    return shards or default_map_shards(max_workers)

def specs_tasks_docs_shards(max_workers: int) -> list[dict[str, Any]]:
    roots = [r for r in ["specs", "tasks", "docs", ".harness/context", ".harness/prompts"] if (ROOT / r).exists()]
    shards = []
    for idx, root in enumerate(roots, start=1):
        shards.append({"shardId": f"shard-{idx:03d}", "title": f"Review {root}", "paths": [root], "workerRole": "map-worker", "taskProfile": "docs", "splitStrategy": "specs-tasks-docs"})
    return shards[:max_workers]

def balance_map_shards(shards: list[dict[str, Any]], max_workers: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Split oversized explicit path shards while preserving a conservative worker cap."""
    balance_cfg = workflow_config().get("shardBalancing", {}) if isinstance(workflow_config().get("shardBalancing", {}), dict) else {}
    enabled = bool(balance_cfg.get("enabled", True))
    max_paths = int(balance_cfg.get("maxPathsPerShard", workflow_budget_value("promptBudget", "maxPaths", 100)))
    if not enabled or max_paths <= 0:
        return shards[:max_workers], {"balanced": False, "reason": "disabled"}
    balanced: list[dict[str, Any]] = []
    split_count = 0
    for shard in shards:
        paths = shard.get("paths", []) if isinstance(shard.get("paths", []), list) else []
        if len(paths) <= max_paths:
            balanced.append(shard)
            continue
        chunks = [paths[i:i + max_paths] for i in range(0, len(paths), max_paths)]
        split_count += len(chunks) - 1
        for idx, chunk in enumerate(chunks, start=1):
            item = dict(shard)
            item["paths"] = chunk
            item["shardId"] = f"{shard.get('shardId', 'shard')}-{idx:02d}"
            item["title"] = f"{shard.get('title', 'Review shard')} (part {idx}/{len(chunks)})"
            item["balancedFromShardId"] = shard.get("shardId")
            balanced.append(item)
    truncated = len(balanced) > max_workers
    return balanced[:max_workers], {
        "balanced": split_count > 0,
        "maxPathsPerShard": max_paths,
        "splitShards": split_count,
        "truncatedToMaxWorkers": truncated,
        "originalShardCount": len(shards),
        "finalShardCount": min(len(balanced), max_workers),
    }

def make_map_shards(split: str, explicit_items: list[str] | None, max_workers: int, includes: list[str] | None = None, excludes: list[str] | None = None, *, diff_scope: str = "working-tree", diff_base: str | None = None, diff_range: str | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if explicit_items:
        shards, meta = explicit_shards(explicit_items, max_workers * 4, includes, excludes), {"partitioning": "explicit"}
    elif split == "changed-files":
        shards, meta = changed_file_shards(max_workers * 4, includes, excludes, diff_scope=diff_scope, diff_base=diff_base, diff_range=diff_range), {"partitioning": "changed-files", "diffSource": {"scope": diff_scope, "base": diff_base, "range": diff_range}}
    elif split == "graphify":
        shards, meta = graphify_shards(max_workers * 4, includes, excludes)
    elif split == "specs-tasks-docs":
        shards, meta = specs_tasks_docs_shards(max_workers * 4), {"partitioning": "specs-tasks-docs"}
    else:
        shards, meta = default_map_shards(max_workers), {"partitioning": "roots"}
    balanced, balancing = balance_map_shards(shards, max_workers)
    meta["shardBalancing"] = balancing
    return balanced, meta

def _keyword_task_profile(title: str) -> str:
    """Legacy keyword fallback: infer a branch's task profile from its title."""
    n = normalize(title)
    return "security" if "security" in n else ("docs" if "doc" in n or "spec" in n else "review")

def default_fork_branches(max_workers: int | None = None, branch_names: list[Any] | None = None) -> list[dict[str, Any]]:
    max_workers = max_workers or workflow_limits()["maxWorkers"]
    defaults = [
        ("branch-security", "security-branch", "Security, secrets, privacy, permissions and trust boundaries", "security"),
        ("branch-testing", "testing-branch", "Tests, coverage, regression evidence and quality gates", "review"),
        ("branch-architecture", "architecture-branch", "Architecture, coupling, dependency paths and maintainability", "review"),
        ("branch-docs", "docs-branch", "Specs, tasks, docs and handoff consistency", "docs"),
        ("branch-dependencies", "dependency-branch", "Dependencies, generated files, supply chain and configuration", "review"),
    ]
    selected = defaults
    if branch_names:
        valid_profiles = set(load_profiles()["profiles"])
        selected = []
        for idx, entry in enumerate(branch_names, start=1):
            bid = f"branch-{idx:03d}"
            if isinstance(entry, dict):
                # 0b: a branch object declares its research role explicitly
                # ({"title", "taskProfile"?, "workerRole"?}); write_worker_prompt
                # already consumes unit.taskProfile/unit.workerRole.
                title = str(entry.get("title", "")).strip()
                if not title:
                    raise HarnessError(f"fork branch {idx} object requires a non-empty 'title'")
                profile = entry.get("taskProfile")
                if profile is None:
                    profile = _keyword_task_profile(title)
                elif profile not in valid_profiles:
                    raise HarnessError(
                        f"fork branch {idx} taskProfile {profile!r} is not a known task profile "
                        f"({', '.join(sorted(valid_profiles))})"
                    )
                role = str(entry.get("workerRole") or "branch-worker")
                # G1 (SPEC-144 Phase 3): a branch object may declare its modify-scope
                # `paths`; worker_prompt persists unit.paths -> scope.json and
                # compute_write_locks turns them into modify-locks. Absent key -> [].
                paths = [str(p) for p in (entry.get("paths") or [])]
                selected.append((bid, role, title, str(profile), paths, workflow_spawn.validated_branch_spawn(entry, idx), {key: entry[key] for key in ("cohortId", "minSuccessConfigured", "minSuccessEffective") if key in entry}))
            else:
                name = str(entry)
                selected.append((bid, "branch-worker", name, _keyword_task_profile(name)))
    return [workflow_spawn.fork_branch_row(row) for row in selected[:max_workers]]

def _fence_workflow_epoch(base: Path, workflow: dict[str, Any], *, force_epoch: bool = False) -> None:
    """SPEC-149 regra 3/5: stamp ownerEpoch and fence a stale writer.

    caller_epoch() is this run's epoch (env HARNESS_RUN_EPOCH). A caller with a
    LOWER epoch than the recorded ownerEpoch is a stale run writing over a newer
    owner -> refuse (unless force_epoch, which overrides loudly, regra 4). A
    caller WITHOUT an epoch is a legacy writer -> advisory epochMissing, never
    blocked (ratchet, regra 5). force_epoch is INDEPENDENT of `force` (the status
    transition override), so the fence still applies to routine forced updates."""
    caller = epoch.caller_epoch()
    owner = workflow.get("ownerEpoch")
    wfid = str(workflow.get("workflowId", base.name))
    if caller is None:
        if isinstance(owner, int):
            workflow["epochMissing"] = True
        return
    if isinstance(owner, int) and caller < owner:
        if not force_epoch:
            raise HarnessError(
                f"workflow {wfid} is owned by epoch {owner}; this run is epoch {caller} "
                f"(stale — a newer run took ownership). Re-run under the current owner, or "
                f"pass force_epoch=True (--force-epoch) to override and take ownership.")
        append_event("epoch_fence_overridden", {"workflowId": wfid, "target": "workflow",
                                                "priorEpoch": owner, "callerEpoch": caller})
    workflow["ownerEpoch"] = caller
    workflow.pop("epochMissing", None)

def workflow_update(base: Path, workflow: dict[str, Any], *, status: str | None = None, force: bool = False, force_epoch: bool = False) -> None:
    _fence_workflow_epoch(base, workflow, force_epoch=force_epoch)
    if status:
        current = str(workflow.get("status", "planned"))
        ensure_transition("workflow", current, status, force=force)
        workflow["status"] = status
    workflow["updatedAt"] = now()
    write_json(base / "workflow.json", workflow)
    workflow_state_put(str(workflow.get("workflowId", base.name)), "workflow", workflow)

def set_worker_status(workflow: dict[str, Any], worker_id: str, status: str, *, force: bool = False, **extra: Any) -> dict[str, Any]:
    for worker in workflow.get("workers", []):
        if worker.get("workerId") == worker_id:
            current = str(worker.get("status", "pending"))
            ensure_transition("worker", current, status, force=force)
            worker["status"] = status
            worker["updatedAt"] = now()
            worker.update({k: v for k, v in extra.items() if v is not None})
            return worker
    raise HarnessError(f"Unknown worker {worker_id}")

def workflow_profile_config(name: str | None) -> dict[str, Any]:
    profiles = load_workflow_profiles().get("profiles", {})
    if not name:
        return {}
    cfg = profiles.get(name)
    if not cfg:
        raise HarnessError(f"Unknown workflow profile {name!r}")
    return cfg if isinstance(cfg, dict) else {}

def controlled_write_config() -> dict[str, Any]:
    return controlled_writes.controlled_write_config(workflow_config())

def controlled_write_token() -> str:
    return controlled_writes.controlled_write_token(workflow_config())

def require_write_approval(token: str | None) -> None:
    controlled_writes.require_write_approval(token, workflow_config(), error_cls=HarnessError)

def workflow_runtime_ignore(dirpath: str, names: list[str]) -> set[str]:
    return controlled_writes.workflow_runtime_ignore(dirpath, names, harness_root=HARNESS)

def normalize_repo_path(path: str) -> str:
    return controlled_writes.normalize_repo_path(path)

def expand_scope_to_files(paths: list[str]) -> list[str]:
    return controlled_writes.expand_scope_to_files(paths, root=ROOT, path_is_excluded=path_is_excluded)

def worker_locked_files(base: Path, worker: dict[str, Any]) -> list[str]:
    return expand_scope_to_files(worker_scope_paths(base, worker))

def parse_worker_path_spec(spec: str, *, kind: str) -> dict[str, str]:
    return controlled_writes.parse_worker_path_spec(spec, kind=kind, error_cls=HarnessError)

def manual_write_locks(create_specs: list[str] | None = None, delete_specs: list[str] | None = None, rename_specs: list[str] | None = None) -> list[dict[str, Any]]:
    return controlled_writes.manual_write_locks(create_specs, delete_specs, rename_specs, now_func=now, error_cls=HarnessError)

def lock_paths(lock: dict[str, Any]) -> list[str]:
    return controlled_writes.lock_paths(lock)

def compute_write_locks(base: Path, workflow: dict[str, Any], workers: list[dict[str, Any]] | None = None, *, create_locks: list[str] | None = None, delete_locks: list[str] | None = None, rename_locks: list[str] | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    return controlled_writes.compute_write_locks(
        base,
        workflow,
        workers=workers,
        create_locks=create_locks,
        delete_locks=delete_locks,
        rename_locks=rename_locks,
        root=ROOT,
        worker_scope_paths=worker_scope_paths,
        path_is_excluded=path_is_excluded,
        now_func=now,
        error_cls=HarnessError,
    )

def create_temp_workspace(base: Path, wfid: str, worker_id: str, lock_scope: dict[str, Any] | None = None) -> str:
    return controlled_writes.create_temp_workspace(
        base,
        wfid,
        worker_id,
        lock_scope,
        root=ROOT,
        harness_root=HARNESS,
        path_is_excluded=path_is_excluded,
        write_json_func=write_json,
        now_func=now,
    )

def append_write_instructions(prompt_path: Path, worker: dict[str, Any], mode: str) -> None:
    controlled_writes.append_write_instructions(prompt_path, worker, mode, read_text_func=read_text, write_text_func=write_text)

def validate_write_workflow_ready(workflow: dict[str, Any]) -> None:
    controlled_writes.validate_write_workflow_ready(workflow, error_cls=HarnessError)

SEED_DEPTH_LIMIT = 2  # F1: refuse seeding from a workflow already at this depth
SEED_MAX_FINDINGS = 12
SEED_MAX_ITEM_CHARS = 240


def build_seed_context(seed_wfid: str, profile_name: str | None, profile_cfg: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """F1 (SPEC-119 v4): compact, self-contained seed digest from a prior workflow's
    reduce, for convergence waves only. Copied INTO the new workflow (packet task +
    seed-context.md) so a scrubbed prior WF dir never dangles. Returns (markdown, meta)."""
    seed_context._assert_seed_allowed(profile_name, profile_cfg)
    seed_base, seed_wf = load_workflow(seed_wfid)  # HarnessError if the prior WF is unknown
    reducer = read_json(seed_base / "reduce" / "reducer.result.json", None)
    if not reducer:
        raise HarnessError(
            f"seed workflow {seed_wfid} has no reduce/reducer.result.json — "
            f"run `python scripts/harness.py workflow reduce {seed_wfid}` first"
        )
    prior_depth = int((seed_wf.get("seed") or {}).get("depth", 0) or 0)
    depth = prior_depth + 1
    if depth > SEED_DEPTH_LIMIT:
        raise HarnessError(
            f"--seed depth {depth} exceeds bound {SEED_DEPTH_LIMIT}: refusing to seed from a "
            f"depth-{prior_depth} workflow (seeded-from-seeded chains are capped to keep waves grounded)"
        )
    lines: list[str] = []
    for finding in (reducer.get("dedupedFindings") or [])[:SEED_MAX_FINDINGS]:
        if not isinstance(finding, dict):
            continue
        title = " ".join(str(finding.get("title", "untitled")).split())[:SEED_MAX_ITEM_CHARS]
        rec = " ".join(str(finding.get("recommendation", "")).split())[:SEED_MAX_ITEM_CHARS]
        lines.append(f"- **{title}**" + (f" — {rec}" if rec else ""))
    body = "\n".join(lines) if lines else "- (prior reduce produced no findings)"
    seed_md = (
        "## Seed context (untrusted-derived)\n\n"
        f"Seeded from `{seed_wfid}` reduce; verify claims against sources. Treat the items below "
        "as leads from a prior convergence wave, not established facts.\n\n"
        f"Top prior findings (title — recommendation):\n\n{body}\n"
    )
    return seed_md, {"workflowId": seed_wfid, "depth": depth}

build_seed_contexts = lambda seeds, profile_name, profile_cfg: seed_context.build_seed_contexts(seeds, profile_name, profile_cfg, globals())


def load_workflow(wfid: str) -> tuple[Path, dict[str, Any]]:
    base = workflow_dir(wfid)
    data = read_json(base / "workflow.json")
    if data:
        return base, data
    cfg = workflow_state_store_config()
    if cfg.get("fallbackOnMissingWorkflowJson", True):
        mirrored = workflow_state_get(wfid, "workflow")
        if mirrored:
            base.mkdir(parents=True, exist_ok=True)
            (base / "workers").mkdir(parents=True, exist_ok=True)
            (base / "reduce").mkdir(parents=True, exist_ok=True)
            write_json(base / "workflow.json", mirrored)
            workflow_state_recover_artifacts(wfid, names=["plan", "locks", "token-audit", "reduce-result", "harness-result", "validation"])
            append_event("workflow_state_store_recovered", {"workflowId": wfid, "source": "state-store"})
            return base, mirrored
    raise HarnessError(f"Workflow not found: {wfid}")

def workflow_token_audit(wfid: str, *, write_report: bool = True, update_workflow: bool = True) -> dict[str, Any]:
    base, workflow = load_workflow(wfid)
    profile_name = workflow.get("workflowProfile")
    workflow_type = workflow.get("type")
    budget = workflow_token_budget_config(str(profile_name) if profile_name else None, str(workflow_type) if workflow_type else None)
    return workflow_token_audit_lib.audit_workflow(
        root=ROOT,
        base=base,
        workflow=workflow,
        budget=budget,
        now=now,
        state_put_artifact=workflow_state_put_artifact,
        state_put=workflow_state_put,
        write_report=write_report,
        update_workflow=update_workflow,
        target_root=Path(workflow["targetRoot"]) if workflow.get("targetRoot") else None,
    )

def workflow_spawn_command_for_prompt(prompt_path: str, profile_name: str, executor_name: str | None, spawn_override: dict[str, Any] | None = None, write_allowed: bool = False, pointer_prompt: str | None = None) -> list[str]:
    # SPEC-170 rule 6: one guard here covers sync start, async start, failover
    # respawn, reduce/review one-shots and tasks_board — not at the read-only
    # branch below, which write workers skip.
    model_routing.enforce_spawn(ROOT, profile_name)
    executor_name, spawn = workflow_spawn.resolved_spawn(profile_name, executor_name, spawn_override)
    executor = executor_config(executor_name)
    # pointer_prompt: non-worker one-shots (tasks refine) reuse this spawn seam
    # with their own pointer line; workers keep the WORKER_RESULT contract text.
    prompt = pointer_prompt or f"Read `{prompt_path}` and execute that workflow worker packet exactly. Return/save WORKER_RESULT only."
    prompt_file = Path(prompt_path)
    prompt_file = prompt_file if prompt_file.is_absolute() else ROOT / prompt_file
    workflow = read_json(prompt_file.parent.parent / "workflow.json", {}) or {}
    target = workflow.get("target")
    mcp_config = Path("graphify-out") / "targets" / str(target) / "adapter" / "mcp-config.json" if target else None
    values = {
        "prompt": prompt,
        "profileName": profile_name,
        "profile": str(spawn.get("profile", profile_name)),
        "model": str(spawn.get("model", "")),
        "effort": str(spawn.get("effort", spawn.get("reasoning", ""))),
        "reasoning": str(spawn.get("reasoning", spawn.get("effort", ""))),
        "agent": str(spawn.get("agent", profile_name)),
        "python": sys.executable,
        "root": str(ROOT),
        "mcpConfig": ["--mcp-config", mcp_config.as_posix()]
        if mcp_config and (ROOT / mcp_config).is_file() else [],
        # S3 (ref-arch round, codex-parity leg): the worker's writeAllowed drives
        # the codex sandbox — write workers finally CAN write (workspace-write),
        # read workers stay read-only. Claude's ceiling is the agent frontmatter
        # (S2) + the v6 diet below; its template has no sandbox flag by design.
        "sandbox": "workspace-write" if write_allowed else "read-only",
    }
    argv = _resolve_argv0(render_template(executor.get("commandTemplate", []), values))
    # SPEC-118 v6 (Phase C): read-only workers run with a tool-schema trim spliced
    # before the {prompt} tail (measured -2,670 tok/turn). writeAllowed workers are
    # NEVER trimmed. An explicit contextDiet on the profile's model-routing role
    # (owner-editable via `routing diet` / the GUI role editor) overrides the
    # default; a keep-all diet yields no flag = trim off. Template bytes untouched.
    if not write_allowed:
        role = model_routing.resolve_role(ROOT, profile_name, executor_name)
        diet = role.get("contextDiet") or context_diet.READONLY_WORKER_DIET
        trim = context_diet.tool_flags(executor_name, diet)
        if trim:
            argv = argv[:-1] + trim + argv[-1:]  # every template ends with {prompt}
    # SPEC-171 verify-then-spawn: codex skips untrusted hook entries silently,
    # so a lane only gets the bypass flag when .codex/hooks.json provably IS the
    # committed canonical render (codex_trust_grant, fail-closed). Denied lanes
    # launch anyway — hooks silently skipped, today's behavior — but say why.
    if executor_name == "codex":
        granted, why = agent_parity.codex_trust_grant(ROOT)
        if granted:
            argv = argv[:-1] + ["--dangerously-bypass-hook-trust"] + argv[-1:]
        else:
            print(f"codex spawn: hook-trust bypass NOT granted — {why}", file=sys.stderr)
    return argv




def worker_scope_paths(base: Path, worker: dict[str, Any]) -> list[str]:
    scope_path = worker.get("scopePath")
    if scope_path:
        data = read_json(ROOT / str(scope_path), {}) or {}
        if isinstance(data, dict) and isinstance(data.get("paths"), list):
            return [str(x) for x in data.get("paths", [])]
    return []








# Reducer/reviewer helpers live in harness_lib.workflow_reduce. Keep the
# public command/router surface here while preserving a compact context boundary
# for agents that only need reducer semantics.

# MF.1 round 1: discovery, result contracts, and escalations live behind
# harness_lib modules; the CLI router passes its shared helpers once.
_HARNESS_LIB_ENV = {
    "ACTIVE_WORKFLOWS_DIR": ACTIVE_WORKFLOWS_DIR,
    "EVENTS": EVENTS,
    "HarnessError": HarnessError,
    "ROOT": ROOT,
    "append_event": append_event,
    "bounded_timeout": bounded_timeout,
    "existing_rel_path": existing_rel_path,
    "graphify_code_ast": graphify_code_ast,
    "load_project": load_project,
    "now": now,
    "re": re,
    "read_json": read_json,
    "rel": rel,
    "read_text": read_text,
    "run_process_tree_bounded": run_process_tree_bounded,
    "validate_json_schema": validate_json_schema,
    "write_json": write_json,
}
for _extracted_module in (discovery, result_contracts, escalations_lib):
    _extracted_module.bind(_HARNESS_LIB_ENV)
DISCOVER_TEXT_EXTENSIONS = discovery.DISCOVER_TEXT_EXTENSIONS
DISCOVER_IMAGE_EXTENSIONS = discovery.DISCOVER_IMAGE_EXTENSIONS
DISCOVER_CODE_EXTENSIONS = discovery.DISCOVER_CODE_EXTENSIONS
_discover_provider_gates = discovery._discover_provider_gates
_discover_refusal_reason = discovery._discover_refusal_reason
discover_paths = discovery.discover_paths
doc_find = discovery.doc_find
extract_json_object = result_contracts.extract_json_object
extract_harness_result = result_contracts.extract_harness_result
validate_result_file = result_contracts.validate_result_file
extract_worker_result = result_contracts.extract_worker_result
validate_worker_result = result_contracts.validate_worker_result
bound_soft_fields = result_contracts.bound_soft_fields
list_escalations = escalations_lib.list_escalations


workflow_reduce_lib.bind(globals())
for _workflow_reduce_name in workflow_reduce_lib.EXPORTED_FUNCTIONS:
    globals()[_workflow_reduce_name] = getattr(workflow_reduce_lib, _workflow_reduce_name)

# Plan compiler lives in harness_lib.workflow_plan. Alias its exports here now so
# _WORKFLOW_LIB_ENV and lifecycle's bind (both below) resolve plan_workflow; the
# matching workflow_plan_lib.bind(globals()) runs after write_worker_prompt is set.
for _workflow_plan_name in workflow_plan_lib.EXPORTED_FUNCTIONS:
    globals()[_workflow_plan_name] = getattr(workflow_plan_lib, _workflow_plan_name)

# Sync fork-join execution engine (worker_harness_vars .. workflow_run) lives in
# harness_lib.workflow_run. Alias its exports now (function OBJECTS exist at
# import time) so the bind dicts below (workflow_spawn.bind, async_runtime.bind)
# and _WORKFLOW_LIB_ENV can reference them by name; the matching
# workflow_run_lib.bind(globals()) runs after every harness.py helper it calls
# at runtime is defined (mirrors workflow_plan_lib.bind below).
for _workflow_run_name in workflow_run_lib.EXPORTED_FUNCTIONS:
    globals()[_workflow_run_name] = getattr(workflow_run_lib, _workflow_run_name)
del _workflow_run_name

# Bind the workflow config/budget/lock/event domain now that its harness-router
# callbacks are defined (mirror of async_state.bind below). The functions were
# already re-exported into globals() where the domain used to live.
workflow_config_lib.bind({
    "WORKFLOWS_DIR": WORKFLOWS_DIR,
    "append_event": append_event,
    "load_project": load_project,
    "workflow_dir": workflow_dir,
    "workflow_profile_config": workflow_profile_config,
})

# Async workflow runtime is implemented in harness_lib.async_runtime to keep
# scripts/harness.py focused on routing, planning, reduce/finalize, and CLI
# command wiring. The runtime is bound after core workflow helpers are defined
# so it can reuse the existing storage, tracing, executor, and validation
# contracts without importing this router recursively.
workflow_spawn.bind({"active_executor": active_executor, "executor_config": executor_config, "executor_profile_spawn": executor_profile_spawn, "resolve_worker_executor": resolve_worker_executor})
async_runtime.bind({
    "ASYNC_TASK_TERMINAL_STATES": ASYNC_TASK_TERMINAL_STATES,
    "AWAIT_MODES": AWAIT_MODES,
    "HARNESS_ROUTER_SCRIPT": Path(__file__).resolve(),
    "active_executor": active_executor,
    "async_group_id": async_group_id,
    "build_worker_spawn_env": build_worker_spawn_env,
    "ensure_executor_runnable": ensure_executor_runnable,
    "executor_concurrency_limit": executor_concurrency_limit,
    "extract_worker_result": extract_worker_result,
    "load_workflow": load_workflow,
    "jsonschema": jsonschema,
    "rate_limit_detected": rate_limit_detected,
    "worker_harness_vars": worker_harness_vars,
    "worker_target_env": worker_target_env,
    "release_workflow_lock": release_workflow_lock,
    "run_one_worker": run_one_worker,
    "set_worker_status": set_worker_status,
    "validate_worker_result": validate_worker_result,
    "bound_soft_fields": bound_soft_fields,
    "validate_write_workflow_ready": validate_write_workflow_ready,
    "worker_event": worker_event,
    "worker_scope_paths": worker_scope_paths,
    "workflow_budget_config": workflow_budget_config,
    "workflow_config": workflow_config,
    "workflow_dir": workflow_dir,
    "workflow_event": workflow_event,
    "workflow_limits": workflow_limits,
    "workflow_lock_active": workflow_lock_active,
    "workflow_lock_path": workflow_lock_path,
    "workflow_profile_config": workflow_profile_config,
    "workflow_runtime_limits": workflow_runtime_limits,
    "workflow_spawn_command_for_prompt": workflow_spawn_command_for_prompt,
    "workflow_state_put": workflow_state_put,
    "workflow_state_put_artifact": workflow_state_put_artifact,
    "workflow_update": workflow_update,
})
for _async_name in async_runtime.EXPORTED_FUNCTIONS:
    globals()[_async_name] = getattr(async_runtime, _async_name)
del _async_name

# async_state owns the pure state/persistence + policy/circuit half (MF split);
# async_runtime re-exports its functions, so it only needs the router callbacks
# those helpers reference. bind after the callbacks above are defined.
async_state.bind({
    "AWAIT_MODES": AWAIT_MODES,
    "validate_worker_result": validate_worker_result,
    "worker_scope_paths": worker_scope_paths,
    "workflow_config": workflow_config,
    "workflow_dir": workflow_dir,
    "workflow_event": workflow_event,
    "workflow_limits": workflow_limits,
    "workflow_profile_config": workflow_profile_config,
    "workflow_runtime_limits": workflow_runtime_limits,
    "workflow_state_put": workflow_state_put,
})

def workflow_mark(wfid: str, worker_id: str, status: str, note: str | None = None, *, force: bool = False) -> dict[str, Any]:
    base, workflow = load_workflow(wfid)
    if status not in {"pending", "queued", "running", "done", "partial", "blocked", "failed", "missing", "skipped"}:
        raise HarnessError("invalid worker status")
    worker = set_worker_status(workflow, worker_id, status, force=force, note=note)
    workflow_update(base, workflow, force=True)
    worker_event(wfid, worker_id, "workflow_worker_marked", {"status": status, "force": force})
    return worker


def workflow_resume(wfid: str, executor_name: str | None = None, concurrency: int | None = None, timeout: int | None = None, dry_run: bool = False, *, allow_placeholder: bool = False, force_round: bool = False, force_lock: bool = False, only_blocked_rate_limit: bool = False) -> dict[str, Any]:
    if only_blocked_rate_limit:
        base, workflow = load_workflow(wfid)
        selected: list[str] = []
        for worker in workflow.get("workers", []):
            run = worker.get("run", {}) if isinstance(worker.get("run", {}), dict) else {}
            if worker.get("status") == "blocked" and run.get("blockedReason") == "rate_limit_or_runtime_limit":
                set_worker_status(workflow, str(worker.get("workerId")), "pending", force=True, resumeReason="blocked-rate-limit")
                selected.append(str(worker.get("workerId")))
        workflow_update(base, workflow, status="partial" if workflow.get("status") == "done" else None, force=True)
        workflow_event(wfid, "workflow_resume_targeted", {"reason": "blocked-rate-limit", "workers": selected})
    return workflow_run(wfid, executor_name, concurrency, timeout, dry_run, True, allow_placeholder=allow_placeholder, force_round=force_round, force_lock=force_lock)









def slugify_task_title(value: str) -> str:
    value = normalize(value)
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value[:48] or "workflow-task"

def next_task_id(index: int, title: str) -> str:
    date = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d")
    return f"TASK-{date}-{index:03d}-{slugify_task_title(title)}"


def locks_by_worker_and_mode(locks: list[dict[str, Any]]) -> dict[str, dict[str, list[Any]]]:
    grouped: dict[str, dict[str, list[Any]]] = {}
    for lock in locks:
        wid = str(lock.get("ownerWorkerId"))
        mode = str(lock.get("mode", "write"))
        grouped.setdefault(wid, {}).setdefault(mode, []).append(lock)
    return grouped



def file_changed_between(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    if not dst.exists():
        return True
    if src.stat().st_size != dst.stat().st_size:
        return True
    try:
        return src.read_bytes() != dst.read_bytes()
    except Exception:
        return True

def workspace_file_set(wroot: Path) -> set[str]:
    out: set[str] = set()
    if not wroot.exists():
        return out
    for item in wroot.rglob("*"):
        if not item.is_file():
            continue
        relp = item.relative_to(wroot).as_posix()
        if relp == ".harness-workspace.json" or path_is_excluded(relp) or relp.startswith(".harness/workflows/active/"):
            continue
        out.add(relp)
    return out


def run_validation_gate(gate: str | None) -> dict[str, Any] | None:
    if not gate:
        return None
    timeout = bounded_timeout("HARNESS_GATE_TIMEOUT", 900)
    try:
        proc = run_process_tree_bounded(
            [sys.executable, "scripts/harness-test.py", gate],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
        return {"gate": gate, "returnCode": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:], "passed": proc.returncode == 0}
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ((exc.stdout or b"").decode("utf-8", errors="ignore") if exc.stdout else "")
        stderr = exc.stderr if isinstance(exc.stderr, str) else ((exc.stderr or b"").decode("utf-8", errors="ignore") if exc.stderr else "")
        return {"gate": gate, "returnCode": 124, "stdout": stdout[-4000:], "stderr": (stderr + f"\ntimeout after {timeout}s")[-4000:], "passed": False, "timeoutSeconds": timeout}

def backup_path(worker_backup: Path, relp: str) -> Path:
    return worker_backup / "before" / relp

def remove_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()

def backup_existing(worker_backup: Path, relp: str) -> bool:
    src = ROOT / relp
    if not src.exists():
        return False
    dst = backup_path(worker_backup, relp)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True

def restore_backup_file(worker_backup: Path, relp: str) -> bool:
    src = backup_path(worker_backup, relp)
    if not src.exists():
        return False
    dst = ROOT / relp
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True








def cmd_workflow_execute(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or [])
    if not task:
        raise HarnessError("workflow execute requires --task or words")
    print(json.dumps(workflow_execute(
        task,
        workflow_type=args.type,
        profile_name=args.profile,
        split=args.split,
        shards=args.shard,
        branches=args.branch,
        executor_name=args.executor,
        concurrency=args.concurrency,
        timeout=args.timeout,
        dry_run=args.dry_run,
        allow_placeholder=args.allow_placeholder,
        finalize=not args.no_finalize,
        promote=args.promote,
        promote_target=args.promote_target,
        pause_before_run=args.pause_before_run,
        pause_before_reduce=args.pause_before_reduce,
        pause_before_finalize=args.pause_before_finalize,
        pause_before_promote=args.pause_before_promote,
        write_allowed=args.write_allowed,
        parallel_writes=args.parallel_writes,
        isolation_mode=args.isolation,
        approval_token=args.approval_token,
        override_budget=args.override_budget,
    ), indent=2, ensure_ascii=False))

def collect_status_snapshot() -> dict[str, Any]:
    """SPEC-104: assemble the read-only supervision snapshot from state files.

    Each section is gathered independently — a missing/corrupt source becomes
    {"unavailable": reason} for that section instead of failing the page.
    """
    def gather(fn):  # noqa: ANN001
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001 - the page must degrade, not crash
            return {"unavailable": f"{type(exc).__name__}: {exc}"}

    def active_workflows() -> dict[str, Any]:
        active: list[dict[str, Any]] = []
        if ACTIVE_WORKFLOWS_DIR.exists():
            for wf_path in sorted(ACTIVE_WORKFLOWS_DIR.glob("WF-*/workflow.json")):
                wf = read_json(wf_path, {}) or {}
                counts: dict[str, int] = {}
                for worker in wf.get("workers", []):
                    status = str(worker.get("status", "unknown"))
                    counts[status] = counts.get(status, 0) + 1
                plan = read_json(wf_path.parent / "plan.json", {}) or {}
                active.append({
                    "workflowId": wf.get("workflowId", wf_path.parent.name),
                    "phase": wf.get("phase", wf.get("status", "unknown")),
                    "task": str(wf.get("task", "")),
                    "workerStatusCounts": counts,
                    "plannedTokens": (plan.get("tokenAudit", {}) or {}).get("totalPlannedTokens", "—"),
                })
        return {"active": active}

    def quality() -> dict[str, Any]:
        data = read_json(HARNESS / "state" / "quality-state.json", None)
        if data is None:
            raise HarnessError("quality-state.json missing or invalid")
        return data

    def drift() -> dict[str, Any]:
        return {"errors": protected_files.compare_snapshot(ROOT, None)}

    def handoff() -> dict[str, Any]:
        data = read_json(HANDOFF_JSON, None)
        if data is None:
            raise HarnessError("handoff.json missing or invalid")
        return data

    return {
        "project": load_project().get("projectName", ROOT.name),
        "generatedAt": now(),
        "escalations": gather(list_escalations),
        "workflows": gather(active_workflows),
        "quality": gather(quality),
        "protectedDrift": gather(drift),
        "handoff": gather(handoff),
    }


def cmd_status(args: argparse.Namespace) -> None:
    if getattr(args, "html", False):
        # SPEC-104: rendering only — collection mutates no state.
        output = Path(getattr(args, "output", None) or (HARNESS / "state" / "supervision.html"))
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(status_html.render_status_html(collect_status_snapshot()), encoding="utf-8", newline="\n")
        print(json.dumps({"ok": True, "page": str(output), "note": "static snapshot; regenerate to refresh"}, indent=2, ensure_ascii=False))
        return
    print(json.dumps({
        "root": str(ROOT),
        "project": load_project().get("projectName", ROOT.name),
        "workflow": read_json(HARNESS / "state" / "workflow-state.json", {}),
        "task": read_json(HARNESS / "state" / "task-state.json", {}),
        "quality": read_json(HARNESS / "state" / "quality-state.json", {}),
        "changedFiles": changed_files(),
        "schemaValidation": schema_validation_status(),
        "knowledgeGraph": graphify_status(),
    }, indent=2, ensure_ascii=False))

# SPEC-107: cheap discovery wrapper — code stays local (AST), text/images go to
# cheap API providers (Gemini free tier, NVIDIA Build free credits), and the
# expensive coder LLM is never the fallback reader.








def cmd_discover(args: argparse.Namespace) -> None:
    if not args.paths:
        raise HarnessError(
            "discover requires at least one path\n"
            "cause: nothing to route\n"
            "fix: python scripts/harness.py discover <files...> (code->AST, text/image->cheap APIs)"
        )
    kwargs: dict[str, Any] = {}
    if getattr(args, "target", None):
        entry = targets_lib.resolve(args.target)
        kwargs = {"subject_root": targets_lib.target_root(entry), "subject_out": targets_lib.out_dir(args.target)}
    print(json.dumps(discover_paths(args.paths, **kwargs), indent=2, ensure_ascii=False))




def cmd_doc_find(args: argparse.Namespace) -> None:
    terms = args.terms or []
    if not terms:
        raise HarnessError(
            "doc-find requires at least one search term\n"
            "cause: nothing to look up\n"
            "fix: python scripts/harness.py doc-find <topic terms...>"
        )
    kwargs: dict[str, Any] = {}
    if getattr(args, "target", None):
        targets_lib.resolve(args.target)
        kwargs = {"subject_out": targets_lib.out_dir(args.target)}
    print(json.dumps(doc_find(terms, **kwargs), indent=2, ensure_ascii=False))


def cmd_self_review(_: argparse.Namespace) -> None:
    """SPEC-109: collect metrics, evaluate rules, apply safe actions, raise findings."""
    state = self_review_lib.run_self_review(ROOT, list_escalations=list_escalations, emit_event=append_event)
    print(json.dumps(state, indent=2, ensure_ascii=False))


def cmd_targets(args: argparse.Namespace) -> None:
    """SPEC-110: list governed target repositories, register one, or sync its adapter."""
    if args.action == "add":  # R32: validation (dir/.git/duplicate) lives in register()
        if not args.name or not args.path:
            raise HarnessError("targets add requires <name> <path>: python scripts/harness.py targets add <name> <path>")
        print(json.dumps(targets_lib.register(ROOT, args.name, args.path), indent=2, ensure_ascii=False)); return
    if args.action == "sync":
        if not args.name:
            raise HarnessError(
                "targets sync requires a target name\n"
                "cause: nothing to sync\n"
                "fix: python scripts/harness.py targets sync <name>"
            )
        entry = targets_lib.resolve(args.name)
        print(json.dumps(targets_lib.sync_adapter(entry), indent=2, ensure_ascii=False))
        return
    report: list[dict[str, Any]] = []
    for name, entry in sorted(targets_lib.load_targets().items()):
        root = targets_lib.target_root(entry)
        if not entry.get("enabled", True):
            report.append({"name": name, "enabled": False, "path": str(root)})
        elif not root.exists():
            report.append({"name": name, "exists": False, "path": str(root),
                           "fix": f"update \"path\" in {entry['profilePath']} or restore the repository"})
        else:
            report.append(targets_lib.inspect(entry))
    emit({"targets": report, "count": len(report),  # TE.5: wrapped dict -> compact JSON (not a flat array)
          "hint": "register a repo by creating .harness/targets/<name>/target.json"})



def cmd_escalations(args: argparse.Namespace) -> None:
    subject = getattr(args, "target", None)
    if args.resolve:
        # esc-subject-scope D2: with --target, cross-subject resolve is refused
        # (each subject keeps its world); the bare CLI stays the unscoped
        # operator escape hatch.
        try:
            escalations_lib.scoped_resolve_check(
                list_escalations()["pending"], args.resolve, subject)
        except ValueError as exc:
            raise HarnessError(str(exc)) from exc
        from harness_lib import responsibility  # SPEC-161: credit the resolver here too
        append_event("escalation_resolved", {"escalationId": args.resolve,
                                             "actor": responsibility.make_actor("accepter")})
        try:  # panel-chat QoL P3: queryable ledger record; loss must never break resolve
            records.add_entry(ROOT, "decision", f"escalation {args.resolve} resolved",
                              tags=["escalation"])
        except Exception:
            pass
        print(json.dumps({"resolved": args.resolve}, indent=2, ensure_ascii=False))
        return
    print(json.dumps(list_escalations(subject=subject), indent=2, ensure_ascii=False))

def cmd_metrics(args: argparse.Namespace) -> None:
    print(json.dumps(cost_metrics.summarize(ROOT), indent=2, ensure_ascii=False))

def cmd_delegation(args: argparse.Namespace) -> None:
    # The caller seat is DECLARED or READ from the session env — never resolved from
    # the routing pin: the pin says who SHOULD be seated, and this field exists
    # because the two diverge (a registered fallback ran an overseer pin all session).
    caller = cost_metrics.resolve_caller_seat(getattr(args, "caller_seat", None))
    if not cost_metrics.record_delegation(
            ROOT, model=args.model, agent_type=args.agent_type,
            tokens=args.tokens, tool_uses=args.tool_uses,
            duration_s=args.duration_s, task=args.task or "",
            target=args.target, outcome=args.outcome,
            effort=getattr(args, "effort", None), caller_seat=caller):
        raise HarnessError("delegation NOT recorded — the cost ledger refused the append; "
                           "nothing was written (re-run after checking .harness/state/)")
    out = {"recorded": "delegation", "model": args.model, "estTokens": args.tokens,
           "callerSeat": caller}
    if caller is None:
        out["note"] = ("caller seat unknown (no --caller-seat and no complete "
                       "HARNESS_SESSION_ROLE/MODEL/EFFORT) — the row is kept as spend "
                       "but excluded from seat denominators")
    print(json.dumps(out, indent=2, ensure_ascii=False))

def cmd_log(args: argparse.Namespace) -> None:
    """SPEC-112: record a worklog entry (the only write path for new records)."""
    title, body, refs = args.title or "", args.body or "", list(args.ref or [])
    tags = list(args.tag or [])
    if args.from_head:
        subject, cbody, sha = records.head_commit(ROOT)
        title = title or subject
        body = body or cbody
        if sha:
            refs.append(sha)
    print(json.dumps(records.add_entry(ROOT, args.kind, title, body, refs, tags,
                                       supersedes=getattr(args, "supersedes", "") or ""),
                     indent=2, ensure_ascii=False))

def cmd_records(args: argparse.Namespace) -> None:
    """SPEC-112: query/rebuild the derived ledger index (just-in-time handles)."""
    if args.action == "rebuild":
        print(json.dumps({"rebuilt": True, "records": records.build_index(ROOT)}, indent=2, ensure_ascii=False))
        return
    if args.action == "sources":
        # M5.mem CLI parity: the scope × purpose memory-source table.
        from harness_lib import ui_memory
        print(ui_memory.render_sources(ROOT))
        return
    if args.action == "summarize":
        print(json.dumps(records.summarize(ROOT, " ".join(args.terms or []), args.kind, args.limit or 200), indent=2, ensure_ascii=False))
        return
    limit = args.limit if args.limit else (10 if args.action == "search" else 20)
    terms = " ".join(args.terms or [])
    out = (records.search(ROOT, terms, kind=args.kind, limit=limit) if args.action == "search"
           else records.recent(ROOT, kind=args.kind, limit=limit))
    emit(out, tsv=True)  # TE.5: flat handle list -> TSV for agents

def cmd_models(args: argparse.Namespace) -> None: model_routing.cmd_models(ROOT, args.rest)  # SPEC-115 thin dispatch
def cmd_routing(args: argparse.Namespace) -> None: model_routing.cmd_routing(ROOT, args.rest)  # SPEC-115 thin dispatch

def cmd_chat(args: argparse.Namespace) -> None:
    rc = chat_operator.run_chat(ROOT, engine=args.engine, model=args.model, effort=args.effort,
                                endpoint=args.endpoint, api_key_env=args.api_key_env,
                                no_input=args.no_input, reconfigure=args.reconfigure,
                                reset_prefs=args.reset_prefs, target=args.target, role=args.role)
    if rc != 0:
        raise SystemExit(rc)

def cmd_ui(args: argparse.Namespace) -> None:
    import harness_ui  # lazy: pulls in http.server only when the panel is used
    # UX separation (Fase 2): seed the user-origin auto-commit flag for THIS live server
    # process — its /api/action handler runs here, so run_action/autocommit_enabled() read
    # it. Interactive owner launch (TTY) -> on; headless -> off; an explicit owner export
    # wins (setdefault). Test panels use make_server directly and never reach this seed.
    os.environ.setdefault("HARNESS_UI_AUTOCOMMIT", "1" if sys.stdout.isatty() else "0")
    # --no-open passthrough (2026-07-20 owner incident: the verb hardcoded
    # open_browser=True, so an agent serve-check popped the OWNER'S browser; the
    # deny_hitl_flags hook requires agents to pass --no-open — the flag must work).
    raise SystemExit(harness_ui.serve(ROOT, port=args.port, engine=args.engine,
                                      open_browser=not getattr(args, "no_open", False),
                                      exit_after=getattr(args, "exit_after_seconds", None)))

def cmd_classify(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or []) or "Continue current task"
    name, profile, scores = classify(task)
    append_event("task_classified", {"task":task,"taskProfile":name,"risk":profile.get("risk"),"scores":scores})
    print(json.dumps({"task":task,"taskProfile":name,"risk":profile.get("risk"),"scores":scores,"workflowRecommendation": workflow_suggestion(task)}, indent=2, ensure_ascii=False))

def cmd_handoff(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or []) or None
    generate_handoff(task, args.executor)
    print(f"Generated {HANDOFF_MD.relative_to(ROOT)} and {HANDOFF_JSON.relative_to(ROOT)}")

def cmd_spawn(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or []) or "Continue current task"
    cmd, profile, executor, spawn_env = spawn_command(task, args.executor, resume=getattr(args, "resume", None))
    append_event("subagent_spawn_command_created", {"taskProfile":profile,"executor":executor})
    print(" ".join(shlex.quote(p) for p in cmd))
    if spawn_env:  # SPEC-141: surface the compact-output env intent (Q2 opt-in) for the runner
        print("-- agent env: " + " ".join(f"{k}={v}" for k, v in spawn_env.items()), file=sys.stderr)
    ann = model_routing.fallback_annotation(ROOT, profile, executor)
    if ann: print(f"-- fallback chain: {ann}", file=sys.stderr)  # SPEC-115: chain only when a profile routes this role

def cmd_route(args: argparse.Namespace) -> None:
    # SPEC-144: opt-in /route -- classify ONE demand + a compact dispatch brief. Phase 2
    # adds two opt-in flags (conductor A): --verdict normalizes the specialized overseer's
    # typed return; --triage-prompt prints the Sonnet router prompt. No loop/live-model/
    # writeAllowed yet (Phase 3). The default (no-flag) path stays byte-identical to Phase 1.
    if getattr(args, "verdict", None):  # overseer->router return half (invariant 5)
        try:
            verdict = json.loads(args.verdict)
        except json.JSONDecodeError as exc:
            raise HarnessError(f"--verdict is not valid JSON: {exc}")
        if not isinstance(verdict, dict):
            raise HarnessError("--verdict must be a JSON object")
        print(json.dumps(route_dispatcher.consume_verdict(verdict), indent=2, ensure_ascii=False))
        return
    if getattr(args, "heartbeat", False):  # Phase 3: re-entry check, never spawns
        from harness_lib import route_loop
        print(json.dumps(route_loop.heartbeat(ROOT), indent=2, ensure_ascii=False))
        return
    if getattr(args, "loop", False):  # Phase 3: conductor-B feed-drain driver
        from harness_lib import route_loop
        print(json.dumps(route_loop.run_loop(
            ROOT, approval_token=getattr(args, "approve_writes", None), executor=args.executor,
            max_demands=getattr(args, "max_demands", 5), max_failures=getattr(args, "max_failures", 2),
            dry_run=getattr(args, "dry_run", False),
            only=getattr(args, "only", None)), indent=2, ensure_ascii=False))
        return
    demand = args.task or " ".join(args.words or [])
    demand = (demand or "").strip()
    if not demand:
        raise HarnessError("route requires a demand string (positional words or --task)")
    floor = route_dispatcher.deterministic_floor(ROOT, demand)
    if getattr(args, "triage_prompt", False):  # router->model triage prompt (invariant 2/3)
        print(route_dispatcher.triage_prompt(demand, floor))
        return
    decision = route_dispatcher.route_decision(demand, floor)
    brief = route_dispatcher.compose_brief(demand, decision, floor)
    # SPEC-144 v8: the durable route ledger (twin of the transient events). demand_id
    # is the ONE idempotent join key (== the withheld esc_id below), so triage <->
    # dispatched <-> done rows join per-demand and survive the SPEC-137 gate wipe.
    from harness_lib import route_ledger  # noqa: E402
    did = route_ledger.demand_id(demand)
    # EXP-10 metric seam: one additive measurement event. reads/tokens are a
    # placeholder until Phase 4 wires stream-json observedUsage per demand.
    # Causal DAG (article Section 8.1): the triage decision CAUSES the later
    # dispatch of a worker -- capture this row's eventId so route_dispatched can
    # name it as its parent (the one demonstrative spawn->worker edge; the
    # remaining call sites are a declared follow-up, not swept here).
    triage_event_id = append_event("route_triage",
                                  {"route": decision["route"], "delegate": decision["delegate"],
                                  "escalate": decision["escalate"], "riskFlags": floor.get("riskFlags", []),
                                  "demandId": did,
                                  "observedReads": None, "observedTokens": None})
    route_ledger.record(ROOT, "triage", {"demandId": did, "route": decision["route"],
                                         "riskTier": decision.get("riskTier", "R0"),
                                         "escalate": decision["escalate"]})
    print(json.dumps(decision, indent=2, ensure_ascii=False))
    print()
    print(brief)
    if decision.get("escalate"):
        # Porteiro incident 2026-07-17: on classify-only the withhold was invisible
        # (no WITHHELD line, nothing in the escalations ledger), so `escalations`
        # count 0 contradicted the printed decision. Persist it (idempotent id =
        # hash of the demand, mirroring security_routing_escalation) and say it.
        esc_id = "route-" + hashlib.sha256(demand.encode("utf-8")).hexdigest()[:8]
        # esc_id == did by construction: the withheld id IS the demand id (one id).
        append_event("route_withheld_escalation", {
            "escalationId": esc_id, "reason": decision.get("reason"),
            "riskFlags": floor.get("riskFlags", []), "demandId": did,
            "workflowProfile": decision.get("workflowProfile"), "demand": demand[:240]})
        route_ledger.record(ROOT, "withheld", {"demandId": did, "escalationId": esc_id,
                                               "route": decision["route"],
                                               "reason": decision.get("reason")})
        print(f"\n-- route WITHHELD: risk flags {floor.get('riskFlags', [])} -> "
              "owner decision inbox (harness.py decide); no room opens")
    dispatch = getattr(args, "dispatch", False)
    if decision["route"] == "inline":
        print("\n-- dispatch: nothing to dispatch (inline; overseer/session handles it here)"
              if dispatch else "\n-- dispatch: inline (no specialized-overseer spawn in Phase 1)")
        return
    # SPEC-144 v5 (Bug A): thread the ROUTED profile into the spawn so the packet is
    # NOT re-classified off the dirty tree (review-glob hijack). workflowProfile is the
    # live-triage hint; a Phase-2 WORKFLOW-profile name (not a task profile) falls back
    # to the deterministic floor's task profile; both unknown -> today's re-classification.
    task_profiles = load_profiles()["profiles"]
    profile_hint = decision.get("workflowProfile") or floor.get("profile")
    if profile_hint not in task_profiles:
        profile_hint = floor.get("profile") if floor.get("profile") in task_profiles else None
    cmd, _route_profile, resolved_executor, spawn_env = route_dispatcher.dispatch_command(
        ROOT, demand, decision, args.executor, profile_hint)
    if resolved_executor == "generic":  # rt-13: the echo stub is never a real overseer; never launch
        print("\n-- detached dispatch REFUSED (rt-13): active executor 'generic' is a stub (echo); "
              "the in-chat room handoff is unaffected. For AFK runs re-run with --executor claude, "
              "or configure .harness/routing/executors.json for this profile.")
        return
    if not dispatch:  # the pre-dispatch contract: PRODUCE the command, do not execute it
        print("\n-- dispatch command (specialized overseer; PRODUCED, not executed):")
        print(" ".join(shlex.quote(p) for p in cmd))
        return
    if decision.get("escalate"):  # security floor survives auto-dispatch: WITHHELD to the owner
        print("\n-- dispatch WITHHELD: decision escalated -> owner decision inbox (harness.py decide)")
        print(" ".join(shlex.quote(p) for p in cmd))
        return
    from harness_lib import route_loop  # _slug for the log filename
    # ponytail: pid+log recorded but nothing reaps a hung detached overseer -- accepted
    # ceiling (the async-supervisor pattern exists if orphan-reaping ever matters).
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    stem = HARNESS / "runs" / f"route-dispatch-{ts}-{route_loop._slug(demand)}"
    # SPEC-144 v6: re-render the spawn with the packet in a file (cmd.exe cannot carry a
    # multi-line prompt argv through the claude.CMD npm shim); the launched argv points at it.
    cmd, route_profile, resolved_executor, spawn_env = route_dispatcher.dispatch_command(
        ROOT, demand, decision, args.executor, profile_hint, stem.with_suffix(".prompt.md"))
    log = stem.with_suffix(".log")
    # S1 (ref-arch adoption round): detached overseers get the SAME SPEC-119
    # least-privilege env as workflow workers — full-shell inheritance leaked
    # every unrelated secret to every AFK run. spawn_env rides as harness_vars;
    # the escape hatch is unchanged (workflows.workerEnvFilter=false).
    # SPEC-149 regra 2: this detached run is born with an ownership epoch. It rides
    # in the spawn env (HARNESS_RUN_EPOCH), the durable ledger row, and the route
    # tuple, so a later fence refuses a stale writer (incident a6c9af5).
    run_epoch, _ = epoch.next_epoch(ROOT)
    spawned = sandbox_spawn.sandbox_spawn(  # SPEC-148: R0 detached dispatch, scoped env
        cmd, vendor=resolved_executor, write_allowed=False, cwd=ROOT,
        # session-seat-unwired: the detached lane's seat rides HERE, NOT in the pes-pinned spawn_env.
        env=build_worker_spawn_env(resolved_executor,
                                   {**dict(spawn_env or {}),
                                    **workflow_spawn.session_env_safe(route_profile, resolved_executor),
                                    epoch.ENV_EPOCH: str(run_epoch)}),
        root=ROOT, mode="detached", log_path=log,
        sandbox_enabled=(workflow_config() or {}).get("workerSandbox", True) is not False)  # SPEC-151 break-glass parity
    pid = spawned["pid"]
    # SECREV H1 Fase 2b (D044, option b): best-effort resource cap on the detached child
    # while THIS long-lived parent (overseer/chat) holds the job handle. FAIL-OPEN — a
    # failed cap NEVER breaks the trusted dispatch (opposite of the fail-closed async seam).
    # Ceiling: launch_detached is untouched, so there is no CREATE_SUSPENDED here and the
    # child already ran between spawn and cap — grandchildren spawned in that window can
    # escape. procApplied goes True ONLY if the cap actually applied; procAppliedScope makes
    # the "cap dies with this parent" ceiling explicit in the manifest.
    # Respect break-glass (reckon 2026-07-21): when the owner disabled the sandbox
    # wholesale (workerSandbox=false -> sandboxBypassed), do NOT re-apply a cap — the
    # layer is off by explicit owner choice (invariant 5), and a break-glass run often
    # needs more than DEFAULT_JOB_LIMITS. procApplied stays the bypassed False.
    _receipt = spawned.get("sandboxReceipt", {})
    if not _receipt.get("sandboxBypassed") and processes.cap_process_best_effort(pid, sandbox_spawn.DEFAULT_JOB_LIMITS):
        _receipt["procApplied"] = True
        _receipt["procAppliedScope"] = "parent-process-lifetime"
    append_event("route_dispatched", {"pid": pid, "taskProfile": profile_hint,
                                      "executor": resolved_executor, "log": str(log.relative_to(ROOT)),
                                      "demandId": did, "epoch": run_epoch,
                                      # L4: the trace-completeness scan keys on this tier
                                      "riskTier": decision.get("riskTier", "R0"),
                                      "sandboxManifest": sandbox_spawn.manifest(spawned.get("sandboxReceipt", {}))},
                 parent=triage_event_id)
    route_ledger.record(ROOT, "dispatched", {"demandId": did, "pid": pid,
                                             "executor": resolved_executor,
                                             "log": str(log.relative_to(ROOT)),
                                             "epoch": run_epoch,
                                             # C13/A2: versioned route pin (additive/observational).
                                             "tuple": route_tuple.route_tuple(
                                                 executor=resolved_executor, task_profile=profile_hint,
                                                 topology="detached-dispatch", write_allowed=False,
                                                 epoch=run_epoch, root=ROOT)})
    print(f"\n-- dispatched (detached): pid {pid}")
    print(str(log.relative_to(ROOT)))
    print("tail it; the overseer ends with HARNESS_RESULT")

def cmd_validate(args: argparse.Namespace) -> None:
    validate_result_file(Path(args.file))

def cmd_event(args: argparse.Namespace) -> None:
    payload = json.loads(args.payload) if args.payload else {}
    append_event(args.name, payload)
    print(f"Recorded event {args.name}")

def cmd_graph_status(_: argparse.Namespace) -> None:
    print(json.dumps(graphify_status(), indent=2, ensure_ascii=False))

def cmd_graph_build_code_ast(args: argparse.Namespace) -> None:
    status = graphify_status()
    max_files = args.max_files or int(status.get("graphifyAst", {}).get("maxFiles", 1000))
    if getattr(args, "target", None):
        entry = targets_lib.resolve(args.target)
        print(json.dumps(graphify_code_ast.build_graphify_code_ast(
            targets_lib.target_root(entry), output_dir=targets_lib.out_dir(args.target), max_files=max_files), indent=2, ensure_ascii=False))
        return
    output_dir = ROOT / str(status.get("outputDir", "graphify-out"))
    result = graphify_code_ast.build_graphify_code_ast(ROOT, output_dir=output_dir, max_files=max_files)
    if args.gemini_doc:
        # Text/image enrichment is a sidecar: the pure-AST graph.json stays the
        # authoritative code graph per knowledgeGraph.llmAssisted policy.
        llm = status.get("llmAssisted", {})
        key_present = bool(os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"))
        sidecar = output_dir / "docs-enrichment.json"
        if not llm.get("enabled"):
            result["geminiDocs"] = {"status": "refused", "reason": "knowledgeGraph.llmAssisted.enabled is false; enable it in .harness/project.json to opt in"}
        elif not key_present:
            result["geminiDocs"] = {"status": "refused", "reason": "GEMINI_API_KEY/GOOGLE_API_KEY not set in environment"}
        else:
            cmd = [sys.executable, str(ROOT / "tools" / "graphify" / "gemini_extract_fallback.py"), "--out", str(sidecar), *args.gemini_doc]
            proc = run_process_tree_bounded(cmd, timeout=bounded_timeout("HARNESS_GEMINI_DOCS_TIMEOUT", 300), cwd=ROOT)
            result["geminiDocs"] = {"status": "ok" if proc.returncode == 0 else "failed", "sidecar": str(sidecar.relative_to(ROOT)), "stderr": proc.stderr[-800:]}
    print(json.dumps(result, indent=2, ensure_ascii=False))

def cmd_workflow_plan(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or [])
    if not task:
        raise HarnessError("workflow plan requires --task or words")
    branches: list[Any] | None = args.branch
    branch_json = getattr(args, "branch_json", None)
    if branch_json is not None:  # SPEC-119 v7: composed branch OBJECTS from the composer
        if args.branch:
            raise HarnessError("pass either --branch (string) or --branch-json (JSON objects), not both")
        try:
            branches = json.loads(branch_json)
        except json.JSONDecodeError as exc:
            raise HarnessError(f"--branch-json is not valid JSON: {exc}")
        if not isinstance(branches, list):
            raise HarnessError("--branch-json must be a JSON array of branch objects [{title, taskProfile?, workerRole?, paths?, spawn?}]")
    result = plan_workflow(
        task,
        args.type,
        args.shard,
        branches,
        profile_name=args.profile,
        split=args.split,
        max_workers=args.max_workers,
        concurrency=args.concurrency,
        includes=args.include,
        excludes=args.exclude,
        diff_scope=args.diff_scope,
        diff_base=args.base,
        diff_range=args.range,
        write_allowed=args.write_allowed,
        parallel_writes=args.parallel_writes,
        isolation_mode=args.isolation,
        approval_token=args.approval_token,
        target_name=getattr(args, "target", None),
        seed=getattr(args, "seed", None),
        width_mode=getattr(args, "width_mode", None),
        width_why=getattr(args, "width_why", None),
        validate_only=getattr(args, "validate_only", False),
        override_budget=getattr(args, "override_budget", False),
    )
    if getattr(args, "validate_only", False):  # N1: report the verdict, materialize nothing
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return
    workflow = result
    print(json.dumps({"workflowId": workflow["workflowId"], "type": workflow["type"], "profile": workflow.get("workflowProfile"), "splitStrategy": workflow.get("splitStrategy"), "workers": len(workflow.get("workers", [])), "dir": str(workflow_dir(workflow["workflowId"]).relative_to(ROOT))}, indent=2, ensure_ascii=False))
    if getattr(args, "explain", False):  # DW.4: surface the observe-only topology verdict
        print(json.dumps(workflow["topologyRouter"], indent=2))

def cmd_workflow_trace(args: argparse.Namespace) -> None:
    result = trace_digest(args.workflow_id, limit=args.limit) if args.digest else workflow_trace(args.workflow_id, limit=args.limit)
    print(json.dumps(result, indent=2, ensure_ascii=False))

def cmd_workflow_trace_export(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_trace_export(args.workflow_id, export_format=args.format, output=args.output, limit=args.limit), indent=2, ensure_ascii=False))

def cmd_workflow_trace_push(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_trace_push(args.workflow_id, target=args.target, endpoint=args.endpoint, api_key_env=args.api_key_env, limit=args.limit, send=args.send, timeout=args.timeout), indent=2, ensure_ascii=False))

def cmd_workflow_state(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_state_summary(args.workflow_id, mirror=args.mirror, recover_artifacts=args.recover_artifacts), indent=2, ensure_ascii=False))

def cmd_workflow_token_audit(args: argparse.Namespace) -> None:
    if args.workflow_id:
        report = workflow_token_audit(args.workflow_id, write_report=not args.no_write_report, update_workflow=True)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return
    items: list[dict[str, Any]] = []
    if ACTIVE_WORKFLOWS_DIR.exists():
        for wf_path in sorted(ACTIVE_WORKFLOWS_DIR.glob("WF-*/workflow.json")):
            data = read_json(wf_path, {}) or {}
            wfid = data.get("workflowId")
            if not wfid:
                continue
            report = workflow_token_audit(str(wfid), write_report=not args.no_write_report, update_workflow=True)
            items.append(report.get("summary", {}))
    status = "fail" if any(i.get("status") == "fail" for i in items) else ("warn" if any(i.get("status") == "warn" for i in items) else "pass")
    print(json.dumps({"status": status, "byType": token_audit_rollup_by_type(items), "workflows": items}, indent=2, ensure_ascii=False))

def cmd_workflow_status(args: argparse.Namespace) -> None:
    if args.workflow_id:
        base, workflow = load_workflow(args.workflow_id)
        validation = read_json(base / "reduce" / "validation.json", {}) or {}
        reduce_result = read_json(base / "reduce" / "reducer.result.json", {}) or {}
        print(json.dumps({"summary": workflow_status_summary(workflow), "workflow": workflow, "validation": validation, "reduce": reduce_result}, indent=2, ensure_ascii=False))
        return
    items = []
    if ACTIVE_WORKFLOWS_DIR.exists():
        for path in sorted(ACTIVE_WORKFLOWS_DIR.glob("WF-*/workflow.json")):
            data = read_json(path, {}) or {}
            items.append({**workflow_status_summary(data), "splitStrategy": data.get("splitStrategy"), "task": data.get("task")})
    print(json.dumps({"workflows": items}, indent=2, ensure_ascii=False))

def cmd_workflow_spawn_commands(args: argparse.Namespace) -> None:
    _, workflow = load_workflow(args.workflow_id)
    for worker in workflow.get("workers", []):
        if args.only_missing:
            result_path = workflow_dir(args.workflow_id) / str(worker.get("resultPath", ""))
            if result_path.exists():
                continue
        cmd = workflow_spawn_command_for_prompt(worker["promptPath"], worker.get("taskProfile", "scan"), args.executor,
                                                write_allowed=bool(worker.get("writeAllowed")))
        print(" ".join(shlex.quote(p) for p in cmd))

def cmd_workflow_run(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_run(args.workflow_id, args.executor, args.concurrency, args.timeout, args.dry_run, args.only_missing, allow_placeholder=args.allow_placeholder, force_round=args.force_round, force_lock=args.force_lock, allow_frontier=args.allow_frontier, spawn_override=workflow_spawn.spawn_override_from_flags(args.model, args.effort)), indent=2, ensure_ascii=False))

def cmd_workflow_validate_results(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_validate_results(args.workflow_id), indent=2, ensure_ascii=False))


def cmd_workflow_reduce(args: argparse.Namespace) -> None:
    reduce_result = workflow_reduce(args.workflow_id, allow_partial=args.allow_partial)
    if args.agent:
        reduce_result["agenticReducer"] = prepare_agentic_reducer_packet(args.workflow_id, reduce_result, args.executor)
    print(json.dumps(reduce_result, indent=2, ensure_ascii=False))

def cmd_workflow_adopt_agent_reduce(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_adopt_agent_reduce(args.workflow_id, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_mark(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_mark(args.workflow_id, args.worker_id, args.status, args.note, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_start(args: argparse.Namespace) -> None:
    if not args.dry_run:
        _, wf = load_workflow(args.workflow_id)
        enforce_token_budget(args.workflow_id, wf, override=args.override_budget)
    print(json.dumps(workflow_start(
        args.workflow_id,
        args.executor,
        args.concurrency,
        args.timeout,
        mode=args.mode,
        min_success=args.min_success,
        only_missing=args.only_missing,
        dry_run=args.dry_run,
        allow_placeholder=args.allow_placeholder,
        force_round=args.force_round,
        force_lock=args.force_lock,
        allow_frontier=args.allow_frontier,
        card_resolver=executor_profile_spawn, executor_resolver=resolve_worker_executor, spawn_override=workflow_spawn.spawn_override_from_flags(args.model, args.effort),
    ), indent=2, ensure_ascii=False))

def cmd_workflow_async_supervisor(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_async_supervisor(args.workflow_id, args.executor, args.concurrency, args.timeout), indent=2, ensure_ascii=False))

def cmd_workflow_await(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_await(
        args.workflow_id,
        mode=args.mode,
        timeout=args.timeout,
        min_success=args.min_success,
        poll_interval=args.poll_interval,
        cancel_on_timeout=args.cancel_on_timeout,
    ), indent=2, ensure_ascii=False))

def cmd_workflow_collect(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_async_collect(args.workflow_id, recover=args.recover), indent=2, ensure_ascii=False))

def cmd_workflow_cancel(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_cancel(args.workflow_id, worker_id=args.worker_id, reason=args.reason, grace_seconds=args.grace_seconds), indent=2, ensure_ascii=False))

def cmd_workflow_reorder(args: argparse.Namespace) -> None:
    # queue-reorder (D039): reorders the ASYNC PENDING queue only. Refuses (exit 2) any
    # wfid that is running/settled or unknown — pending/queued workflows only.
    print(json.dumps(async_state.workflow_reorder(ROOT, args.workflow_ids), indent=2, ensure_ascii=False))

def cmd_workflow_async_status(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_async_status(args.workflow_id, recover=args.recover), indent=2, ensure_ascii=False))

def cmd_workflow_async_recover(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_async_recover(args.workflow_id), indent=2, ensure_ascii=False))

def cmd_workflow_doctor(args: argparse.Namespace) -> None:
    # Diagnose-only: prints the verdict incl. suggestedCommand as a STRING; never runs it.
    print(json.dumps(workflow_doctor(args.workflow_id), indent=2, ensure_ascii=False))

def cmd_workflow_fold(args: argparse.Namespace) -> None:
    # F1: non-destructive fold manifest (dry-run) — inventories artifacts + reclaimable bytes, moves nothing.
    print(json.dumps(workflow_fold(args.workflow_id), indent=2, ensure_ascii=False))

def cmd_workflow_evidence(args: argparse.Namespace) -> None:
    # UX-GA.3 phase 1: pure handle assembly (no re-run, no LLM); artifact bodies stay at their paths.
    print(json.dumps(evidence_bundle.bundle(ROOT, args.workflow_id, worker_id=args.worker_id), indent=2, ensure_ascii=False))

def cmd_workflow_watch(args: argparse.Namespace) -> None:
    seen = 0
    deadline = time.time() + args.timeout if args.timeout else None
    while True:
        events = workflow_async_events(args.workflow_id, limit=args.limit)
        new_events = events[seen:] if seen < len(events) else []
        if args.follow:
            for event in new_events:
                print(json.dumps(event, ensure_ascii=False), flush=True)
            seen = len(events)
            status = workflow_async_status(args.workflow_id, recover=True)
            group_status = (status.get("asyncGroup") or {}).get("status")
            if group_status in ASYNC_GROUP_TERMINAL_STATES:
                break
            if deadline is not None and time.time() >= deadline:
                break
            time.sleep(max(0.1, args.poll_interval))
        else:
            print(json.dumps({"workflowId": args.workflow_id, "events": events}, indent=2, ensure_ascii=False))
            break

def cmd_workflow_retry(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_retry(args.workflow_id, args.worker_id, args.clear_result, force_round=args.force_round), indent=2, ensure_ascii=False))

def cmd_workflow_finalize(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_finalize(args.workflow_id, update_context=not args.no_update_context, regenerate_handoff=not args.no_regenerate_handoff, skip_review=args.skip_review), indent=2, ensure_ascii=False))

def cmd_workflow_resume(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_resume(args.workflow_id, args.executor, args.concurrency, args.timeout, args.dry_run, allow_placeholder=args.allow_placeholder, force_round=args.force_round, force_lock=args.force_lock, only_blocked_rate_limit=args.only_blocked_rate_limit), indent=2, ensure_ascii=False))

def cmd_workflow_unlock(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_unlock(args.workflow_id, stale_only=args.stale_only, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_promote(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_promote(args.workflow_id, args.limit, target=args.to), indent=2, ensure_ascii=False))

def cmd_workflow_suggest(args: argparse.Namespace) -> None:
    task = args.task or " ".join(args.words or [])
    if not task:
        raise HarnessError("workflow suggest requires --task or words")
    suggestion = workflow_suggestion(task)
    append_event("workflow_suggested", {"task": task, **suggestion})
    print(json.dumps({"task": task, **suggestion}, indent=2, ensure_ascii=False))

def cmd_workflow_events(args: argparse.Namespace) -> None:
    events: list[dict[str, Any]] = []
    if EVENTS.exists():
        for line in EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                item = json.loads(line)
            except Exception:
                continue
            if item.get("workflowId") != args.workflow_id:
                continue
            if args.worker_id and item.get("workerId") != args.worker_id:
                continue
            events.append(item)
    print(json.dumps({"workflowId": args.workflow_id, "events": events[-args.limit:]}, indent=2, ensure_ascii=False))

def cmd_workflow_review_reduce(args: argparse.Namespace) -> None:
    result = workflow_prepare_reduce_review_packet(
        args.workflow_id,
        executor_name=args.executor,
        validate_existing=args.validate_existing,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))

def cmd_workflow_prepare_write(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_prepare_write(
        args.workflow_id,
        mode=args.mode,
        create_workspaces=not args.no_create_workspaces,
        allow_conflicts=args.allow_conflicts,
        approval_token=args.approval_token,
        create_locks=args.create_lock,
        delete_locks=args.delete_lock,
        rename_locks=args.rename_lock,
    ), indent=2, ensure_ascii=False))

def cmd_workflow_merge_plan(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_merge_plan(args.workflow_id, validation_gate=args.validation_gate), indent=2, ensure_ascii=False))

def cmd_workflow_apply_merge(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_apply_merge(
        args.workflow_id,
        approval_token=args.approval_token,
        validation_gate=args.validation_gate,
        final_gate=args.final_gate,
        dry_run=args.dry_run,
        rollback_on_final_gate_failure=args.rollback_on_final_gate_failure,
        rollback_on_validation_gate_failure=args.rollback_on_validation_gate_failure,
        interactive=args.interactive,
    ), indent=2, ensure_ascii=False))

def cmd_workflow_rollback(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_rollback(args.workflow_id, worker_id=args.worker_id), indent=2, ensure_ascii=False))

def cmd_workflow_cleanup_write(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_cleanup_write(args.workflow_id, force=args.force), indent=2, ensure_ascii=False))

# SPEC-108 H3: test/finished workflows kept leaving residues in active/ and the
# state-store mirror; manual deletion tripped release-hygiene twice.

# Promoted to harness_lib.common when its Deferred trigger fired (SPEC-109).
_rmtree_robust = rmtree_robust


def cmd_workflow_scrub(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_scrub(args.workflow_id, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_prepare_worktrees(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_prepare_worktrees(args.workflow_id, approval_token=args.approval_token, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_cleanup_worktrees(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_cleanup_worktrees(args.workflow_id, force=args.force), indent=2, ensure_ascii=False))

def cmd_workflow_review_merge(args: argparse.Namespace) -> None:
    print(json.dumps(workflow_review_merge(args.workflow_id, executor=args.executor, validate_existing=args.validate_existing), indent=2, ensure_ascii=False))


def cmd_protected_files_check(args: argparse.Namespace) -> None:
    baseline = None
    if getattr(args, "snapshot", None):
        baseline = json.loads(Path(args.snapshot).read_text(encoding="utf-8"))
    errors = protected_files.compare_snapshot(ROOT, baseline)
    payload = {"ok": not errors, "errors": errors, "protectedFiles": protected_files.protected_paths(ROOT)}
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    if errors:
        raise HarnessError("protected file drift detected: " + "; ".join(errors[:5]))


def cmd_protected_files_snapshot(args: argparse.Namespace) -> None:
    target = Path(args.output) if getattr(args, "output", None) else None
    path = protected_files.write_snapshot(ROOT, target)
    print(json.dumps({"ok": True, "snapshot": str(path)}, indent=2, ensure_ascii=False))


def cmd_protected_files_list(args: argparse.Namespace) -> None:
    print(json.dumps({"protectedFiles": protected_files.protected_paths(ROOT)}, indent=2, ensure_ascii=False))

def cmd_executor_validate(args: argparse.Namespace) -> None:
    if args.executor:
        print(json.dumps(validate_executor_adapter(args.executor), indent=2, ensure_ascii=False))
        return
    data = {name: validate_executor_adapter(name) for name in sorted(load_executors().get("executors", {}))}
    print(json.dumps({"executors": data, "allValid": all(item.get("valid") for item in data.values())}, indent=2, ensure_ascii=False))

def cmd_executor_list(args: argparse.Namespace) -> None:
    executors = load_executors().get("executors", {})
    print(json.dumps({"defaultExecutor": load_executors().get("defaultExecutor"), "executors": executors}, indent=2, ensure_ascii=False))

def cmd_agents(args: argparse.Namespace) -> None:
    """SPEC-113: agent capability parity across vendor CLIs (hooks/MCP/skills)."""
    if args.action == "audit":
        adopt = agent_parity.adopt(ROOT) if getattr(args, "adopt", False) else None  # seeds only when absent
        result = agent_parity.audit(ROOT)
        if adopt is not None:
            result["adopt"] = adopt
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return
    if args.action == "claude-trust":
        result = agent_parity.claude_trust_apply(ROOT, apply=getattr(args, "apply", False))
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return
    if args.action == "codex-trust":
        granted, why = agent_parity.codex_trust_grant(ROOT)
        if getattr(args, "flag", False):  # hand-typed recipes: append the output verbatim
            print("--dangerously-bypass-hook-trust" if granted else "")
            return
        print(json.dumps({"granted": granted, "reason": why,
                          "argv": ["--dangerously-bypass-hook-trust"] if granted else []},
                         indent=2, ensure_ascii=False))
        return
    print(json.dumps(agent_parity.pair(ROOT, apply=getattr(args, "apply", False)), indent=2, ensure_ascii=False))


# MF.1 round 2: controlled-write orchestration and lifecycle ops live behind
# harness_lib modules; the router passes its shared helpers once.
_WORKFLOW_LIB_ENV = {
    "ACTIVE_WORKFLOWS_DIR": ACTIVE_WORKFLOWS_DIR,
    "HARNESS": HARNESS,
    "HarnessError": HarnessError,
    "ROOT": ROOT,
    "_rmtree_robust": rmtree_robust,
    "active_executor": active_executor,
    "append_event": append_event,
    "append_write_instructions": append_write_instructions,
    "backup_existing": backup_existing,
    "compute_write_locks": compute_write_locks,
    "controlled_write_token": controlled_write_token,
    "create_temp_workspace": create_temp_workspace,
    "enforce_token_budget": enforce_token_budget,
    "file_changed_between": file_changed_between,
    "generate_handoff": generate_handoff,
    "load_workflow": load_workflow,
    "jsonschema": jsonschema,
    "next_task_id": next_task_id,
    "normalize_repo_path": normalize_repo_path,
    "now": now,
    "path_is_excluded": path_is_excluded,
    "plan_workflow": plan_workflow,
    "read_json": read_json,
    "rel": rel,
    "remove_path": remove_path,
    "require_write_approval": require_write_approval,
    "restore_backup_file": restore_backup_file,
    "run_validation_gate": run_validation_gate,
    "set_worker_status": set_worker_status,
    "validate_json_schema": validate_json_schema,
    "worker_event": worker_event,
    "workflow_dir": workflow_dir,
    "workflow_event": workflow_event,
    "workflow_limits": workflow_limits,
    "workflow_lock_active": workflow_lock_active,
    "workflow_lock_path": workflow_lock_path,
    "workflow_reduce_lib": workflow_reduce_lib,
    "workflow_run": workflow_run,
    "workflow_spawn_command_for_prompt": workflow_spawn_command_for_prompt,
    "workflow_state_put_artifact": workflow_state_put_artifact,
    "workflow_state_get": workflow_state_get,
    "workflow_update": workflow_update,
    "workspace_file_set": workspace_file_set,
    "write_json": write_json,
    "write_text": write_text,
}
# runtime re-exports (workflow_reduce/async_runtime EXPORTED_FUNCTIONS) are not
# AST-visible top-level defs — pass them explicitly.
for _name in (*workflow_reduce_lib.EXPORTED_FUNCTIONS, *async_runtime.EXPORTED_FUNCTIONS):
    _WORKFLOW_LIB_ENV.setdefault(_name, globals()[_name])
# cross-module dependency: lifecycle's execute() calls into workflow_writes
# (QA.1 bind-env-completeness caught this as a latent NameError)
_WORKFLOW_LIB_ENV.setdefault("workflow_prepare_write", workflow_writes_lib.workflow_prepare_write)
for _wf_module in (workflow_writes_lib, workflow_lifecycle_lib):
    _wf_module.bind(_WORKFLOW_LIB_ENV)
lock_paths_for_worker = workflow_writes_lib.lock_paths_for_worker
workflow_prepare_write = workflow_writes_lib.workflow_prepare_write
workflow_merge_plan = workflow_writes_lib.workflow_merge_plan
workflow_apply_merge = workflow_writes_lib.workflow_apply_merge
workflow_rollback = workflow_writes_lib.workflow_rollback
workflow_cleanup_write = workflow_writes_lib.workflow_cleanup_write
workflow_prepare_worktrees = workflow_writes_lib.workflow_prepare_worktrees
workflow_cleanup_worktrees = workflow_writes_lib.workflow_cleanup_worktrees
workflow_review_merge = workflow_writes_lib.workflow_review_merge
SCRUB_SAFE_PHASES = workflow_lifecycle_lib.SCRUB_SAFE_PHASES
workflow_retry = workflow_lifecycle_lib.workflow_retry
workflow_finalize = workflow_lifecycle_lib.workflow_finalize
workflow_promote = workflow_lifecycle_lib.workflow_promote
workflow_unlock = workflow_lifecycle_lib.workflow_unlock
workflow_scrub = workflow_lifecycle_lib.workflow_scrub
workflow_fold = workflow_lifecycle_lib.workflow_fold
update_context_from_workflow = workflow_lifecycle_lib.update_context_from_workflow
workflow_status_summary = workflow_lifecycle_lib.workflow_status_summary
workflow_execute = workflow_lifecycle_lib.workflow_execute


# Line-budget burndown (owner-approved 2026-07-13): observability + worker-packet
# rendering bodies live in harness_lib; the names below stay public attributes of
# this router (CLI handlers, cli_workflow_tree and scenarios resolve them here).
workflow_observability_lib.bind({
    "ROOT": ROOT,
    "append_event": append_event,
    "workflow_config": workflow_config,
    "workflow_dir": workflow_dir,
    "workflow_tail": workflow_tail,
    "workflow_async_status": workflow_async_status,
    "ASYNC_GROUP_TERMINAL_STATES": ASYNC_GROUP_TERMINAL_STATES,
})
workflow_trace = workflow_observability_lib.workflow_trace
trace_digest = workflow_observability_lib.trace_digest
workflow_trace_export = workflow_observability_lib.workflow_trace_export
workflow_trace_push = workflow_observability_lib.workflow_trace_push
cmd_workflow_tail = workflow_observability_lib.cmd_workflow_tail
worker_prompt_lib.bind({
    "ROOT": ROOT,
    "workflow_budget_config": workflow_budget_config,
    "workflow_token_budget_config": workflow_token_budget_config,
    "estimate_tokens_from_text": estimate_tokens_from_text,
    "estimate_tokens_from_chars": estimate_tokens_from_chars,
    "token_budget_limit": token_budget_limit,
    "token_budget_status": token_budget_status,
})
write_worker_prompt = worker_prompt_lib.write_worker_prompt
# workflow_plan.bind runs here (not with its re-export above) because the plan
# compiler needs write_worker_prompt, which is only resolved on the line above.
workflow_plan_lib.bind(globals())
workflow_run_lib.bind(globals())

def cmd_hold_recover(args: argparse.Namespace) -> None:
    # Row gate-hold-abandoned-detector: recovery moves trees, so it is a verb of
    # its own, never a side effect of an unrelated command. Body + the live-pid
    # refusal live in scenario_isolation (the module that owns the hold format).
    n = scenario_isolation.recover_abandoned_holds(ROOT)
    if n:
        print(f"hold-recover: restored {n} abandoned gate-hold(s); review the "
              f"*-recovered dir(s) under .harness/runs/gate-hold/ before deleting.")


def main(argv: list[str] | None = None) -> int:
    enforce_declared_python(sys.argv[1:] if argv is None else argv)  # runtime.python.envOverride
    load_ambient_keys()  # OS vault; real env always wins (SPEC-107, keys-keyring v2)
    # Row gate-hold-abandoned-detector: a crashed gate parks the owner's .harness
    # state inside its hold and the live tree looks wiped -- say so on EVERY entry
    # (read-only, stderr, fail-open inside; near-zero when no hold exists).
    scenario_isolation.warn_abandoned_holds(ROOT)
    parser = argparse.ArgumentParser(description="Universal Agent Harness")
    sub = parser.add_subparsers(required=True)
    # MF.1-r2 (harness-lines burndown): the NON-workflow top-level verbs
    # (status .. graph-build-code-ast, plus the protected-files/executor/agents
    # groups) register in harness_lib.cli_registry -- a future verb adds one line
    # THERE with zero edits here. The workflow subcommand tree registers in
    # harness_lib.cli_workflow_tree (workflow-block r2); its cmd_workflow_*
    # HANDLERS stay in this module. The graph-build-code-ast boundary
    # literal is named here so spec_test_gate.py's modular-boundary check holds.
    cli_registry.register(sub, sys.modules[__name__])
    wp = sub.add_parser("workflow", help="Plan and reduce large-task workflow packets")
    wsub = wp.add_subparsers(required=True)
    cli_workflow_tree.register(wsub, sys.modules[__name__])
    args = parser.parse_args(argv)
    # cli-gate-hold-write-guard (owner 2026-07-29): a write verb during a LIVE
    # gate-hold would land on the materialized-HEAD tree and be discarded on
    # release (the 2026-07-23 3x loss class). Verb list + logic live with the
    # hold's owner (scenario_isolation); honest refusal beats silent loss.
    raw_argv = argv if argv is not None else sys.argv[1:]
    verb = next((a for a in raw_argv if not a.startswith("-")), "")
    hold_reason = scenario_isolation.hold_write_guard(verb, ROOT)
    if hold_reason:
        print(f"harness: REFUSED - {hold_reason}", file=sys.stderr)
        return 3
    # cli-gate-hold-read-warn: a READ verb during a live hold sees materialized HEAD,
    # not live state (the 2026-07-31 false "records lost" report). Warn, never block.
    if read_warn := scenario_isolation.hold_read_warning(verb, ROOT):
        print(f"harness: NOTE - {read_warn}", file=sys.stderr)
    try:
        args.func(args)
        closing_block(argv if argv is not None else sys.argv[1:])
        return 0
    except HarnessError as exc:
        print(f"harness error: {exc}", file=sys.stderr)
        return 2


def closing_block(argv: list[str]) -> None:
    """SPEC-102 (M2.1): outcome + state + next action on stderr after every
    successful subcommand. stderr only — stdout stays parseable JSON."""
    try:
        command = " ".join(argv[:2] if argv[:1] == ["workflow"] or argv[:1] == ["executor"] or argv[:1] == ["protected-files"] else argv[:1]) or "harness"
        wf_state = read_json(HARNESS / "state" / "workflow-state.json", {}) or {}
        quality = read_json(HARNESS / "state" / "quality-state.json", {}) or {}
        last_validation = quality.get("lastValidation", {}) or {}
        pending = list_escalations().get("count", 0)
        state_bits = []
        if wf_state.get("workflowId"):
            state_bits.append(f"workflow {wf_state.get('workflowId')} {wf_state.get('phase') or wf_state.get('status') or ''}".strip())
        if last_validation.get("gate"):
            state_bits.append(f"last gate {last_validation.get('gate')}={last_validation.get('status')}")
        if pending:
            state_bits.append(f"{pending} escalation(s) pending")
        if pending:
            next_action = "python scripts/harness.py escalations"
        elif wf_state.get("workflowId") and (wf_state.get("phase") or "") in {"planned", "running", "awaiting_reduce"}:
            next_action = f"python scripts/harness.py workflow status {wf_state.get('workflowId')}"
        elif command == "status":
            next_action = 'python scripts/harness.py handoff --task "<describe the next task>"'
        else:
            next_action = "python scripts/harness.py status"
        print(f"-- ok: {command}", file=sys.stderr)
        if state_bits:
            print(f"-- state: {'; '.join(state_bits)}", file=sys.stderr)
        print(f"-- next: {next_action}", file=sys.stderr)
    except Exception:
        # The courtesy block must never break a command.
        pass

if __name__ == "__main__":
    raise SystemExit(main())
