#!/usr/bin/env bash
# POSIX-shell convenience wrapper. The canonical cross-platform entrypoint is
# `python scripts/harness-test.py` using a project/operator-managed Python.
set -euo pipefail
exec "$(dirname "$0")/../tools/agent-sync/py-run.sh" "$(dirname "$0")/harness-test.py" "$@"
