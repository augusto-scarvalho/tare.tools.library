#!/usr/bin/env python3
"""Generate deterministic release SBOM, checksums and local attestation.

This is intentionally dependency-free and does not claim external signing. It
provides reproducible supply-chain evidence that can later be wrapped by Sigstore
or an organization-specific signing pipeline.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RELEASE_DIR = ROOT / "release"
SBOM = RELEASE_DIR / "harness-sbom.cdx.json"
CHECKSUMS = RELEASE_DIR / "checksums.sha256"
ATTESTATION = RELEASE_DIR / "release-attestation.json"
SIGNATURE = RELEASE_DIR / "release-signature.sha256"
PROVENANCE = RELEASE_DIR / "slsa-provenance.intoto.jsonl"
EXTERNAL_SIGNING_PLAN = RELEASE_DIR / "external-signing-plan.json"
EXCLUDE_PARTS = {".git", ".venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules", "graphify-out"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log", ".jsonl", ".tsbuildinfo"}
RUNTIME_PREFIXES = (".harness/workflows/active/WF-", ".harness/runs/", ".harness/state-store/", ".harness/runtime/executor-circuit-")
# Class B/D content (internal journals + local coordination state): operational, never
# product. Excluded from the manifest, SBOM, and release ZIP (package-release calls
# is_private) so a client adoption never ships this repo's internal decisions or work
# trail.
#
# WHOLE DIRECTORIES, not a per-file list (2026-07-24). The per-file curation below
# named 8 files under `.harness/state/`; nine more appeared since and every one of
# them leaked into the committed inventory -- measured that day: 13 machine-local
# files listed, so the artifact could never verify on a clean clone or anyone else's
# checkout. The declared TWIN of this list, tools/state_home_sync.py, already made
# the opposite choice and said why: "Dirs are copied whole ... per-file curation here
# would rot." It was right, and the two twins had silently disagreed about what class
# B/D even means. Directory rules FAIL SAFE: a new state file is excluded by default
# instead of shipped by default.
PRIVATE_PREFIXES = (".harness/handoff/", ".harness/runtime/", ".harness/state/",
                    "dist/")  # dist/: release ZIPs this script's own packager builds
PRIVATE_FILES = {
    ".harness/context/DECISIONS.md", ".harness/context/DECISIONS_ARCHIVE.md",
    ".harness/context/HISTORY.md", ".harness/context/LEDGER_HEAD.md",
    ".mcp.json",  # local MCP server wiring, gitignored here
}
# The narrow exception to the directory rules: git-TRACKED files under those prefixes
# are product an adopter needs (baselines, the seed task board, the runtime example),
# not this machine's state. Kept explicit and tiny -- inverted curation fails safe,
# because a missing entry under-reports a shipped file instead of leaking a private one.
PRIVATE_EXCEPTIONS = {
    ".harness/runtime/executor-state.example.json",
    ".harness/state/security-baseline.json",
    ".harness/state/security-exemptions.json",
    ".harness/state/tasks.json",
}


def is_private(rel: str) -> bool:
    """The ONE class-B/D decision, read by BOTH the inventory and the release ZIP.

    package-release.py used to re-derive this from the raw tuples, which is how the
    export side and the backup side drifted apart. One predicate, two callers."""
    if rel in PRIVATE_EXCEPTIONS:
        return False
    if rel.endswith(".local.json"):  # per-user editor/agent settings, never product
        return True
    return rel in PRIVATE_FILES or rel.startswith(PRIVATE_PREFIXES)
ARTIFACTS = {"release/harness-sbom.cdx.json", "release/checksums.sha256", "release/release-attestation.json", "release/release-signature.sha256", "release/slsa-provenance.intoto.jsonl", "release/external-signing-plan.json", "EXPORT_MANIFEST.md"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def should_include(path: Path, *, include_release_artifacts: bool = False) -> bool:
    if not path.is_file():
        return False
    rel = path.relative_to(ROOT).as_posix()
    if not include_release_artifacts and rel in ARTIFACTS:
        return False
    if path.suffix in EXCLUDE_SUFFIXES:
        return False
    if any(part in EXCLUDE_PARTS for part in path.relative_to(ROOT).parts):
        return False
    if path.name.startswith(".env") and path.name != ".env.example":
        # Operator secrets (gitignored, agent-write-blocked) never enter release evidence.
        return False
    if any(rel.startswith(prefix) for prefix in RUNTIME_PREFIXES):
        return False
    if is_private(rel):
        return False
    if path.parent == ROOT and path.name.startswith("tmp-async") and path.suffix == ".py":
        return False
    return True


def file_inventory(*, include_release_artifacts: bool = False) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(ROOT.rglob("*")):
        if not should_include(path, include_release_artifacts=include_release_artifacts):
            continue
        rel = path.relative_to(ROOT).as_posix()
        rows.append({"path": rel, "size": path.stat().st_size, "sha256": sha256(path)})
    return rows


def component_type(path: str) -> str:
    if path.startswith("scripts/") or path.startswith("tools/"):
        return "library"
    if path.startswith("schemas/"):
        return "data"
    if path.startswith("docs/") or path.endswith(".md"):
        return "documentation"
    return "file"


def generate() -> dict[str, Any]:
    RELEASE_DIR.mkdir(parents=True, exist_ok=True)
    files = file_inventory(include_release_artifacts=False)
    manifest_lines = ["# Export manifest", "", "Generated by scripts/release_integrity.py from the current clean harness tree.", "", "## Files", ""]
    manifest_paths = sorted({item["path"] for item in files} | (ARTIFACTS - {"EXPORT_MANIFEST.md"}))
    manifest_lines.extend(f"- `{path}`" for path in manifest_paths)
    (ROOT / "EXPORT_MANIFEST.md").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8", newline="\n")
    components = [{
        "type": component_type(item["path"]),
        "name": item["path"],
        "version": "template",
        "hashes": [{"alg": "SHA-256", "content": item["sha256"]}],
        "properties": [{"name": "file:size", "value": str(item["size"])}],
    } for item in files]
    sbom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "serialNumber": "urn:uuid:00000000-0000-0000-0000-000000000000",
        "version": 1,
        "metadata": {
            "component": {"type": "application", "name": "universal-agent-harness", "version": "template"},
            "properties": [
                {"name": "generator", "value": "scripts/release_integrity.py"},
                {"name": "fileCount", "value": str(len(files))},
            ],
        },
        "components": components,
    }
    SBOM.write_text(json.dumps(sbom, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    checksum_lines = [f"{item['sha256']}  {item['path']}" for item in files]
    CHECKSUMS.write_text("\n".join(checksum_lines) + "\n", encoding="utf-8", newline="\n")
    provenance = {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": [{"name": item["path"], "digest": {"sha256": item["sha256"]}} for item in files],
        "predicateType": "https://slsa.dev/provenance/v1",
        "predicate": {
            "buildDefinition": {
                "buildType": "https://cmmdr.dev/universal-agent-harness/local-template-release",
                "externalParameters": {},
                "internalParameters": {"generator": "scripts/release_integrity.py"},
                "resolvedDependencies": [],
            },
            "runDetails": {
                "builder": {"id": "local:universal-agent-harness"},
                "metadata": {"invocationId": "local-deterministic", "finishedOn": "1970-01-01T00:00:00Z"},
            },
        },
    }
    PROVENANCE.write_text(json.dumps(provenance, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    signing_plan = {
        "schemaVersion": "1.0",
        "purpose": "downstream external signing handoff",
        "networkRequired": True,
        "templateDoesNotInvokeExternalTools": True,
        "inputs": {
            "sbom": "release/harness-sbom.cdx.json",
            "checksums": "release/checksums.sha256",
            "attestation": "release/release-attestation.json",
            "provenance": "release/slsa-provenance.intoto.jsonl",
            "localSignature": "release/release-signature.sha256",
            "releaseArchive": "<release-zip>"
        },
        "commands": [
            "python scripts/release_integrity.py verify",
            "cosign sign-blob --bundle release/cosign.bundle --output-signature release/cosign.sig <release-zip>",
            "cosign attest-blob --predicate release/slsa-provenance.intoto.jsonl --type slsaprovenance <release-zip>",
            "slsa-verifier verify-artifact --provenance-path release/slsa-provenance.intoto.jsonl <release-zip>"
        ],
        "notes": [
            "This template emits deterministic local evidence only.",
            "External Sigstore/cosign/SLSA commands are handoff guidance and must run in the adopter release pipeline with its own identities and policies."
        ]
    }
    EXTERNAL_SIGNING_PLAN.write_text(json.dumps(signing_plan, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    attestation = {
        "schemaVersion": "1.0",
        "subject": "universal-agent-harness",
        "predicateType": "local-release-integrity",
        "predicate": {
            "generator": "scripts/release_integrity.py",
            "fileCount": len(files),
            "sbomPath": "release/harness-sbom.cdx.json",
            "checksumsPath": "release/checksums.sha256",
            "provenancePath": "release/slsa-provenance.intoto.jsonl",
            "externalSigningPlanPath": "release/external-signing-plan.json",
            "externalSigningPlanSha256": sha256(EXTERNAL_SIGNING_PLAN),
            "sbomSha256": sha256(SBOM),
            "checksumsSha256": sha256(CHECKSUMS),
            "provenanceSha256": sha256(PROVENANCE),
            "python": platform.python_version(),
            "platform": platform.system(),
            "note": "Unsigned local SLSA-shaped provenance; wrap with Sigstore/cosign in downstream release pipeline for external provenance.",
        },
    }
    ATTESTATION.write_text(json.dumps(attestation, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    signature_material = "\n".join([sha256(SBOM), sha256(CHECKSUMS), sha256(PROVENANCE), sha256(EXTERNAL_SIGNING_PLAN), sha256(ATTESTATION)]) + "\n"
    signature = hashlib.sha256(signature_material.encode("utf-8")).hexdigest()
    SIGNATURE.write_text(f"{signature}  local-release-integrity\n", encoding="utf-8", newline="\n")
    return {"files": len(files), "sbom": str(SBOM.relative_to(ROOT)), "checksums": str(CHECKSUMS.relative_to(ROOT)), "provenance": str(PROVENANCE.relative_to(ROOT)), "externalSigningPlan": str(EXTERNAL_SIGNING_PLAN.relative_to(ROOT)), "attestation": str(ATTESTATION.relative_to(ROOT)), "signature": str(SIGNATURE.relative_to(ROOT))}


def tree_divergence() -> dict[str, list[str]]:
    """How the committed inventory differs from the tree, split BY KIND — one
    derivation with two readers: `verify()` (release-time, where every kind is an
    error) and `doctor` (daily, where only some kinds are actionable).

      missing    — in the tree, absent from the inventory: never recorded at all
      extra      — in the inventory, gone from the tree
      mismatched — in both, different bytes: development since the last `generate`
      malformed  — unparseable checksum lines

    The split IS the point. Collapsing these into one boolean is what made `doctor`
    yellow after every commit touching a tracked file (measured 2026-07-24).
    """
    actual = {item["path"]: item["sha256"] for item in file_inventory(include_release_artifacts=False)}
    listed: dict[str, str] = {}
    malformed: list[str] = []
    for line in CHECKSUMS.read_text(encoding="utf-8", errors="ignore").splitlines():
        if not line.strip():
            continue
        try:
            digest, name = line.split("  ", 1)
        except ValueError:
            malformed.append(f"malformed checksum line: {line[:80]}")
            continue
        listed[name] = digest
    return {"missing": sorted(set(actual) - set(listed)),
            "extra": sorted(set(listed) - set(actual)),
            "mismatched": sorted(p for p, d in actual.items() if listed.get(p) and listed[p] != d),
            "malformed": malformed}


def staleness_verdict(divergence: dict[str, list[str]],
                      internal_errors: "list[str] | tuple[str, ...]" = ()) -> tuple[str, str]:
    """The DAILY verdict for `doctor` — a different question from `verify()`.

    `verify()` asks a RELEASE-time question: do these artifacts describe this exact
    tree? Between releases the honest answer is "no", so reporting it daily turned the
    check yellow after every commit that touched a tracked file (measured 2026-07-24:
    9 files, every one of them that same day's own work). An alarm that fires on
    ordinary work is one people learn to skip — the same "an alarm nobody trusts is a
    disabled alarm" that graph-refresh-decoupled.md rule 6 is built on. This check was
    added on 2026-07-24 to make staleness visible; a week of yellow would have made it
    invisible again, by habit instead of by absence.

    Daily-actionable is narrower, and it is precisely the kinds that mean the inventory
    stopped TRACKING the repo rather than merely lagging it:

      missing/extra  the inventory does not know this tree's SHAPE — the 2026-07-24
                     incident: 631 files listed for a tree of 1183, 552 never recorded,
                     8 days unnoticed. WARN.
      internal       artifacts disagreeing with each other (attestation hash, malformed
                     provenance). Corruption, actionable now. WARN.
      mismatched     content moved since the last `generate`. That is development.
                     Counted in the detail so it stays visible; never warned.

    Still WARN-only and still not a commit gate: making every commit that adds a file
    regenerate a release artifact is the exact coupling the post-commit graph refresh
    had to be undone for.
    """
    missing = divergence.get("missing") or []
    extra = divergence.get("extra") or []
    problems = list(internal_errors) + list(divergence.get("malformed") or [])
    if missing or extra:
        problems.append(f"inventory does not describe the tree's shape: {len(missing)} "
                        f"file(s) never recorded, {len(extra)} listed but gone")
    if problems:
        return "warn", ("; ".join(problems)[:170]
                        + " | refresh: python scripts/release_integrity.py generate")
    drift = len(divergence.get("mismatched") or [])
    if drift:
        return "ok", (f"inventory covers the tree; {drift} file(s) changed since it was "
                      f"generated (expected between releases)")
    return "ok", "release inventory matches the tree"


def verify(*, include_tree: bool = True) -> tuple[bool, list[str]]:
    """Release-time integrity. `include_tree=False` asks only whether the artifacts
    agree with EACH OTHER — the half that is actionable on any ordinary day."""
    errors: list[str] = []
    for path in [SBOM, CHECKSUMS, PROVENANCE, EXTERNAL_SIGNING_PLAN, ATTESTATION, SIGNATURE]:
        if not path.exists():
            errors.append(f"missing {path.relative_to(ROOT)}")
    if errors:
        return False, errors
    try:
        json.loads(SBOM.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid SBOM JSON: {exc}")
    try:
        att = json.loads(ATTESTATION.read_text(encoding="utf-8"))
        predicate = att.get("predicate", {}) if isinstance(att, dict) else {}
        if predicate.get("sbomSha256") != sha256(SBOM):
            errors.append("attestation sbomSha256 mismatch")
        if predicate.get("checksumsSha256") != sha256(CHECKSUMS):
            errors.append("attestation checksumsSha256 mismatch")
        if predicate.get("provenanceSha256") != sha256(PROVENANCE):
            errors.append("attestation provenanceSha256 mismatch")
        if predicate.get("externalSigningPlanSha256") != sha256(EXTERNAL_SIGNING_PLAN):
            errors.append("attestation externalSigningPlanSha256 mismatch")
    except Exception as exc:
        errors.append(f"invalid attestation JSON: {exc}")
    try:
        prov = json.loads(PROVENANCE.read_text(encoding="utf-8"))
        if prov.get("_type") != "https://in-toto.io/Statement/v1":
            errors.append("invalid provenance statement type")
        if prov.get("predicateType") != "https://slsa.dev/provenance/v1":
            errors.append("invalid provenance predicateType")
    except Exception as exc:
        errors.append(f"invalid provenance JSON: {exc}")
    try:
        plan = json.loads(EXTERNAL_SIGNING_PLAN.read_text(encoding="utf-8"))
        if not isinstance(plan.get("commands"), list) or not plan.get("commands"):
            errors.append("external signing plan has no commands")
        if "cosign" not in json.dumps(plan):
            errors.append("external signing plan missing cosign handoff")
    except Exception as exc:
        errors.append(f"invalid external signing plan JSON: {exc}")
    expected_signature_material = "\n".join([sha256(SBOM), sha256(CHECKSUMS), sha256(PROVENANCE), sha256(EXTERNAL_SIGNING_PLAN), sha256(ATTESTATION)]) + "\n"
    expected_signature = hashlib.sha256(expected_signature_material.encode("utf-8")).hexdigest()
    signature_text = SIGNATURE.read_text(encoding="utf-8", errors="ignore").strip().split()
    if not signature_text or signature_text[0] != expected_signature:
        errors.append("release signature mismatch")
    if include_tree:
        div = tree_divergence()
        errors.extend(div["malformed"])
        for kind, label in (("missing", "checksums missing"), ("extra", "checksums extra"),
                            ("mismatched", "checksums mismatch")):
            if div[kind]:
                errors.append(f"{label}: " + ", ".join(div[kind][:5]))
    return not errors, errors



def external_preflight(*, strict: bool = False) -> tuple[bool, dict[str, Any]]:
    """Check downstream signing/provenance prerequisites without invoking them.

    The reusable template must remain dependency-free and offline-safe. This
    preflight gives product release pipelines a machine-readable readiness report
    for optional external signing tools while keeping local validation non-blocking.
    """
    plan_ok = EXTERNAL_SIGNING_PLAN.exists()
    plan: dict[str, Any] = {}
    errors: list[str] = []
    if plan_ok:
        try:
            plan = json.loads(EXTERNAL_SIGNING_PLAN.read_text(encoding="utf-8"))
        except Exception as exc:
            plan_ok = False
            errors.append(f"invalid external signing plan JSON: {exc}")
    else:
        errors.append("missing release/external-signing-plan.json")

    tools = {
        "cosign": shutil.which("cosign"),
        "slsa-verifier": shutil.which("slsa-verifier"),
    }
    tool_status = {name: {"available": bool(path), "path": path or None} for name, path in tools.items()}
    recommended_env = [
        "GITHUB_ACTIONS",
        "ACTIONS_ID_TOKEN_REQUEST_URL",
        "ACTIONS_ID_TOKEN_REQUEST_TOKEN",
    ]
    env_status = {name: bool(os.environ.get(name)) for name in recommended_env}
    required_inputs = [
        SBOM,
        CHECKSUMS,
        ATTESTATION,
        SIGNATURE,
        PROVENANCE,
        EXTERNAL_SIGNING_PLAN,
    ]
    input_status = {path.relative_to(ROOT).as_posix(): path.exists() for path in required_inputs}
    local_ok, local_errors = verify()
    errors.extend(local_errors)
    ready = bool(local_ok and plan_ok and all(item["available"] for item in tool_status.values()))
    if strict and not ready:
        if not all(item["available"] for item in tool_status.values()):
            missing = [name for name, item in tool_status.items() if not item["available"]]
            errors.append("missing external signing tools: " + ", ".join(missing))
    report = {
        "schemaVersion": "1.0",
        "strict": strict,
        "ok": bool(local_ok and plan_ok and (ready or not strict)),
        "readyForExternalSigning": ready,
        "localIntegrityOk": local_ok,
        "networkRequired": True,
        "templateInvokesExternalTools": False,
        "tools": tool_status,
        "recommendedEnvironment": env_status,
        "inputs": input_status,
        "planCommandCount": len(plan.get("commands", [])) if isinstance(plan.get("commands"), list) else 0,
        "errors": errors,
    }
    return bool(report["ok"]), report

def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or verify release integrity artifacts")
    parser.add_argument("command", choices=["generate", "verify", "external-preflight"], nargs="?", default="generate")
    parser.add_argument("--strict", action="store_true", help="fail if optional external signing tools are unavailable")
    args = parser.parse_args()
    if args.command == "generate":
        print(json.dumps(generate(), indent=2))
        return 0
    if args.command == "external-preflight":
        ok, report = external_preflight(strict=args.strict)
        print(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
        return 0 if ok else 1
    ok, errors = verify()
    print(json.dumps({"ok": ok, "errors": errors}, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
