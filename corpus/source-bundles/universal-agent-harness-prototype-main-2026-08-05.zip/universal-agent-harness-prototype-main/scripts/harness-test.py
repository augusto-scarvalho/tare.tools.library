#!/usr/bin/env python3
"""Cross-platform wrapper for the Universal Agent Harness validation gate.

Prefer this entrypoint when a shell is not guaranteed. Shell wrappers such as
`scripts/harness-test.sh` are convenience adapters only.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import spec_test_gate  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(spec_test_gate.main(sys.argv[1:]))
