#!/usr/bin/env python3
"""Language-agnostic harness validation gate.

The harness core is always validated. Project-specific commands are configured
in .harness/project.json under validation.<gate>.commands. Auto-detection is
advisory by default and never runs unknown commands unless a project explicitly
sets runDetected=true for that gate.
"""
from __future__ import annotations

import argparse
import datetime as dt
import ast
import json
import os
import re
import subprocess
import shutil
import shlex
import signal
import sys
import tempfile
import time
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import importlib.util
from pathlib import Path
from typing import Any

from harness_lib import processes, engineering_guardrails, baseline_catalog, graphify_code_ast, protected_files, deprecation_hygiene, fixture_liveness, spec_conformance, security_baseline, security_directives, security_routing, spawn_ratchet, control_liveness, sandbox_spawn, ritual_map
from harness_lib import gate_fixtures_workflow, gate_fixtures_trace, gate_fixtures_graphify, gate_fixtures_isolation
from harness_lib import gate_generic, scenario_verdict, workflow_plan
from harness_lib import gate_checks_content
from harness_lib import gate_checks_policy
from harness_lib import gate_checks_release
from harness_lib import gate_checks_structure
from harness_lib import log_rotation
from harness_lib import scenario_isolation, gate_scenario_order

# Windows consoles default to cp1252, which cannot encode the ✓/✗ marks.
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[1]
HARNESS = ROOT / ".harness"
PROJECT = HARNESS / "project.json"
QUALITY = HARNESS / "state" / "quality-state.json"
RUNS = HARNESS / "runs" / "validation-results.jsonl"
GATES = ["smoke", "spec-pack", "commit", "feature", "release", "product-release", "coverage", "graph", "workflow", "soak", "scenarios"]

# TE.1: quiet mode. Env HARNESS_TEST_QUIET=1 or --quiet suppress ✓/skip lines
# (re-consumed as noise in implementer contexts); ✗ fails always print and a
# counted gate summary is added. Default output stays byte-identical.
QUIET = os.environ.get("HARNESS_TEST_QUIET") == "1"

def read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


# SPEC-101: remediation by check-name prefix, appended to fail lines so a red
# gate diagnoses itself. Map only entries with a concrete command or policy
# pointer; unknown prefixes keep today's output.
REMEDIATION = {
    "protected-files:": "review the diff first; if intentional: python tools/hooks/protect_canonical_files.py snapshot",
    "release-hygiene:": "remove stray/test artifacts named in the detail; if the change is intentional: python scripts/release_integrity.py generate",
    "runtime-portability:": "remove the forbidden term from the named file (policy: docs/RUNTIME_PORTABILITY.md)",
    "control-liveness": "restore the control, or update PROBES in control_liveness.py in the same commit as the refactor",
}


def result(name: str, status: str, detail: str = "",
           duration_ms: float | None = None) -> dict[str, str]:
    mark = {"pass": "✓", "fail": "✗", "skip": "-"}.get(status, "?")
    line = f"{mark} {name}: {status}" + (f" — {detail}" if detail else "")
    if status == "fail":
        fix = next((cmd for prefix, cmd in REMEDIATION.items() if name.startswith(prefix)), "")
        if fix:
            line += f" | fix: {fix}"
    if not (QUIET and status in ("pass", "skip")):
        print(line, flush=True)
    row = {"name": name, "status": status, "detail": detail}
    if duration_ms is not None:  # perf-metrics rung: machine-readable wall time
        row["durationMs"] = round(float(duration_ms), 1)
    return row



FIXTURE_DIRS = [
    "tmp-workflow-write-fixture",
    "tmp-workflow-write-validation-fixture",
]


def fixture_timeout() -> int:
    return int(os.environ.get("HARNESS_FIXTURE_TIMEOUT", "45"))



def run_bounded_command(cmd: list[str] | str, *, timeout: int, cleanup_on_timeout: bool = False, **kwargs: Any) -> subprocess.CompletedProcess[str]:
    """Run a subprocess with process-tree cleanup on timeout.

    `subprocess.run(..., timeout=...)` only guarantees cleanup for the direct
    child. Project validation commands and fixture helpers can spawn their own
    children, so this helper always starts an isolated process group/session and
    signals the whole tree before returning a synthetic timeout result.
    """
    kwargs.setdefault("cwd", ROOT)
    kwargs.setdefault("text", True)
    kwargs.setdefault("stdout", subprocess.PIPE)
    kwargs.setdefault("stderr", subprocess.PIPE)
    if os.name == "nt":
        kwargs.setdefault("creationflags", getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    else:
        kwargs.setdefault("start_new_session", True)
    input_data = kwargs.pop("input", None)
    if input_data is not None:
        kwargs.setdefault("stdin", subprocess.PIPE)
    proc = subprocess.Popen(cmd, **kwargs)  # type: ignore[arg-type]
    try:
        stdout, stderr = proc.communicate(input=input_data, timeout=timeout)
        return subprocess.CompletedProcess(cmd, proc.returncode, stdout=stdout or "", stderr=stderr or "")
    except subprocess.TimeoutExpired:
        processes.signal_process_tree(proc.pid, signal.SIGTERM)
        try:
            stdout, stderr = proc.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            processes.signal_process_tree(proc.pid, getattr(signal, "SIGKILL", signal.SIGTERM))
            try:
                stdout, stderr = proc.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                stdout, stderr = "", ""
        stdout_s = processes.decode_pipe(stdout)
        stderr_s = processes.decode_pipe(stderr)
        detail = stderr_s or stdout_s or ""
        if cleanup_on_timeout:
            cleanup_test_artifacts()
        return subprocess.CompletedProcess(cmd, 124, stdout=stdout_s, stderr=f"timeout after {timeout}s" + (f"; {detail[-500:]}" if detail else ""))



def run_fixture_command(cmd: list[str] | str, *, timeout: int | None = None, **kwargs: Any) -> subprocess.CompletedProcess[str]:
    """Run fixture subprocesses with bounded time and hermetic process cleanup.

    Some workflow fixtures intentionally launch detached async supervisors.  A
    plain parent-process kill can leave those children alive, keeping pipes open
    or mutating `.harness/workflows/active` after the fixture directory was
    deleted.  The fixture runner therefore terminates the process group and any
    discoverable descendants before returning a synthetic timeout result.
    """
    return run_bounded_command(cmd, timeout=timeout or fixture_timeout(), cleanup_on_timeout=True, **kwargs)


def mark_fixture_workflow(wfid: str, label: str) -> None:
    wf_path = HARNESS / "workflows" / "active" / wfid / "workflow.json"
    wf = read_json(wf_path, {}) or {}
    if isinstance(wf, dict):
        wf["testFixture"] = True
        wf["testFixtureLabel"] = label
        write_json(wf_path, wf)


def write_sample_worker_result(wfid: str, worker: dict[str, Any]) -> None:
    """Write a compact valid WORKER_RESULT so token audits can measure observed output."""
    worker_id = str(worker.get("workerId"))
    result_rel = str(worker.get("resultPath") or f"workers/{worker_id}.result.json")
    payload = {
        "workflowId": wfid,
        "workerId": worker_id,
        "workerRole": str(worker.get("workerRole", "fixture-worker")),
        "status": "done",
        "summary": "Fixture output used to verify observed token accounting for workflow result payloads.",
        "itemsAnalyzed": [str(worker.get("unitId", worker_id))],
        "findings": [],
        "sourceFilesVerified": [str(worker.get("promptPath", ""))],
        "graphify": {"used": False, "reason": "fixture"},
    }
    write_json(HARNESS / "workflows" / "active" / wfid / result_rel, payload)


def is_fixture_workflow(path: Path) -> bool:
    wf_path = path / "workflow.json"
    # Incomplete WF-* directories are always stale test residue for this harness
    # validation context. Keep cleanup fail-closed so interrupted fixtures cannot
    # leak empty active workflow shells into release hygiene checks.
    if not wf_path.exists():
        return True
    data = read_json(wf_path, {}) or {}
    if not isinstance(data, dict):
        return True
    if data.get("testFixture") is True:
        return True
    task = str(data.get("task", "")).lower()
    return "fixture" in task



def cleanup_fixture_workflow(workflow_dir: Path) -> None:
    """Cancel fixture runtime processes before removing their state directory.

    Identity-guarded (processes.filter_stale_records): a recorded PID re-issued
    by Windows to an innocent live process must never be killed by number."""
    processes.cleanup_recorded_tree(workflow_dir, "spec_test_gate.cleanup_fixture_workflow")
    shutil.rmtree(workflow_dir, ignore_errors=True)

def cleanup_test_artifacts() -> None:
    fixture_liveness.cleanup_transient_market_fixture_files(ROOT)
    for name in FIXTURE_DIRS:
        shutil.rmtree(ROOT / name, ignore_errors=True)
    # Fixture workspaces must not inherit previous validation event logs; they can create
    # confusing stale runtime state and make controlled-write checks slower/noisier.
    # SPEC-109: before wiping, compact supervision events (escalation raises/
    # resolves, self-review findings) into the durable state ledger — wiping the
    # log wholesale used to erase human decisions on every gate run.
    runs = HARNESS / "runs"
    if runs.exists():
        compacted = False
        try:
            from harness_lib import escalations_lib
            escalations_lib.compact_supervision_events(runs / "events.jsonl", HARNESS / "state" / "escalations.json")
            compacted = True
        except Exception:
            pass  # compaction must never block cleanup; list_escalations also compacts on read
        for pattern in ["*.jsonl", "*.log"]:
            for file in runs.glob(pattern):
                # ledger-anomaly root fix (2026-07-15): un-compacted events carry human
                # escalation resolves — wiping them on a failed compaction is data loss
                # (resolvedIds 103 -> 99). Keep events.jsonl until a compaction succeeds.
                if not compacted and file.name == "events.jsonl":
                    continue
                if file.name in ("gate-perf.jsonl", "reckon-results.jsonl", PARTIAL_LOG_NAME, "gate-parallel-aborts.jsonl", "kill-audit.jsonl"):  # durable ledgers (log_rotation-rotated), never gate-wiped: reckon-results is the reckon gate's hold-immune fallback — wiping it here is what made the v1 rescue ineffective live (reckon-eaten-by-gate-hold v2); the last two are the 2026-08-03 hard-kill survivors (partial perf stream + abort reasons) and this cleanup runs at the START of the very run that must read them; kill-audit is the kill-decision forensic ledger (owner data window 2026-07-29+) — this wipe zeroed it on EVERY gate for 5 days
                    continue
                try:
                    file.unlink()
                except OSError:
                    # WinError 32 (2026-07-17): a live detached route-dispatch worker
                    # holds its .log open for write — skipping one held log beats
                    # crashing the whole gate cleanup over it.
                    pass
    runtime = HARNESS / "runtime"
    if runtime.exists():
        for file in runtime.glob("executor-circuit-fixture*.json"):
            try:
                file.unlink()
            except FileNotFoundError:
                pass
    # SPEC-109: ignore_errors=True swallowed transient OneDrive locks and left
    # empty dirs behind (release-hygiene trips on them) — retry, then give up quietly.
    # I5/MF.4 fix: discover cache + enrichment sidecars are operator data bought
    # with API tokens, not test artifacts — wiping graphify-out wholesale erased
    # them on every gate run. Spare them; delete the rest.
    # "targets" (SPEC-110): per-target knowledge/adapter state is operator data too.
    keep_names = {"discover-cache.json", "docs-enrichment.json", "image-enrichment.json", "targets"}
    try:
        from harness_lib.common import rmtree_robust
        rmtree_robust(HARNESS / "state-store")
        graph_dir = ROOT / "graphify-out"
        if graph_dir.exists():
            for child in graph_dir.iterdir():
                if child.name in keep_names:
                    continue
                if child.is_dir():
                    rmtree_robust(child)
                else:
                    child.unlink(missing_ok=True)
    except OSError:
        shutil.rmtree(HARNESS / "state-store", ignore_errors=True)
    executors_path = HARNESS / "routing" / "executors.json"
    executors = read_json(executors_path, {}) or {}
    if isinstance(executors, dict) and isinstance(executors.get("executors"), dict):
        changed = False
        for fixture_executor in ["fixture", "fixture-async", "fixture-async-slow"]:
            if fixture_executor in executors["executors"]:
                executors["executors"].pop(fixture_executor, None)
                changed = True
        if changed:
            write_json(executors_path, executors)
    active = HARNESS / "workflows" / "active"
    if active.exists():
        for wf in active.glob("WF-*"):
            if is_fixture_workflow(wf):
                cleanup_fixture_workflow(wf)
        active.mkdir(parents=True, exist_ok=True)
        (active / ".gitkeep").touch()


def call_harness_function(name: str, *args: Any, **kwargs: Any) -> Any:
    spec = importlib.util.spec_from_file_location("harness_runtime_for_tests", ROOT / "scripts" / "harness.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load scripts/harness.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return getattr(module, name)(*args, **kwargs)

def project_config() -> dict[str, Any]:
    data = read_json(PROJECT, {}) or {}
    return data if isinstance(data, dict) else {}


def command_config(project: dict[str, Any], gate: str) -> tuple[list[str], bool, bool, str]:
    """Return commands, required, run_detected, description for a gate.

    Supports legacy forms:
    - validation.gate = "cmd"
    - validation.gate = ["cmd"]
    and preferred form:
    - validation.gate = {commands: [], required: false, runDetected: false}
    """
    raw = (project.get("validation") or {}).get(gate, []) if isinstance(project.get("validation"), dict) else []
    required = False
    run_detected = False
    description = ""
    if isinstance(raw, str):
        commands = [raw]
    elif isinstance(raw, list):
        commands = [str(x) for x in raw]
    elif isinstance(raw, dict):
        commands_raw = raw.get("commands", [])
        if isinstance(commands_raw, str):
            commands = [commands_raw]
        elif isinstance(commands_raw, list):
            commands = [str(x) for x in commands_raw]
        else:
            commands = []
        required = bool(raw.get("required", False))
        run_detected = bool(raw.get("runDetected", False))
        description = str(raw.get("description", ""))
    else:
        commands = []
    return [c for c in commands if c.strip()], required, run_detected, description


def check_required_files() -> list[dict[str, str]]:
    required = [
        "AGENTS.md",
        ".harness/project.json",
        ".harness/context/CONTEXT.md",
        ".harness/context/STATE.md",
        ".harness/context/NEXT_STEPS.md",
        ".harness/routing/task-profiles.json",
        ".harness/routing/executors.json",
        ".harness/prompts/subagent-contract.md",
        "scripts/harness.py",
        "scripts/harness-test.py",
        "scripts/package-release.py",
        "scripts/harness-test.sh",
        "docs/RUNTIME_PORTABILITY.md",
        "docs/GRAPHIFY_INTEGRATION.md",
        "docs/AGENTIC_WORKFLOWS.md",
        ".harness/workflows/WORKFLOWS.md",
        ".harness/workflows/workflow-profiles.json",
        "schemas/workflow.schema.json",
        "schemas/worker-result.schema.json",
        "schemas/reduce-result.schema.json",
        "tools/hooks/graphify_search_guard.py",
    ]
    out: list[dict[str, str]] = []
    for item in required:
        p = ROOT / item
        out.append(result(f"required:{item}", "pass" if p.exists() else "fail", "exists" if p.exists() else "missing"))
    return out


# gate-lines-burndown r1: the six self-contained structure/syntax checks live in
# harness_lib.gate_checks_structure (bound with _POLICY_ENV below); call sites in
# main() are unchanged.
from harness_lib.gate_checks_structure import check_json_syntax, check_yaml_syntax, check_python_compile, check_directory_guides, check_runtime_portability, check_markdown_links


def check_static_integrity() -> list[dict[str, str]]:
    """Catch module-level hygiene regressions that py_compile cannot see."""
    out: list[dict[str, str]] = []
    script_files = [ROOT / "scripts" / "harness.py", ROOT / "scripts" / "spec_test_gate.py", ROOT / "scripts" / "package-release.py"]
    harness_lib = ROOT / "scripts" / "harness_lib"
    if harness_lib.exists():
        script_files.extend(sorted(harness_lib.rglob("*.py")))

    duplicate_details: list[str] = []
    no_timeout_details: list[str] = []
    duplicate_dict_key_details: list[str] = []
    for path in script_files:
        if not path.exists():
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as exc:
            out.append(result(f"static-integrity:{path.relative_to(ROOT)}:parse", "fail", str(exc)))
            continue
        seen: dict[str, int] = {}
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                previous = seen.get(node.name)
                if previous is not None:
                    duplicate_details.append(f"{path.relative_to(ROOT)}:{node.name} line {previous} and {node.lineno}")
                seen[node.name] = node.lineno
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            is_subprocess_run = isinstance(func, ast.Attribute) and func.attr == "run" and isinstance(func.value, ast.Name) and func.value.id == "subprocess"
            if not is_subprocess_run:
                continue
            has_timeout = any(kw.arg == "timeout" for kw in node.keywords)
            if not has_timeout:
                no_timeout_details.append(f"{path.relative_to(ROOT)}:{node.lineno}")
        for node in ast.walk(tree):
            if not isinstance(node, ast.Dict):
                continue
            literal_keys: dict[str, int] = {}
            for key in node.keys:
                if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
                    continue
                previous = literal_keys.get(key.value)
                if previous is not None:
                    duplicate_dict_key_details.append(f"{path.relative_to(ROOT)}:{key.value!r} line {previous} and {getattr(key, 'lineno', '?')}")
                literal_keys[key.value] = getattr(key, 'lineno', 0)
    out.append(result("static-integrity:duplicate-top-level-symbols", "fail" if duplicate_details else "pass", "; ".join(duplicate_details[:10]) if duplicate_details else "none"))
    out.append(result("static-integrity:subprocess-run-timeouts", "fail" if no_timeout_details else "pass", "; ".join(no_timeout_details[:10]) if no_timeout_details else "all subprocess.run calls bounded"))
    try:  # QA.1: bind()-env completeness lives behind harness_lib (guardrails note)
        from harness_lib import bind_completeness
        bind_details = bind_completeness.check_bind_completeness(ROOT)
    except Exception as exc:  # checker trouble must be visible, not silent
        bind_details = [f"checker error: {type(exc).__name__}: {exc}"]
    out.append(result("static-integrity:bind-env-completeness", "fail" if bind_details else "pass",
                      "; ".join(bind_details[:10]) if bind_details else "every bind() free name is satisfied by its binder env"))
    out.append(result("static-integrity:duplicate-literal-dict-keys", "fail" if duplicate_dict_key_details else "pass", "; ".join(duplicate_dict_key_details[:10]) if duplicate_dict_key_details else "no duplicate literal dict keys"))

    modular_errors: list[str] = []
    required_modules = (
        "__init__.py", "common.py", "token_economics.py", "workflow_token_audit.py",
        "workflow_reduce.py", "workflow_plan.py", "tracing.py", "state_store.py", "observability_exporters.py",
        "processes.py", "controlled_writes.py", "async_runtime.py", "graphify_adapter.py",
        "handoff.py", "workflow_ids.py", "workflow_state.py", "engineering_guardrails.py",
        "baseline_catalog.py", "graphify_code_ast.py")
    modular_errors.extend(f"missing scripts/harness_lib/{name}" for name in required_modules
                          if not (harness_lib / name).exists())
    harness_text = (ROOT / "scripts" / "harness.py").read_text(encoding="utf-8", errors="ignore")
    # MF.1 r2: the delegation boundaries live across the router and its extracted
    # workflow modules — assert over the union.
    for _extracted in ("workflow_writes.py", "workflow_lifecycle.py"):
        harness_text += (ROOT / "scripts" / "harness_lib" / _extracted).read_text(encoding="utf-8", errors="ignore") if (ROOT / "scripts" / "harness.py").exists() else ""
    if "from harness_lib.common import" not in harness_text:
        modular_errors.append("scripts/harness.py does not import common helper boundary")
    if "from harness_lib import token_economics" not in harness_text and "from harness_lib import token_economics, tracing" not in harness_text:
        modular_errors.append("scripts/harness.py does not import token_economics boundary")
    if "tracing" not in harness_text or "workflow_trace" not in harness_text:
        modular_errors.append("scripts/harness.py does not expose trace boundary")
    if "state_store" not in harness_text or "workflow_state_store" not in harness_text:
        modular_errors.append("scripts/harness.py does not expose state-store runtime boundary")
    if "observability_exporters" not in harness_text or "workflow_trace_export" not in harness_text:
        modular_errors.append("scripts/harness.py does not expose trace-export boundary")
    if "harness_lib.processes" not in harness_text or "run_process_tree_bounded" not in harness_text:
        modular_errors.append("scripts/harness.py does not import process-tree helper boundary")
    if "controlled_writes" not in harness_text or "controlled_writes.compute_write_locks" not in harness_text:
        modular_errors.append("scripts/harness.py does not delegate controlled-write policy to harness_lib.controlled_writes")
    if "async_runtime" not in harness_text or "async_runtime.bind" not in harness_text or "workflow_async_run_one_worker" in harness_text:
        modular_errors.append("scripts/harness.py does not delegate async workflow runtime to harness_lib.async_runtime")
    if "workflow_token_audit_lib" not in harness_text or "workflow_token_audit_lib.audit_workflow" not in harness_text:
        modular_errors.append("scripts/harness.py does not delegate workflow token-audit rendering to harness_lib.workflow_token_audit")
    if "workflow_reduce_lib" not in harness_text or "workflow_reduce_lib.bind" not in harness_text or "def workflow_reduce(" in harness_text or "def validate_reviewer_result(" in harness_text:
        modular_errors.append("scripts/harness.py does not delegate reducer/reviewer helpers to harness_lib.workflow_reduce")
    if "workflow_plan_lib" not in harness_text or "workflow_plan_lib.bind" not in harness_text or "def plan_workflow(" in harness_text or "def _compile_workflow_plan(" in harness_text:
        modular_errors.append("scripts/harness.py does not delegate workflow-plan compilation to harness_lib.workflow_plan")
    if "graphify_adapter" not in harness_text or "group_graphify_paths" not in harness_text:
        modular_errors.append("scripts/harness.py does not import graphify adapter boundary")
    if "graphify_code_ast" not in harness_text or "graph-build-code-ast" not in harness_text:
        modular_errors.append("scripts/harness.py does not expose Graphify code AST graph boundary")
    if "handoff_lib" not in harness_text or "handoff_lib.generate_handoff" not in harness_text:
        modular_errors.append("scripts/harness.py does not delegate handoff generation to harness_lib.handoff")
    if "workflow_ids" not in harness_text or "allocate_workflow_id" not in harness_text:
        modular_errors.append("scripts/harness.py does not delegate workflow id allocation to harness_lib.workflow_ids")
    if "workflow_state_lib" not in harness_text or "workflow_state_lib.summary" not in harness_text:
        modular_errors.append("scripts/harness.py does not delegate workflow state mirroring to harness_lib.workflow_state")
    try:
        harness_lines = len(harness_text.splitlines())
        if harness_lines > 5400:
            modular_errors.append(f"scripts/harness.py exceeded calibrated modularization slice limit: {harness_lines} lines")
    except Exception:
        pass
    out.append(result("static-integrity:harness-modular-boundary", "fail" if modular_errors else "pass", "; ".join(modular_errors[:10]) if modular_errors else "core helper modules extracted and guarded"))

    # Runtime/schema contract drift check: workflow ids were hardened with
    # microseconds after earlier schema versions accepted second-level ids only.
    # Keep this explicit so future id-format changes update schemas together.
    schema_id_errors: list[str] = []
    try:
        # Keep this check static/dependency-free. Earlier versions imported the
        # harness runtime to generate sample ids, but product-release gates must
        # not depend on runtime side effects or fixture state. These samples
        # represent the current documented runtime format.
        wfid = "WF-20260707-181201-069561"
        agid = "AG-20260707-181201-069561"
        workflow_schema = read_json(ROOT / "schemas" / "workflow.schema.json", {}) or {}
        async_task_schema = read_json(ROOT / "schemas" / "async-task.schema.json", {}) or {}
        async_group_schema = read_json(ROOT / "schemas" / "async-group.schema.json", {}) or {}
        await_schema = read_json(ROOT / "schemas" / "await-result.schema.json", {}) or {}
        checks = [
            ("workflow.schema.workflowId", workflow_schema.get("properties", {}).get("workflowId", {}).get("pattern"), wfid),
            ("async-task.workflowId", async_task_schema.get("properties", {}).get("workflowId", {}).get("pattern"), wfid),
            ("async-task.asyncGroupId", async_task_schema.get("properties", {}).get("asyncGroupId", {}).get("pattern"), agid),
            ("async-group.workflowId", async_group_schema.get("properties", {}).get("workflowId", {}).get("pattern"), wfid),
            ("async-group.asyncGroupId", async_group_schema.get("properties", {}).get("asyncGroupId", {}).get("pattern"), agid),
            ("await-result.workflowId", await_schema.get("properties", {}).get("workflowId", {}).get("pattern"), wfid),
        ]
        for label, pattern, sample in checks:
            if not isinstance(pattern, str) or not re.match(pattern, sample):
                schema_id_errors.append(f"{label} pattern does not accept {sample}")
    except Exception as exc:
        schema_id_errors.append(str(exc))
    out.append(result("static-integrity:workflow-async-id-schema-patterns", "fail" if schema_id_errors else "pass", "; ".join(schema_id_errors[:10]) if schema_id_errors else "runtime ids match schemas"))

    stale_doc_terms = [
        "future lock/worktree/merge-plan layer",
        "does not implement parallel source editing",
        "Parallel writes remain intentionally unsupported",
        "WF-YYYYMMDD-HHMMSS --",
    ]
    stale_doc_hits: list[str] = []
    for path in [ROOT / "docs" / "AGENTIC_WORKFLOWS.md", ROOT / "docs" / "WORKFLOW_OPERATIONS_RUNBOOK.md", ROOT / "specs" / "00-universal" / "agentic-map-reduce.md"]:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for term in stale_doc_terms:
            if term in text:
                stale_doc_hits.append(f"{path.relative_to(ROOT)} contains stale phrase: {term}")
    out.append(result("static-integrity:workflow-doc-runtime-consistency", "fail" if stale_doc_hits else "pass", "; ".join(stale_doc_hits[:10]) if stale_doc_hits else "docs match current controlled-write/id behavior"))

    command_surface_errors: list[str] = []
    try:
        # workflow-block r2: the wsub.add_parser tree lives in
        # harness_lib/cli_workflow_tree.py; scan it plus harness.py so the
        # check still compares the FULL CLI set vs supportedWorkflowCommands.
        cli_surface_text = (ROOT / "scripts" / "harness.py").read_text(encoding="utf-8", errors="ignore") \
            + (ROOT / "scripts" / "harness_lib" / "cli_workflow_tree.py").read_text(encoding="utf-8", errors="ignore")
        cli_workflow_commands = set(re.findall(r'wsub\.add_parser\("([^"]+)"', cli_surface_text))
        workflows_cfg = (project_config().get("workflows") or {})
        configured_public = set(workflows_cfg.get("supportedWorkflowCommands", []) or []) if isinstance(workflows_cfg, dict) else set()
        configured_internal = set(workflows_cfg.get("internalWorkflowCommands", []) or []) if isinstance(workflows_cfg, dict) else set()
        missing_from_config = sorted(cli_workflow_commands - configured_public - configured_internal)
        missing_from_cli = sorted(configured_public - cli_workflow_commands)
        if missing_from_config:
            command_surface_errors.append("CLI commands not declared: " + ", ".join(missing_from_config))
        if missing_from_cli:
            command_surface_errors.append("declared commands missing CLI parser: " + ", ".join(missing_from_cli))
    except Exception as exc:
        command_surface_errors.append(str(exc))
    out.append(result("static-integrity:workflow-command-surface", "fail" if command_surface_errors else "pass", "; ".join(command_surface_errors[:10]) if command_surface_errors else "CLI commands match workflow config"))
    return out


def check_universal_specs() -> list[dict[str, str]]:
    return [
        result(item["name"], item["status"], item.get("detail", ""))
        for item in baseline_catalog.evaluate_universal_spec_files(ROOT)
    ]


def check_feature_spec_conformance() -> list[dict[str, str]]:  # SPEC-116 D
    legacy = set(((project_config().get("specConformance") or {}).get("legacy")) or [])
    return [result(i["name"], i["status"], i.get("detail", ""))
            for i in spec_conformance.check_feature_specs(ROOT, legacy)]


def check_agent_parity() -> list[dict[str, str]]:
    """SPEC-113 observe-only: hook manifest<->adapter parity + codex hook-trust
    staleness (machine-local). Logic lives in agent_parity.parity_gate_findings so
    the gate source keeps shrinking; emits pass/skip, never fail."""
    from harness_lib import agent_parity
    return [result(*row) for row in agent_parity.parity_gate_findings(ROOT)]


def check_test_quality() -> list[dict[str, str]]:
    """W29.N6 observe-only: logic lives in test_quality_ast.gate_check (gs-7)."""
    from harness_lib import test_quality_ast
    return [result(*row) for row in test_quality_ast.gate_check(ROOT)]



# gate-lines-burndown r3: the content/policy checks (testing artifacts,
# validation policy, handles-lint, SPEC-122 EN-default guard) live in
# harness_lib.gate_checks_content (bound with _POLICY_ENV below); call sites in
# main() and the ce3/en scenarios' stg.-attribute access are unchanged.
from harness_lib.gate_checks_content import check_handles_lint, check_en_default_strings, check_validation_policy, check_testing_artifacts, scan_en_default, EN_GUARD_SCOPE








# gate-lines-burndown r2: release-hygiene lives in harness_lib.gate_checks_release
# (bound with _POLICY_ENV below); re-exported so the call site in main() and the
# ph_path_hygiene scenario's stg.-attribute access are unchanged.
from harness_lib.gate_checks_release import check_release_hygiene, LOCAL_ABSOLUTE_PATH_PATTERNS


def check_engineering_guardrails_fixture() -> list[dict[str, str]]:
    """Validate executable software-engineering guardrails for modularity and context budget."""
    return [result(item["name"], item["status"], item.get("detail", "")) for item in engineering_guardrails.evaluate(ROOT)]



def check_protected_files_fixture() -> list[dict[str, str]]:
    """Validate canonical agent-file protection and installer-drift detection."""
    out = [result(item["name"], item["status"], item.get("detail", "")) for item in protected_files.evaluate(ROOT)]
    before = protected_files.snapshot(ROOT)
    drift_path = ROOT / "AGENTS.md"
    # Byte-exact save/restore: text-mode round-trips rewrite LF as CRLF on
    # Windows, leaving a false-positive hash drift after every fixture run.
    original_bytes = drift_path.read_bytes()
    try:
        drift_path.write_bytes(original_bytes + b"\n<!-- installer drift fixture -->\n")
        errors = protected_files.compare_snapshot(ROOT, before)
        out.append(result("protected-files:installer-drift-detected", "pass" if any("AGENTS.md" in item for item in errors) else "fail", "; ".join(errors[:3]) if errors else "no drift detected"))
    finally:
        drift_path.write_bytes(original_bytes)
    hook = run_fixture_command([sys.executable, "tools/hooks/protect_canonical_files.py", "check"], cwd=ROOT, timeout=fixture_timeout())
    out.append(result("protected-files:hook-check", "pass" if hook.returncode == 0 else "fail", "ok" if hook.returncode == 0 else (hook.stderr or hook.stdout)[-300:]))
    cli = run_fixture_command([sys.executable, "scripts/harness.py", "protected-files", "check"], cwd=ROOT, timeout=fixture_timeout())
    out.append(result("protected-files:cli-check", "pass" if cli.returncode == 0 else "fail", "ok" if cli.returncode == 0 else (cli.stderr or cli.stdout)[-300:]))
    payload = json.dumps({"tool_input": {"file_path": "AGENTS.md"}})
    guard = run_fixture_command([sys.executable, "tools/hooks/protect_files.py"], cwd=ROOT, timeout=fixture_timeout(), input=payload)
    out.append(result("protected-files:write-hook-blocks-canonical", "pass" if guard.returncode != 0 else "fail", "blocked AGENTS.md" if guard.returncode != 0 else "write hook allowed protected file"))

    market_paths = [
        "AGENTS.override.md",
        "GEMINI.md",
        ".github/copilot-instructions.md",
        ".github/instructions/python.instructions.md",
        ".cursor/rules/harness.mdc",
        ".clinerules/security.md",
        ".devin/rules/harness.md",
        ".windsurf/rules/harness.md",
        ".windsurfrules",
        ".roorules",
        "AGENT.md",
    ]
    # Validate the full market path matrix in-process.  Earlier revisions
    # spawned the write hook once per market file; that was logically correct
    # but made a simple policy check sensitive to Python process startup and
    # pipe-lifetime noise on slow CI hosts.  Keep one representative subprocess
    # check below so the installed hook path is still exercised.
    import fnmatch as _fnmatch
    market_patterns = protected_files.write_block_patterns(ROOT)
    blocked_market = [
        rel for rel in market_paths
        if any(_fnmatch.fnmatch(rel, pattern) or _fnmatch.fnmatch(Path(rel).name, pattern) for pattern in market_patterns)
    ]
    out.append(result(
        "protected-files:write-hook-blocks-market-files",
        "pass" if len(blocked_market) == len(market_paths) else "fail",
        f"blocked={len(blocked_market)}/{len(market_paths)}",
    ))
    # Keep market instruction-file coverage in-process. The canonical protected
    # write hook is already exercised above with AGENTS.md; repeating another
    # Python subprocess for GEMINI.md made aggregate product-release gates
    # sensitive to slow interpreter startup without adding a distinct policy
    # contract. The full market-path matrix above is the source of truth here.
    out.append(result("protected-files:write-hook-blocks-market-hook", "pass" if "GEMINI.md" in blocked_market else "fail", "blocked GEMINI.md via market matrix" if "GEMINI.md" in blocked_market else "market matrix allowed GEMINI.md"))

    transient = ROOT / "GEMINI.md"
    try:
        transient.write_text("# installer-created generic Gemini context\n", encoding="utf-8")
        errors = protected_files.compare_snapshot(ROOT, before)
        out.append(result("protected-files:new-market-file-drift", "pass" if any("GEMINI.md" in item for item in errors) else "fail", "; ".join(errors[:3]) if errors else "new GEMINI.md not detected"))
    finally:
        try:
            transient.unlink()
        except FileNotFoundError:
            pass
    return out

def check_workflow_profile_planning_fixture() -> list[dict[str, str]]:
    """Plan each configured workflow profile once to catch profile-by-profile drift."""
    cleanup_test_artifacts()
    out: list[dict[str, str]] = []
    wfids: list[str] = []
    try:
        profiles_payload = read_json(HARNESS / "workflows" / "workflow-profiles.json", {}) or {}
        profiles = profiles_payload.get("profiles", {}) if isinstance(profiles_payload.get("profiles"), dict) else {}
        if not profiles:
            return [result("workflow:profile-planning-fixture", "fail", "no profiles configured")]
        for name, cfg in sorted(profiles.items()):
            try:
                kwargs: dict[str, Any] = {"profile_name": name, "max_workers": 1, "concurrency": 1}
                # D010: research-*/widthDeclarationRequired profiles refuse to plan without a width.
                if workflow_plan.width_declaration_required(name, cfg):
                    kwargs.update(width_mode="custom", width_why="profile-planning fixture probe")
                if cfg.get("type") == "map-reduce":
                    kwargs.update({"split": "explicit", "shards": ["README.md"]})
                payload = call_harness_function(
                    "plan_workflow",
                    f"profile planning fixture {name}",
                    None,
                    **kwargs,
                )
                wfid = str(payload.get("workflowId"))
                wfids.append(wfid)
                mark_fixture_workflow(wfid, "profile-planning")
                workflow_path = HARNESS / "workflows" / "active" / wfid / "workflow.json"
                workflow = read_json(workflow_path, {}) or {}
                ok = workflow.get("workflowProfile") == name and workflow.get("workers")
                detail = f"{wfid}; workers={len(workflow.get('workers', []) or [])}"
                out.append(result(f"workflow:profile-planning-fixture:{name}", "pass" if ok else "fail", detail if ok else str(workflow)[:300]))
            except Exception as exc:
                out.append(result(f"workflow:profile-planning-fixture:{name}", "fail", str(exc)[:300]))
        return out
    finally:
        for wfid in wfids:
            shutil.rmtree(HARNESS / "workflows" / "active" / wfid, ignore_errors=True)
        cleanup_test_artifacts()














def _json_path_exists(obj: Any, dotted_path: str) -> bool:
    current: Any = obj
    for part in dotted_path.split('.'):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return False
    return True


def check_cli_golden_fixture() -> list[dict[str, str]]:
    """Golden-master public CLI contract check.

    The snapshots intentionally assert stable exit codes and JSON shapes rather
    than volatile values such as absolute repository paths.
    """
    contract_path = ROOT / "testing" / "golden" / "cli-contract.json"
    contract = read_json(contract_path, {}) or {}
    commands = contract.get("commands", []) if isinstance(contract.get("commands"), list) else []
    out: list[dict[str, str]] = []
    if not commands:
        return [result("golden-cli:contract", "fail", "no commands configured")]
    failures: list[str] = []
    for item in commands:
        if not isinstance(item, dict):
            failures.append("invalid command entry")
            continue
        name = str(item.get("name") or "unnamed")
        argv = [str(x) for x in (item.get("argv") or [])]
        expected_exit = int(item.get("exitCode", 0) or 0)
        proc = run_fixture_command([sys.executable, "scripts/harness.py", *argv], timeout=fixture_timeout())
        if proc.returncode != expected_exit:
            failures.append(f"{name}: exit {proc.returncode} != {expected_exit}")
            continue
        try:
            payload = json.loads(proc.stdout or "{}")
        except Exception as exc:
            failures.append(f"{name}: stdout is not JSON: {exc}")
            continue
        missing = [path for path in item.get("requiredJsonPaths", []) if not _json_path_exists(payload, str(path))]
        if missing:
            failures.append(f"{name}: missing {', '.join(missing)}")
    out.append(result("golden-cli:public-command-contract", "pass" if not failures else "fail", f"commands={len(commands)}" if not failures else "; ".join(failures[:5])))
    return out























def check_release_external_preflight_fixture() -> list[dict[str, str]]:
    """Verify optional external signing preflight is machine-readable and non-blocking."""
    gen = run_fixture_command([sys.executable, "scripts/release_integrity.py", "generate"], timeout=fixture_timeout())
    if gen.returncode != 0:
        detail = (gen.stdout or gen.stderr).strip().replace("\n", " ")[:300]
        return [result("release-external-preflight:generate", "fail", detail or "generation failed")]
    proc = run_fixture_command([sys.executable, "scripts/release_integrity.py", "external-preflight"], timeout=fixture_timeout())
    detail = (proc.stdout or proc.stderr).strip().replace("\n", " ")[:400]
    failures: list[str] = []
    if proc.returncode != 0:
        failures.append("non-strict preflight returned non-zero")
    try:
        data = json.loads(proc.stdout or "{}")
        if data.get("schemaVersion") != "1.0":
            failures.append("missing schemaVersion")
        if data.get("templateInvokesExternalTools") is not False:
            failures.append("template must not invoke external signing tools")
        if "cosign" not in data.get("tools", {}) or "slsa-verifier" not in data.get("tools", {}):
            failures.append("tool readiness missing cosign/slsa-verifier")
        if data.get("localIntegrityOk") is not True:
            failures.append("local integrity not ok before external preflight")
        if data.get("planCommandCount", 0) < 3:
            failures.append("external signing plan command count too low")
    except Exception as exc:
        failures.append(f"invalid external preflight JSON: {exc}; {detail}")
    return [result("release-external-preflight:optional-tool-readiness", "pass" if not failures else "fail", "external signing preflight is non-blocking and machine-readable" if not failures else "; ".join(failures[:5]))]

def check_release_integrity_fixture() -> list[dict[str, str]]:
    """Verify SBOM/checksum/attestation artifacts are present and internally consistent."""
    gen = run_fixture_command([sys.executable, "scripts/release_integrity.py", "generate"], timeout=fixture_timeout())
    if gen.returncode != 0:
        detail = (gen.stdout or gen.stderr).strip().replace("\n", " ")[:300]
        return [result("release-integrity:generate", "fail", detail or "generation failed")]
    proc = run_fixture_command([sys.executable, "scripts/release_integrity.py", "verify"], timeout=fixture_timeout())
    detail = (proc.stdout or proc.stderr).strip().replace("\n", " ")[:300]
    return [result("release-integrity:sbom-checksums-attestation-signature-plan", "pass" if proc.returncode == 0 else "fail", detail or "ok")]

def check_red_team_fixture() -> list[dict[str, str]]:
    """Minimal OWASP LLM-style agency-boundary fixture."""
    hook = ROOT / "tools" / "hooks" / "workflow_write_guard.py"
    if not hook.exists():
        return [result("red-team:write-guard", "fail", "missing workflow_write_guard.py")]
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        allowed = workspace / "allowed.txt"
        result_path = tmp_path / "worker.result.json"
        env_base = os.environ.copy()
        env_base.update({
            "HARNESS_WORKFLOW_ID": "WF-redteam",
            "HARNESS_WORKER_ID": "worker-001",
            "HARNESS_WORKER_RESULT_PATH": str(result_path),
        })
        failures: list[str] = []
        # Read-only worker must not write arbitrary repo/system paths.
        proc = run_fixture_command(
            [sys.executable, str(hook)],
            input=json.dumps({"file_path": "../../secrets.env"}),
            env=env_base,
            timeout=fixture_timeout(),
        )
        if proc.returncode == 0:
            failures.append("read-only traversal write allowed")
        # Result path stays allowed so workers can report structured output.
        proc = run_fixture_command(
            [sys.executable, str(hook)],
            input=json.dumps({"file_path": str(result_path)}),
            env=env_base,
            timeout=fixture_timeout(),
        )
        if proc.returncode != 0:
            failures.append("worker result path blocked")
        # Controlled write can write only locked paths inside workspace.
        env_write = dict(env_base)
        env_write.update({
            "HARNESS_WORKFLOW_WRITE_ALLOWED": "1",
            "HARNESS_WORKER_WORKSPACE": str(workspace),
            "HARNESS_WORKER_LOCKED_PATHS": json.dumps(["allowed.txt"]),
        })
        proc = run_fixture_command(
            [sys.executable, str(hook)],
            input=json.dumps({"file_path": str(allowed)}),
            env=env_write,
            timeout=fixture_timeout(),
        )
        if proc.returncode != 0:
            failures.append("locked workspace path blocked")
        outside = tmp_path / "outside.txt"
        proc = run_fixture_command(
            [sys.executable, str(hook)],
            input=json.dumps({"file_path": str(outside)}),
            env=env_write,
            timeout=fixture_timeout(),
        )
        if proc.returncode == 0:
            failures.append("controlled-write outside workspace allowed")
    return [result("red-team:agency-boundaries", "pass" if not failures else "fail", "write/traversal boundaries ok" if not failures else "; ".join(failures[:5]))]



def check_provider_canary_policy_fixture() -> list[dict[str, str]]:
    """Validate real-provider canaries are explicit opt-in and classify common failures."""
    return [result(item["name"], item["status"], item.get("detail", "")) for item in fixture_liveness.provider_canary_policy(ROOT)]


def check_deprecation_hygiene_fixture() -> list[dict[str, str]]:
    return [result(item["name"], item["status"], item.get("detail", "")) for item in deprecation_hygiene.evaluate(ROOT)]



def check_process_timeout_cleanup_fixture() -> list[dict[str, str]]:
    return [result(item["name"], item["status"], item.get("detail", "")) for item in fixture_liveness.process_timeout_cleanup(ROOT)]


def check_fixture_liveness_fixture() -> list[dict[str, str]]:
    return [result(item["name"], item["status"], item.get("detail", "")) for item in fixture_liveness.fixture_liveness(ROOT)]





# MF.2: fixture domains live in harness_lib modules; the gate passes its
# shared helpers once and keeps the FIXTURES registry below unchanged.
_GATE_ENV = {
    "BaseHTTPRequestHandler": BaseHTTPRequestHandler,
    "HARNESS": HARNESS,
    "HTTPServer": HTTPServer,
    "PROJECT": PROJECT,
    "ROOT": ROOT,
    "call_harness_function": call_harness_function,
    "cleanup_fixture_workflow": cleanup_fixture_workflow,
    "cleanup_test_artifacts": cleanup_test_artifacts,
    "fixture_timeout": fixture_timeout,
    "graphify_code_ast": graphify_code_ast,
    "mark_fixture_workflow": mark_fixture_workflow,
    "now": now,
    "processes": processes,
    "project_config": project_config,
    "read_json": read_json,
    "result": result,
    "run_fixture_command": run_fixture_command,
    "signal": signal,
    "tempfile": tempfile,
    "threading": threading,
    "write_json": write_json,
    "write_sample_worker_result": write_sample_worker_result,
}

_POLICY_ENV = {
    "GATES": GATES,
    "HARNESS": HARNESS,
    "ROOT": ROOT,
    "command_config": command_config,
    "fixture_timeout": fixture_timeout,
    "graphify_code_ast": graphify_code_ast,
    "project_config": project_config,
    "read_json": read_json,
    "result": result,
    "run_fixture_command": run_fixture_command,
}
gate_checks_content.bind(_POLICY_ENV)
gate_checks_policy.bind(_POLICY_ENV)
gate_checks_release.bind(_POLICY_ENV)
gate_checks_structure.bind(_POLICY_ENV)
check_knowledge_graph_policy = gate_checks_policy.check_knowledge_graph_policy
check_workflow_policy = gate_checks_policy.check_workflow_policy
check_self_review_freshness = gate_checks_policy.check_self_review_freshness
check_commit_hook_adoption = gate_checks_policy.check_commit_hook_adoption
check_precommit_override = gate_checks_policy.check_precommit_override

gate_generic.bind({"result": result, "run_bounded_command": run_bounded_command})
for _gate_fixture_module in (gate_fixtures_workflow, gate_fixtures_trace, gate_fixtures_graphify, gate_fixtures_isolation):
    _gate_fixture_module.bind(_GATE_ENV)
check_controlled_write_fixture = gate_fixtures_workflow.check_controlled_write_fixture
check_workflow_lifecycle_fixture = gate_fixtures_workflow.check_workflow_lifecycle_fixture
check_workflow_execute_output_fixture = gate_fixtures_workflow.check_workflow_execute_output_fixture
check_git_worktree_fixture = gate_fixtures_workflow.check_git_worktree_fixture
check_async_workflow_fixture = gate_fixtures_workflow.check_async_workflow_fixture
check_handoff_budget_fixture = gate_fixtures_workflow.check_handoff_budget_fixture
check_workflow_token_budget_fixture = gate_fixtures_workflow.check_workflow_token_budget_fixture
check_workflow_soak_fixture = gate_fixtures_workflow.check_workflow_soak_fixture
check_state_store_fixture = gate_fixtures_workflow.check_state_store_fixture
check_state_runtime_fixture = gate_fixtures_workflow.check_state_runtime_fixture
check_state_artifacts_fixture = gate_fixtures_workflow.check_state_artifacts_fixture
check_workflow_id_boundary_fixture = gate_fixtures_workflow.check_workflow_id_boundary_fixture
check_trace_contract_fixture = gate_fixtures_trace.check_trace_contract_fixture
check_trace_export_fixture = gate_fixtures_trace.check_trace_export_fixture
check_trace_push_fixture = gate_fixtures_trace.check_trace_push_fixture
check_trace_secret_redaction_fixture = gate_fixtures_trace.check_trace_secret_redaction_fixture
check_trace_push_send_fixture = gate_fixtures_trace.check_trace_push_send_fixture
check_trace_push_policy_fixture = gate_fixtures_trace.check_trace_push_policy_fixture
check_graphify_adapter_fixture = gate_fixtures_graphify.check_graphify_adapter_fixture
check_graphify_code_ast_fixture = gate_fixtures_graphify.check_graphify_code_ast_fixture
check_graphify_api_providers_fixture = gate_fixtures_graphify.check_graphify_api_providers_fixture

WORKFLOW_FIXTURE_FUNCTIONS = {
    "engineering-guardrails": check_engineering_guardrails_fixture,
    "isolation-audit": gate_fixtures_isolation.check_isolation_audit_fixture,
    "protected-files": check_protected_files_fixture,
    "deprecation-hygiene": check_deprecation_hygiene_fixture,
    "handoff-budget": check_handoff_budget_fixture,
    "workflow-id-boundary": check_workflow_id_boundary_fixture,
    "profile-planning": check_workflow_profile_planning_fixture,
    "token-budget": check_workflow_token_budget_fixture,
    "graphify-adapter": check_graphify_adapter_fixture,
    "graphify-code-ast": check_graphify_code_ast_fixture,
    "graphify-api-providers": check_graphify_api_providers_fixture,
    "lifecycle": check_workflow_lifecycle_fixture,
    "controlled-write": check_controlled_write_fixture,
    "execute-output": check_workflow_execute_output_fixture,
    "git-worktree": check_git_worktree_fixture,
    "async-workflow": check_async_workflow_fixture,
    "workflow-soak": check_workflow_soak_fixture,
    "cli-golden": check_cli_golden_fixture,
    "state-store": check_state_store_fixture,
    "state-runtime": check_state_runtime_fixture,
    "state-artifacts": check_state_artifacts_fixture,
    "trace-contract": check_trace_contract_fixture,
    "trace-export": check_trace_export_fixture,
    "trace-push": check_trace_push_fixture,
    "trace-push-send": check_trace_push_send_fixture,
    "trace-push-policy": check_trace_push_policy_fixture,
    "trace-secret-redaction": check_trace_secret_redaction_fixture,
    "release-integrity": check_release_integrity_fixture,
    "release-external-preflight": check_release_external_preflight_fixture,
    "process-timeout-cleanup": check_process_timeout_cleanup_fixture,
    "fixture-liveness": check_fixture_liveness_fixture,
    "provider-canary": check_provider_canary_policy_fixture,
    "red-team": check_red_team_fixture,
}


def run_isolated_workflow_fixture(name: str) -> list[dict[str, str]]:
    """Run heavy workflow fixtures in a fresh Python process with bounded output.

    The aggregate workflow gate should never depend on an unbounded inherited
    stdio stream.  Capture child output, replay it after completion, and rely on
    the shared process-tree timeout helper to terminate descendants if the child
    or any inherited pipe stalls.
    """
    timeout = max(120, fixture_timeout() * 4)
    cmd = [sys.executable, str(Path(__file__).resolve()), "--fixture", name]
    print(f"$ workflow fixture {name} (timeout={timeout}s)", flush=True)
    started = time.time()
    # The historical POSIX-spawn path avoids inherited pipe stalls on some hosts,
    # but containerized sandboxes can make waitpid/setsid behavior less
    # predictable after repeated fixture launches. Keep it as explicit opt-in and
    # default to the shared Popen-based process-tree cleanup helper.
    proc = None
    if os.environ.get("HARNESS_USE_POSIX_SPAWN_FIXTURES") == "1":
        proc = processes.run_posix_spawn_bounded(cmd, timeout=timeout)
    if proc is None:
        proc = run_bounded_command(
            cmd,
            timeout=timeout,
            cleanup_on_timeout=True,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
    elapsed = time.time() - started
    output = (proc.stdout or "").rstrip()
    if output:
        print(output, flush=True)
    detail = f"elapsed={elapsed:.1f}s" if proc.returncode == 0 else f"exit={proc.returncode}; elapsed={elapsed:.1f}s"
    if proc.returncode == 124:
        timeout_detail = (proc.stderr or proc.stdout or f"timeout after {timeout}s").strip().splitlines()[-1:] or [f"timeout after {timeout}s"]
        detail = f"{timeout_detail[0]}; {detail}"
    return [result(f"workflow:fixture:{name}:isolated", "pass" if proc.returncode == 0 else "fail", detail)]

def detected_commands() -> dict[str, list[str]]:
    suggestions: dict[str, list[str]] = {gate: [] for gate in GATES}
    def add(gate: str, cmd: str) -> None:
        if cmd not in suggestions[gate]:
            suggestions[gate].append(cmd)

    if (ROOT / "package.json").exists():
        try:
            pkg = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
            scripts = pkg.get("scripts", {}) if isinstance(pkg, dict) else {}
            if isinstance(scripts, dict):
                if "lint" in scripts: add("commit", "npm run lint")
                if "typecheck" in scripts: add("commit", "npm run typecheck")
                if "test" in scripts: add("commit", "npm test")
                if "build" in scripts: add("feature", "npm run build")
                for name in ["coverage", "test:coverage", "coverage:ci"]:
                    if name in scripts: add("coverage", f"npm run {name}")
        except Exception:
            pass
    if (ROOT / "pyproject.toml").exists() or (ROOT / "pytest.ini").exists() or (ROOT / "tox.ini").exists():
        add("commit", "python -m pytest")
        add("coverage", "python -m pytest --cov")
    if (ROOT / "go.mod").exists():
        add("commit", "go test ./...")
        add("coverage", "go test ./... -cover")
    if (ROOT / "Cargo.toml").exists():
        add("commit", "cargo test")
    if (ROOT / "pom.xml").exists():
        add("commit", "mvn test")
    if (ROOT / "build.gradle").exists() or (ROOT / "build.gradle.kts").exists():
        add("commit", "./gradlew test")
    if (ROOT / "Makefile").exists():
        text = (ROOT / "Makefile").read_text(encoding="utf-8", errors="ignore")
        for target, gate in [("test", "commit"), ("lint", "commit"), ("build", "feature"), ("coverage", "coverage")]:
            if re.search(rf"^{re.escape(target)}\s*:", text, flags=re.M):
                add(gate, f"make {target}")
    return suggestions


def run_commands(gate: str, commands: list[str], label: str) -> list[dict[str, str]]:
    if not commands:
        return []
    out: list[dict[str, str]] = []
    timeout = int(os.environ.get("HARNESS_GATE_TIMEOUT", "900"))
    for cmd in commands:
        print(f"$ {cmd}")
        proc = run_bounded_command(
            cmd,
            timeout=timeout,
            cleanup_on_timeout=False,
            shell=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        if proc.returncode == 124:
            detail = (proc.stderr or proc.stdout or f"timeout after {timeout}s").strip().splitlines()[-1:] or [f"timeout after {timeout}s"]
            out.append(result(f"{label}:{cmd}", "fail", detail[0]))
        else:
            tail = (proc.stdout or "").strip().splitlines()[-1:] or [""]
            out.append(result(f"{label}:{cmd}", "pass" if proc.returncode == 0 else "fail", tail[0]))
    return out


def run_configured_commands(gate: str, *, no_project_commands: bool = False, dry_run: bool = False) -> list[dict[str, str]]:
    project = project_config()
    commands, required, run_detected, _ = command_config(project, gate)
    detected = detected_commands().get(gate, []) if ((project.get("autoDetect") or {}).get("enabled", False)) else []
    out: list[dict[str, str]] = []
    if commands:
        if dry_run or no_project_commands:
            return [result(f"commands:{gate}", "skip", "configured but not run due to dry-run/no-project-commands")]
        return run_commands(gate, commands, "command")
    if detected:
        detail = "; ".join(detected)
        if run_detected and not (dry_run or no_project_commands):
            out.extend(run_commands(gate, detected, "detected-command"))
        else:
            out.append(result(f"commands:{gate}", "skip", "no configured commands; detected suggestions not run: " + detail))
    elif required:
        out.append(result(f"commands:{gate}", "fail", "required gate has no commands configured"))
    else:
        out.append(result(f"commands:{gate}", "skip", "no project commands configured"))
    return out


def run_coverage(gate: str, *, no_project_commands: bool = False, dry_run: bool = False) -> list[dict[str, str]]:
    project = project_config()
    coverage = project.get("coverage", {}) if isinstance(project.get("coverage"), dict) else {}
    enabled = bool(coverage.get("enabled", False))
    mode = coverage.get("mode", "disabled")
    enforce_gates = set(coverage.get("enforceOnGates", []) or [])
    commands = [str(c) for c in (coverage.get("commands") or [])]
    if not commands:
        commands = command_config(project, "coverage")[0]
    should_run = gate == "coverage" or (enabled and gate in enforce_gates)
    if not should_run:
        return [result("coverage", "skip", f"not required for gate {gate}")]
    if not enabled or mode == "disabled":
        return [result("coverage", "skip", "coverage disabled in .harness/project.json")]
    if not commands:
        return [result("coverage", "fail" if mode in {"enforced", "risk-targeted"} else "skip", "coverage enabled but no command configured")]
    if dry_run or no_project_commands:
        return [result("coverage", "skip", "coverage command configured but not run due to dry-run/no-project-commands")]
    return run_commands("coverage", commands, "coverage-command")


# CQ.1: files whose modification alone marks a patch high-risk (the gate itself,
# the security baseline, the secret scanner) plus the prompt contracts dir.
_RISK_HIGH_FILES = {
    "scripts/spec_test_gate.py",
    "scripts/harness_lib/security_baseline.py",
    "scripts/harness_lib/secret_scan.py",
}


def risk_tier(changed: list[str], new_findings: list[str], sink_files: list[str]) -> tuple[str, str]:
    """CQ.1 observe-only: deterministic per-patch risk tier. First match wins."""
    if new_findings:
        return "high", f"{len(new_findings)} new security finding(s)"
    if sink_files:
        return "high", f"sink in changed file(s): {', '.join(sorted(sink_files)[:3])}"
    hot = sorted(p for p in changed if p in _RISK_HIGH_FILES or p.startswith(".harness/prompts/"))
    if hot:
        return "high", f"security-sensitive file(s) changed: {', '.join(hot[:3])}"
    if not changed:
        return "low", "no changes"
    if all(p.startswith("docs/") or p.endswith(".md") for p in changed):
        return "low", "docs/markdown-only change"
    return "medium", "code change without new findings or sinks"


# W29.N7 tier -> verification depth: map + writer live in harness_lib.gate_perf
# (gs-7 line ratchet); imported here so the gate and the cq teeth read ONE name.
from harness_lib.gate_perf import EXECUTION_LEVELS, PARTIAL_LOG_NAME, PartialRows, execution_level, log_tier_level  # noqa: E402,F401


def collect_risk_tier(new_findings: list[str]) -> tuple[str, str, list[str]]:
    """Collect the per-patch inputs for risk_tier(). ANY failure => medium (fail-closed)."""
    try:
        changed: set[str] = set()
        for cmd in (["git", "diff", "--name-only", "HEAD"],
                    ["git", "ls-files", "-o", "--exclude-standard"]):
            proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=30)
            if proc.returncode != 0:
                raise RuntimeError(f"{' '.join(cmd)} rc={proc.returncode}")
            changed.update(ln.strip() for ln in proc.stdout.splitlines() if ln.strip())
        changed_list = sorted(changed)
        sink_files: list[str] = []
        for rel in changed_list:
            if not (rel.startswith("scripts/") and rel.endswith(".py")):
                continue
            path = ROOT / rel
            if not path.is_file():
                continue  # deleted in the diff — nothing to parse
            try:
                tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                continue  # ponytail: unparsable changed .py stays medium-default, never auto-high
            if any(security_baseline._classify_sink(node) for node in ast.walk(tree)):
                sink_files.append(rel)
        tier, reason = risk_tier(changed_list, new_findings, sink_files)
        return tier, reason, changed_list
    except Exception:
        return "medium", "unclassifiable (fail-closed)", []


def ratchet_hits(new: list[str], changed: list[str]) -> list[str]:
    """SEC.2 pure join: NEW (non-baselined) security findings whose file the
    current patch touched. Finding ids end with the rel path
    (secret:<pattern>:<rel> / sink:<kind>:<rel> / config:tracked-env:<rel>,
    security_baseline.py). `changed=[]` (collect_risk_tier's fail-closed git
    default) yields no hits, so a git failure can never false-red the ratchet."""
    touched = set(changed)
    return sorted(f for f in new if f.rsplit(":", 1)[-1] in touched)


def run_security_checks() -> tuple[list[dict[str, str]], dict]:
    """The six always-on security/ratchet checks main() runs on every gate.

    Returns the result rows plus the security-baseline evaluation (main still
    needs `security["new"]` for the quality-state requiresSecurityReview bit)."""
    results: list[dict[str, str]] = []
    # OBSERVE-ONLY security baseline (measurement before control): reports NEW vs
    # baselined findings and never fails the gate. Snapshot is write-once (day-one
    # green); requiresSecurityReview REPORTS bool(new) — nothing blocks on it yet.
    security = security_baseline.evaluate(ROOT)
    results.append(result("security-baseline", "pass",
                          f"{len(security['new'])} new / {len(security['baselined'])} baselined"))
    # CQ.1 observe-only: first consumer of the security['new'] diff. Always "pass".
    tier, reason, changed = collect_risk_tier(security["new"])
    security["riskTier"] = tier  # W29.N7: main() logs (tier, level, status) at gate end
    results.append(result("risk-tier", "pass", f"tier={tier}; level={execution_level(tier)}; changed={len(changed)}; {reason}"))
    # SEC.2 join + security-diff-routing (owner decision 2026-07-13 #1: ROUTE,
    # not block): a NEW (non-baselined) finding in a changed file no longer
    # hard-fails — security_routing.route() raises ONE durable security-triage
    # escalation (idempotent by finding-set hash) for hits not covered by the
    # known-FP exemption registry. The check fails only on an INVALID registry
    # entry: an exemption without pattern/reason/reviewedAt is prose, not control.
    hits = ratchet_hits(security["new"], changed)
    routing = security_routing.route(ROOT, hits)
    if routing["invalid"]:
        ratchet_detail = ("invalid exemption entries in .harness/state/security-exemptions.json: "
                          + "; ".join(routing["invalid"]))
    elif routing["routed"]:
        ratchet_detail = (f"routed {len(routing['routed'])} hit(s) to security-triage "
                          f"({routing['escalationId']}); {len(routing['exempted'])} exempted; "
                          "resolve the escalation, add a reviewed exemption, or delete "
                          ".harness/state/security-baseline.json to re-baseline")
    elif hits:
        ratchet_detail = f"all {len(hits)} hit(s) exempted by the FP registry"
    else:
        ratchet_detail = "no new finding in changed files"
    results.append(result(
        "security-regression-ratchet",
        "fail" if routing["invalid"] else "pass",
        ratchet_detail))
    # no-raw-subprocess ratchet: a NEW unmediated subprocess/asyncio spawn site
    # outside processes.py fails — route it through the mediation layer, or
    # consciously re-baseline (delete the snapshot). Legacy sites are baselined.
    spawns = spawn_ratchet.evaluate(ROOT)
    results.append(result(
        "raw-subprocess-ratchet",
        "fail" if spawns["new"] else "pass",
        f"{len(spawns['baselined'])} baselined spawn site(s), no new" if not spawns["new"]
        else f"new unmediated spawn site(s): {', '.join(spawns['new'][:4])}; "
             "route through harness_lib/processes.py helpers, or delete "
             f"{spawn_ratchet.SNAPSHOT_REL} to re-baseline"))
    # SPEC-170 rule 6 (audit dacbdc8 F2/F5): Option B's documented fallback
    # patches playbook_registry.REGISTRY_REL from a scenario; a dotted
    # assignment to it anywhere OUTSIDE testing/scenarios/ is an enforcement
    # off-switch. Module-level definitions (`REGISTRY_REL = "..."`) don't match.
    _rrl = re.compile(r"\.\s*REGISTRY_REL\s*=[^=]")
    rrl_hits = sorted(
        p.relative_to(ROOT).as_posix()
        for base in ("scripts", "tools") if (ROOT / base).is_dir()
        for p in (ROOT / base).rglob("*.py")
        if _rrl.search(p.read_text(encoding="utf-8", errors="ignore")))
    results.append(result(
        "registry-rel-ratchet",
        "fail" if rrl_hits else "pass",
        "no REGISTRY_REL attribute patch outside testing/scenarios/" if not rrl_hits
        else "REGISTRY_REL patched outside testing/scenarios/: " + ", ".join(rrl_hits[:4])
             + " — Option B is scenario-only (playbook_enforcement docstring)"))
    # SPEC-148: named worker-spawn functions must route through sandbox_spawn.
    chokepoint = sandbox_spawn.evaluate_chokepoint(ROOT)
    results.append(result(
        "sandbox-chokepoint", "fail" if chokepoint["missing"] else "pass",
        f"{len(chokepoint['sites'])} worker-spawn site(s) routed through sandbox_spawn" if not chokepoint["missing"]
        else "unrouted spawn site(s): " + ", ".join(chokepoint["missing"]) + " | fix: route through harness_lib/sandbox_spawn"))
    # Phase 3 ENFORCING directive map: every `## Invariants` bullet of the six
    # security universal specs must carry an EXPLICIT enforcement mapping
    # (check:/trigger:/prose) — a new prose-only directive cannot merge
    # silently, and a removed directive must retire its entry.
    dmap = security_directives.evaluate(ROOT)
    dmap_problems = ([f"unmapped: {r['id']}" for r in dmap["unmapped"]]
                     + [f"stale: {i}" for i in dmap["stale"]]
                     + [f"invalid status: {i}" for i in dmap["invalid"]])
    results.append(result(
        "security-directive-map",
        "fail" if dmap_problems else "pass",
        (f"{dmap['count']} directives mapped ({dmap['byStatus']})" if not dmap_problems
         else "; ".join(dmap_problems[:5])
         + " | fix: add/remove the entry in testing/security-directive-map.json "
           "in the same commit as the directive change")))
    # Same idiom for the overseer RITUAL (hook:/gate:/leg:/doctor:/advisory:/gap:): a new or REWORDED playbook step forces a fresh enforcement decision, a deleted one retires its entry.
    rmap = ritual_map.evaluate(ROOT)
    rmap_problems = [f"unmapped: {r['id']}" for r in rmap["unmapped"]] + [f"stale: {i}" for i in rmap["stale"]] + [f"invalid status: {i}" for i in rmap["invalid"]]
    results.append(result(
        "ritual-enforcement-map",
        "fail" if rmap_problems else "pass",
        (f"{rmap['count']} ritual steps mapped ({rmap['byStatus']})" if not rmap_problems
         else "; ".join(rmap_problems[:5])
         + " | fix: add/remove the entry in testing/ritual-enforcement-map.json "
           "in the same commit as the playbook step change")))
    # SEC.3 ENFORCING control-plane liveness: each declared control has a
    # deterministic probe (control_liveness.PROBES, pure reads); a silently-dead
    # control — scrub call deleted in a refactor, env-filter flipped off,
    # protection snapshot gone — fails the gate here instead of dying unnoticed.
    dead_controls = [r["control"] for r in control_liveness.evaluate(ROOT)
                     if r["status"] == "dead"]
    results.append(result(
        "control-liveness",
        "fail" if dead_controls else "pass",
        f"{len(control_liveness.PROBES)} declared controls alive" if not dead_controls
        else f"dead control(s): {', '.join(dead_controls)}"))
    return results, security


# Color/TTY + session GUI env scrubbed from scenarios -- leaked HARNESS_UI_AUTOCOMMIT=1 lets the browser e2e REALLY COMMIT against ROOT mid-gate (ua_user_autocommit.py:113); leaked HARNESS_CHAT_TURN would Stop-block a scenario-spawned claude on the OUTER gate (deadlock).
_ENV_SCRUB = {"HARNESS_COLOR", "NO_COLOR", "FORCE_COLOR", "CLICOLOR", "CLICOLOR_FORCE", "HARNESS_CHAT_TURN",
              "HARNESS_AGENT_OUTPUT", "HARNESS_CHAT_EVENTS", "HARNESS_CHAT_SESSION", "HARNESS_UI_AUTOCOMMIT"}


# SEAM: durability rides on append/extend ONLY — `_PERF_ROWS += rows`, insert and slice assignment bypass PartialRows silently (list.__iadd__ is C-level); every producer must append/extend.
_PERF_ROWS: list[dict[str, Any]] = PartialRows(ROOT)  # EXP-12 per-attempt overhead split: flushed to gate-perf.jsonl at settle AND streamed row-by-row (a settle-only flush dies with the 1800s hard-kill — both 2026-08-03 kills left zero rows)


def _run_isolated_scenario(scenario_path: Path, attempt: str = "") -> Any:
    """One hermetic scenario attempt: fresh volatile-state snapshot, bounded run, F4b
    failure forensics BEFORE restore, then restore. A retry passes attempt="-retry" so its
    forensics land in a distinct dir."""
    t0 = time.monotonic()
    iso_hold = Path(tempfile.mkdtemp(prefix="scniso-"))
    iso_token = scenario_isolation.snapshot_volatile_state(ROOT, iso_hold)
    t_snap = time.monotonic()
    proc = None
    # Scrub inherited color/TTY env so a parent that forces color (HARNESS_COLOR=always,
    # FORCE_COLOR=1, ...) can't leak ANSI into scenario output and break hl_highlight.
    # TERM stays -- scenarios key off it, not the color-force vars.
    env = {k: v for k, v in os.environ.items() if k not in _ENV_SCRUB}
    # Scenario mutations are sandboxed by THIS snapshot/restore, so the panel's
    # gate-in-flight guard (ui_actions._gate_in_flight) must stand down inside one —
    # here the restore is the contract, not the hazard it protects the owner from.
    env["HARNESS_SCENARIO_ISOLATED"] = "1"
    try:
        proc = run_bounded_command([sys.executable, str(scenario_path)], timeout=900, env=env)
    finally:
        t_sub = time.monotonic()
        if proc is not None and proc.returncode != 0:
            scenario_isolation.capture_scenario_forensics(ROOT, scenario_path.stem + attempt, proc)
        scenario_isolation.restore_volatile_state(iso_token)
        shutil.rmtree(iso_hold, ignore_errors=True)
        _PERF_ROWS.append({"scenario": scenario_path.stem, "attempt": attempt or "first",
                           "snapshotS": round(t_snap - t0, 3), "subprocessS": round(t_sub - t_snap, 3),
                           "restoreS": round(time.monotonic() - t_sub, 3),
                           "rc": getattr(proc, "returncode", None)})
    return proc


def _run_scenarios_gate(args: argparse.Namespace, results: list[dict[str, str]], section_times: list[tuple[str, float]]) -> None:
    """The `scenarios` gate body, split out of `main` for maxFunctionLines; mutates `results`/`section_times` in place."""
    # QA.2: the regression treasury as a first-class tier — every testing/scenarios/*.py, aggregated RC, one row per scenario.
    # Runner-level hermeticity: snapshot/restore volatile on-disk state per scenario (order-independent, no leak into the next; scenario_isolation).
    recovered_scenarios: list[str] = []
    # Gate-level hermeticity: move the dirty .harness baseline aside and materialize
    # HEAD for the whole scenarios run so pre-existing dirt (owner GUI edits, runtime
    # state) can't turn scenarios red. Released byte-identically in the finally; a
    # hard-kill that skips it is recovered on the next run (scenario_isolation).
    # EXP-11 v2 (reopened post-EXP-12): promote ONLY cheap flakies to the front; heavies keep
    # alphabetical spacing (v1 clustering regression). Computed BEFORE the hold (forensics/sidecar class D).
    scenario_run_order = gate_scenario_order.fail_fast_order(ROOT)
    from harness_lib import gate_affected  # SPEC-159: shadow decorates perf rows; Phase-2 (flag) pre-filters parallel skips
    shadow_ledger = gate_affected.ShadowLedger(ROOT)
    # SPEC-159 Phase-2 flip (owner GO 2026-07-22, EXP-29): partition provably-unaffected + cached-pass scenarios out of the PARALLEL shard set — gate_affected.partition_skips builds the SKIP rows (never a pass, never cache-fed; logic lives there per the gs-7 ratchet).
    cache_skip_rows, cache_skip_perf, parallel_paths = gate_affected.partition_skips(shadow_ledger, scenario_run_order, result_fn=result, enabled=bool(read_json(PROJECT, {}).get("validation", {}).get("scenarioSkipEnabled", False)), serial=getattr(args, "serial", False))
    baseline_hold = scenario_isolation.hold_dirty_baseline(ROOT)
    try:
        # SPEC-160 DEFAULT (owner flip D041, 2026-07-21): --serial forces the old
        # loop (None here); ANY parallel-infra error -> the same serial fallback.
        # Post-flip the SPEC-159 shadow feeds from the MERGED verdicts, real root.
        from harness_lib import gate_parallel
        parallel_rows = gate_parallel.run_default_parallel(args, parallel_paths, root=ROOT, result_fn=result, env_scrub=_ENV_SCRUB, perf_rows=_PERF_ROWS, shadow_ledger=shadow_ledger, run_isolated=_run_isolated_scenario)
        if parallel_rows is not None:
            results.extend(cache_skip_rows + parallel_rows)  # pre-emitted cache-skips ride the parallel path
            _PERF_ROWS.extend(cache_skip_perf)               # savedS realized in the sidecar
        else:  # --serial OR a parallel-infra fallback: the serial loop runs the FULL original order (skips dropped, no coverage loss)
            for scenario_path in scenario_run_order:
                if scenario_path.name.startswith("_"):
                    continue
                scenario_t0 = time.monotonic()
                perf_start = len(_PERF_ROWS)
                # Retry-once net (SPEC-137) + the two-channel verdict, both owned by
                # harness_lib.scenario_verdict so serial and parallel cannot drift:
                # the trusted rc comes from the venv LAUNCHER while the scorecard is
                # written by a different interpreter PID, so an rc-0 attempt whose
                # scorecard reports failures used to certify as pass (2026-07-28).
                proc, verdict, contradiction, recovered = scenario_verdict.run_with_retry(
                    lambda a="": _run_isolated_scenario(scenario_path, attempt=a))
                if recovered:
                    print(f"! scenarios:{scenario_path.stem}: recovered-on-retry (flaky; forensics kept)", flush=True)
                    recovered_scenarios.append(scenario_path.stem)
                scenario_ms = (time.monotonic() - scenario_t0) * 1000
                # A skip is a skip, never a pass: it must not feed the SPEC-159 verdict
                # cache (rt6's 0.4s pseudo-passes poisoned it into a live false-skip on
                # 2026-07-20) and it reports as `skip` in the gate.
                scen_skipped = verdict == "skip"
                if perf_start < len(_PERF_ROWS) and not scen_skipped:  # SPEC-159 SHADOW: stamp row + false-skip detector (still ran)
                    shadow_ledger.annotate(_PERF_ROWS[perf_start], scenario_path.stem, verdict == "pass")
                tail = ((proc.stdout or "").strip().splitlines() or [""])[-1]
                if contradiction:
                    tail = f"{contradiction} | {tail}"
                detail = (("recovered-on-retry | " + tail) if recovered else tail)[:200]
                section_times.append((f"scenario:{scenario_path.stem}", scenario_ms / 1000))
                results.append(result(f"scenarios:{scenario_path.stem}", verdict,
                                      detail, duration_ms=scenario_ms))
            if recovered_scenarios:
                print(f"scenarios recovered-on-retry ({len(recovered_scenarios)}): {', '.join(recovered_scenarios)}", flush=True)
    finally:
        scenario_isolation.release_dirty_baseline(baseline_hold)
        shadow_ledger.commit()  # SPEC-159: persist fresh per-scenario verdicts (measure-only store)
        from harness_lib import gate_perf
        gate_perf.flush_run(_PERF_ROWS, ROOT)  # EXP-12 sidecar (extracted; fail-open inside)
        if _PERF_ROWS:
            from harness_lib import gate_governance  # B4: advisory-only, fail-open inside
            gate_governance.advise(ROOT)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Universal harness validation gate")
    parser.add_argument("gate", nargs="?", default="smoke", choices=GATES)
    parser.add_argument("--task", help="Optional task id/name for logging only.")
    parser.add_argument("--spec", action="append", default=[], help="Relevant spec path/id for logging only. May repeat.")
    parser.add_argument("--manifest", help="Optional release/validation manifest path for logging only.")
    parser.add_argument("--changed-files", help="Optional changed files manifest for logging only.")
    parser.add_argument("--no-project-commands", action="store_true", help="Validate harness structure without running configured project commands.")
    parser.add_argument("--quiet", action="store_true", help="Suppress passing/skip check lines; print only failures plus a counted gate summary (also via HARNESS_TEST_QUIET=1).")
    parser.add_argument("--dry-run", action="store_true", help="Print validation plan without running configured commands.")
    parser.add_argument("--list-detected", action="store_true", help="Print advisory auto-detected commands and exit.")
    parser.add_argument("--clean-fixtures", action="store_true", help="Remove stale harness test workflow fixtures and exit.")
    parser.add_argument("--fixture", choices=sorted(WORKFLOW_FIXTURE_FUNCTIONS), help="Run one workflow fixture in isolation and exit.")
    parser.add_argument("--target", help="SPEC-110: run this gate over a registered target repository instead of the harness itself.")
    parser.add_argument("--parallel", nargs="?", const=0, type=int, default=None, metavar="N", help="SPEC-160 (scenarios gate): worker count for the sharded-parallel run (default: cores). Parallel IS the default since the 2026-07-21 owner flip (D041); this flag only tunes N.")
    parser.add_argument("--serial", action="store_true", help="SPEC-160 (scenarios gate): force the pre-flip serial loop (debug/reversal path; also the automatic fallback on any parallel-infra error).")
    args = parser.parse_args(argv)
    global QUIET
    if args.quiet:
        QUIET = True

    if getattr(args, "target", None):
        # Subject = target: generic structural checks over the target tree plus
        # the target's own gate commands; per-target quality-state persisted.
        target_results, target_status = gate_generic.run_target_gate(args.target, args.gate)
        print(f"\nGate {args.gate} [target {args.target}]: {target_status}")
        return 0 if target_status == "pass" else 1

    if args.list_detected:
        print(json.dumps(detected_commands(), indent=2, ensure_ascii=False))
        return 0
    if getattr(args, "clean_fixtures", False):
        cleanup_test_artifacts()
        print("Cleaned harness test fixtures")
        return 0
    if getattr(args, "fixture", None):
        cleanup_test_artifacts()
        fixture_results = WORKFLOW_FIXTURE_FUNCTIONS[args.fixture]()
        failed = [r for r in fixture_results if r["status"] == "fail"]
        cleanup_test_artifacts()
        return 1 if failed else 0

    cleanup_test_artifacts()
    # perf-metrics rung (Phase 1): coarse wall-time blocks + per-scenario/per-
    # fixture timings feed one cost_metrics gate record per run. ponytail:
    # block granularity on the cheap structural checks; split a block into
    # per-check timing only if it ever recurs in the slowest table.
    gate_t0 = time.monotonic()
    section_times: list[tuple[str, float]] = []
    results: list[dict[str, str]] = []
    core_t0 = time.monotonic()
    results.extend(check_required_files())
    results.extend(check_release_hygiene())
    sec_results, security = run_security_checks()
    results.extend(sec_results)
    product_release_fast = args.gate == "product-release"
    if product_release_fast:
        # Keep product-release as a bounded release smoke gate. Deep structural
        # validation lives under spec-pack/workflow/soak and CI invokes those
        # separately. This prevents release hygiene from hanging in interactive
        # sandboxes while still blocking leaks and contract drift.
        results.extend(check_json_syntax())
    else:
        results.extend(check_json_syntax())
        results.extend(check_yaml_syntax())
        results.extend(check_universal_specs())
        results.extend(check_testing_artifacts())
        results.extend(check_directory_guides())
        results.extend(check_runtime_portability())
        results.extend(check_knowledge_graph_policy())
        results.extend(check_workflow_policy())
        results.extend(check_self_review_freshness())
        results.extend(check_commit_hook_adoption())
        results.extend(gate_checks_policy.check_gate_controlplane() + gate_checks_policy.check_operator_only_gates() + check_precommit_override())  # SPEC-137: control-plane ENFORCING (live policy) + --no-verify audit (advisory); one line, gs-7 burndown ratchet
        results.extend(check_handles_lint())  # CE.3 G5: observe-only, cannot fail the gate
        results.extend(check_agent_parity())  # SPEC-113: observe-only hook parity + codex trust
        results.extend(check_test_quality())  # W29.N6: observe-only, reads what N4/N5 recorded
        results.extend(check_en_default_strings())  # SPEC-122: enforcing EN-default UI guard
    section_times.append(("core-checks", time.monotonic() - core_t0))
    if args.gate == "workflow":
        try:
            for fixture_name in ["engineering-guardrails", "protected-files", "deprecation-hygiene", "fixture-liveness", "workflow-id-boundary", "handoff-budget", "isolation-audit"]:
                cleanup_test_artifacts()
                fixture_t0 = time.monotonic()
                results.extend(WORKFLOW_FIXTURE_FUNCTIONS[fixture_name]())
                section_times.append((f"fixture:{fixture_name}", time.monotonic() - fixture_t0))
        finally:
            cleanup_test_artifacts()
    if args.gate == "soak":
        try:
            results.extend(run_isolated_workflow_fixture("workflow-soak"))
        finally:
            cleanup_test_artifacts()
    if args.gate == "scenarios":
        _run_scenarios_gate(args, results, section_times)
    if args.gate == "product-release":
        try:
            # Product-release fixtures are bounded and dependency-free; run them
            # directly with cleanup between fixtures so the release gate remains
            # fast enough for interactive sandboxes and CI smoke jobs. Heavy
            # process-isolated stress fixtures stay under workflow/soak gates.
            for fixture_name in ["release-integrity", "release-external-preflight", "trace-push-policy", "protected-files", "deprecation-hygiene"]:
                cleanup_test_artifacts()
                fixture_t0 = time.monotonic()
                results.extend(WORKFLOW_FIXTURE_FUNCTIONS[fixture_name]())
                section_times.append((f"fixture:{fixture_name}", time.monotonic() - fixture_t0))
        finally:
            cleanup_test_artifacts()
    tail_t0 = time.monotonic()
    results.extend(check_validation_policy())
    results.extend(check_python_compile())
    results.extend(check_static_integrity())
    if args.gate in {"spec-pack", "commit", "feature", "release", "product-release", "coverage", "workflow", "soak"}:
        results.extend(check_markdown_links())
        from harness_lib import wiki_conformance; results.extend(check_feature_spec_conformance() + wiki_conformance.check_wiki(ROOT))  # SPEC-167 wiki guard (net-zero wiring; harness_lib append impossible under gs-1/gs-6 freezes)
    results.extend(run_configured_commands(args.gate, no_project_commands=args.no_project_commands, dry_run=args.dry_run))
    if args.gate in {"feature", "release", "coverage"}:
        results.extend(run_coverage(args.gate, no_project_commands=args.no_project_commands, dry_run=args.dry_run))
    section_times.append(("tail-checks", time.monotonic() - tail_t0))

    status = "pass" if not any(r["status"] == "fail" for r in results) else "fail"
    counts = {"pass": 0, "fail": 0, "skip": 0}
    for item in results:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    failures = [r for r in results if r["status"] == "fail"]
    skips = [r for r in results if r["status"] == "skip"]
    RUNS.parent.mkdir(parents=True, exist_ok=True)
    log_rotation.spill_if_over(RUNS)  # R1: bound the append-only validation log (gap G1)
    with RUNS.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "gate": args.gate,
            "status": status,
            # subject-tagged-events (isolation Phase 4): harness-subject runs
            # only reach this writer (a --target run returns earlier through
            # run_target_gate, which stamps its own rows) — the field makes
            # that structural instead of implicit.
            "subject": "self",
            "counts": counts,
            "task": args.task,
            "specs": args.spec,
            "manifest": args.manifest,
            "changedFiles": args.changed_files,
            "results": results,
        }, ensure_ascii=False) + "\n")
    write_json(QUALITY, {
        "schemaVersion": "1.0",
        "lastValidation": {
            "gate": args.gate,
            "status": status,
            "validatedAt": now(),
            "counts": counts,
            "task": args.task,
            "specs": args.spec,
            "manifest": args.manifest,
            "failureCount": len(failures),
            "skipCount": len(skips),
            "failureNames": [r.get("name", "unknown") for r in failures[:10]],
            "details": ".harness/runs/validation-results.jsonl",
        },
        "qualityGates": {
            "requiresReview": args.gate in {"commit", "feature", "release", "coverage"} or bool(failures),
            "requiresSecurityReview": bool(security["new"]),
            "requiresMigrationReview": False,
        },
    })
    # perf-metrics rung: one small ledger record per gate run (never-crash
    # writer; slowest = top-5 coarse blocks/fixtures/scenarios of THIS run).
    from harness_lib import cost_metrics
    cost_metrics.record_gate(
        ROOT, gate=args.gate, status=status,
        total_s=time.monotonic() - gate_t0, checks=len(results),
        slowest=[{"name": n, "durationS": round(d, 3)}
                 for n, d in sorted(section_times, key=lambda t: -t[1])[:5]])
    log_tier_level(RUNS.parent / "tier-level.jsonl", args.gate,
                   security.get("riskTier"), status, counts["fail"])
    if QUIET:
        print(f"\nGate {args.gate}: {status} ({counts['pass']} pass, {counts['fail']} fail, {counts['skip']} skip)")
    else:
        print(f"\nGate {args.gate}: {status}")
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
