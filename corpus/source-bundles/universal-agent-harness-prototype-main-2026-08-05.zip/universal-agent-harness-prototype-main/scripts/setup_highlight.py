"""Provision the OPTIONAL vendored GUI assets (tree-sitter WASM + CodeMirror ESM).

First-run setup: installs the pinned highlight deps into ``.venv`` and fetches +
sha256-verifies every family listed as ``vendor/*/manifest.json`` — the
web-tree-sitter core/grammars/queries (~21MB) and the SPEC-147 CodeMirror 6
package set (~1.6MB). The harness CORE runs without any of this — the CLI and
panel degrade gracefully — so this is safe to skip and safe to re-run.

Idempotent with a fast path: each family records the sha256 of its manifest in
``resolved.json``; when that matches and every pinned file exists on disk, the
family is skipped without touching the network (this is what lets ``harness.py
ui`` call :func:`ensure_vendor` on every launch — SPEC-147 zero-touch
bootstrap). Stdlib only; cross-platform.

Run:  ./setup.sh   |   setup.bat   |   .venv/.../python scripts/setup_highlight.py
Assets are resolved from the npm registry using the versions + hashes pinned in
each manifest; nothing is trusted that does not match a pin.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import ssl
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENDOR_ROOT = ROOT / "vendor"
REQ = ROOT / "requirements-highlight.txt"


def _log(msg: str) -> None:
    print(f"[setup-highlight] {msg}", flush=True)


def _ensure_deps() -> bool:
    try:
        import tree_sitter  # noqa: F401
        import tree_sitter_language_pack  # noqa: F401
        return True
    except Exception:
        _log("installing optional deps (tree-sitter, language-pack) via `uv pip` ...")
        try:
            subprocess.run(["uv", "pip", "install", "-r", str(REQ)], check=True,
                           env={**os.environ, "VIRTUAL_ENV": str(ROOT / ".venv")})
            import tree_sitter  # noqa: F401
            import tree_sitter_language_pack  # noqa: F401
            return True
        except Exception as exc:  # noqa: BLE001
            _log(f"could not install deps ({exc}); CLI/panel will run WITHOUT highlighting")
            return False


def _get(url: str, *, timeout: int) -> bytes:
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(url, timeout=timeout, context=ctx) as resp:  # noqa: S310 (pinned host)
        return resp.read()


def _tarball_url(registry: str, version: str) -> str:
    meta = json.loads(_get(f"{registry}/{version}", timeout=60))
    return meta["dist"]["tarball"]


def _fetch_package(spec: dict, family_dir: Path, dest_sub: str) -> int:
    """Download the pinned npm tarball, verify each file's sha256, write to the family dir."""
    url = _tarball_url(spec["registry"], spec["version"])
    _log(f"fetching {spec['package']}@{spec['version']} ...")
    raw = _get(url, timeout=180)
    dest_dir = family_dir / dest_sub if dest_sub else family_dir
    dest_dir.mkdir(parents=True, exist_ok=True)
    written = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tf:
        members = {m.name: m for m in tf.getmembers()}
        for name, meta in spec["files"].items():
            member = members.get(meta["from"])
            if member is None:
                raise SystemExit(f"missing {meta['from']} in {spec['package']} tarball")
            data = tf.extractfile(member).read()  # type: ignore[union-attr]
            got = hashlib.sha256(data).hexdigest()
            if got != meta["sha256"]:
                raise SystemExit(f"sha256 mismatch for {name}: {got} != pinned {meta['sha256']}")
            (dest_dir / name).write_bytes(data)
            written += 1
        lic = members.get(spec.get("licenseFrom", ""))
        if lic is not None:
            (family_dir / spec["licenseDest"]).write_bytes(tf.extractfile(lic).read())  # type: ignore[union-attr]
    return written


def _export_queries(spec: dict, family_dir: Path) -> int:
    import tree_sitter_language_pack as tlp
    qd = family_dir / spec["dest"]
    qd.mkdir(parents=True, exist_ok=True)
    n = 0
    for stem, meta in spec["langs"].items():
        query = tlp.get_highlights_query(meta["packLang"]) or ""
        # Derived from the version-pinned pack; the panel validates each query against
        # its grammar at load and falls back to plain text on any mismatch, so the .scm
        # are not byte-pinned (they vary cosmetically with the pack's query cache).
        (qd / f"{stem}.scm").write_bytes(query.encode("utf-8"))
        n += 1
    return n


def _manifest_sha(family_dir: Path) -> str:
    return hashlib.sha256((family_dir / "manifest.json").read_bytes()).hexdigest()


def _pinned_files(manifest: dict) -> list[tuple[str, str]]:
    """(dest_sub, filename) for every byte-pinned file in either manifest shape."""
    out: list[tuple[str, str]] = []
    if "packages" in manifest:  # codemirror shape: flat family dir
        for spec in manifest["packages"].values():
            out.extend(("", name) for name in spec["files"])
    else:  # tree-sitter shape: core + grammars sections
        for key in ("core", "grammars"):
            spec = manifest.get(key) or {}
            out.extend((spec.get("dest", ""), name) for name in spec.get("files", {}))
    return out


def _satisfied(family_dir: Path, manifest: dict) -> bool:
    """Fast no-network check: resolved.json matches this manifest and files exist."""
    try:
        rpath = family_dir / "resolved.json"
        resolved = json.loads(rpath.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001 - absent/corrupt = not satisfied
        return False
    if not resolved.get("ok"):
        return False
    files_ok = all((family_dir / sub / name).is_file() for sub, name in _pinned_files(manifest))
    if files_ok and "manifestSha" not in resolved:
        # pre-SPEC-147 resolved.json: files were pin-verified when written — stamp
        # the manifest sha instead of refetching the whole family once.
        resolved["manifestSha"] = _manifest_sha(family_dir)
        rpath.write_text(json.dumps(resolved, indent=2) + "\n", encoding="utf-8")
    return files_ok and resolved["manifestSha"] == _manifest_sha(family_dir)


def _provision_family(family_dir: Path, manifest: dict, have_deps: bool) -> None:
    """Fetch one vendor family; a failed fetch degrades, never raises."""
    resolved: dict[str, object]
    try:
        if "packages" in manifest:
            n = sum(_fetch_package(spec, family_dir, "") for spec in manifest["packages"].values())
            resolved = {"files": n, "ok": n == len(manifest["packages"])}
        else:
            core = _fetch_package(manifest["core"], family_dir, "")
            grammars = _fetch_package(manifest["grammars"], family_dir, manifest["grammars"]["dest"])
            queries = _export_queries(manifest["queries"], family_dir) if have_deps else 0
            resolved = {"core": core, "grammars": grammars, "queries": queries,
                        "ok": bool(core and grammars and queries)}
            if not queries:
                _log("note: queries need the optional deps — run again after they install")
    except Exception as exc:  # noqa: BLE001 - a failed fetch must not brick the harness
        _log(f"{family_dir.name}: asset fetch failed ({exc}); the panel will degrade")
        return
    resolved["manifestSha"] = _manifest_sha(family_dir)
    (family_dir / "resolved.json").write_text(
        json.dumps(resolved, indent=2) + "\n", encoding="utf-8")
    _log(f"{family_dir.name}: provisioned ({resolved})")


def ensure_vendor(root: Path = ROOT) -> None:
    """Zero-touch bootstrap (SPEC-147 inv 4): reconcile every vendor family.

    Satisfied families are skipped without network (~ms). Optional Python deps
    install lazily, only when an unsatisfied family needs them. Any failure
    logs and returns — callers (``harness.py ui`` startup, setup scripts) must
    never be blocked by provisioning; the panel degrades and retries next launch.
    """
    have_deps: bool | None = None  # resolved lazily, at most once
    for mpath in sorted((root / "vendor").glob("*/manifest.json")):
        family_dir = mpath.parent
        try:
            manifest = json.loads(mpath.read_text(encoding="utf-8"))
            if _satisfied(family_dir, manifest):
                continue
            if have_deps is None and "queries" in manifest:
                have_deps = _ensure_deps()
            _provision_family(family_dir, manifest, bool(have_deps))
        except Exception as exc:  # noqa: BLE001
            _log(f"{family_dir.name}: skipped ({exc})")


def main() -> int:
    ensure_vendor(ROOT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
