"""P6 markdown renderer for the supervision panel chat (SPEC-114 QoL batch).

Exports MD_JS — a self-contained JS IIFE assigning `const MD` with the single API
`MD.renderInto(container, text)`. It is spliced into harness_ui_page.PAGE at the
`/*__MD_JS__*/` placeholder AFTER the page's esc() and HL (tree-sitter) globals are
defined, so it reuses both: every text node is escaped via esc() first (no raw HTML
from input ever reaches innerHTML), and fenced code blocks route through
HL.highlightBlock — degrading to a plain escaped <pre> when the WASM assets are absent.

Kept in its own module (not grown into the over-budget harness_ui_page.py); the same
renderer is intended to serve the future wiki screen.
"""
# ponytail: string concatenation over template literals in the JS below — keeps the
# Python raw string free of ${} / backtick collisions; str.replace() inserts it verbatim.
MD_JS = r"""
// Escape-first markdown -> DOM. Block state machine over lines; inline() runs on
// already-escaped text so **/*/`/[]() can never smuggle markup.
const MD = (function(){
  function inline(s){
    s = esc(s);                                                  // escape FIRST
    s = s.replace(/`([^`]+)`/g, function(m,c){ return "<code>" + c + "</code>"; });
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/\*([^*]+)\*/g, "<em>$1</em>");
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function(m,t,u){
      return '<a href="' + u.replace(/"/g, "%22") + '" target="_blank" rel="noopener">' + t + "</a>";
    });
    // Relative .md link (wiki cross-links): NO href -- inert everywhere; the wiki
    // content pane's delegated click resolves data-href against the current page
    // dir. Outside that pane (e.g. chat) it renders as plain styled text.
    s = s.replace(/\[([^\]]+)\]\((?!https?:)([^\s)]+\.md(?:#[^\s)]*)?)\)/g, function(m,t,u){
      return '<a class="mdrel" data-href="' + u.replace(/"/g, "%22") + '">' + t + "</a>";
    });
    return s;
  }
  function renderInto(container, text){
    const lines = String(text == null ? "" : text).split("\n");
    const frag = document.createDocumentFragment();
    let list = null;                                             // open <ul>/<ol>, else null
    let i = 0;
    while (i < lines.length){
      const line = lines[i];
      const fence = line.match(/^```\s*(\S*)/);
      if (fence){                                                // fenced code block
        list = null;
        const lang = fence[1] || "";
        const buf = [];
        i++;
        while (i < lines.length && !/^```/.test(lines[i])){ buf.push(lines[i]); i++; }
        i++;                                                     // consume the closing fence
        const pre = document.createElement("pre");
        const code = buf.join("\n");
        if (typeof HL !== "undefined" && HL.highlightBlock) HL.highlightBlock(pre, code, lang);
        else pre.textContent = code;                             // fallback: escaped plain <pre>
        frag.appendChild(pre);
        continue;
      }
      const h = line.match(/^(#{1,4})\s+(.*)$/);
      if (h){ list = null; const e = document.createElement("h" + h[1].length);
        e.innerHTML = inline(h[2]); frag.appendChild(e); i++; continue; }
      const bq = line.match(/^>\s?(.*)$/);
      if (bq){ list = null; const e = document.createElement("blockquote");
        e.innerHTML = inline(bq[1]); frag.appendChild(e); i++; continue; }
      const li = line.match(/^\s*[-*]\s+(.*)$/) || line.match(/^\s*\d+\.\s+(.*)$/);
      if (li){
        const want = /^\s*\d/.test(line) ? "ol" : "ul";
        if (!list || list.tagName.toLowerCase() !== want){ list = document.createElement(want); frag.appendChild(list); }
        const item = document.createElement("li"); item.innerHTML = inline(li[1]); list.appendChild(item);
        i++; continue;
      }
      if (!line.trim()){ list = null; i++; continue; }           // blank line ends a list
      list = null;
      const p = document.createElement("p"); p.innerHTML = inline(line); frag.appendChild(p);
      i++;
    }
    container.innerHTML = "";
    container.appendChild(frag);
  }
  return { renderInto };
})();
"""


if __name__ == "__main__":
    # ponytail: browser DOM code can't run here — this only guards against a truncated /
    # malformed export (the e2e path exercises the renderer in real chromium).
    assert "const MD" in MD_JS and "renderInto" in MD_JS and "highlightBlock" in MD_JS, "MD_JS export malformed"
    assert MD_JS.count("(function(){") >= 1 and "return { renderInto }" in MD_JS
    # wiki cross-link rule: emits a data-href anchor with NO href (inert outside the wiki pane).
    assert '<a class="mdrel" data-href="' in MD_JS, "mdrel relative-link anchor missing/malformed"
    assert '<a class="mdrel" href=' not in MD_JS, "mdrel anchor must carry no href attribute"
    print("harness_ui_page_md self-check ok")
