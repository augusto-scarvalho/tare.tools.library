"""SPEC-114 supervision panel front-end: the inline PAGE constant.

Split out of scripts/harness_ui.py (MF fragmentation). harness_ui.py keeps the
loopback server, routes, serve() and main(), and does `from harness_ui_page import PAGE`.
This is UI bulk (a self-contained HTML/CSS/JS document), not library logic.
"""
# -- inline front-end (single-screen, dark, vanilla, zero external requests) --
# SPEC-114 v2: one 100vh grid (no page scroll), terminal-parity transcript,
# pipe-event-driven busy/telemetry/mode, native <dialog> for records/metrics.
PAGE = r"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; connect-src 'self'; style-src 'unsafe-inline'; script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval'; base-uri 'none'; form-action 'none'">
<title>Harness supervision panel</title>
<style>
/* Design tokens — docs/DESIGN_SYSTEM.md is normative. Component CSS references
   tokens only; the sole hex literals on this page live in this block. */
:root {
  color-scheme: dark;
  /* typography */
  --font-ui: ui-sans-serif, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  --font-mono: ui-monospace, 'Cascadia Mono', 'Cascadia Code', Consolas, 'Liberation Mono', monospace;
  --text-xs: 0.75rem; --text-sm: 0.8125rem; --text-md: 0.875rem; --text-lg: 1rem;
  --line-tight: 1.25; --line-ui: 1.4; --line-reading: 1.55;
  /* surfaces (darkest -> brightest; never invent a new grey) */
  --bg-base: #090b0f; --bg-inset: #0c0f14;
  --surface-1: #10141a; --surface-2: #161b22; --surface-3: #1c232c;
  --surface-hover: #202833; --surface-control: #1a2028;
  --overlay-bg: rgb(16 20 26 / 0.96);
  /* structure */
  --border-subtle: #202832; --border: #27303a; --border-strong: #34404d;
  --line: 1px solid var(--border);
  /* text (contrast-audited — see docs/DESIGN_SYSTEM.md §2) */
  --text-primary: #eef1f5; --text-secondary: #9aa5b2;
  --text-muted: #7a8693; --text-disabled: #4e5865;
  /* accent: selection + primary action; the one brand hue */
  --accent: #8b7cff; --accent-hover: #9b8fff; --accent-contrast: #090b0f;
  --accent-bg: rgb(139 124 255 / 0.14); --accent-border: rgb(139 124 255 / 0.4);
  /* semantic families: text tone / 12% tint bg / 34% border / filled-control */
  --stream: #5ccfe6; --stream-bg: rgb(92 207 230 / 0.12); --stream-border: rgb(92 207 230 / 0.34);
  --success: #65c49a; --success-bg: rgb(101 196 154 / 0.12); --success-border: rgb(101 196 154 / 0.34); --success-strong: #3f8f69;
  --warning: #e0b66a; --warning-bg: rgb(224 182 106 / 0.12); --warning-border: rgb(224 182 106 / 0.34); --warning-strong: #9b7538;
  --danger: #e4777f; --danger-bg: rgb(228 119 127 / 0.12); --danger-border: rgb(228 119 127 / 0.34); --danger-strong: #b84a54;
  /* code highlighting only (tree-sitter + CM6) — never UI chrome */
  --syntax-keyword: #c98bdb; --syntax-operator: #b7bdc7; --syntax-string: #e0a07a;
  --syntax-escape: #d7b06a; --syntax-comment: #7f8895; --syntax-function: #e6d78a;
  --syntax-type: #6fd3bd; --syntax-number: #a8d99a; --syntax-constant: #86b8ff;
  --syntax-property: #9fd4ff; --syntax-parameter: #f0b98a; --syntax-punctuation: #8b93a0;
  /* spacing / shape / density */
  --space-1: 0.25rem; --space-2: 0.375rem; --space-3: 0.5rem;
  --space-4: 0.75rem; --space-5: 1rem; --space-6: 1.5rem;
  --topbar-h: 52px; --subnav-h: 38px; --row-h: 36px; --control-h: 32px;
  --radius-xs: 4px; --radius-sm: 6px; --radius-md: 8px; --radius-pill: 999px;
  --shadow-overlay: 0 16px 48px rgb(0 0 0 / 0.4);
  --backdrop: rgb(0 0 0 / 0.56);
}
* { box-sizing: border-box; }
html, body { height: 100%; }
body { margin: 0; font: var(--text-md)/var(--line-ui) var(--font-ui); background: var(--bg-base); color: var(--text-primary);
       display: flex; flex-direction: column; overflow: hidden; }
.mono { font-family: var(--font-mono); }
header { display: flex; align-items: center; gap: var(--space-1); min-height: var(--topbar-h);
         padding: 0 var(--space-4); background: var(--surface-2);
         border-bottom: 1px solid var(--border); flex-wrap: wrap; flex: 0 0 auto; }
header h1 { font-size: var(--text-lg); margin: 0 var(--space-4) 0 0; font-weight: 600; letter-spacing: -0.01em; }
.spacer { margin-left: auto; }
/* nav items are quiet borderless text buttons; selection = accent inset underline
   (.navsel below). The transparent border keeps .alert from shifting layout. */
.pillbtn { background: transparent; color: var(--text-secondary); border: 1px solid transparent; border-radius: var(--radius-sm);
           padding: 0 var(--space-3); min-height: var(--control-h); cursor: pointer; font: inherit; font-size: var(--text-sm); }
.pillbtn:hover { background: var(--surface-hover); color: var(--text-primary); }
.pillbtn.alert { border-color: var(--danger-border); color: var(--danger); }   /* red when escalations+attention > 0 */
#onboardChip { border-color: var(--border); }  /* repo/profile switcher reads as a control, not navigation */
#modeBadge { background: var(--accent-bg); color: var(--accent); border-color: var(--accent); }
.badge2 { display: inline-block; padding: 0.15rem 0.55rem; border-radius: var(--radius-sm); font-size: var(--text-sm); font-weight: 600; }
.badge2.ok { background: var(--success-bg); color: var(--success); } .badge2.bad { background: var(--danger-bg); color: var(--danger); }
.badge2.none { background: var(--border); color: var(--text-secondary); }
.chip { display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.12rem 0.5rem; border-radius: var(--radius-pill);
        font-size: var(--text-sm); font-weight: 600; background: var(--surface-hover); color: var(--text-secondary); white-space: nowrap; }
.chip.na { color: var(--text-muted); background: var(--surface-1); font-weight: 400; }
.chip.ctx { color: var(--accent); } .chip.cin { color: var(--stream); } .chip.cout { color: var(--success); }
.chip.cost { color: var(--warning); } .chip.dur { color: var(--text-secondary); } .chip.sess { color: var(--text-muted); }
#warnBadge { background: var(--danger-bg); color: var(--warning); }
select, input { background: var(--bg-inset); color: var(--text-primary); border: 1px solid var(--border); border-radius: var(--radius-sm);
                padding: 0.28rem 0.45rem; font: inherit; }
button.act { background: var(--accent); color: var(--accent-contrast); border: none; border-radius: var(--radius-sm);
             padding: 0 var(--space-4); min-height: var(--control-h); cursor: pointer; font: inherit;
             font-size: var(--text-sm); font-weight: 600; }
button.act:hover { background: var(--accent-hover); }
button.act.danger, button.act.stop { background: var(--danger-strong); color: #fff; }
button.act.danger:hover, button.act.stop:hover { background: var(--danger-strong); filter: brightness(1.12); }
button.act.stop { white-space: nowrap; }
button.act:disabled { opacity: 0.45; cursor: not-allowed; filter: none; }
.body { flex: 1 1 auto; display: flex; min-height: 0; }
/* stats HUD: floats top-RIGHT over the transcript (messages are left-aligned, so
   the right corner covers nothing). .min = one compact cost line; expanded adds
   the Metrics body. The old side columns are gone — their space is reserved for
   the file tree / diff+editor workspace (docs/roadmap/chat-workspace.md). */
.hud { position: absolute; top: 2.6rem; right: 0.6rem; z-index: 6; max-width: 26rem;
       background: var(--overlay-bg); border: 1px solid var(--border); border-radius: var(--radius-md);
       box-shadow: var(--shadow-overlay); }
.hud.min { max-width: 15rem; }  /* compact pill; long stats wrap to the next line */
.hudbar { display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap; padding: 0.3rem 0.5rem; }
.hudbar #hudToggle { margin-left: auto; }
#hudLine { font-size: var(--text-sm); overflow-wrap: anywhere; }
.hudbody { display: none; border-top: 1px solid var(--border-subtle); padding: 0.5rem 0.6rem;
           max-height: 55vh; overflow-y: auto; }
.hud:not(.min) .hudbody { display: block; }
.hudbody h2 { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.05em;
        color: var(--text-muted); margin: 0 0 0.4rem; }
#ledger { font-size: var(--text-sm); }
/* R26: ledger cards — kind badge + ellipsised title + dim short ref + tag micro-badges */
.lcard { border: 1px solid var(--border-subtle); border-left: 3px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface-1);
         padding: 0.35rem 0.45rem; margin-bottom: 0.35rem; }
.lcard .ltop { display: flex; align-items: center; gap: 0.35rem; }
.kbadge { padding: 0.03rem 0.4rem; border-radius: var(--radius-xs); font-size: var(--text-xs); font-weight: 600;
          text-transform: uppercase; letter-spacing: 0.03em; background: var(--border); color: var(--text-secondary); }
.kbadge.milestone { background: var(--accent-bg); color: var(--accent); } .kbadge.decision { background: var(--accent-bg); color: var(--accent); }
.kbadge.note { background: var(--border); color: var(--text-secondary); } .kbadge.amber { background: var(--warning-bg); color: var(--warning); }
.lref { font-size: var(--text-xs); color: var(--text-muted); }
.ldate { padding: 0.03rem 0.4rem; border-radius: var(--radius-xs); font-size: var(--text-xs); background: var(--surface-hover); color: var(--text-muted); }
.ltitle { font-size: var(--text-sm); color: var(--text-secondary); margin: 0.15rem 0; overflow: hidden;
          display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.ltag { display: inline-block; padding: 0 0.3rem; margin: 0.1rem 0.2rem 0 0; border-radius: var(--radius-xs);
        background: var(--surface-hover); color: var(--text-muted); font-size: var(--text-xs); }
/* R27: metrics mini-dashboard — stat tiles + horizontal mini-bars (pure CSS) */
.stiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(5.2rem, 1fr)); gap: 0.4rem; margin-bottom: 0.6rem; }
.stile { background: var(--surface-2); border: 1px solid var(--border); border-left: 3px solid var(--border-strong); border-radius: var(--radius-sm);
         padding: 0.35rem 0.5rem; }
.stile.cost { border-left-color: var(--warning); } .stile.turns { border-left-color: var(--accent); }
.stile.deleg { border-left-color: var(--success); } .stile.wf { border-left-color: var(--stream); } .stile.rec { border-left-color: var(--text-secondary); }
.snum { font-size: var(--text-lg); font-weight: 700; color: var(--text-primary); }
.slabel { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.03em; color: var(--text-muted); }
.ssub { font-size: var(--text-xs); color: var(--success); margin-top: 0.1rem; }
.mbar { margin-bottom: 0.4rem; }
.mbtop { display: flex; align-items: center; gap: 0.35rem; font-size: var(--text-sm); margin-bottom: 0.15rem; }
.mbid { color: var(--text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mbval { margin-left: auto; color: var(--warning); white-space: nowrap; }
.mbtrack { height: 5px; background: var(--surface-hover); border-radius: var(--radius-xs); overflow: hidden; }
.mbfill { height: 100%; background: var(--accent); border-radius: var(--radius-xs); min-width: 2px; }
.center { flex: 1 1 auto; display: flex; flex-direction: column; min-width: 0; position: relative; }
#transcript { flex: 1 1 auto; overflow-y: auto; white-space: pre-wrap; word-break: break-word;
        padding: 0.6rem 0.8rem; background: var(--bg-inset); font-size: var(--text-md); }
#transcript .ln { min-height: 1.1em; }
#transcript .ln.user { color: var(--accent); }
#transcript .ln.err { color: var(--text-muted); font-style: italic; }
#transcript .ln.dim { color: var(--text-muted); }
#transcript .ln.busy { color: var(--warning); }
/* SPEC-114 v13 verbose chat: mid-turn tool/shell activity line + a dim per-turn model tag */
#transcript .ln.tool { color: var(--stream); font-size: 0.92em; }
#transcript .ln.tool .tmodel { color: var(--text-muted); }
#transcript a { color: var(--accent); }
/* P6 markdown message: block flow inside one transcript line (transcript is pre-wrap) */
#transcript .ln.md, #transcript .ln.approve { white-space: normal; }
.md h1, .md h2, .md h3, .md h4 { margin: 0.4em 0 0.2em; line-height: 1.3; }
.md h1 { font-size: 1.2em; } .md h2 { font-size: 1.1em; } .md h3, .md h4 { font-size: 1em; }
.md p { margin: 0.3em 0; }
.md ul, .md ol { margin: 0.3em 0; padding-left: 1.4em; }
.md blockquote { margin: 0.3em 0; padding-left: 0.7em; border-left: 3px solid var(--border); color: var(--text-secondary); }
.md code { background: var(--surface-hover); padding: 0.05em 0.3em; border-radius: var(--radius-xs);
           font-family: var(--font-mono); font-size: 0.92em; }
.md pre { background: var(--bg-inset); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 0.5rem;
          overflow-x: auto; white-space: pre-wrap; word-break: break-word; }
.md pre code { background: none; padding: 0; }
.ln.approve { display: flex; gap: 0.5rem; align-items: center; margin: 0.2rem 0; }
/* SPEC-146 room exit affordance: centered under the overseer's farewell */
.ln.leaveroom { display: flex; justify-content: center; margin: 0.5rem 0; }
.ln.leaveroom button { font-size: var(--text-md); padding: 0.3rem 0.9rem; }
#chips { flex: 0 0 auto; display: flex; gap: 0.4rem; flex-wrap: wrap; padding: 0.4rem 0.8rem;
         border-top: 1px solid var(--border-subtle); background: var(--surface-1); }
.inputrow { flex: 0 0 auto; display: flex; align-items: stretch; gap: 0.5rem; padding: 0.5rem 0.8rem;
            border-top: 1px solid var(--border-subtle); background: var(--surface-1); }
.inputrow #chatin { flex: 1; resize: none; max-height: 9em; overflow-y: auto; line-height: 1.4;
                    background: var(--bg-inset); color: var(--text-primary); border: 1px solid var(--border); border-radius: var(--radius-sm);
                    padding: 0.28rem 0.45rem; font: inherit; }
.inputrow #modeBadge { display: flex; align-items: center; white-space: nowrap; }
.inputrow #attach { display: flex; align-items: center; padding: 0 0.5rem; }
.dropping { outline: 2px dashed var(--accent); outline-offset: -2px; }
.stale { color: var(--warning); }
.sessionbar { flex: 0 0 auto; display: flex; align-items: center; gap: 0.3rem; overflow-x: auto;
              padding: 0.35rem 0.6rem; border-bottom: 1px solid var(--border-subtle); background: var(--surface-1); }
.stab { display: inline-flex; align-items: center; gap: 0.3rem; padding: 0.18rem 0.5rem; cursor: pointer;
        border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--surface-hover); color: var(--text-secondary);
        font-size: var(--text-sm); white-space: nowrap; }
.stab.active { border-color: var(--accent); color: var(--accent); background: var(--accent-bg); }
.stab .sx { color: var(--text-muted); } .stab .sx:hover { color: var(--danger); }
.stab .sdead { color: var(--danger); }
.snew { background: transparent; color: var(--text-secondary); border: 1px solid transparent; border-radius: var(--radius-sm);
        padding: 0.18rem 0.55rem; cursor: pointer; font: inherit; font-size: var(--text-sm); white-space: nowrap; }
.snew:hover { background: var(--surface-hover); color: var(--text-primary); }
/* UX-GA.1 risk-summary strip (now inside the Alerts dialog) */
#riskSum { display: flex; flex-wrap: wrap; gap: 0.3rem; align-items: center; font-size: var(--text-xs); }
#riskSum .chip.dim { opacity: 0.5; }
#riskSum .rs-bad { color: var(--danger); border-color: var(--danger-strong); }
#riskSum .rs-top { flex-basis: 100%; font-size: var(--text-xs); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
/* gate tier chips (still used by the chat gate sub-tracker) */
.gtiers { display: flex; flex-wrap: wrap; gap: 0.25rem; margin-top: 0.35rem; }
.gtier { font-size: var(--text-xs); padding: 0.05rem 0.4rem; border-radius: var(--radius-xs); background: var(--surface-hover); color: var(--text-muted); }
.gtier.on.ok { background: var(--success-bg); color: var(--success); } .gtier.on.bad { background: var(--danger-bg); color: var(--danger); }
.gtier.on.none { background: var(--border); color: var(--text-secondary); }
.gline { font-size: var(--text-sm); margin-bottom: 0.25rem; }
.gline .mono { color: var(--text-secondary); }
/* N3 flight-strip attention bay: ordered by attention tier, each names an action */
.astrip { background: var(--surface-2); border: 1px solid var(--border); border-left: 3px solid var(--border-strong); border-radius: var(--radius-sm);
          padding: 0.4rem 0.55rem; margin-bottom: 0.4rem; }
.astrip.s-escalation { border-left-color: var(--danger-strong); } .astrip.s-gate { border-left-color: var(--warning); }
.astrip.s-worker { border-left-color: var(--stream); }
.astrip.clickable, .astrip.esc-jump { cursor: pointer; }
.astrip.clickable:hover, .astrip.esc-jump:hover { border-color: var(--border-strong); }
.astrip .atop { display: flex; align-items: center; gap: 0.4rem; }
.asrc { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted);
        background: var(--surface-hover); padding: 0.03rem 0.4rem; border-radius: var(--radius-xs); flex: 0 0 auto; }
.alabel { font-size: var(--text-sm); color: var(--text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.adet { font-size: var(--text-sm); color: var(--text-secondary); margin: 0.2rem 0; word-break: break-word; }
.anext { font-size: var(--text-sm); }
.wcard { background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 0.4rem 0.55rem;
         margin-bottom: 0.4rem; }
.wcard.dim { opacity: 0.55; }
/* UX-GA.2: grouped fan-out worker cards — one bordered group per workflow/wave */
.wgroup { border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 0.35rem 0.4rem; margin-bottom: 0.5rem; }
/* full-page homes (Tasks/Queue): cards tile instead of stacking a narrow column */
.decsgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(22rem, 1fr)); gap: 0.5rem; }
#agents { display: grid; grid-template-columns: repeat(auto-fill, minmax(24rem, 1fr)); gap: 0.5rem; }
#agents .wgroup { margin-bottom: 0; }
.wgroup .wcard:last-child { margin-bottom: 0; }
.wghead { display: flex; align-items: center; gap: 0.4rem; margin-bottom: 0.35rem; min-width: 0; overflow: hidden; }
.wgid { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-secondary); overflow-wrap: anywhere; }
.wgcounts { font-size: var(--text-xs); margin-left: auto; flex: 0 0 auto; }
.wtop { display: flex; align-items: center; gap: 0.4rem; }
.wid { font-family: var(--font-mono); font-size: var(--text-sm); }
.wmeta { font-size: var(--text-sm); color: var(--text-muted); margin-top: 0.15rem; }
.pill { margin-left: auto; padding: 0.05rem 0.45rem; border-radius: var(--radius-pill); font-size: var(--text-xs); font-weight: 600; }
.pill.run { background: var(--warning-bg); color: var(--warning); animation: pulse 1.4s ease-in-out infinite; }
.pill.queue { background: var(--border); color: var(--text-secondary); } .pill.ok { background: var(--success-bg); color: var(--success); }
.pill.bad { background: var(--danger-bg); color: var(--danger); } .pill.done { background: var(--border-subtle); color: var(--text-secondary); }
@keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.5; } }
.ecard { background: var(--surface-2); border: 1px solid var(--border); border-left: 3px solid var(--border-strong); border-radius: var(--radius-sm);
         padding: 0.45rem 0.55rem; margin-bottom: 0.45rem; }
.ecard .etop { display: flex; align-items: center; gap: 0.4rem; }
.ecard .eid { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-secondary); }
.ecard .ereason { font-size: var(--text-sm); margin: 0.25rem 0; word-break: break-word; }
.ecard .eprof { font-size: var(--text-sm); color: var(--text-muted); margin-bottom: 0.3rem; }
/* v12: keep a long id / suggestedProfile from overflowing the escalation/worker cards.
   min-width:0 lets the flex rows shrink; overflow-wrap breaks the long mono tokens. */
.ecard, .wcard, .etop, .wtop { min-width: 0; overflow: hidden; }
.etop > *, .wtop > * { min-width: 0; }
.eid, .eprof, .wid, .wmeta, .ereason { overflow-wrap: anywhere; }
.badge { display: inline-block; padding: 0.05rem 0.45rem; border-radius: var(--radius-pill); font-size: var(--text-xs); font-weight: 600; }
.badge.critical { background: var(--danger-bg); color: var(--danger); } .badge.high { background: var(--warning-border); color: var(--warning); }
.badge.watch { background: var(--stream-bg); color: var(--stream); } .badge.info, .badge.none { background: var(--border); color: var(--text-secondary); }
/* SPEC-145 v2: compact colored pill badges per decision action (replace the big
   buttons). Rendered as <button> so the existing data-di click handler + disable
   still work; unknown choice falls back to the neutral base .abadge. */
.abadge { display: inline-block; border: none; border-radius: var(--radius-pill); padding: 1px 8px; margin: 0.2rem 0.25rem 0 0;
          font: inherit; font-size: var(--text-xs); font-weight: 600; color: var(--text-primary); background: var(--border-strong); cursor: pointer; }
.abadge:hover { filter: brightness(1.18); }
.abadge:disabled { opacity: 0.5; cursor: not-allowed; }
.abadge-done { background: var(--border-strong); } .abadge-resolve { background: var(--border-strong); }
.abadge-discard { background: var(--danger-strong); } .abadge-spec { background: var(--accent); }
.abadge-experiment { background: var(--success-strong); } .abadge-backlog { background: var(--accent); color: var(--text-primary); }
/* SPEC-145 v2: cap the Decisions list to ~2 cards; the rest scrolls inside the
   section so it never eats the right column. Full question stays in the title
   tooltip + the confirm modal (the card text is clamped to 2 lines). */
#decs { max-height: 230px; overflow-y: auto; }
#decs .ereason { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.dim { color: var(--text-muted); }
dialog { background: var(--surface-1); color: var(--text-primary); border: 1px solid var(--border); border-radius: var(--radius-md);
         box-shadow: var(--shadow-overlay); width: min(52rem, 92vw);
         max-height: 85vh; padding: 0; }
dialog::backdrop { background: var(--backdrop); }
.dlghead { display: flex; align-items: center; padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border); }
.dlghead h2 { margin: 0; font-size: var(--text-lg); } .dlghead .x { margin-left: auto; background: none; border: none;
         color: var(--text-secondary); font-size: var(--text-lg); cursor: pointer; }
.dlgbody { padding: 0.7rem 0.8rem; overflow: auto; max-height: 70vh; }
.dlgrow { display: flex; gap: 0.5rem; flex-wrap: wrap; padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--border-subtle); }
/* v12 confirm/alert/prompt modal (replaces native dialogs) */
#confirmDlg { width: min(40rem, 92vw); }
#confirmMsg { white-space: pre-wrap; word-break: break-word; font-size: var(--text-md); margin-bottom: 0.6rem; }
#confirmInput, #confirmSel { width: 100%; margin-bottom: 0.6rem; }
/* v12 conservative git-diff colorizer (diff-only, no language tokenizer) */
.dadd { color: var(--success); } .ddel { color: var(--danger); }
.dhunk { color: var(--stream); } .dhead { color: var(--text-muted); font-weight: 600; }
/* tree-sitter syntax tokens (native WASM highlighter; capture -> class). Dark palette. */
.ts-keyword { color: var(--syntax-keyword); } .ts-operator { color: var(--syntax-operator); }
.ts-string { color: var(--syntax-string); } .ts-escape { color: var(--syntax-escape); }
.ts-comment { color: var(--syntax-comment); font-style: italic; }
.ts-function { color: var(--syntax-function); } .ts-constructor, .ts-type { color: var(--syntax-type); }
.ts-number, .ts-float, .ts-boolean { color: var(--syntax-number); }
.ts-constant { color: var(--syntax-constant); }
.ts-property, .ts-attribute { color: var(--syntax-property); } .ts-tag { color: var(--syntax-constant); }
.ts-variable-parameter { color: var(--syntax-parameter); } .ts-punctuation { color: var(--syntax-punctuation); }
.ts-label { color: var(--syntax-property); }
.hl-ln { white-space: pre-wrap; word-break: break-word; }
table { border-collapse: collapse; width: 100%; font-size: var(--text-md); }
th, td { text-align: left; padding: 0.3rem 0.5rem; border-bottom: 1px solid var(--border-subtle); vertical-align: top; word-break: break-word; }
th { color: var(--text-muted); }
.dlgbody h3 { font-size: var(--text-sm); text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); margin: 0.8rem 0 0.2rem; }
.dlgbody h3:first-child { margin-top: 0; }
/* SPEC-114 v6 worker drill-in */
.wcard.clickable { cursor: pointer; } .wcard.clickable:hover { border-color: var(--border-strong); }
#wkMeta { font-size: var(--text-sm); color: var(--text-muted); margin-left: auto; }
/* SPEC-114 v9 N4 recovery console: a small allowlisted-verb bar inside the drawer */
.wkrec { display: flex; gap: 0.4rem; align-items: center; flex-wrap: wrap; padding: 0.4rem 0 0.2rem; }
.wkrec .dim { font-size: var(--text-sm); }
#wkOut { font-family: var(--font-mono); font-size: var(--text-sm); white-space: pre-wrap; word-break: break-word;
         max-height: 60vh; overflow: auto; background: var(--bg-inset); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm);
         padding: 0.5rem; }
.wln { padding: 0.02rem 0; } .wln.wtool { color: var(--stream); } .wln.wtext { color: var(--text-primary); }
.wln.wresult { color: var(--success); } .wln.dim { color: var(--text-muted); }
#wkErr { font-family: var(--font-mono); font-size: var(--text-sm); white-space: pre-wrap; word-break: break-word;
         max-height: 24vh; overflow: auto; color: var(--danger); }
.wev { font-size: var(--text-sm); padding: 0.1rem 0; }
/* SPEC-129 v2 (UX-GA.3 phase 2) evidence drill-in: handles rendered as text */
.ebkv { font-size: var(--text-sm); padding: 0.1rem 0; word-break: break-all; }
.ebref { font-size: var(--text-sm); padding: 0.1rem 0; word-break: break-all; }
/* SPEC-115 config view: model-card grid + routing matrix + advanced JSON */
.navsel { color: var(--text-primary) !important; box-shadow: inset 0 -2px 0 var(--accent); }
/* "Advanced" dropdown: native <details>, rightmost in the header */
.navdrop { position: relative; }
.navdrop > summary { list-style: none; display: inline-block; }
.navdrop > summary::-webkit-details-marker { display: none; }
.navdropmenu { position: absolute; right: 0; top: calc(100% + 4px); display: flex;
  flex-direction: column; gap: 4px; padding: 6px; min-width: 10rem; z-index: 60;
  background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius-sm); }
.navdropmenu .pillbtn { text-align: left; }
/* Every full-page view must own its scroll: body is overflow:hidden, so a view
   without overflow-y:auto CLIPS anything taller than the window (the kanban
   board was the visible case — long columns simply vanished below the fold). */
#viewConfig, #viewCompose, #viewTasks, #viewQueue, #viewChangelog, #viewMemory,
#viewSpecs, #viewResearch, #viewExperiments, #viewGraphs, #viewFallbacks {
  flex: 1 1 auto; overflow-y: auto; padding: 0.8rem 1rem; background: var(--bg-base); }
/* Wiki: two-pane reader (tree sidebar + markdown content), each pane owns its scroll. */
#viewWiki { flex: 1 1 auto; min-height: 0; background: var(--bg-base); }
.wikiwrap { display: flex; height: 100%; min-height: 0; }
.wikinav { flex: 0 0 16rem; overflow-y: auto; padding: 0.6rem 0.4rem;
  border-right: 1px solid var(--border); background: var(--surface-1); }
.wikinav .wikidir { color: var(--text-secondary); font-weight: 600; font-size: var(--text-sm);
  margin: 0.5rem 0 0.15rem; }
.wikinav .wikipage { display: block; width: 100%; text-align: left; border: none;
  background: transparent; color: var(--text-primary); cursor: pointer; font: inherit;
  padding: 0.15rem 0.35rem; border-radius: var(--radius-xs); }
.wikinav .wikipage:hover { background: var(--surface-hover); }
.wikinav .wikipage.sel { background: var(--surface-2); color: var(--accent); }
.wikibody { flex: 1 1 auto; overflow-y: auto; padding: 0.8rem 1.4rem; }
.wikibody .md { max-width: 60rem; }
.md a.mdrel { color: var(--accent); cursor: pointer; text-decoration: underline; }
.wikisrc { color: var(--text-muted); font-size: var(--text-sm); margin-top: 0.6rem; }
.cfgwrap { display: flex; flex-direction: column; gap: 1rem; max-width: 74rem; margin: 0 auto; }
.cfgsec { background: var(--surface-1); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 0.8rem; }
.cfghead { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.6rem; }
.cfghead h2 { margin: 0; font-size: var(--text-md); color: var(--text-primary); }
.iconbtn { margin-left: auto; background: transparent; color: var(--text-muted); border: 1px solid transparent; border-radius: var(--radius-sm);
           padding: 0.15rem 0.45rem; cursor: pointer; font-family: var(--font-mono); font-size: var(--text-sm); }
.iconbtn:hover { color: var(--text-primary); background: var(--surface-hover); }
.cardgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(13rem, 1fr)); gap: 0.6rem; }
.mcard { border: 1px solid var(--border-subtle); border-radius: var(--radius-md); background: var(--surface-2); padding: 0.6rem; cursor: pointer; position: relative; }
.mcard:hover { border-color: var(--border-strong); }
.mcard.add { display: flex; align-items: center; justify-content: center; color: var(--text-muted);
             border-style: dashed; min-height: 6rem; font-size: var(--text-md); }
.mprov { display: inline-block; padding: 0.05rem 0.45rem; border-radius: var(--radius-xs); font-size: var(--text-xs); font-weight: 600;
         background: var(--border); color: var(--text-secondary); }
/* provider/vendor is identity, not status — no per-vendor colors (design system §1) */
.mname { font-size: var(--text-lg); font-weight: 600; margin: 0.3rem 0 0.1rem; }
.mid { font-size: var(--text-xs); color: var(--text-muted); }
.mpills { margin-top: 0.35rem; display: flex; flex-wrap: wrap; gap: 0.2rem; }
.rpill { padding: 0.02rem 0.42rem; border-radius: var(--radius-pill); font-size: var(--text-xs); background: var(--surface-hover); color: var(--text-muted); }
.rpill.def { background: var(--accent-bg); color: var(--accent); }
.overseerbadge { position: absolute; top: 0.5rem; right: 0.55rem; font-size: var(--text-xs); font-weight: 700;
                 text-transform: uppercase; letter-spacing: 0.04em; padding: 0.08rem 0.4rem; border-radius: var(--radius-xs);
                 background: var(--accent-bg); color: var(--accent); }
.mctx { font-size: var(--text-xs); color: var(--text-muted); margin-top: 0.3rem; }
/* GUI-RG1 4-layer model card dialog: each layer a separated block with a LAYER LABEL
   (the acceptance is declared != measured, so the separation IS the design) */
#mcDlg { max-width: 46rem; width: 92vw; }
.mcmeta { display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; margin-bottom: 0.7rem; }
.mcacct { padding: 0.1rem 0.5rem; border-radius: var(--radius-sm); font-size: var(--text-xs); font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.04em; }
.mcacct.measured { background: var(--success-bg); color: var(--success); }
.mcacct.estimate, .mcacct.emulated { background: var(--warning-bg); color: var(--warning); }
.mchealth { padding: 0.1rem 0.5rem; border-radius: var(--radius-pill); font-size: var(--text-xs); font-weight: 700; }
.mchealth.healthy { background: var(--success-bg); color: var(--success); }
.mchealth.open { background: var(--danger-bg); color: var(--danger); }
.mcengine { font-size: var(--text-xs); color: var(--text-secondary); background: var(--border); padding: 0.05rem 0.45rem; border-radius: var(--radius-xs); }
.mcsec { border: 1px solid var(--border-subtle); border-radius: var(--radius-md); background: var(--surface-2);
         padding: 0.6rem 0.7rem; margin-bottom: 0.6rem; }
.mclabel { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
           color: var(--text-muted); margin-bottom: 0.45rem; }
.mckv { display: grid; grid-template-columns: 9rem 1fr; gap: 0.15rem 0.6rem; font-size: var(--text-sm); }
.mckv dt { color: var(--text-muted); } .mckv dd { margin: 0; color: var(--text-primary); overflow-wrap: anywhere; }
.mctag { font-size: var(--text-xs); background: var(--surface-hover); color: var(--text-secondary); padding: 0.05rem 0.42rem; border-radius: var(--radius-pill); margin-right: 0.25rem; }
.mcnote { font-size: var(--text-xs); color: var(--text-muted); margin-top: 0.35rem; }
.mcstat { font-size: var(--text-sm); margin: 0.15rem 0; } .mcstat .mcstatk { color: var(--text-muted); }
.mcprov { font-size: var(--text-xs); color: var(--text-muted); margin: 0.05rem 0 0.45rem; overflow-wrap: anywhere; }
.mcbasis { font-size: var(--text-xs); font-weight: 600; color: var(--warning); }
.mcbasis.measured { color: var(--success); }
.mcprobe { font-size: var(--text-sm); margin: 0.2rem 0; } .mcprobe .dim { margin-left: 0.4rem; }
.mcfell { font-size: var(--text-sm); border-left: 2px solid var(--danger-border); padding-left: 0.5rem; margin: 0.25rem 0; }
.mcpills { display: flex; flex-wrap: wrap; gap: 0.3rem; }
.mcpill { font-size: var(--text-xs); font-weight: 600; padding: 0.1rem 0.5rem; border-radius: var(--radius-pill);
          background: var(--surface-hover); color: var(--text-secondary); }
.mcpill.routed { background: var(--accent-bg); color: var(--accent); }
.mcpill.judged { background: var(--stream-bg); color: var(--stream); }
.mcpill.gate { background: var(--success-bg); color: var(--success); }
.mcpill.gate.closed { background: var(--warning-bg); color: var(--warning); }
.profilebar { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.6rem; }
.activepill { padding: 0.15rem 0.55rem; border-radius: var(--radius-pill); font-size: var(--text-sm); font-weight: 600;
              background: var(--accent-bg); color: var(--accent); }
.robadge { font-size: var(--text-xs); color: var(--text-muted); background: var(--surface-hover); padding: 0.08rem 0.42rem; border-radius: var(--radius-xs); }
.targetchips { display: flex; flex-wrap: wrap; gap: 0.35rem; margin-bottom: 0.6rem; }
.matrix { display: flex; flex-direction: column; gap: 0.4rem; }
.mrow { display: grid; grid-template-columns: 9rem 1fr auto; gap: 0.6rem; align-items: center; padding: 0.45rem 0.6rem;
        border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); background: var(--surface-1); cursor: pointer; }
.mrow:hover { border-color: var(--accent); background: var(--surface-hover); }
.mrow:focus-visible { outline: 2px solid var(--accent); outline-offset: 1px; }
.mrole { font-size: var(--text-sm); font-weight: 600; }
.mrole .risk { display: block; font-size: var(--text-xs); font-weight: 400; text-transform: uppercase; letter-spacing: 0.04em; }
.risk.low { color: var(--success); } .risk.medium { color: var(--warning); } .risk.high, .risk.critical { color: var(--danger); }
.mrow .edithint { font-size: var(--text-xs); color: var(--text-muted); white-space: nowrap; }
.mrow:hover .edithint { color: var(--accent); }
.chain { display: flex; align-items: center; gap: 0.3rem; flex-wrap: wrap; }
.cchip { display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.12rem 0.5rem; border-radius: var(--radius-pill);
         font-size: var(--text-sm); background: var(--surface-hover); color: var(--text-secondary); }
.cchip.primary { background: var(--accent-bg); color: var(--accent); } .cchip.broken { background: var(--danger-bg); color: var(--danger); }
.arrow { color: var(--text-muted); }
/* role edit dialog: ordered chain of card+effort selects */
.rolerisk { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; padding: 0.06rem 0.4rem;
            border-radius: var(--radius-xs); margin-left: 0.4rem; vertical-align: middle; background: var(--border); color: var(--text-secondary); }
.roledesc { color: var(--text-muted); font-size: var(--text-sm); margin: 0 0 0.6rem; }
.forkbanner { background: var(--accent-bg); color: var(--accent); border: 1px solid var(--accent); border-radius: var(--radius-sm);
              padding: 0.45rem 0.6rem; margin-bottom: 0.6rem; font-size: var(--text-sm); }
.forkbanner input { margin-top: 0.35rem; width: 100%; }
.rentry { display: flex; align-items: center; gap: 0.4rem; padding: 0.35rem 0; }
.rentry .rlabel { flex: 0 0 5.2rem; font-size: var(--text-xs); color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.03em; }
.rentry select.rcard { flex: 1 1 auto; } .rentry select.reff { flex: 0 0 8rem; }
.rentry .ebtn { background: transparent; color: var(--text-secondary); border: 1px solid var(--border); border-radius: var(--radius-sm);
                padding: 0.1rem 0.45rem; cursor: pointer; font: inherit; font-size: var(--text-sm); }
.rentry .ebtn:disabled { opacity: 0.3; cursor: default; }
/* card form: reasoning pill multi-select */
.pillsel { display: flex; flex-wrap: wrap; gap: 0.3rem; }
.rpillbtn { padding: 0.12rem 0.6rem; border-radius: var(--radius-pill); font-size: var(--text-sm); cursor: pointer;
            background: var(--surface-hover); color: var(--text-muted); border: 1px solid var(--border); }
.rpillbtn.on { background: var(--accent-bg); color: var(--accent); border-color: var(--accent); }
.jsonbox { width: 100%; min-height: 16rem; background: var(--bg-inset); color: var(--text-primary); border: 1px solid var(--border);
           border-radius: var(--radius-sm); padding: 0.5rem; }
.jsonerr { color: var(--danger); font-size: var(--text-sm); margin: 0.4rem 0; white-space: pre-wrap; }
.fld { display: flex; flex-direction: column; gap: 0.2rem; margin-bottom: 0.5rem; }
.fld label { font-size: var(--text-xs); color: var(--text-muted); }
/* N2 flow composer: derived SVG DAG + branch forms + validate-only report */
.cmrow { display: flex; gap: 0.8rem; flex-wrap: wrap; }
.cmrow .fld { flex: 1 1 14rem; }
.cmtask { width: 100%; background: var(--bg-inset); color: var(--text-primary); border: 1px solid var(--border); border-radius: var(--radius-sm);
          padding: 0.4rem; font: inherit; resize: vertical; }
#viewCompose h3 { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin: 0.9rem 0 0.4rem; }
.cmdag { background: var(--bg-inset); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 0.5rem; margin: 0.6rem 0; overflow-x: auto; }
.cmdag svg text { fill: var(--text-primary); font-size: 11px; font-family: var(--font-mono); }
.cmnode rect { fill: var(--surface-2); stroke: var(--border-strong); stroke-width: 1.5; }
.cmnode.n-source rect { fill: var(--accent-bg); stroke: var(--accent); } .cmnode.n-reduce rect { fill: var(--success-bg); stroke: var(--success-strong); }
.cmnode .tok { font-size: 10px; } .cmnode .tokbadge { stroke-width: 1; }
.cmnode .tokbadge.pass { fill: var(--success-bg); stroke: var(--success-strong); } .cmnode .tokbadge.warn { fill: var(--warning-bg); stroke: var(--warning-strong); } .cmnode .tokbadge.fail { fill: var(--danger-bg); stroke: var(--danger); }
.cmedge { fill: none; stroke: var(--border-strong); stroke-width: 1.5; }
.cmedge.e-reduce { stroke: var(--success-strong); } .cmedge.e-seed { stroke: var(--accent); stroke-dasharray: 4 3; }
.cmseed { fill: var(--accent) !important; font-size: 10px; }
.cmbranch { display: grid; grid-template-columns: 1fr 8rem 9rem auto; gap: 0.4rem; margin-bottom: 0.35rem; align-items: center; }
.cmbranch input, .cmbranch select { width: 100%; }
.cmreport { margin-top: 0.7rem; }
.cmverdict { font-size: var(--text-md); font-weight: 600; margin-bottom: 0.5rem; }
.cmverdict.ok { color: var(--success); } .cmverdict.bad { color: var(--danger); }
.cmta { font-size: var(--text-sm); margin-bottom: 0.5rem; }
.cmout { font-size: var(--text-sm); white-space: pre-wrap; word-break: break-word; margin-top: 0.5rem;
         color: var(--text-secondary); max-height: 180px; overflow: auto; }
.cmerrs, .cmwarns { font-size: var(--text-sm); margin-top: 0.5rem; }
.cmerrs { color: var(--danger); } .cmwarns { color: var(--warning); }
.cmerrs ul, .cmwarns ul { margin: 0.2rem 0 0; padding-left: 1.2rem; }
/* escalation subject scoping (esc-scoped-hitl-view) */
.eschips { display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 4px; }
.eschip { font-size: var(--text-xs); padding: 0 7px; }
.esub { border: 1px solid var(--warning-border); border-radius: var(--radius-md); padding: 0 6px;
        font-size: var(--text-xs); color: var(--warning); }
/* memory snapshot (M5.mem) */
.memscope { margin: 8px 0 4px; font-size: var(--text-md); color: var(--accent); }
/* graphs screen (B3): provider toolbar, metric tiles, artifact + exploration tables */
#viewGraphs .cfgwrap { max-width: 82rem; }
.grtoolbar { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.7rem; }
.grlbl { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); }
.grstatus { margin-left: 0.4rem; white-space: pre-wrap; overflow-wrap: anywhere; }
.grtiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(9rem, 1fr)); gap: 0.5rem; }
.grtile { border: 1px solid var(--border-subtle); border-radius: var(--radius-md); background: var(--surface-2); padding: 0.5rem 0.6rem; }
.grtile .grk { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); }
.grtile .grv { font-size: var(--text-lg); font-weight: 600; margin-top: 0.15rem; overflow-wrap: anywhere; }
.grbadge { display: inline-block; padding: 0.05rem 0.45rem; border-radius: var(--radius-pill); font-size: var(--text-xs); font-weight: 600; }
.grbadge.fresh { background: var(--success-bg); color: var(--success); }
.grbadge.stale { background: var(--warning-bg); color: var(--warning); }
.grexplore { display: grid; grid-template-columns: repeat(auto-fit, minmax(18rem, 1fr)); gap: 0.8rem; }
.grtable h3 { font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin: 0 0 0.4rem; }
.grtable table { width: 100%; border-collapse: collapse; }
.grtable th { text-align: left; font-size: var(--text-xs); color: var(--text-muted); font-weight: 600; padding: 0.12rem 0.3rem; }
.grtable td { padding: 0.12rem 0.3rem; font-size: var(--text-sm); border-bottom: 1px solid var(--border-subtle); overflow-wrap: anywhere; }
.grtable td.grcount { text-align: right; color: var(--text-secondary); font-variant-numeric: tabular-nums; white-space: nowrap; }
.grconsume { font-size: var(--text-sm); margin-top: 0.5rem; }
/* GUI-RG2 fallback: per-role ORDERED vertical sequence (never a graph) + RG3 simulate */
#viewFallbacks .cfgwrap { max-width: 60rem; }
.fbrole { border: 1px solid var(--border-subtle); border-radius: var(--radius-md); background: var(--surface-1);
          padding: 0.6rem 0.75rem; margin-bottom: 0.75rem; }
.fbrolehead { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.5rem; }
.fbrolehead h3 { margin: 0; font-size: var(--text-md); font-weight: 600; }
.fbroledesc { font-size: var(--text-xs); color: var(--text-muted); margin: 0 0 0.55rem; overflow-wrap: anywhere; }
.fbstack { display: flex; flex-direction: column; align-items: stretch; gap: 0; }
.fblevel { border: 1px solid var(--border-subtle); border-left: 3px solid var(--text-muted); border-radius: var(--radius-sm);
           background: var(--surface-2); padding: 0.5rem 0.65rem; }
.fblevel.primary { border-left-color: var(--accent); }
.fblevel.term { border-left-color: var(--warning-strong); border-style: dashed; background: var(--bg-inset); }
.fblevelhead { display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; }
.fbpos { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); }
.fbcard { font-size: var(--text-sm); font-weight: 600; }
.fbexec { font-size: var(--text-xs); color: var(--text-secondary); background: var(--surface-hover); padding: 0.05rem 0.45rem; border-radius: var(--radius-xs); }
.fbtrig { font-size: var(--text-xs); color: var(--text-secondary); margin-top: 0.3rem; }
.fbtrig .fbtrigk { color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.03em; margin-right: 0.3rem; }
.fbtrig code { background: var(--surface-hover); padding: 0.02rem 0.35rem; border-radius: var(--radius-xs); margin-right: 0.25rem; }
.fbmeta { display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; margin-top: 0.3rem; }
.fbcost { font-size: var(--text-xs); color: var(--text-muted); font-family: var(--font-mono); }
.fbarrow { text-align: center; color: var(--text-muted); font-size: var(--text-sm); line-height: 1.1; padding: 0.05rem 0; }
.fbedit { margin-top: 0.45rem; }
.fbsim textarea { width: 100%; min-height: 4.5rem; background: var(--bg-inset); color: var(--text-primary);
                  border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 0.45rem; font: inherit; resize: vertical; }
.fbsim .fbhints { width: 100%; margin-top: 0.4rem; background: var(--bg-inset); color: var(--text-primary);
                  border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 0.35rem; font: inherit; }
.fbsimout { margin-top: 0.6rem; }
.fbsimraw { font-size: var(--text-xs); font-family: var(--font-mono); white-space: pre-wrap; overflow-wrap: anywhere;
            background: var(--bg-inset); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm);
            padding: 0.45rem; max-height: 16rem; overflow-y: auto; color: var(--text-secondary); }
/* SPEC-116 experiment lifecycle explainer, board, and card dialog */
#viewExperiments .cfgwrap { max-width: 90rem; }
.explife { margin: 0 0 0.85rem; border: 1px solid var(--border-subtle); border-radius: var(--radius-md); background: var(--surface-1); }
.explife > summary { padding: 0.48rem 0.65rem; color: var(--text-secondary); cursor: pointer; font-size: var(--text-sm); }
.explife > summary:hover { color: var(--text-primary); }
.explife > summary .dim { margin-left: 0.35rem; font-size: var(--text-xs); }
.expflow { display: grid; grid-template-columns: minmax(9rem, 0.8fr) 18px minmax(15rem, 1.3fr) 18px minmax(18rem, 1.5fr);
           gap: 0.45rem; align-items: stretch; padding: 0 0.65rem 0.65rem; }
.expstep { min-width: 0; padding: 0.55rem 0.65rem; border: 1px solid var(--border); border-top: 2px solid var(--text-muted);
           border-radius: var(--radius-sm); background: var(--surface-1); }
.expstep.active { border-top-color: var(--warning); }
.expstep.verdict { border-top-color: var(--success); }
.expstephead { display: flex; align-items: center; gap: 0.4rem; margin-bottom: 0.22rem; }
.expstate { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-primary); }
.expverb { padding: 0.04rem 0.38rem; border-radius: var(--radius-pill); background: var(--surface-3); color: var(--accent);
           font-family: var(--font-mono); font-size: var(--text-xs); }
.expstep > span, .expstep > small { display: block; }
.expstep > span { font-size: var(--text-sm); color: var(--text-secondary); }
.expstep > small { margin-top: 0.2rem; color: var(--text-muted); font-size: var(--text-xs); line-height: 1.35; }
.expnext { align-self: center; justify-self: center; color: var(--text-disabled); font-size: var(--text-md); }
.expcycle { display: flex; align-items: center; flex-wrap: wrap; gap: 0.25rem; margin-top: 0.4rem; }
.expcycle span { padding: 0.06rem 0.38rem; border: 1px solid var(--border-strong); border-radius: var(--radius-pill);
                 color: var(--text-secondary); font-size: var(--text-xs); }
.expexits { display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; margin-top: 0.4rem; }
.expexit { padding: 0.32rem 0.42rem; border: 1px solid var(--border); border-radius: var(--radius-sm);
           color: var(--text-secondary); font-size: var(--text-xs); line-height: 1.3; }
.expexit b { display: block; margin-bottom: 0.08rem; font-family: var(--font-mono); font-size: var(--text-xs); }
.expexit.shipped { border-color: var(--success-border); background: var(--success-bg); }
.expexit.shipped b { color: var(--success); }
.expexit.shelved { border-color: var(--accent-border); background: var(--accent-bg); }
.expexit.shelved b { color: var(--accent); }

#expBoard .tlanes { display: grid; grid-template-columns: repeat(4, minmax(13.5rem, 1fr)); gap: 0.65rem;
                    overflow-x: auto; padding-bottom: 0.2rem; }
#expBoard .tlane { --exp-accent: var(--text-muted); --exp-lane-bg: var(--surface-1); min-width: 13.5rem; padding: 0.55rem;
                   border: 1px solid var(--border-subtle); border-top: 2px solid var(--exp-accent);
                   border-radius: var(--radius-md); background: var(--exp-lane-bg); }
#expBoard .tlane.exp-proposed { --exp-accent: var(--text-muted); --exp-lane-bg: var(--surface-1); }
#expBoard .tlane.exp-active { --exp-accent: var(--warning); --exp-lane-bg: var(--warning-bg); }
#expBoard .tlane.exp-shipped { --exp-accent: var(--success); --exp-lane-bg: var(--success-bg); }
#expBoard .tlane.exp-shelved { --exp-accent: var(--accent); --exp-lane-bg: var(--accent-bg); }
#expBoard .tlane h3 { display: flex; align-items: center; margin: 0 0 0.5rem; color: var(--exp-accent);
                      font-family: var(--font-mono); font-size: var(--text-sm); font-weight: 600; }
.expcount { margin-left: auto; min-width: 1.25rem; padding: 0.02rem 0.35rem; border-radius: var(--radius-pill);
            background: var(--surface-3); color: var(--text-secondary); text-align: center; font-size: var(--text-xs); }
#expBoard .expcard { display: block; width: 100%; margin: 0 0 0.45rem; padding: 0.55rem 0.6rem;
                     appearance: none; border: 1px solid var(--border); border-left: 3px solid var(--exp-accent);
                     border-radius: var(--radius-sm); background: var(--surface-2); color: var(--text-primary); font: inherit;
                     text-align: left; cursor: pointer; transition: border-color 120ms ease, background 120ms ease; }
#expBoard .expcard:last-child { margin-bottom: 0; }
#expBoard .expcard:hover { border-color: var(--exp-accent); background: var(--surface-hover); }
#expBoard .expcard:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.expcardhead { display: flex; align-items: center; gap: 0.4rem; }
.expcardhead b { color: var(--text-primary); font-size: var(--text-sm); }
#expBoard .expcard .ttl { margin-top: 0.3rem; color: var(--text-secondary); line-height: 1.35; }
.expbadge { display: inline-flex; align-items: center; padding: 0.05rem 0.42rem; border: 1px solid var(--border-strong);
            border-radius: var(--radius-pill); background: var(--surface-3); color: var(--text-muted); font-size: var(--text-xs); }
.expbadge.expreview.overdue { border-color: var(--warning-border); background: var(--warning-bg); color: var(--warning); }
.expempty { margin: 0.35rem 0; color: var(--text-muted); font-size: var(--text-sm); text-align: center; }

#expDlg { width: min(58rem, 94vw); }
#expDlg .dlgbody { padding: 0; }
#expDlgBody { padding: 0.85rem 1rem 0.45rem; }
#expDlgBody > h3:first-child { margin: 0 0 0.65rem; color: var(--text-primary); font-size: var(--text-lg);
                               text-transform: none; letter-spacing: 0; }
.expfld { display: grid; grid-template-columns: 7rem minmax(0, 1fr); gap: 0.75rem; align-items: baseline;
          padding: 0.34rem 0; border-bottom: 1px solid var(--surface-3); font-size: var(--text-sm); }
.expfld .expk { color: var(--text-muted); text-transform: uppercase; font-size: var(--text-xs); letter-spacing: 0.05em; }
.expfld > span:last-child { min-width: 0; overflow-wrap: anywhere; color: var(--text-secondary); line-height: 1.4; }
.expfld ul { margin: 0; padding-left: 1.1rem; }
.expfld li { padding: 0.12rem 0; }
.expover { color: var(--warning); }
#expDlgBody > h3:not(:first-child) { margin: 0.9rem 0 0.35rem; }
#expDlgBody .tkpre, #expProposalWrap .tkpre { max-height: 14rem; overflow-y: auto; padding: 0.55rem 0.65rem;
                                             border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--surface-1);
                                             color: var(--text-secondary); white-space: pre-wrap; overflow-wrap: anywhere;
                                             font-size: var(--text-sm); line-height: 1.45; }
#expDlg > .dlgbody > .dlgrow { padding: 0.65rem 1rem; border-top: 1px solid var(--border-subtle) !important;
                              background: var(--surface-1); }
#expDlg select { min-width: 14rem; }
#expProposalWrap { margin: 0.65rem 1rem; padding: 0.65rem; border: 1px solid var(--border);
                   border-radius: var(--radius-md); background: var(--surface-1); }
#expProposalWrap h3 { margin-top: 0; }
#expProposalWrap .dlgrow { padding: 0.55rem 0 0; }
#expOut { margin: 0 1rem 0.75rem; }

@media (max-width: 900px) {
  .expflow { grid-template-columns: 1fr; }
  .expnext { justify-self: start; transform: rotate(90deg); }
}
@media (max-width: 560px) {
  .explife > summary .dim { display: none; }
  .expexits { grid-template-columns: 1fr; }
  .expfld { grid-template-columns: 1fr; gap: 0.12rem; }
  #expDlg > .dlgbody > .dlgrow { align-items: stretch; }
  #expDlg select { width: 100%; min-width: 0; }
}
.memrow { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 8px; }
.memcard { border: 1px solid var(--border); border-radius: var(--radius-md); padding: 6px 9px; cursor: pointer;
           font-size: var(--text-sm); }
.memcard:hover { background: var(--surface-hover); }
.memabsent { opacity: 0.45; }
.memtop { display: flex; justify-content: space-between; gap: 8px; }
.memprev { margin: 4px 0 0; padding: 4px 6px; font-size: var(--text-xs); background: var(--surface-1);
           border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); white-space: pre-wrap;
           overflow-wrap: anywhere; max-height: 130px; overflow-y: auto; color: var(--text-muted); }
.specbadges { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; margin-top: 4px; }
/* research round view — source lanes (GUI-RS1); reuses .pill/.cchip/.memcard idioms */
.roundhead { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; margin-bottom: 6px; }
.roundq { font-size: var(--text-sm); margin: 2px 0 10px; }
.wavehead { font-size: var(--text-xs); margin: 8px 0 4px; }
.lanestrip { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; }
.lanecard { flex: 0 0 auto; min-width: 168px; border: 1px solid var(--border); border-radius: var(--radius-md);
            padding: 6px 9px; display: flex; flex-direction: column; gap: 4px; }
.lanecard.clickable { cursor: pointer; } .lanecard.clickable:hover { background: var(--surface-hover); }
.lanerole { font-size: var(--text-sm); font-weight: 600; }
.lanestat .pill { margin-left: 0; }
/* claims subtab (GUI-RS2): reuses .rpillbtn toggle, base table, .pill, .cchip */
.roundtabs { display: flex; gap: 4px; margin-bottom: 8px; }
.claimswrap { overflow-x: auto; }
.claimev { max-width: 340px; }
.claimx { color: var(--danger); font-size: var(--text-sm); }
.claimtag { margin-right: 4px; }
.lanecounts { font-size: var(--text-xs); color: var(--text-secondary); } .lanearrow { opacity: 0.55; }
.convfoot { margin-top: 10px; font-size: var(--text-xs); }
/* consensus subtab (GUI-RS3): header card of NAMED real signals + inline report */
.conscard { border: 1px solid var(--border); border-radius: var(--radius-md); padding: 10px 12px;
            margin-bottom: 10px; display: flex; flex-direction: column; gap: 9px; }
.conssec { display: flex; flex-direction: column; gap: 3px; }
.conslabel { font-size: var(--text-xs); color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.04em; }
.consposition { font-size: var(--text-md); font-weight: 600; }
.consrow { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.consrow .pill { margin-left: 0; }
.consconflict { margin: 2px 0 4px; }
.consreport { margin-top: 4px; }
.consreport .md { border-top: 1px solid var(--border-subtle); padding-top: 8px; }
/* changelog (M5.rec commit timeline) */
.clrow { display: flex; align-items: center; gap: 10px; padding: 3px 4px; font-size: var(--text-sm);
         border-bottom: 1px solid var(--border-subtle); cursor: pointer; }
.clrow:hover { background: var(--surface-hover); }
.clrow b { font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cldate { flex-shrink: 0; }
.cldeco { border: 1px solid var(--border-strong); border-radius: var(--radius-md); padding: 0 6px;
          font-size: var(--text-xs); color: var(--accent); flex-shrink: 0; }
/* GUI-AC3 audit trail + GUI-AC4 incident detail (reuse .pill/.badge/.conssec) */
.auditstat { display: flex; align-items: center; gap: 8px; margin: 4px 0 8px; flex-wrap: wrap; }
.auditstat .pill { margin-left: 0; }
.auditbreak { border-left: 3px solid var(--danger); padding: 4px 8px; margin: 4px 0; font-size: var(--text-sm); }
.auditrow { font-size: var(--text-sm); padding: 1px 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.auditrow .pill { margin-left: 6px; }
.auditout { margin-left: 6px; }
.increvt { font-size: var(--text-sm); padding: 1px 0; }
#incDlgBody .conssec { margin-bottom: 9px; }
/* work queue (B0 live view) */
.qwf { border: 1px solid var(--border); border-radius: var(--radius-md); padding: 6px 9px; margin: 8px 0; }
.qhead { display: flex; align-items: center; gap: 8px; font-size: var(--text-md); }
.qphase { border: 1px solid var(--border-strong); border-radius: var(--radius-md); padding: 0 7px;
          font-size: var(--text-xs); color: var(--warning); }
.qscope { border: 1px solid var(--warning-border); border-radius: var(--radius-md); padding: 0 7px;
          font-size: var(--text-xs); color: var(--warning); }
.qtask { font-size: var(--text-sm); margin: 2px 0 4px; }
.qrow { display: flex; align-items: center; gap: 8px; font-size: var(--text-sm); padding: 1px 0; }
.qst { border-radius: var(--radius-md); padding: 0 6px; font-size: var(--text-xs); border: 1px solid var(--border-strong); }
.qst-running { color: var(--success); border-color: var(--success-border); }
.qst-queued, .qst-pending { color: var(--text-secondary); }
.qst-failed, .qst-cancelled { color: var(--danger); border-color: var(--danger-border); }
.qstage { color: var(--accent); font-size: var(--text-xs); }
/* chat plan-steps card (floating above the input row; TodoWrite live plan) */
#planCard { border: 1px solid var(--border); border-radius: var(--radius-md); margin: 4px 0; padding: 4px 8px;
            background: var(--surface-1); font-size: var(--text-sm); }
#planHead { display: flex; align-items: center; }
#planTitle { font-weight: 600; color: var(--accent); }
#planHead .iconbtn { margin-left: auto; }
#planSteps { list-style: none; margin: 4px 0 2px; padding: 0; }
#planSteps li { padding: 1px 0; color: var(--text-secondary); overflow-wrap: anywhere; }
#planSteps li.ps-in_progress { color: var(--warning); }
#planSteps li.ps-completed { color: var(--success); }
/* chat-gate-tracker: gate sub-tracker in the HUD (harness vs target distinct, read-only).
   Harness chips reuse the ladder .gtier chip; target chips get a distinct border+hue. */
#gateCard { border: 1px solid var(--border); border-radius: var(--radius-md); margin: 4px 0; padding: 4px 8px;
            background: var(--surface-1); font-size: var(--text-sm); }
#gateCard .ghead { font-weight: 600; color: var(--accent); }
#gateSub { display: flex; flex-wrap: wrap; gap: 0.3rem; margin-top: 3px; padding-left: 0.9rem; }
.gsub { font-size: var(--text-xs); padding: 0.05rem 0.4rem; border-radius: var(--radius-xs); }
.gsub.tgt { background: var(--stream-bg); color: var(--stream); border: 1px solid var(--stream-border); }
.gsub .mono { color: var(--stream); }
/* chat tool chips (expand-to-inspect via native <details>) */
.tchip summary { cursor: pointer; list-style-position: inside; color: var(--text-muted); }
.tchip summary:hover { color: var(--accent); }
.tchip[open] { border-left: 2px solid var(--accent); padding-left: 6px; margin: 2px 0; }
/* chip-preview: one indented context line on the COLLAPSED chip (CLI style); a diff
   chip previews its first hunk lines instead. Hidden once the chip is expanded. */
.tchip .tprev { margin: 2px 0 0 1.4rem; color: var(--text-muted); font-size: var(--text-sm);
  font-family: var(--font-mono); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.tchip .tprev.block { white-space: pre-wrap; word-break: break-word; }
.tchip[open] summary .tprev { display: none; }
.tchip pre { margin: 4px 0 4px 1.4rem; padding: 5px 7px; font-size: var(--text-sm);
             background: var(--surface-1); border: 1px solid var(--border); border-radius: var(--radius-sm);
             white-space: pre-wrap; overflow-wrap: anywhere; max-height: 260px; overflow-y: auto; }
.tchip .tchip-out.dim { color: var(--text-disabled); }
/* chip-error-color: a FAILED tool call (claude is_error / codex non-zero exit) —
   red summary + a ✗ marker, so the signal survives a colorblind viewer. The
   output body keeps its normal text color; only its frame goes red (long error
   logs stay legible). */
.tchip.failed summary, .tchip.failed summary .tprev { color: var(--danger); }
.tchip.failed[open] { border-left-color: var(--danger); }
.tchip.failed .tchip-out { border-color: var(--danger-border); }
/* tasks board (A0 read-only Kanban) */
.tlanes { display: flex; gap: 10px; align-items: flex-start; }
.tlane { flex: 1; min-width: 0; }
.tlane h3 { margin: 0 0 0.3rem; font-size: var(--text-md); }
.tcard { border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 5px 7px; margin: 6px 0;
         font-size: var(--text-sm); overflow-wrap: anywhere; }
.tcard .ttl { color: var(--text-secondary); margin-top: 2px; }
.tcat { display: inline-block; border-radius: var(--radius-md); padding: 0 6px; font-size: var(--text-xs);
        margin-right: 4px; border: 1px solid var(--border-strong); color: var(--accent); }
.tgt-head { margin: 0.9rem 0 0.3rem; font-size: var(--text-md); color: var(--text-secondary);
            border-top: 1px solid var(--border); padding-top: 0.6rem; }
.tcat-bug { color: var(--danger); border-color: var(--danger-border); }
.tcat-ideation { color: var(--warning); border-color: var(--warning-border); }
.tcat-chore { color: var(--text-secondary); border-color: var(--border-strong); }
/* task modal (store cards): clickable card + inline done/delete buttons */
.tcard[data-tid] { cursor: pointer; }
.tcard[data-tid]:hover { border-color: var(--border-strong); }
.tbtns { float: right; }
.tbtns button { font-size: var(--text-xs); padding: 0 5px; margin-left: 3px; }
#taskDlg { width: min(52rem, 94vw); }
#taskDlg textarea { width: 100%; background: var(--surface-1); color: var(--text-primary);
  border: 1px solid var(--border); border-radius: var(--radius-sm); font: inherit; padding: 5px 7px; }
#taskDlg .tkpre { white-space: pre-wrap; overflow-wrap: anywhere; max-height: 13rem;
  overflow-y: auto; background: var(--surface-1); border: 1px solid var(--border);
  border-radius: var(--radius-sm); padding: 5px 7px; font-size: var(--text-sm); }
/* -- design-system global interaction layer (docs/DESIGN_SYSTEM.md §3) ------- */
button:focus-visible, summary:focus-visible, a:focus-visible,
input:focus-visible, select:focus-visible, textarea:focus-visible {
  outline: 2px solid var(--accent); outline-offset: 2px; }
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; } }
/* -- GUI-RG4/RG5 access matrix (semantic state colors, never per-vendor) ------ */
.amtbl { border-collapse: collapse; width: 100%; font-size: var(--text-sm); }
.amtbl th, .amtbl td { border: 1px solid var(--border-subtle); padding: 3px 7px; text-align: center; }
.amtbl td.amrole { text-align: left; cursor: pointer; white-space: nowrap; }
.amtbl td.amrole:hover { text-decoration: underline; }
.amcell { font-size: 0.72rem; font-weight: 600; }
.amcell[data-state="allowed"] { color: var(--success-strong, var(--success)); }
.amcell[data-state="denied"] { color: var(--text-secondary); font-weight: 400; }
.amcell[data-state="scoped"] { color: var(--accent); }
.amcell[data-state="approval-required"] { color: var(--warning-strong, var(--warning)); }
.amcell[data-state="temporarily-revoked"] { color: var(--danger-strong, var(--danger)); }
.amcell[data-state="inherited"] { color: var(--accent); }
.amcell[data-state="degraded"], .amcell[data-state="emulated"],
.amcell[data-state="unsupported"] { color: var(--warning-strong, var(--warning)); }
.amnosrc { color: var(--text-secondary); opacity: 0.6; font-style: italic; }
.amrolecard h3 { font-size: 0.82rem; margin: 0.7rem 0 0.2rem; }
.amrolecard h4 { font-size: 0.78rem; margin: 0.5rem 0 0.2rem; }
.amrolecard pre { background: var(--surface-1); border: 1px solid var(--border-subtle);
  border-radius: var(--radius-sm); padding: 5px 7px; overflow-x: auto; font-size: 0.72rem; }
/*__WS_CSS__*/
</style>
<script type="importmap">/*__WS_IMPORTMAP__*/</script>
</head>
<body>
<header>
  <h1 id="h1t">Harness</h1>
  <button id="navPanel" class="pillbtn navsel" title="chat — click again to toggle the vibe/copilot workspace">Chat</button>
  <button id="navConfig" class="pillbtn">Config</button>
  <button id="navTasks" class="pillbtn" title="derived read-only tasks board: backlog tables + self-review inbox + pending escalations + active workers">Tasks</button>
  <button id="navQueue" class="pillbtn" title="live work queue: active workflows, phase, per-worker stage (profile) chips">Queue</button>
  <button id="navChangelog" class="pillbtn" title="commit timeline with branch/hash/text filters + secret-redacted diff viewer">Changelog</button>
  <button id="navSpecs" class="pillbtn" title="specs snapshot: the SDD inventory by scope dir — legacy-frozen badge + gherkin id counts, click opens the full body">Specs</button>
  <button id="navWiki" class="pillbtn" title="wiki: DERIVED orientation docs (docs/wiki) -- two-pane reader, click a page in the tree; cross-links stay inside the wiki">Wiki</button>
  <button id="navResearch" class="pillbtn" title="research snapshot: throwaway Double-Diamond rounds — tracked in git?, linked workflows, records refs; click opens the round doc">Research</button>
  <button id="navExperiments" class="pillbtn" title="experiment-lifecycle board: proposed → active → shipped/shelved, reviewBy staleness nag, click opens the full card; CLI parity: experiment list">Experiments</button>
  <button id="navGraphs" class="pillbtn" title="knowledge graph: active provider + code-AST metrics (files/edges/freshness), artifacts, and server-side exploration (most imported, top fan-out, communities); CLI parity: graph providers | graph metrics">Graphs</button>
  <button id="navFallbacks" class="pillbtn" title="fallback chains: per role the ORDERED primary → fallback-n → human-escalation vertical sequence with REAL trigger conditions (runtimeLimits/circuit), executor circuit + RG1 measured cost/latency; edit chain reuses the role editor; + Simulate route (read-only /route --triage-prompt classify)">Fallbacks</button>
  <button id="onboardChip" class="pillbtn" title="repository and routing profile — click to switch">📁 …</button>
  <span id="targetLabel" class="dim mono" style="font-size:0.76rem"></span>
  <span id="branchChip" class="chip" style="display:none" title="current git branch"></span>
  <span id="warnBadge" class="chip" style="display:none"></span>
  <span class="spacer"></span>
  <button id="openAlerts" class="pillbtn">⚠ Alerts</button>
  <details id="navAdvanced" class="navdrop">
    <summary id="navAdvT" class="pillbtn" title="advanced: compose, memory, records">Advanced ▾</summary>
    <div class="navdropmenu">
      <button id="navCompose" class="pillbtn" title="flow composer: derived DAG + validate-only compile">Compose</button>
      <button id="navMemory" class="pillbtn" title="memory snapshot: every ledger/memory an agent can reach, by scope and purpose, secret-redacted">Memory</button>
      <button id="openRec" class="pillbtn">Records</button>
    </div>
  </details>
</header>
<div class="body">
  <section class="center">
    <div id="sessionbar" class="sessionbar"></div>
    <!-- stats HUD: floats top-RIGHT over the transcript (left-aligned messages stay
         readable). min (default) = one compact cost line; expanded adds the Metrics
         tiles. The per-turn chips (engine/ctx/tokens) live above the input row, NOT
         here — owner call. The freed side columns are reserved for the file tree /
         diff+editor (docs/roadmap/chat-workspace.md) — deliberately empty for now. -->
    <div id="hud" class="hud min">
      <div class="hudbar">
        <span id="hudLine" class="dim">📊 stats</span>
        <button id="hudToggle" class="iconbtn" title="expand / minimize session stats">▸</button>
      </div>
      <div class="hudbody">
        <h2>Metrics</h2><div id="metPanel"><p class="dim">loading…</p></div>
      </div>
    </div>
    <div id="transcript" class="mono"></div>
    <div id="chips">
      <span id="engineChip" class="chip" title="">⚙ …</span>
      <span id="telchips"></span>
    </div>
    <div id="planCard" style="display:none">
      <div id="planHead"><span id="planTitle">Plan</span>
        <button id="planMin" class="iconbtn" title="minimize / expand">–</button></div>
      <ul id="planSteps"></ul>
    </div>
    <div id="gateCard" style="display:none">
      <div class="ghead">Gates <span class="dim" style="font-weight:400">· harness vs target · read-only</span></div>
      <div id="gateSub"></div>
    </div>
    <div class="inputrow">
      <button id="attach" class="pillbtn" title="attach a file (or drag and drop onto the chat)">📎</button>
      <input type="file" id="filein" multiple style="display:none">
      <button id="modeBadge" class="pillbtn" title="click or Shift+Tab to cycle mode">mode: —</button>
      <textarea id="chatin" rows="1" placeholder="Enter sends · Shift+Enter = newline · 📎/drop attaches · !command runs locally (no LLM) · /help"></textarea>
      <button id="stopbtn" class="act stop" style="display:none" title="stop the current turn">⏹ Stop</button>
      <button id="send" class="act">Send</button>
    </div>
  </section>
  <!-- SPEC-147 chat workspace: hidden in chat mode; vibe = 60/40 diff pane,
       copilot = 50/50 IDE pane (editor lands in M2). -->
  <div id="wsSplit" hidden></div>
  <section id="wsPane" hidden>
    <div class="wsbar">
      <span id="wsTitle" class="mono dim">diff</span>
      <span class="spacer"></span>
      <button id="wsSbs" class="pillbtn" title="toggle unified / side-by-side">⇔</button>
      <button id="wsClose" class="pillbtn" title="close (back to chat)">✕</button>
      <!-- SPEC-147 v2 split mode selector — authored by gpt-5.6-sol xhigh (owner delegation) -->
      <div id="wsModeSel" role="group" aria-label="IDE mode">
        <button type="button" data-mode="vibe" aria-pressed="false" aria-label="Vibe mode: diff viewer" title="Show diff viewer">vibe</button>
        <button type="button" data-mode="copilot" aria-pressed="false" aria-label="Copilot mode: editor" title="Open editor">copilot</button>
      </div>
    </div>
    <!-- M3 floating explorer toggle: left inner edge of the IDE pane -->
    <button id="wsTreeBtn" hidden title="project explorer">🗂</button>
    <!-- M2 copilot file bar (the explorer complements the path input) -->
    <div id="wsFileBar" hidden>
      <input id="wsPath" class="mono" placeholder="relative/path/file.py — Enter opens">
      <button id="wsOpen" class="pillbtn">Open</button>
      <button id="wsFmt" class="pillbtn" title="format: ruff for .py, reindent selection otherwise (Ctrl+Shift+F)">⌥ Format</button>
      <button id="wsSave" class="act" title="Ctrl+S">Save</button>
      <span id="wsEdState" class="mono dim" title="● = unsaved"></span>
    </div>
    <div id="wsBody"></div>
  </section>
  <!-- M3 explorer overlay: 1/4-screen, floats over the chat side until closed -->
  <section id="wsTree" hidden>
    <div class="wstbar">
      <span class="dim">explorer</span>
      <span class="spacer"></span>
      <button id="wsNew" class="pillbtn" title="new file">＋</button>
      <button id="wsTreeClose" class="pillbtn">✕</button>
    </div>
    <div id="wsTreeBody" class="mono"></div>
  </section>
</div>
<section id="viewConfig" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Model cards</h2>
        <button id="advCardsBtn" class="iconbtn" title="advanced mode: raw JSON">&lt;/&gt;</button></div>
      <div id="cardGrid" class="cardgrid">loading…</div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Keys</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">secret values live in the OS vault; set writes via stdin (never argv); presence only, never the value; CLI parity: keys list/set/unset</span></div>
      <div id="keysBody">loading&hellip;</div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Routing by role</h2>
        <button id="advRoutingBtn" class="iconbtn" title="advanced mode: raw JSON">&lt;/&gt;</button></div>
      <div id="profileBar" class="profilebar"></div>
      <div id="targetChips" class="targetchips"></div>
      <div id="routeMatrix" class="matrix">loading…</div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Skills</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">read-only · grouped by scope (harness / target / user) · click opens SKILL.md · CLI parity: agents skills</span></div>
      <div id="skillsGrid">loading…</div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>MCP servers</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">read-only · env shown as key names only · deny-by-default per scope · CLI parity: agents mcp</span></div>
      <div id="mcpGrid">loading…</div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Access matrix</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">read-only · role × resource · every cell state maps to a NAMED source (hover); a cell with none renders <i>no source</i> · click a role for its card + declared-vs-effective policy</span></div>
      <div id="accessMatrix">loading&hellip;</div>
    </div>
  </div>
</section>
<dialog id="capDlg">
  <div class="dlghead"><h2 id="capDlgT" class="mono">capability</h2><button class="x" data-close="capDlg">✕</button></div>
  <div class="dlgbody"><div id="capDlgBody" class="md"></div></div>
</dialog>
<dialog id="incDlg">
  <div class="dlghead"><h2 id="incDlgT" class="mono">incident</h2><button class="x" data-close="incDlg">✕</button></div>
  <div class="dlgbody"><div id="incDlgBody"></div></div>
</dialog>
<section id="viewCompose" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Flow composer</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">derived view · Compile validates (nothing written) · Create materializes (confirm) · guide: docs/FLOW_COMPOSER.md</span></div>
      <div class="cmrow">
        <div class="fld"><label>profile (closed vocabulary)</label><select id="cmProfile"></select></div>
        <div class="fld"><label>executor (spawn target — not used in compile)</label><select id="cmExecutor"></select></div>
      </div>
      <div class="fld"><label>task / goal (secret-scanned on compile)</label><textarea id="cmTask" class="cmtask" rows="2"></textarea></div>
      <div id="cmDag" class="cmdag"><p class="dim">loading…</p></div>
      <h3>branches</h3>
      <div id="cmBranches"></div>
      <div class="dlgrow" style="border:none;padding:0.4rem 0 0">
        <button class="act" id="cmCompile">Compile (validate-only)</button>
        <button class="act" id="cmCreate" disabled title="materializes the workflow (creates, does NOT start) — requires a valid compile">Create workflow</button>
        <span id="cmMeta" class="dim" style="align-self:center"></span>
      </div>
      <div id="cmReport" class="cmreport"><p class="dim">Compile to validate this composition — nothing is written.</p></div>
    </div>
  </div>
</section>
<section id="viewTasks" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Tasks board</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">derived read-only · sources: backlog tables + self-review inbox + escalations + active workers · CLI parity: harness.py tasks list</span></div>
      <div id="tasksSummary" class="dim" style="font-size:0.78rem;margin-bottom:0.4rem"></div>
      <div id="tasksBoard"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Decisions</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">pending intake triage + escalation calls · CLI parity: harness.py intake list / escalations</span></div>
      <div id="decs" class="decsgrid"><p class="dim">loading…</p></div>
    </div>
  </div>
</section>
<section id="viewQueue" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Work queue</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">live (3s poll) · stage chip = declared taskProfile, not observed activity · CLI parity: workflow list / async-status</span></div>
      <div id="queueBoard"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Agents</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">live worker cards, grouped per workflow · click opens the drill-in drawer</span></div>
      <div id="agents"><p class="dim">no workers</p></div>
    </div>
  </div>
</section>
<section id="viewChangelog" style="display:none">
  <div class="roundtabs" style="margin:0 0 8px">
    <button class="rpillbtn on" id="clTabTimeline" title="commit timeline + records ledger">Changelog</button>
    <button class="rpillbtn" id="clTabAudit" title="tamper-evident event audit: hash-chain status (real verifier) + causal parent tree">Audit</button>
  </div>
  <div id="clMain">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Changelog</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">commit timeline · diffs secret-redacted server-side · CLI parity: git log / records recent --kind commit · ledger rows: Records dialog</span></div>
      <div class="cmrow" style="align-items:flex-end">
        <div class="fld"><label>branch</label><select id="clBranch"><option value="">(all)</option></select></div>
        <div class="fld"><label>text filter (--grep)</label><input id="clQ" placeholder="subject/body text"></div>
        <div class="fld"><label>hash</label><input id="clHash" placeholder="7-40 hex"></div>
        <button class="act" id="clApply" style="height:30px">Filter</button>
      </div>
      <div id="clTable"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2 id="ledgerHead" title="project ledger — milestones · decisions · changes — tail of .harness/state/worklog.json; add one with harness.py log">Records ledger</h2></div>
      <div id="ledger">loading…</div>
    </div>
  </div>
  </div>
  <div id="clAudit" style="display:none">
    <div class="cfgwrap">
      <div class="cfgsec">
        <div class="cfghead"><h2>Audit trail</h2>
          <button class="act" id="clAuditRefresh" style="height:26px;margin-left:10px" title="re-verify the live event log">↻ refresh</button>
          <span class="dim" style="margin-left:auto;font-size:0.74rem">tamper-evident hash-chain (T-HASHCHAIN) verified server-side · causal parent DAG (T-CAUSALPARENT) · read-only</span></div>
        <div id="auditChain"><p class="dim">loading…</p></div>
        <div id="auditTree"></div>
      </div>
    </div>
  </div>
</section>
<section id="viewMemory" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Memory snapshot</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">every byte secret-redacted server-side · user scope = machine-local, not repo state · CLI parity: records sources</span></div>
      <div id="memGrid"><p class="dim">loading…</p></div>
    </div>
  </div>
</section>
<dialog id="memDlg">
  <div class="dlghead"><h2 id="memDlgT" class="mono">source</h2><button class="x" data-close="memDlg">✕</button></div>
  <div class="dlgbody"><div id="memDlgBody" class="md"></div></div>
</dialog>
<section id="viewSpecs" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Specs</h2>
        <button class="act" id="specRefresh" style="height:26px;margin-left:10px">↻ refresh</button>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">read-only SDD inventory · grouped by scope dir · click opens the full body · CLI parity: spec-index</span></div>
      <div id="specGrid"><p class="dim">loading…</p></div>
    </div>
  </div>
</section>
<dialog id="specDlg">
  <div class="dlghead"><h2 id="specDlgT" class="mono">spec</h2><button class="x" data-close="specDlg">✕</button></div>
  <div class="dlgbody"><div id="specDlgBody" class="md"></div></div>
</dialog>
<section id="viewWiki" style="display:none">
  <div class="wikiwrap">
    <div id="wikiNav" class="wikinav"><p class="dim">loading...</p></div>
    <div class="wikibody"><div id="wikiBody" class="md"><p class="dim">select a page from the tree</p></div></div>
  </div>
</section>
<section id="viewResearch" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Research</h2>
        <button class="act" id="researchRefresh" style="height:26px;margin-left:10px">↻ refresh</button>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">read-only research rounds · tracked / linked WFs / records refs · click opens the round doc · CLI parity: research list</span></div>
      <div id="researchGrid"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Start a research round</h2>
        <span class="dim" style="margin-left:auto;font-size:0.74rem">Phase-0 declarations (question / criteria / budget / width) -&gt; workflow plan --profile | create-only: Start the round on the Queue screen</span></div>
      <div class="fld"><label>question <span style="color:var(--danger)">*</span></label><textarea id="rfQuestion" class="cmtask" rows="2" placeholder="what is being investigated?"></textarea></div>
      <div class="fld"><label>success criteria <span style="color:var(--danger)">*</span></label><textarea id="rfCriteria" class="cmtask" rows="2" placeholder="what would count as an answer / stopping rule?"></textarea></div>
      <div class="fld"><label>budget note <span style="color:var(--danger)">*</span></label><input id="rfBudget" placeholder="declared token / wave budget"></div>
      <div class="cmrow">
        <div class="fld"><label>profile</label><select id="rfProfile"><option value="research-divergence">research-divergence</option><option value="research-critique">research-critique</option></select></div>
        <div class="fld"><label>width-mode (D010)</label><select id="rfWidth"><option value="focused">focused</option><option value="exploratory">exploratory</option></select></div>
      </div>
      <div class="fld"><label>width justification <span id="rfWhyReq" style="color:var(--danger);display:none">*</span></label><textarea id="rfWhy" class="cmtask" rows="2" placeholder="why this width? (required for exploratory -- D010)"></textarea></div>
      <div class="cmrow" style="align-items:center">
        <button class="act" id="rfCreate" style="height:30px">Create round</button>
        <span id="rfMsg" class="dim mono" style="font-size:0.74rem"></span>
      </div>
    </div>
  </div>
</section>
<dialog id="researchDlg">
  <div class="dlghead"><h2 id="researchDlgT" class="mono">round</h2><button class="x" data-close="researchDlg">✕</button></div>
  <div class="dlgbody"><div id="researchDlgBody" class="md"></div></div>
</dialog>
<section id="viewExperiments" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Experiments</h2>
        <button class="act" id="expRefresh" style="height:26px;margin-left:10px">↻ refresh</button></div>
      <details class="explife" open>
        <summary>How an experiment moves <span class="dim">idea → measurement → owner decision</span></summary>
        <div class="expflow" role="list" aria-label="Experiment lifecycle">
          <div class="expstep proposed" role="listitem" title="A proposed experiment is the idea on paper: a card containing its hypothesis, metric, baseline, success criteria, abandon criteria, and reversal plan.">
            <div class="expstephead"><strong class="expstate">proposed</strong></div>
            <span>The idea on paper</span>
            <small>Hypothesis · metric · criteria · reversal plan</small>
          </div>
          <span class="expnext" aria-hidden="true">→</span>
          <div class="expstep active" role="listitem" title="Activate the card, run its probe, and record measurements directly on the card. Repeat as needed. Measuring happens while active and does not require shipping product code.">
            <div class="expstephead"><span class="expverb">activate</span><strong class="expstate">active</strong></div>
            <span>Measure here, without shipping</span>
            <div class="expcycle" aria-label="Repeat measurement cycle"><span>run probe</span><b aria-hidden="true">→</b><span>record measurement</span><b aria-hidden="true">↻</b></div>
            <small><span class="mono">reviewBy +14d</span> is the only tracking. The doctor nags when the card is stale.</small>
          </div>
          <span class="expnext" aria-hidden="true">→</span>
          <div class="expstep verdict" role="listitem" title="The owner closes an active experiment with exactly one verdict: shipped or shelved.">
            <div class="expstephead"><strong class="expstate">verdict</strong></div>
            <span>The owner makes the closing decision</span>
            <div class="expexits">
              <span class="expexit shipped" title="Success criteria were met. The experiment's conclusion graduates into permanent product code, typically an advisory doctor check. Track the thing it created from now on; the card remains a closed tombstone."><b>shipped</b>Conclusion graduates into permanent product code</span>
              <span class="expexit shelved" title="There is nothing to fix. Archive the experiment with its evidence and a concrete trigger that would justify reopening it."><b>shelved</b>Archive with evidence and a reopen trigger</span>
            </div>
          </div>
        </div>
      </details>
      <div id="expBoard"><p class="dim">loading…</p></div>
    </div>
  </div>
</section>
<section id="viewGraphs" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Knowledge graph</h2>
        <button class="act" id="grRefresh" style="height:26px;margin-left:10px" title="reload the graph snapshot">↻ refresh</button></div>
      <div class="grtoolbar">
        <label class="grlbl" for="grProviderSel">provider</label>
        <select id="grProviderSel" title="active knowledge-graph provider — registered providers only (external ones are declared in .harness/project.json)"></select>
        <button class="act" id="grApply" title="set the active graph provider (graph set <name>)">Apply</button>
        <button class="act" id="grRebuild" title="rebuild the code-AST graph with the active provider (graph-build-code-ast)">Rebuild</button>
        <span id="grStatus" class="dim mono grstatus"></span>
      </div>
      <div id="grTiles" class="grtiles"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Artifacts</h2></div>
      <div id="grArtifacts"></div>
      <div id="grConsumption" class="dim grconsume"></div>
    </div>
    <div class="cfgsec">
      <div class="cfghead"><h2>Exploration</h2></div>
      <div class="grexplore">
        <div class="grtable"><h3>Most imported <span class="dim">(in-degree)</span></h3><div id="grMostImported"></div></div>
        <div class="grtable"><h3>Top fan-out <span class="dim">(out-degree)</span></h3><div id="grTopFanout"></div></div>
        <div class="grtable"><h3>Communities <span class="dim">(members)</span></h3><div id="grCommunities"></div></div>
      </div>
    </div>
  </div>
</section>
<section id="viewFallbacks" style="display:none">
  <div class="cfgwrap">
    <div class="cfgsec">
      <div class="cfghead"><h2>Fallback chains</h2>
        <button class="act" id="fbRefresh" style="height:26px;margin-left:10px" title="reload the fallback snapshot">↻ refresh</button></div>
      <p class="dim" style="font-size:0.78rem;margin:0 0 0.6rem">Per role, the ORDERED primary → fallback-n → human-escalation sequence (never a free graph). Trigger conditions derive from the executor runtimeLimits classes + the circuit gate the real walk uses (SPEC-165 spawn / SPEC-166 chat); cost/latency shown only where the harness has measured it (RG1).</p>
      <div id="fbStacks"><p class="dim">loading…</p></div>
    </div>
    <div class="cfgsec fbsim">
      <div class="cfghead"><h2>Simulate route</h2></div>
      <p class="dim" style="font-size:0.78rem;margin:0 0 0.5rem">Read-only classify (<span class="mono">route &lt;demand&gt; --triage-prompt</span>): the deterministic floor + the router prompt, no spawn, no live model. The answer is walked by the <span class="mono">router</span> chain above.</p>
      <textarea id="fbDemand" placeholder="demand text — e.g. add oauth login to the settings page"></textarea>
      <input id="fbHints" class="fbhints" placeholder="optional task-class hints (appended to the demand)">
      <div class="dlgrow" style="border:none;margin-top:0.5rem">
        <button class="act" id="fbSimBtn" title="classify this demand (read-only, non-spawning)">Simulate</button>
        <span id="fbSimStatus" class="dim mono" style="font-size:0.76rem"></span>
      </div>
      <div id="fbSimOut" class="fbsimout"></div>
    </div>
  </div>
</section>
<dialog id="expDlg">
  <div class="dlghead"><h2 id="expDlgT" class="mono">experiment</h2><button class="x" data-close="expDlg">✕</button></div>
  <div class="dlgbody"><div id="expDlgBody"></div>
    <div class="dlgrow" style="border:none">
      <select id="expModel"><option value="">model: plan-profile default</option></select>
      <button class="act" id="expRefine" title="bounded READ-ONLY model run proposing an implementation/measurement plan (experiment refine)">Refine plan</button>
      <button class="act" id="expStatus" title="lifecycle move: activate a proposed card, or settle an active one with a shipped/shelved verdict">Change status</button>
      <button class="act" id="expDispatch" title="open a chat with the front desk; it triages and routes the start, opening an overseer room when needed">Start experiment</button></div>
    <div id="expProposalWrap" style="display:none">
      <h3>Refined proposal <span id="expPropFile" class="dim mono" style="font-size:0.7rem"></span></h3>
      <div id="expProposal" class="tkpre mono"></div>
      <div class="dlgrow" style="border:none">
        <button class="act" id="expAccept" title="append the proposal to the experiment's plan (experiment plan --from-run)">Accept into plan</button>
        <button class="pillbtn" id="expDiscardProp">Discard proposal</button></div>
    </div>
    <div id="expOut" class="dim mono" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:9rem;overflow-y:auto"></div>
  </div>
</dialog>
<dialog id="commitDlg">
  <div class="dlghead"><h2 id="commitDlgT" class="mono">commit</h2><button class="x" data-close="commitDlg">✕</button></div>
  <div class="dlgbody"><pre id="commitDlgBody" class="mono" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre></div>
</dialog>
<dialog id="cardDlg">
  <div class="dlghead"><h2 id="cardDlgT">Card</h2><button class="x" data-close="cardDlg">✕</button></div>
  <div class="dlgbody">
    <div class="fld"><label>engine</label><select id="cEngine"></select></div>
    <div class="fld"><label>model (from the catalog — fills the fields below)</label><select id="cModelSel"></select></div>
    <div class="fld" id="cIdCustomWrap" style="display:none"><label>custom id (what the CLI/engine receives)</label><input id="cId"></div>
    <div class="fld"><label>name</label><input id="cName"></div>
    <div class="fld"><label>provider</label><input id="cProvider" placeholder="Anthropic / OpenAI / …"></div>
    <div class="fld"><label>reasoning (supported levels)</label><div id="cReasoningPills" class="pillsel"></div></div>
    <div class="fld"><label>defaultReasoning (effect when none is chosen)</label><select id="cDefReason"></select></div>
    <div class="fld"><label>contextWindow (tokens, optional)</label><input id="cCtx" type="number" min="1"></div>
    <div id="cardErr" class="jsonerr"></div>
    <div class="dlgrow" style="border:none">
      <button class="act" id="cardSave">Save</button>
      <button class="act danger" id="cardDel" style="display:none">Delete</button>
    </div>
  </div>
</dialog>
<dialog id="mcDlg">
  <div class="dlghead"><h2 id="mcDlgT" class="mono">model card</h2>
    <button class="act" id="mcEdit" style="margin-left:auto;height:26px" title="edit this card's declared fields">edit card</button>
    <button class="x" data-close="mcDlg" style="margin-left:0.5rem">✕</button></div>
  <div class="dlgbody"><div id="mcDlgBody"></div></div>
</dialog>
<dialog id="keyDlg">
  <div class="dlghead"><h2 id="keyDlgT" class="mono">key</h2><button class="x" data-close="keyDlg">&times;</button></div>
  <div class="dlgbody">
    <div class="fld"><label>value (write-only -- stored in the OS vault, never displayed)</label>
      <input id="keyVal" type="password" autocomplete="off"></div>
    <div id="keyErr" class="jsonerr"></div>
    <div class="dlgrow" style="border:none">
      <button class="act" id="keySave">Save</button>
      <button class="act" id="keyCancel">Cancel</button>
    </div>
  </div>
</dialog>
<dialog id="roleDlg">
  <div class="dlghead"><h2 id="roleDlgT">Role</h2><button class="x" data-close="roleDlg">✕</button></div>
  <div class="dlgbody">
    <p id="roleDesc" class="roledesc"></p>
    <div id="roleFork" class="forkbanner" style="display:none">
      the canonical profile is derived and read-only — saving will create an editable profile
      <input id="roleForkName" placeholder="profile name">
    </div>
    <p class="dim" id="roleProfLabel" style="font-size:0.76rem;margin:0 0 0.5rem"></p>
    <div id="roleChain"></div>
    <div id="roleDietBox" style="margin-top:0.7rem;border-top:1px solid var(--line,#3333);padding-top:0.5rem">
      <div style="font-weight:600;font-size:0.82rem">Context diet <span class="dim" style="font-weight:400">— session trim for this role (SPEC-118)</span></div>
      <label style="display:block;font-size:0.8rem"><input type="checkbox" id="dietUser"> strip user-scope config/plugins</label>
      <label style="display:block;font-size:0.8rem"><input type="checkbox" id="dietPack"> skip canonical-pack reinjection</label>
      <label style="display:block;font-size:0.8rem"><input type="checkbox" id="dietTrim"> trim built-in tools, keeping:</label>
      <div id="dietCaps" style="margin-left:1.2rem;font-size:0.78rem"></div>
    </div>
    <div id="roleErr" class="jsonerr"></div>
    <div class="dlgrow" style="border:none">
      <button class="act" id="roleSave">Save routing</button>
    </div>
  </div>
</dialog>
<dialog id="advCards">
  <div class="dlghead"><h2>Model cards — raw JSON</h2><button class="x" data-close="advCards">✕</button></div>
  <div class="dlgbody"><textarea id="advCardsTa" class="jsonbox mono"></textarea>
    <div id="advCardsErr" class="jsonerr"></div>
    <button class="act" id="advCardsApply">Apply</button></div>
</dialog>
<dialog id="advRouting">
  <div class="dlghead"><h2>Routing — raw JSON</h2><button class="x" data-close="advRouting">✕</button></div>
  <div class="dlgbody"><textarea id="advRoutingTa" class="jsonbox mono"></textarea>
    <div id="advRoutingErr" class="jsonerr"></div>
    <button class="act" id="advRoutingApply">Apply</button></div>
</dialog>
<dialog id="recDlg">
  <div class="dlghead"><h2>Records</h2><button class="x" data-close="recDlg">✕</button></div>
  <div class="dlgrow">
    <input id="rq" placeholder="search terms (empty = recent)" style="flex:1">
    <input id="rk" placeholder="kind (optional)" size="12">
    <button class="act" id="rsearch">Search</button>
    <button class="act danger" id="rrebuild">Rebuild index</button>
  </div>
  <div id="recBody" class="dlgbody"><p class="dim">enter a query</p></div>
</dialog>
<dialog id="alertsDlg">
  <div class="dlghead"><h2>Alerts</h2><button class="x" data-close="alertsDlg">✕</button></div>
  <div class="dlgbody">
    <div class="sec risksum"><div id="riskSum"><p class="dim">…</p></div></div>
    <div class="sec atten"><h2>Attention</h2><div id="atten"><p class="dim">board is calm</p></div></div>
    <div class="sec escs"><h2>Escalations</h2><div id="escs"><p class="dim">loading…</p></div></div>
  </div>
</dialog>
<dialog id="wkDlg">
  <div class="dlghead"><h2 id="wkTitle">worker</h2><span id="wkPill" class="pill done"></span>
    <span id="wkMeta"></span>
    <button class="act" id="wkEvidence" title="SPEC-129 reviewer evidence bundle for this workflow (handles only)" style="margin-left:0.5rem">evidence</button>
    <button class="x" data-close="wkDlg">✕</button></div>
  <div class="dlgbody">
    <div id="wkRecovery" class="wkrec"><span class="dim">recover:</span>
      <button class="act" data-rec="retry">retry worker</button>
      <button class="act" data-rec="mark">mark…</button>
      <button class="act" data-rec="recover">recover WF</button>
      <button class="act danger" data-rec="cancel">cancel WF</button>
      <button class="act danger" data-rec="discard" title="removes a STOPPED workflow (planned/settled) and its cards — scrub restricted to not-running">Discard</button></div>
    <h3>live output (stdout)</h3>
    <div id="wkOut"><div class="dim">loading…</div></div>
    <details><summary class="dim" style="cursor:pointer;margin-top:0.5rem">stderr</summary>
      <div id="wkErr"></div></details>
    <h3>events</h3>
    <div id="wkEvents"></div>
  </div>
</dialog>
<dialog id="ebDlg">
  <div class="dlghead"><h2 id="ebTitle">evidence</h2><button class="x" data-close="ebDlg">✕</button></div>
  <div id="ebBody" class="dlgbody"><p class="dim">loading…</p></div>
</dialog>
<dialog id="taskDlg">
  <div class="dlghead"><h2 id="tkTitle" class="mono">task</h2><button class="x" data-close="taskDlg">✕</button></div>
  <div class="dlgbody">
    <div id="tkMeta" class="dim mono" style="font-size:0.72rem;margin-bottom:0.4rem"></div>
    <h3>Notes for the planner</h3>
    <textarea id="tkNotes" rows="4" placeholder="complementary information the planning agent should use"></textarea>
    <div class="dlgrow" style="border:none">
      <button class="act" id="tkSaveNotes" title="harness.py tasks note <id> --text …">Save notes</button></div>
    <h3>Plan</h3>
    <div id="tkPlan" class="tkpre mono"></div>
    <div class="dlgrow" style="border:none">
      <select id="tkModel"><option value="">model: plan-profile default</option></select>
      <button class="act" id="tkRefine" title="bounded READ-ONLY model run proposing a refined plan (tasks refine)">Refine plan</button>
      <button class="act" id="tkDispatch" title="ship card + plan through the porteiro (tasks dispatch → route --task --dispatch)">Send to agent</button></div>
    <div id="tkProposalWrap" style="display:none">
      <h3>Refined proposal <span id="tkPropFile" class="dim mono" style="font-size:0.7rem"></span></h3>
      <div id="tkProposal" class="tkpre mono"></div>
      <div class="dlgrow" style="border:none">
        <button class="act" id="tkAccept" title="append the proposal to the task's plan (tasks plan --from-run)">Accept into plan</button>
        <button class="pillbtn" id="tkDiscardProp">Discard proposal</button></div>
    </div>
    <div id="tkOut" class="dim mono" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:9rem;overflow-y:auto"></div>
  </div>
</dialog>
<dialog id="confirmDlg">
  <div class="dlghead"><h2 id="confirmT">Confirm</h2><button class="x" data-close="confirmDlg">✕</button></div>
  <div class="dlgbody">
    <div id="confirmMsg" class="mono"></div>
    <input id="confirmInput" style="display:none">
    <select id="confirmSel" style="display:none"></select>
    <div class="dlgrow" style="border:none">
      <button class="act" id="confirmOk">Confirm</button>
      <button class="pillbtn" id="confirmCancel">Cancel</button>
    </div>
  </div>
</dialog>
<dialog id="onboardDlg">
  <div class="dlghead"><h2>Welcome to the panel</h2><button class="x" data-close="onboardDlg">✕</button></div>
  <div class="dlgbody">
    <p class="dim">Choose the working repository and the routing profile. Reopen anytime via the 📁 chip at the top. Applying only a profile switch restarts the chat session.</p>
    <div class="fld"><label>working repository</label>
      <div style="display:flex;gap:0.4rem">
        <select id="obRepo" style="flex:1"></select>
        <button type="button" class="pillbtn" id="obBrowse" title="register a project outside the list">browse folder…</button>
      </div>
      <div id="obRepoPath" class="dim mono" style="font-size:0.72rem;margin-top:0.25rem;word-break:break-all"></div></div>
    <div id="obAddArea" style="display:none;border:1px solid var(--border);border-radius:var(--radius-sm);padding:0.5rem;margin:0 0 0.5rem">
      <div class="dim" style="font-size:0.76rem;margin-bottom:0.3rem">register new target (git repository)</div>
      <div class="fld"><label>name</label><input id="obAddName"></div>
      <div class="fld"><label>path</label><input id="obAddPath" class="mono" readonly></div>
      <div id="obAddErr" class="jsonerr"></div>
      <div style="display:flex;gap:0.5rem">
        <button type="button" class="act" id="obAddDo">register</button>
        <button type="button" class="pillbtn" id="obAddCancel">cancel</button></div>
    </div>
    <div id="obRememberInfo" class="dim" style="font-size:0.78rem;margin:-0.2rem 0 0.5rem"></div>
    <div class="fld"><label>routing profile</label><select id="obProfile"></select></div>
    <div id="obErr" class="jsonerr"></div>
    <div class="dlgrow" style="border:none">
      <button class="act" id="obStart">start</button>
      <button class="pillbtn" id="obSkip">skip</button>
    </div>
  </div>
</dialog>
<script>
const TOKEN = "__HARNESS_TOKEN__";
const H = { "X-Harness-Token": TOKEN };
const MODES = ["manual", "plan", "auto", "accept-edits"];
async function jget(p){ const r = await fetch(p, {headers: H}); return r.json(); }
async function jpost(p, body){ const r = await fetch(p, {method:"POST", headers:{...H,"Content-Type":"application/json"}, body: JSON.stringify(body)}); return r.json(); }
function el(id){ return document.getElementById(id); }
function esc(s){ const d = document.createElement("div"); d.textContent = s==null?"":String(s); return d.innerHTML; }
function fmtTok(n){ if (typeof n!=="number") return "n/a"; return n>=1000 ? (n/1000).toFixed(1)+"k" : String(Math.round(n)); }
function fmtEl(s){ if (s==null||s<0) return "-"; s=Math.floor(s);
  if (s>=3600) return Math.floor(s/3600)+"h"+String(Math.floor((s%3600)/60)).padStart(2,"0")+"m";
  if (s>=60) return Math.floor(s/60)+"m"+String(s%60).padStart(2,"0")+"s"; return s+"s"; }
function ageSec(iso){ const s = (Date.now()-Date.parse(iso))/1000; return isFinite(s) ? s : null; }

// -- transcript (one terminal pane; busy line pinned at the bottom) ----------
const transcript = el("transcript");
const busyEl = document.createElement("div"); busyEl.className = "ln busy"; busyEl.style.display = "none";
transcript.appendChild(busyEl);
let lastBlank = false;
function atBottom(){ return transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 6; }
function append(cls, text, html){
  const blank = !html && !String(text||"").trim();
  if (blank && lastBlank) return;   // collapse consecutive blank lines
  lastBlank = blank;
  const stick = atBottom();
  const d = document.createElement("div");
  d.className = "ln" + (cls ? " " + cls : "");
  if (html) d.innerHTML = html; else d.innerHTML = esc(text);
  transcript.insertBefore(d, busyEl);
  if (stick) transcript.scrollTop = transcript.scrollHeight;
}
const FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧";
let busyStart = 0, busyTimer = null;
function tickBusy(){
  const s = Math.floor((Date.now()-busyStart)/1000);
  // chat-status-line: live turn tokens (usage frames) + elapsed, CLI-style
  const tok = turnTok ? " · ↓ " + fmtTok(turnTok) + " tokens" : "";
  busyEl.textContent = FRAMES[Math.floor(Date.now()/120) % FRAMES.length] + " responding… " + s + "s" + tok;
  const live = document.getElementById("psLive");   // the in_progress plan step's suffix
  if (live){
    const eff = readyInfo.effort ? " · " + readyInfo.effort + " effort" : "";
    live.textContent = " (" + fmtElapsed(s) + tok + eff + ")";
  }
}
function fmtTok(n){ return n >= 1000 ? (n/1000).toFixed(1) + "k" : String(n); }
function fmtElapsed(s){ return s >= 60 ? Math.floor(s/60) + "m " + (s%60) + "s" : s + "s"; }
let turnTok = 0;   // output tokens streamed this turn (reset at turn-start)
function busyOn(){
  const stick = atBottom();
  busyStart = Date.now(); busyEl.style.display = ""; tickBusy();
  if (!busyTimer) busyTimer = setInterval(tickBusy, 120);
  el("stopbtn").style.display = "";   // ⏹ lives only while a turn is running
  if (stick) transcript.scrollTop = transcript.scrollHeight;
}
function busyOff(){ busyEl.style.display = "none"; if (busyTimer){ clearInterval(busyTimer); busyTimer = null; }
  el("stopbtn").style.display = "none"; }

// -- mode badge (Shift+Tab / click cycles via /mode <next>) ------------------
// -- session-stats HUD: min (default) / expanded, persisted per browser --------
function setHud(min){
  el("hud").classList.toggle("min", min);
  el("hudToggle").textContent = min ? "▸" : "▾";
  try { localStorage.setItem("hudMin", min ? "1" : "0"); } catch(e){}
}
el("hudToggle").onclick = () => setHud(!el("hud").classList.contains("min"));
try { setHud(localStorage.getItem("hudMin") !== "0"); } catch(e){ setHud(true); }

let curMode = "manual";
function setMode(m){ curMode = m; el("modeBadge").textContent = "mode: " + m; }
function cycleMode(){ jpost("/api/chat/send", {session: curSession, line: "/mode " + MODES[(MODES.indexOf(curMode)+1) % MODES.length]}); }
el("modeBadge").onclick = cycleMode;
document.addEventListener("keydown", e => {
  if (e.key === "Tab" && e.shiftKey && !e.repeat){ e.preventDefault(); cycleMode(); }
});

// -- telemetry chip bar (from the last turn-end event; honest n/a) -----------
let lastTurn = null;
function chip(cls, txt, na){ return `<span class="chip ${cls}${na?' na':''}">${esc(txt)}</span>`; }
function renderTelemetry(){
  const u = (lastTurn && lastTurn.usage) || {}, sess = (lastTurn && lastTurn.session) || null;
  let ctx;
  if (typeof u.ctx_used==="number" && typeof u.ctx_window==="number" && u.ctx_window){
    const pct = Math.round(u.ctx_used*100/u.ctx_window);
    const f = Math.min(10, Math.max(u.ctx_used?1:0, Math.round(u.ctx_used*10/u.ctx_window)));
    ctx = chip("ctx", "ctx " + "▮".repeat(f) + "▯".repeat(10-f) + " " + pct + "%");
  } else ctx = chip("ctx", "ctx n/a", true);
  const inC = typeof u.in_tokens==="number" ? chip("cin", "in "+fmtTok(u.in_tokens)) : chip("cin","in n/a",true);
  const outC = typeof u.out_tokens==="number" ? chip("cout", "out "+fmtTok(u.out_tokens)) : chip("cout","out n/a",true);
  const costC = typeof u.cost_usd==="number" ? chip("cost", "$"+u.cost_usd.toFixed(3)) : chip("cost","$n/a",true);
  const durC = typeof u.duration_s==="number" ? chip("dur", u.duration_s.toFixed(1)+"s") : chip("dur","n/a s",true);
  const sessC = (sess && typeof sess.cost_usd==="number")
    ? chip("sess", "session $"+sess.cost_usd.toFixed(2)+"/"+(sess.turns||0)+" turns")
    : chip("sess", "session "+((sess&&sess.turns)||0)+" turns", !sess);
  el("telchips").innerHTML = ctx + inC + outC + costC + durC + sessC;
  renderEngineChip();
}
// -- engine identity chip (⚙ provider · model · effort; honest n/a) ----------
let readyInfo = {};
function hostOf(url){ try { return new URL(url).host; } catch(e){ return url || ""; } }
function providerOf(engine, endpoint){
  if (engine === "claude") return "anthropic";
  if (engine === "codex")  return "openai";
  if (engine === "openai") return hostOf(endpoint) || "openai";
  return "manual";                                   // manual or absent
}
function renderEngineChip(){
  const eng = readyInfo.engine || "";
  const prov = providerOf(eng, readyInfo.endpoint);
  const measured = lastTurn && lastTurn.usage && lastTurn.usage.model;  // actual id this turn
  const model = measured || readyInfo.model;                           // else configured
  // R21: a card-backed engine always resolves a model, so bare "default" only
  // shows for a truly unknown engine (openai without cards / manual) — dim it.
  const modelHtml  = model ? esc(model) : '<span class="dim">vendor default</span>';
  const effortHtml = readyInfo.effort ? esc(readyInfo.effort) : '<span class="dim">vendor default</span>';
  const chip = el("engineChip");
  chip.innerHTML = "⚙ " + esc(prov) + " · " + modelHtml + " · " + effortHtml;
  const src = readyInfo.modelSource;
  const srcLabel = measured ? "measured this turn"
    : (model && src && src !== "default") ? src : "vendor default";  // e.g. card default / saved default / flag
  chip.title = "engine: " + (eng || "manual")
    + (readyInfo.endpoint ? " · endpoint: " + readyInfo.endpoint : "")
    + " · model (" + srcLabel + ")";
}
renderTelemetry();

// -- ledger cards (R26: structured worklog tail, not markdown) ---------------
const KINDCLASS = {milestone:"milestone", change:"milestone", release:"milestone",
                   decision:"decision", note:"note", fix:"amber", incident:"amber"};
// P3: the purpose text (this ledger is the worklog tail from `records log/add`, SPEC-112)
// plus the live "last entry <relative> ago" now live on the section h2's hover tooltip,
// not as visible subtitle rows — the cards carry a per-entry YYYY-MM-DD date pill instead.
const LEDGER_TITLE = 'project ledger — milestones · decisions · changes — '
  + 'tail of .harness/state/worklog.json; add one with harness.py log';
function renderLedger(items){
  const sorted = items.slice().sort((a,b) => String(b.at||"").localeCompare(String(a.at||"")));
  const age = sorted.length ? ageSec(sorted[0].at) : null;
  const head = el("ledgerHead");
  if (head) head.title = LEDGER_TITLE + (age!=null ? ` · last entry ${fmtEl(age)} ago` : "");
  if (!sorted.length){
    el("ledger").innerHTML = '<p class="dim">no records yet — harness.py records log adds one</p>';
    return;
  }
  el("ledger").innerHTML = sorted.map(it => {
    const k = it.kind || "note";
    const date = String(it.at||"").slice(0,10);   // YYYY-MM-DD from the ISO stamp
    const ref = (it.refs && it.refs.length) ? String(it.refs[0]).slice(0,7) : "";
    const tags = (it.tags||[]).slice(0,4).map(t => `<span class="ltag">${esc(t)}</span>`).join("");
    return `<div class="lcard"><div class="ltop">
      <span class="kbadge ${KINDCLASS[k]||''}">${esc(k)}</span>
      ${date?`<span class="ldate mono" title="${esc(it.at||'')}">${esc(date)}</span>`:""}
      ${ref?`<span class="lref mono">${esc(ref)}</span>`:""}</div>
      <div class="ltitle">${esc(it.title||"")}</div>${tags?`<div>${tags}</div>`:""}</div>`;
  }).join("");
}

// -- right column + header (from /api/state poll) ----------------------------
function renderAgents(workers, groups){
  const isActive = w => ["running","queued","pending"].includes(w.status);
  const flat = ws => {   // today's flat selection: active first, then the 5 most-recent done
    const act = ws.filter(isActive);
    const done = ws.filter(w => !isActive(w))
      .sort((a,b) => String(b.finishedAt||"").localeCompare(String(a.finishedAt||""))).slice(0,5);
    return act.concat(done);
  };
  const card = w => {
    const st = w.status;
    const pill = st==="running"?"run":st==="succeeded"?"ok":st==="failed"?"bad":
                 (st==="queued"||st==="pending")?"queue":"done";
    const meta = [];
    if (st==="running" && w.elapsed!=null) meta.push(fmtEl(w.elapsed));
    if (w.tokens) meta.push("~"+fmtTok(w.tokens)+" tok");
    // v6: clicking a card opens the live-output drawer (needs the workflow id to address it)
    const wf = w.workflow ? ` clickable" data-wf="${esc(w.workflow)}" data-worker="${esc(w.workerId)}` : "";
    // v7: last-activity line — "output há Ns" from lastOutputAt vs now; "—" when null, never an error
    const outAgo = w.lastOutputAt ? "output " + fmtEl((Date.now()-Date.parse(w.lastOutputAt))/1000) + " ago" : "—";
    // stale-planned badge (server-computed w.stale): names the dead weight and points
    // at the working exit — cancel is a no-op for a never-started (planned) WF.
    const stale = w.stale ? ` <span class="pill bad" title="planned workflow never started (>1 day) — cancel is a no-op here; open the card and use Discard">stale</span>` : "";
    return `<div class="wcard${isActive(w)?'':' dim'}${wf}"><div class="wtop">
      <span class="wid">${esc(w.workerId)}</span><span class="pill ${pill}">${esc(st)}</span>${stale}</div>
      ${meta.length?`<div class="wmeta">${esc(meta.join(" · "))}</div>`:""}
      <div class="wmeta dim">${esc(outAgo)}</div></div>`;
  };
  // UX-GA.2: >1 backend-computed groups (st.workerGroups) → one card-group per
  // workflow/wave, header = workflowId + status counts, the SAME wcard markup
  // nested inside (categorize, not stream). Groups render AS-IS — no client-side
  // grouping/sorting, no extra poll. ≤1 group keeps today's flat render byte-identical.
  if ((groups||[]).length > 1){
    el("agents").innerHTML = groups.map(g => {
      const counts = Object.entries(g.statusCounts||{}).map(([s,n]) => s+" "+n).join(" · ");
      return `<div class="wgroup"><div class="wghead"><span class="wgid">${esc(g.workflowId)}</span>`+
        `<span class="wgcounts dim">${esc(counts)}</span></div>${flat(g.workers||[]).map(card).join("")}</div>`;
    }).join("");
  } else {
    const all = flat(workers);
    if (!all.length){ el("agents").innerHTML = '<p class="dim">no workers</p>'; return; }
    el("agents").innerHTML = all.map(card).join("");
  }
  el("agents").querySelectorAll(".wcard.clickable").forEach(c =>
    c.onclick = () => openWorker(c.dataset.wf, c.dataset.worker));
}

// -- worker drill-in drawer (SPEC-114 v6): human-initiated live output --------
let wkTimer = null, wkWf = null, wkWorker = null;
// Progressive claude stream-json → a structured activity line; NEVER throws:
// anything that doesn't parse or isn't a known shape renders as escaped raw text.
function fmtStreamLine(line){
  let o; try { o = JSON.parse(line); } catch(e){ return {cls:"", text:line}; }
  if (!o || typeof o !== "object") return {cls:"", text:line};
  try {
    const t = o.type;
    if (t === "assistant" && o.message && Array.isArray(o.message.content)){
      for (const c of o.message.content){
        if (c.type === "tool_use"){
          const i = c.input || {};
          const arg = i.file_path || i.path || i.command || i.pattern || i.url || "";
          return {cls:"wtool", text:"tool: " + (c.name||"?") + (arg?" "+String(arg).slice(0,120):"")};
        }
        if (c.type === "text" && c.text) return {cls:"wtext", text:String(c.text).slice(0,240)};
      }
      return {cls:"wtext", text:"(assistant)"};
    }
    if (t === "user" && o.message && Array.isArray(o.message.content)
        && o.message.content.some(c => c.type === "tool_result"))
      return {cls:"wtool", text:"tool_result"};
    if (t === "result") return {cls:"wresult", text:"result (" + (o.subtype || (o.is_error?"error":"ok")) + ")"};
    if (t === "system" && o.subtype) return {cls:"dim", text:"system: " + o.subtype};
    return {cls:"", text:line};   // parsed but unknown shape → raw
  } catch(e){ return {cls:"", text:line}; }
}
function renderWorker(d){
  if (!d || d.error){ el("wkOut").innerHTML = `<div class="dim">${esc((d&&d.error)||"no data")}</div>`; return; }
  el("wkTitle").textContent = d.workerId;
  const st = d.status || "";
  const pill = st==="running"?"run":st==="succeeded"?"ok":st==="failed"?"bad":
               (st==="queued"||st==="pending")?"queue":"done";
  el("wkPill").className = "pill " + pill; el("wkPill").textContent = st;
  const tk = d.task || {}, meta = [];
  if (tk.pid) meta.push("pid " + tk.pid);
  if (tk.returnCode != null) meta.push("rc " + tk.returnCode);
  if (tk.executor) meta.push(String(tk.executor));
  el("wkMeta").textContent = meta.join(" · ");
  const out = el("wkOut"), stick = out.scrollHeight - out.scrollTop - out.clientHeight < 40;  // sticky auto-scroll
  const so = (d.stdout && d.stdout.lines) || [];
  const joined = so.join("\n");
  if (!so.length) {
    out.innerHTML = '<div class="dim">no output yet</div>';
  } else if (looksDiff(joined)) {
    out.innerHTML = `<div class="wln">${colorizeDiff(joined)}</div>`;   // v12: a raw stdout diff, colorized whole
  } else if (d.language) {
    out.dataset.hlLang = d.language;                                    // code: on-demand tree-sitter highlight
    HL.highlightBlock(out, joined, d.language);
  } else {
    out.innerHTML = so.map(l => { const f = fmtStreamLine(l); return `<div class="wln ${f.cls}">${esc(f.text)}</div>`; }).join("");
  }
  if (stick) out.scrollTop = out.scrollHeight;
  const se = (d.stderr && d.stderr.lines) || [];
  el("wkErr").textContent = se.length ? se.join("\n") : "(empty)";
  const ev = d.events || [];
  el("wkEvents").innerHTML = ev.length
    ? ev.map(e => `<div class="wev"><span class="mono dim">${esc(e.event||"")}</span> ${esc(e.workerStatus||e.status||"")}</div>`).join("")
    : '<div class="dim">no events</div>';
}
async function pollWorker(){
  if (!wkWf || document.visibilityState !== "visible") return;
  let d; try {
    d = await jget(`/api/worker?wf=${encodeURIComponent(wkWf)}&worker=${encodeURIComponent(wkWorker)}&lines=400`);
  } catch(e){ return; }
  renderWorker(d);
  // settled worker → one final render, then stop polling (post-mortem view stays)
  if (d && !["running","queued","pending"].includes(d.status) && wkTimer){ clearInterval(wkTimer); wkTimer = null; }
}
function openWorker(wf, worker){
  wkWf = wf; wkWorker = worker;
  el("wkTitle").textContent = worker; el("wkMeta").textContent = "";
  el("wkOut").innerHTML = '<div class="dim">loading…</div>';
  el("wkErr").textContent = ""; el("wkEvents").innerHTML = "";
  el("wkDlg").showModal();
  pollWorker();
  if (wkTimer) clearInterval(wkTimer);
  wkTimer = setInterval(pollWorker, 1500);
}
el("wkDlg").addEventListener("close", () => {   // closing stops the poll timer
  if (wkTimer){ clearInterval(wkTimer); wkTimer = null; } wkWf = null;
});
// N4 recovery console: fire an allowlisted workflow-recovery verb for the OPEN
// worker/WF through the SAME confirm→/api/action path as resolve-escalation. The
// button only names the verb + shows the exact command; the server (run_action)
// re-validates the wfid against active/ state and refuses scrub/--force — it is the
// trust boundary, not this handler. scrub/--force have no button here by design.
async function recover(verb){
  if (!wkWf) return;
  let action, params, cmd, warn;
  if (verb === "retry"){ action = "workflow-retry"; params = {wfid: wkWf, workerId: wkWorker}; cmd = `workflow retry ${wkWf} ${wkWorker}`; }
  else if (verb === "recover"){ action = "workflow-recover"; params = {wfid: wkWf}; cmd = `workflow async-recover ${wkWf}`; }
  else if (verb === "cancel"){ action = "workflow-cancel"; params = {wfid: wkWf}; cmd = `workflow cancel ${wkWf}`;
    // cancel only signals a RUNNING workflow's async task PIDs — a no-op for a WF that never started.
    warn = `cancel — runs: harness.py ${cmd}\n\nCancels a RUNNING workflow. For a workflow that never started (planned), use Discard.`; }
  else if (verb === "discard"){ action = "workflow-discard"; params = {wfid: wkWf}; cmd = `workflow scrub ${wkWf}`;
    warn = `Discard workflow — runs: harness.py ${cmd}\n\nRemoves workflow ${wkWf} and its worker cards from the board. Irreversible. Only works if the workflow is NOT running — cancel it first.`; }
  else if (verb === "mark"){
    // v12: the 9 valid worker statuses as a <select>, not free text
    const status = await promptModal("mark " + wkWorker + " as?",
      {options: ["pending","queued","running","done","partial","blocked","failed","missing","skipped"]});
    if (!status) return;
    action = "workflow-mark"; params = {wfid: wkWf, workerId: wkWorker, status}; cmd = `workflow mark ${wkWf} ${wkWorker} ${status}`;
  } else return;
  if (!(await confirmModal(warn || `${verb} — runs: harness.py ${cmd}`))) return;
  const res = await jpost("/api/action", {action, params: {...params, confirm: true}});
  await alertModal(res.ok ? "ok" : "refused/failed: " + (res.refused || res.output || res.rc));
  if (verb === "discard" && res.ok){ el("wkDlg").close(); refresh(); return; }  // WF gone → close drawer, clear cards
  pollWorker(); refresh();
}
el("wkRecovery").querySelectorAll("button[data-rec]").forEach(b => b.onclick = () => recover(b.dataset.rec));

// SPEC-129 v2 (UX-GA.3 phase 2) evidence drill-in: ONE fetch of the backend-assembled
// bundle per open, rendered AS-IS (no client-side assembly, no polling). Every path
// (resultPath, artifactPath, harnessResultPath) is TEXT — the view never fetches
// artifact bodies (handles-not-bodies, SPEC-129 rule 1).
function renderEvidence(b){
  if (!b || b.error){ el("ebBody").innerHTML = `<div class="dim">${esc((b&&b.error)||"no data")}</div>`; return; }
  el("ebTitle").textContent = "evidence · " + (b.workflowId||"");
  const cap = c => c ? ["oracle","exitClass","artifactPath","rerunCmd"].filter(k => c[k]!=null)
      .map(k => `<div class="ebkv"><span class="dim">${esc(k)}</span> <span class="mono">${esc(String(c[k]))}</span></div>`).join("")
      : '<span class="dim">no capsule</span>';
  const rows = (b.workers||[]).map(w => `<tr><td class="mono">${esc(w.workerId||"")}</td>`
      + `<td>${esc(w.status||"—")}</td><td>${esc(w.failureClass||"—")}</td>`
      + `<td class="mono">${esc(w.resultPath||"—")}</td><td>${cap(w.oracleEvidence)}</td></tr>`).join("");
  const refs = (b.recordsRefs||[]).map(r =>
      `<div class="ebref"><span class="mono dim">${esc(r.ref||"")}</span> ${esc(r.title||"")}</div>`).join("");
  el("ebBody").innerHTML =
    `<h3>workers</h3><table><tr><th>worker</th><th>status</th><th>failureClass</th><th>result path</th><th>oracle evidence</th></tr>${rows}</table>`
    + `<h3>rollup</h3><div class="ebkv"><span class="dim">HARNESS_RESULT</span> <span class="mono">${esc(b.harnessResultPath||"—")}</span></div>`
    + `<div class="ebkv"><span class="dim">risk flags</span> <span class="mono">${b.riskFlags?esc(JSON.stringify(b.riskFlags)):"—"}</span></div>`
    + `<h3>records refs</h3>${refs||'<div class="dim">none</div>'}`;
}
async function openEvidence(wf){
  el("ebTitle").textContent = "evidence · " + wf;
  el("ebBody").innerHTML = '<div class="dim">loading…</div>';
  el("ebDlg").showModal();
  let d; try { d = await jget(`/api/evidence?workflow_id=${encodeURIComponent(wf)}`); }
  catch(e){ d = {error: String(e)}; }
  renderEvidence(d);
}
el("wkEvidence").onclick = () => { if (wkWf) openEvidence(wkWf); };

// UX-GA.1 risk-summary strip: render the backend-computed rollup AS-IS (same
// discipline as renderAtten below — no client-side aggregation, no extra poll;
// st.riskSummary is derived server-side beside st.attention every /api/state tick).
function renderRisk(rs){
  rs = rs || {}; const t = rs.tiers || {};
  el("riskSum").innerHTML =
    ["critical","high","watch","info"].map(k =>
      `<span class="chip${(t[k]||0)?"":" dim"}">${k} ${t[k]||0}</span>`).join("")
    + `<span class="chip${rs.gateFailing?" rs-bad":" dim"}">gate ${rs.gateFailing?"failing":"ok"}</span>`
    + `<span class="chip${(rs.openEscalations||0)?"":" dim"}">esc ${rs.openEscalations||0}</span>`
    + (rs.requiresSecurityReview?'<span class="chip rs-bad">security review</span>':"")
    + (rs.topStrip?`<span class="rs-top dim" title="${esc(rs.topStrip)}">top: ${esc(rs.topStrip)}</span>`:"");
}
// N3 flight-strip attention bay: render the backend-ordered strips as-is (do NOT
// sort/cache in JS — the backend derived the order from /api/state every poll).
// Each strip shows source + label + detail + a dim "→ <nextAction>". A worker strip
// opens the drill-in drawer; an escalation strip scrolls to the Escalations card
// (reuse existing affordances, no new endpoint). Empty bay = a calm board.
function renderAtten(strips){
  if (!strips.length){ el("atten").innerHTML = '<p class="dim">board is calm</p>'; return; }
  el("atten").innerHTML = strips.map(s => {
    const src = s.source||"";
    const addr = s.wf ? ` clickable" data-wf="${esc(s.wf)}" data-worker="${esc(s.worker||'')}`
               : (src==="escalation" ? " esc-jump" : "");
    return `<div class="astrip s-${esc(src)}${addr}"><div class="atop">`+
      `<span class="asrc">${esc(src)}</span><span class="alabel">${esc(s.label||"")}</span></div>`+
      (s.detail?`<div class="adet">${esc(s.detail)}</div>`:"")+
      `<div class="anext dim">→ ${esc(s.nextAction||"")}</div></div>`;
  }).join("");
  el("atten").querySelectorAll(".astrip.clickable").forEach(c =>
    c.onclick = () => openWorker(c.dataset.wf, c.dataset.worker));
  el("atten").querySelectorAll(".astrip.esc-jump").forEach(c =>
    c.onclick = () => { const t = document.querySelector(".escs"); if (t) t.scrollIntoView({block:"nearest"}); });
}
// esc-scoped-hitl-view: subject filter chips (all / self / each target seen) +
// a subject badge per card; Resolve ALWAYS forwards the card's subject so the
// server refuses a cross-subject resolve (each subject keeps its world).
let escSubjectFilter = "all";
function renderEsc(escs){
  if (!escs.length){ el("escs").innerHTML = '<p class="dim">nothing waiting on a human</p>'; return; }
  const subjects = [...new Set(escs.map(e => e.subject || "self"))].sort();
  const chips = (subjects.length > 1 || escSubjectFilter !== "all")
    ? `<div class="eschips">` + ["all", ...subjects].map(s =>
        `<button class="pillbtn eschip${escSubjectFilter === s ? " navsel" : ""}" data-sub="${esc(s)}">${esc(s)}</button>`
      ).join("") + `</div>` : "";
  const shown = escs.filter(e => escSubjectFilter === "all" || (e.subject || "self") === escSubjectFilter);
  el("escs").innerHTML = chips + shown.map(e => `<div class="ecard" data-inc="${esc(e.id)}" title="click for incident detail"><div class="etop">
    <span class="badge ${e.criticality||'none'}">${esc(e.criticality||'none')}</span>
    <span class="eid">${esc(e.id)}</span>
    ${(e.subject && e.subject !== "self")?`<span class="esub mono">${esc(e.subject)}</span>`:""}</div>
    <div class="ereason">${esc(e.reason)}</div>
    ${e.suggestedProfile?`<div class="eprof">→ ${esc(e.suggestedProfile)}</div>`:""}
    <button class="act danger" data-id="${esc(e.id)}" data-sub="${esc(e.subject||'self')}">Resolve</button></div>`).join("")
    + (shown.length ? "" : '<p class="dim">no escalations in this scope</p>');
  el("escs").querySelectorAll(".eschip").forEach(c => c.onclick = () => {
    escSubjectFilter = c.dataset.sub; refresh();
  });
  // GUI-AC4: the card opens the incident-detail dialog; Resolve stops propagation
  // so the write path (below) never doubles as an open.
  el("escs").querySelectorAll(".ecard[data-inc]").forEach(c => c.onclick = () => openIncident(c.dataset.inc));
  el("escs").querySelectorAll("button[data-id]").forEach(b => b.onclick = async (ev) => {
    ev.stopPropagation();
    if (!(await confirmModal(`Resolve escalation ${b.dataset.id}? Runs: harness.py escalations --resolve <id> --target ${b.dataset.sub}`))) return;
    b.disabled = true;
    const res = await jpost("/api/action", {action:"resolve-escalation",
      params:{id:b.dataset.id, subject:b.dataset.sub, confirm:true}});
    await alertModal(res.ok ? "resolved" : "refused/failed: " + (res.refused||res.output||res.rc));
    refresh();
  });
}
// -- GUI-AC4 incident detail dialog: progressive disclosure over ONE escalation
// (capDlg idiom — same read-only reuse discipline as RG1/RG5). Every block from a
// NAMED real source; an absent field renders dim, never a fabricated state.
function incField(label, val){
  return (val === 0 || val)
    ? `<div><span class="dim">${esc(label)}:</span> ${esc(String(val))}</div>`
    : `<div class="dim">${esc(label)}: <i>absent</i></div>`;
}
function incSec(label, body){
  return `<div class="conssec"><div class="conslabel">${esc(label)}</div>${body}</div>`;
}
function incidentBody(d){
  const s = d.summary || {};
  const summary = incSec("Summary · the escalation record",
    `<div class="consrow"><span class="badge ${s.criticality||'none'}">${esc(s.criticality||'none')}</span>` +
    `<span class="badge none">${esc(s.status||'')}</span></div>` +
    incField("id", s.id) + incField("subject", s.subject) + incField("reason", s.reason) +
    incField("failureClass", s.failureClass) + incField("source", s.source) +
    incField("suggestedProfile", s.suggestedProfile) + incField("raisedAt", s.raisedAt));
  const tl = d.timeline || [];
  const timeline = incSec("Timeline · events joined to this escalation",
    tl.length ? tl.map(e => e.outsideWindow
      ? `<div class="increvt dim">↑ parent ${esc((e.parentEventId||'').slice(0,12))} outside window <span class="badge none">causal</span></div>`
      : `<div class="increvt"><span class="mono dim">${esc((e.eventId||'').slice(0,8))}</span> ` +
        `<b>${esc(e.event||'?')}</b> <span class="cldate dim">${esc((e.timestamp||'').slice(0,19))}</span> ` +
        `<span class="badge none" title="how this row joined the incident">${esc(e.provenance||'')}</span></div>`
    ).join("") : '<p class="dim">no events joined by id or causal parent</p>');
  const c = d.state;
  const stateB = incSec("Executor state · circuit breaker",
    c ? `<div class="consrow"><span class="badge ${c.state==='open'?'high':'none'}">${esc(c.state||'?')}</span> ` +
        `<span class="mono">${esc(c.executor||'')}</span></div>` +
        incField("failureCount", c.failureCount) + incField("lastFailureReason", c.lastFailureReason)
      : '<p class="dim">no executor named on this escalation — no circuit to show</p>');
  const sp = d.suspects || {}, recs = sp.records || [];
  const suspects = incSec("Suspects · real joins only",
    (recs.length ? recs.map(r => `<div><span class="badge none">${esc(r.kind||'')}</span> ${esc(r.title||'')}</div>`).join("") : "") +
    (sp.commit ? `<div>commit <span class="mono">${esc(sp.commit)}</span></div>` : "") +
    (!recs.length && !sp.commit ? '<p class="dim">no suspect recorded</p>' : ""));
  const r = d.resolution;
  const resolution = incSec("Resolution",
    r ? incField("resolvedAt", r.resolvedAt) + incField("actor", r.actor) + incField("causal parent", r.parentEventId)
      : '<p class="dim">unresolved — nothing waiting is closed yet</p>');
  return summary + timeline + stateB + suspects + resolution;
}
async function openIncident(id){
  el("incDlgT").textContent = "incident " + id;
  const body = el("incDlgBody");
  body.innerHTML = '<p class="dim">loading…</p>';
  el("incDlg").showModal();
  let d = null;
  try { d = await jget("/api/incident?id=" + encodeURIComponent(id)); } catch (e) { d = null; }
  if (!d){ body.innerHTML = '<p class="jsonerr">incident unavailable</p>'; return; }
  if (!d.found){ body.innerHTML = `<p class="dim">no escalation record for ${esc(id)}</p>`; return; }
  body.innerHTML = incidentBody(d);
}
// SPEC-145 Decisions card: one row per pending human decision — the plain question
// + one button per selectable option (the option hint as the button title). Clicking
// routes through the EXISTING single write path (confirmModal -> jpost /api/action):
// intake -> the gated `intake-decide` action, escalation -> the untouched
// `resolve-escalation` action. `keep` renders no button (doing nothing is its default).
function renderDecisions(decs){
  if (!decs.length){ el("decs").innerHTML = '<p class="dim">no decisions waiting</p>'; return; }
  // By-date order (oldest askedAt first). String-derived YYYY-MM-DD, no Date() round-trip,
  // so the chip matches the state files regardless of browser TZ. Missing/unparseable
  // askedAt -> "" (no chip) and sorts last; tiebreak kind then id for a stable order.
  const ymd = at => { const s = (typeof at === "string" ? at : "").slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ""; };
  const sorted = decs.slice().sort((a, b) => {
    const ka = ymd(a.askedAt) && a.askedAt, kb = ymd(b.askedAt) && b.askedAt;  // full ts, "" if invalid
    if (ka !== kb) return ka && kb ? (ka < kb ? -1 : 1) : (ka ? -1 : 1);  // valid asc, missing last
    return (a.kind < b.kind ? -1 : a.kind > b.kind ? 1 : 0) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  });
  el("decs").innerHTML = sorted.map((d, di) => {
    const btns = (d.options||[]).filter(o => o.value !== "keep").map(o =>
      `<button class="abadge abadge-${esc(o.value)}" data-di="${di}" data-choice="${esc(o.value)}" title="${esc(o.hint||'')}">${esc(o.label||o.value)}</button>`
    ).join(" ");
    const day = ymd(d.askedAt);  // YYYY-MM-DD chip; "" -> omitted
    // date + hash in neutral-gray pills (same color as the intake kind badge, .badge.none)
    const dchip = day ? `<span class="badge none">${esc(day)}</span>` : "";
    return `<div class="ecard"><div class="etop">
      <span class="badge ${d.kind==='escalation'?'high':'none'}">${esc(d.kind)}</span>
      ${dchip}<span class="badge none mono">${esc(d.id)}</span></div>
      <div class="ereason" title="${esc(d.question)}">${esc(d.question)}</div>
      <div>${btns || '<span class="dim">nothing to do — leave it pending</span>'}</div></div>`;
  }).join("");
  el("decs").querySelectorAll("button[data-di]").forEach(b => b.onclick = async () => {
    const d = sorted[+b.dataset.di], choice = b.dataset.choice;
    const esc_kind = d.kind === "escalation", acc_kind = d.kind === "acceptance";
    // SPEC-172: an acceptance goes through its OWN gated action (its apply types into a
    // vendor TUI, so it gets its own server-side gate).
    const action = acc_kind ? "acceptance-decide"
                 : esc_kind ? "resolve-escalation" : "intake-decide";
    // BOTH decide-verb kinds forward the row digest — the C12 TOCTOU binding
    // (apply_decision refuses an approval whose content changed since it was shown).
    // The server has always accepted it and `decide --expected-digest` has always been
    // built for it, but this client did not SEND it, so intake decisions from the
    // browser were unbound in practice while everything around them said otherwise.
    // undefined (not "") when a row carries no digest: JSON drops the key, and the
    // server refuses a present-but-malformed digest rather than treating it as absent.
    const params = esc_kind ? {id:d.id, subject:d.subject||"self", confirm:true}
                            : {id:d.id, choice:choice, expectedDigest:d.digest||undefined,
                               confirm:true};
    // The parenthetical must follow the CHOICE, not the kind: `visible` opens the
    // vendor's TUI for the owner to answer by hand and types nothing (found by the
    // third-door lane 2026-07-30 — this line claimed the drive for every choice).
    const runs = acc_kind ? `harness.py decide ${d.id} ${choice}` + (choice === "visible"
                   ? ` (opens ${d.vendor||""}'s own prompt for you to answer)`
                   : ` (drives ${d.vendor||""}'s own prompt)`)
               : esc_kind ? `harness.py escalations --resolve ${d.id}`
                          : `harness.py intake decide ${d.id} ${choice}`;
    if (!(await confirmModal(`${d.question} Runs: ${runs}`))) return;
    b.disabled = true;
    const res = await jpost("/api/action", {action:action, params:params});
    await alertModal(res.ok ? "done" : "refused/failed: " + (res.refused||res.output||res.rc));
    refresh();
  });
}
function renderHeader(st){
  el("h1t").title = "snapshot " + (st.generatedAt||"");
  // P4: gitInfo {branch, sha, dirty} enriches the chip; st.branch stays the source of
  // truth (falls back to it), so the chip never regresses when gitInfo is empty.
  const gi = st.gitInfo || {};
  const br = gi.branch || st.branch || "";  // git branch chip (polled every 3s)
  const bc = el("branchChip");
  if (br){
    bc.style.display="";
    bc.textContent = "⎇ " + br + (gi.sha ? " @" + gi.sha : "") + (gi.dirty>0 ? " ●" + gi.dirty : "");
    bc.title = "branch " + br + (gi.sha ? " · " + gi.sha : "")
      + (gi.dirty>0 ? " · " + gi.dirty + " uncommitted file(s)" : gi.sha ? " · clean" : "");
  } else bc.style.display="none";
  const escs = st.escalations||[];
  const hi = escs.filter(e => e.criticality==="high"||e.criticality==="critical").length;
  const wb = el("warnBadge");
  if (hi){ wb.style.display=""; wb.textContent = "⚠"+hi; } else wb.style.display="none";
}
// (the static right-column Gates section is gone — owner call, it wasn't earning
// its space; the chat gate SUB-TRACKER below keeps reading st.gates untouched.)
let metTick = 0;
async function refresh(){
  if (document.visibilityState !== "visible") return;
  const st = await jget("/api/state");
  renderHeader(st);
  renderLedger(st.ledger||[]);
  renderRisk(st.riskSummary||{});
  renderAtten(st.attention||[]);
  renderAgents(st.workers||[], st.workerGroups||[]);
  lastGates = st.gates || {}; renderGateSub(lastGates);  // chat-gate-tracker: same authoritative source
  renderDecisions(st.decisions||[]);
  renderEsc(st.escalations||[]);
  // Alerts header button: red + count when there is anything to check, gray when calm.
  const alertN = (st.escalations||[]).length + (st.attention||[]).length;
  el("openAlerts").classList.toggle("alert", alertN > 0);
  el("openAlerts").textContent = alertN > 0 ? `⚠ Alerts (${alertN})` : "⚠ Alerts";
  if (metTick++ % 3 === 0){  // /api/metrics re-reads the ledger; throttle to ~every 9s
    try {
      const m = await jget("/api/metrics");
      el("metPanel").innerHTML = metricsTiles(m, true);
      // HUD min line: the two numbers that matter at a glance (today / all-time $)
      const ct = m.chatTurns || {};
      const tot = ct.costUsd && ct.costUsd.total != null ? "$" + Number(ct.costUsd.total).toFixed(2) : "$–";
      const td = (ct.byDay || {})[new Date().toISOString().slice(0, 10)];
      const tdc = td && td.total != null ? "$" + Number(td.total).toFixed(2) : "$0";
      el("hudLine").textContent = `📊 ${tdc} today · ${tot} total`;
    } catch(e){}
  }
}

// -- tree-sitter syntax highlighting (native WASM, on demand) -----------------
// web-tree-sitter core + per-language grammars served from /vendor/ (provisioned by
// ./setup.sh). Highlights ONLY lines currently in the viewport (IntersectionObserver);
// grammars load lazily on first use of a language. ANY failure (assets absent, unknown
// language, query mismatch) degrades to plain text. HTML is never injected: bytes are
// esc()'d, spans wrap already-escaped text. Language must be known (server-detected or a
// hint); there is no client-side guessing.
const HL = (function(){
  const TOKEN = "__HARNESS_TOKEN__";
  const url = p => `/vendor/tree-sitter/${p}?token=${encodeURIComponent(TOKEN)}`;  // family-prefixed (SPEC-147)
  const enc = new TextEncoder(), dec = new TextDecoder();
  const CLASSES = new Set(["keyword","operator","string","escape","comment","function",
    "constructor","type","number","float","boolean","constant","property","attribute",
    "tag","variable.parameter","punctuation","label"]);
  const PRIORITY = {comment:9,string:8,keyword:7,type:6,constructor:6,function:5,number:5,
    boolean:5,constant:5,attribute:4,property:4,"variable.parameter":4,escape:4,tag:4,
    label:3,operator:2,punctuation:1};
  const EXT = {py:"python",js:"javascript",jsx:"javascript",mjs:"javascript",ts:"typescript",
    tsx:"tsx",rs:"rust",go:"go",java:"java",cs:"c-sharp",cpp:"cpp",cc:"cpp",cxx:"cpp",
    hpp:"cpp",php:"php",rb:"ruby",sh:"bash",bash:"bash",css:"css",ini:"ini",ps1:"powershell"};
  let TS=null, manifest=null, initP=null;
  const langs = new Map();  // name -> {L,Q} | null | Promise

  async function ready(){
    if(initP) return initP;
    initP = (async () => {
      try{
        manifest = await fetch(url("manifest.json")).then(r => r.ok ? r.json() : null);
        if(!manifest || !manifest.queries) return false;
        TS = await import(url("web-tree-sitter.js"));
        await TS.Parser.init({ locateFile: () => url("web-tree-sitter.wasm") });
        return true;
      } catch(e){ TS = null; return false; }
    })();
    return initP;
  }
  function langName(hint){
    if(!hint || !manifest) return null;
    hint = String(hint).toLowerCase().replace(/^\./, "");
    const L = manifest.queries.langs;
    if(L[hint]) return hint;
    for(const stem in L){ if(L[stem].packLang === hint) return stem; }  // server pack name -> grammar stem
    if(EXT[hint]) return EXT[hint];
    return null;
  }
  async function getLang(name){
    if(langs.has(name)){ const v = langs.get(name); return (v && v.then) ? await v : v; }
    const meta = manifest.queries.langs[name];
    if(!meta){ langs.set(name, null); return null; }
    const p = (async () => {
      try{
        const L = await TS.Language.load(url(`grammars/${meta.grammar}`));
        const scm = await fetch(url(`queries/${name}.scm`)).then(r => r.ok ? r.text() : "");
        return { L, Q: new TS.Query(L, scm) };
      } catch(e){ return null; }
    })();
    langs.set(name, p);
    const r = await p; langs.set(name, r); return r;
  }
  function classOf(name){
    const parts = name.split(".");
    for(let i = parts.length; i > 0; i--){ const k = parts.slice(0,i).join("."); if(CLASSES.has(k)) return "ts-" + k.replace(/\./g,"-"); }
    return null;
  }
  function prioOf(name){
    const parts = name.split(".");
    for(let i = parts.length; i > 0; i--){ const k = parts.slice(0,i).join("."); if(k in PRIORITY) return PRIORITY[k]; }
    return 0;
  }
  // Highlight one line (row) using a range-limited query so off-screen lines cost nothing.
  function renderLine(lineText, lineStartByte, tree, Q, row){
    const lb = enc.encode(lineText), n = lb.length;
    if(n === 0) return "​";
    let caps;
    try { caps = Q.captures(tree.rootNode, {startPosition:{row,column:0}, endPosition:{row:row+1,column:0}}); }
    catch(e){ return esc(lineText); }
    const spans = [];
    for(const c of caps){
      const s = Math.max(c.node.startIndex - lineStartByte, 0);
      const e = Math.min(c.node.endIndex - lineStartByte, n);
      if(e > s){ const cls = classOf(c.name); if(cls) spans.push([s, e, cls, prioOf(c.name)]); }
    }
    spans.sort((a,b) => ((b[1]-b[0]) - (a[1]-a[0])) || (a[3]-b[3]));  // larger first, higher-prio last (wins)
    const color = new Array(n).fill(null);
    for(const [s,e,cls] of spans) for(let k=s;k<e;k++) color[k] = cls;
    let out = "", i = 0;
    while(i < n){ const c = color[i]; let j = i; while(j < n && color[j] === c) j++;
      const txt = esc(dec.decode(lb.slice(i,j)));
      out += c ? `<span class="${c}">${txt}</span>` : txt; i = j; }
    return out;
  }
  // Render `code` into `container` as line elements; highlight only visible lines.
  async function highlightBlock(container, code, hint){
    container.textContent = code;            // plain, safe, shown immediately
    if(!(await ready())) return;
    const name = langName(hint);
    if(!name) return;
    const lang = await getLang(name);
    if(!lang) return;
    let parser, tree;
    try { parser = new TS.Parser(); parser.setLanguage(lang.L); tree = parser.parse(code); }
    catch(e){ return; }
    const lines = code.split("\n");
    const starts = new Array(lines.length); let b = 0;
    for(let i=0;i<lines.length;i++){ starts[i] = b; b += enc.encode(lines[i]).length + 1; }
    const io = new IntersectionObserver((entries) => {
      for(const ent of entries){
        if(!ent.isIntersecting) continue;
        const el = ent.target; if(el.dataset.hl) continue; el.dataset.hl = "1";
        el.innerHTML = renderLine(lines[+el.dataset.i], starts[+el.dataset.i], tree, lang.Q, +el.dataset.i);
        io.unobserve(el);
      }
    }, {rootMargin: "150px"});
    container.textContent = "";
    const frag = document.createDocumentFragment();
    for(let i=0;i<lines.length;i++){
      const d = document.createElement("div"); d.className = "hl-ln"; d.dataset.i = i;
      d.textContent = lines[i] === "" ? "​" : lines[i];   // plain until scrolled into view
      frag.appendChild(d);
    }
    container.appendChild(frag);
    container.querySelectorAll(".hl-ln").forEach(d => io.observe(d));
  }
  return { highlightBlock, langName, _ready: ready };
})();

// -- P6 markdown renderer (const MD): injected here so it can use esc() + HL above --
/*__MD_JS__*/

// -- conservative git-diff colorizer (diff-only; no language tokenizer) --------
// Colorizes ONLY blocks that look like a real unified diff (a `diff --git` line, an
// `@@ … @@` hunk header, or paired `---`/`+++` file headers). Anything else returns
// the plain esc()'d text, so ordinary command output / code stays clean monospace.
// esc() runs on every line BEFORE it is wrapped, so browser input can never inject HTML.
function looksDiff(s){
  return /^diff --git /m.test(s) || /^@@ .* @@/m.test(s) || (/^--- /m.test(s) && /^\+\+\+ /m.test(s));
}
// Doc dialogs (specs / memory / research / skills): the bodies are markdown, so
// render them like assistant replies (MD escapes every text node; fenced code
// routes through HL) instead of dumping the raw string into a <pre>.
function fillDocDlg(id, d){
  const box = el(id);
  box.textContent = "";
  if (d && d.error){ box.textContent = d.error; return; }
  MD.renderInto(box, (d && d.body) || "(empty)");
}
function colorizeDiff(text){
  const s = text == null ? "" : String(text);
  if (!looksDiff(s)) return esc(s);
  return s.split("\n").map(line => {
    const e = esc(line);
    if (/^diff --git /.test(line) || /^index /.test(line) || /^(\+\+\+|---) /.test(line)) return `<span class="dhead">${e}</span>`;
    if (/^@@ /.test(line)) return `<span class="dhunk">${e}</span>`;
    if (/^\+/.test(line)) return `<span class="dadd">${e}</span>`;
    if (/^-/.test(line)) return `<span class="ddel">${e}</span>`;
    return e;
  }).join("\n");
}

// chip-diff-v2: numbered pretty diff (`NNN - old` / `NNN + new` / `NNN   ctx`)
// from the stream_json producer — marker-aware coloring, esc()'d per line.
function colorizeNumDiff(text){
  return String(text == null ? "" : text).split("\n").map(line => {
    const e = esc(line);
    if (/^\s*\d+ - /.test(line)) return `<span class="ddel">${e}</span>`;
    if (/^\s*\d+ \+ /.test(line)) return `<span class="dadd">${e}</span>`;
    return e;
  }).join("\n");
}
function diffCounts(d){
  if (d.diffAdded == null && d.diffRemoved == null) return "";
  const a = d.diffAdded || 0, r = d.diffRemoved || 0;
  return `Added ${a} line${a === 1 ? "" : "s"}, removed ${r} line${r === 1 ? "" : "s"}`;
}
// chip-preview: the collapsed chip carries one indented context line (CLI style).
// A diff chip previews its first hunk lines (>=5 body lines when the diff has them,
// colorized — colorizeDiff esc()s every line); a code chip previews its first line;
// a Bash chip previews the tool's own `description`; anything else starts bare and
// gains a `⎿ result` line when the tool-result lands (see the tool-result branch).
const PREV_DIFF_LINES = 6;  // hunk header + 5 diff body lines
function previewLine(text){
  const lines = String(text || "").split("\n").filter(l => l.trim());
  if (!lines.length) return "";
  return lines[0] + (lines.length > 1 ? "  (+" + (lines.length - 1) + " lines)" : "");
}
function chipPreview(d){
  if (d.diffPretty){   // chip-diff-v2: counts line + first numbered rows (CLI look)
    const head = diffCounts(d);
    const body = d.diffPretty.split("\n").slice(0, PREV_DIFF_LINES).join("\n");
    return `<div class="tprev block">${head ? `⎿ ${esc(head)}\n` : ""}${colorizeNumDiff(body)}</div>`;
  }
  if (d.diff){
    const body = d.diff.split("\n").filter(l => !/^(--- |\+\+\+ )/.test(l));
    return `<div class="tprev block">${colorizeDiff(body.slice(0, PREV_DIFF_LINES).join("\n"))}</div>`;
  }
  let line = d.code ? previewLine(d.code) : "";
  if (!line && d.inputDigest){          // Bash chips carry a human description in the input
    try { line = String(JSON.parse(d.inputDigest).description || ""); } catch(e){}
  }
  return line ? `<div class="tprev">⎿ ${esc(line)}</div>` : "";
}

// chat-chip-render: syntax-highlight `code` into `pre`, but only once the chip is
// actually open — collapsed chips pay nothing (tree-sitter is costly; HL degrades to
// plain text by itself). Highlights now if already open, else on the first expand.
function hlWhenOpen(det, pre, code, lang){
  if (!pre) return;
  const run = () => HL.highlightBlock(pre, code, lang || "");
  if (det.open){ run(); return; }
  det.addEventListener("toggle", function h(){
    if (det.open){ det.removeEventListener("toggle", h); run(); }
  });
}

// -- confirm/alert/prompt modal (replaces native dialogs; Playwright-assertable) --
// One #confirmDlg backs three awaitable helpers. Cancel / Esc / ✕ / backdrop all
// resolve negatively (confirm→false, prompt→null, alert→undefined) via the close event.
let _cf = null;   // pending modal: {resolve, kind}
function _cfClose(val){ const c = _cf; _cf = null; const d = el("confirmDlg"); if (d.open) d.close(); if (c) c.resolve(val); }
function _cfNeg(){ return _cf ? (_cf.kind === "confirm" ? false : _cf.kind === "alert" ? undefined : null) : undefined; }
function _cfShow(kind, text){
  if (kind === "alert") el("confirmMsg").innerHTML = colorizeDiff(text || "");   // colorize a diff-shaped result
  else el("confirmMsg").textContent = text || "";
  el("confirmInput").style.display = kind === "prompt-text" ? "" : "none";
  el("confirmSel").style.display = kind === "prompt-select" ? "" : "none";
  el("confirmCancel").style.display = kind === "alert" ? "none" : "";
  el("confirmOk").textContent = kind === "confirm" ? "Confirm" : "OK";
  el("confirmT").textContent = kind === "alert" ? "Result" : kind.startsWith("prompt") ? "Input" : "Confirm";
  return new Promise(resolve => { _cf = {resolve, kind}; el("confirmDlg").showModal(); });
}
el("confirmOk").onclick = () => { if (!_cf) return; const k = _cf.kind;
  _cfClose(k === "prompt-select" ? el("confirmSel").value : k === "prompt-text" ? el("confirmInput").value
           : k === "confirm" ? true : undefined); };
el("confirmCancel").onclick = () => _cfClose(_cfNeg());
el("confirmDlg").addEventListener("close", () => { if (_cf) _cfClose(_cfNeg()); });  // Esc / ✕ / backdrop
function confirmModal(text){ return _cfShow("confirm", text); }
function alertModal(text){ return _cfShow("alert", text); }
function promptModal(text, opts){
  opts = opts || {};
  if (opts.options){
    el("confirmSel").innerHTML = opts.options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join("");
    return _cfShow("prompt-select", text);
  }
  const p = _cfShow("prompt-text", text);
  el("confirmInput").value = opts.value || "";
  return p;
}

// -- modals ------------------------------------------------------------------
document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => el(b.dataset.close).close());
el("openRec").onclick = () => el("recDlg").showModal();
el("openAlerts").onclick = () => el("alertsDlg").showModal();
el("rsearch").onclick = async () => {
  const out = await jget(`/api/records?q=${encodeURIComponent(el("rq").value)}&kind=${encodeURIComponent(el("rk").value)}`);
  if (!Array.isArray(out)){ el("recBody").innerHTML = `<pre>${esc(JSON.stringify(out))}</pre>`; return; }
  el("recBody").innerHTML = out.length
    ? `<table><tr><th>kind</th><th>title</th><th>source:ref</th></tr>` +
      out.map(r => `<tr><td>${esc(r.kind)}</td><td>${esc(r.title)}</td><td class="dim">${esc(r.source)}:${esc(r.ref)}</td></tr>`).join("") + `</table>`
    : '<p class="dim">no hits</p>';
};
el("rrebuild").onclick = async () => {
  if (!(await confirmModal("Rebuild the records index? Runs: harness.py records rebuild"))) return;
  const res = await jpost("/api/action", {action:"records-rebuild", params:{confirm:true}});
  await alertModal(res.ok ? "rebuilt" : "refused/failed: " + (res.refused||res.output||res.rc));
};
// R27: stat tiles + CSS mini-bars, shared by the left panel (compact) and modal (full).
const na = '<span class="dim">n/a</span>';
function tile(cls, label, value, sub, title){
  return `<div class="stile ${cls}"${title?` title="${esc(title)}"`:""}><div class="snum">${value}</div>` +
    `<div class="slabel">${esc(label)}</div>${sub?`<div class="ssub">${esc(sub)}</div>`:""}</div>`;
}
function metricsTiles(m, compact){
  const ct = m.chatTurns||{}, dg = m.delegations||{}, wf = m.workflows||{};
  // P2 honest labels: the old "session $" tile was really the ALL-TIME total → "total $";
  // a new "today $" reads chatTurns.byDay[<UTC date>].total (0/n-a when nothing spent today).
  const cost = ct.costUsd && ct.costUsd.total!=null ? "$"+Number(ct.costUsd.total).toFixed(3) : na;
  const today = new Date().toISOString().slice(0,10);
  const tday = (ct.byDay||{})[today];
  const todayCost = (tday && tday.total!=null) ? "$"+Number(tday.total).toFixed(3) : na;
  const dtok = dg.estTokens && dg.estTokens.total!=null ? "~"+fmtTok(dg.estTokens.total)+" tok" : "";
  const tiles = tile("cost","total $",cost,"","all-time · last 500 records") +
    tile("cost","today $",todayCost,"",today+" · UTC") +
    tile("turns","turns",ct.count||0) +
    tile("deleg","delegations",dg.count||0,dtok) + tile("wf","workflows",wf.count||0) +
    tile("rec","records",m.records||0);
  const top = m.topExpensive||[];
  const vals = top.map(t => t.costUsd!=null ? Number(t.costUsd) : (t.estTokens!=null ? Number(t.estTokens) : 0));
  const max = Math.max(1, ...vals);
  const bars = top.slice(0, compact?3:5).map((t,i) => {
    const who = t.label ? esc(String(t.label).slice(0,20)) : '<span class="dim">no label</span>';
    const val = t.costUsd!=null ? "$"+Number(t.costUsd).toFixed(3)
      : (t.estTokens!=null ? "~"+fmtTok(t.estTokens)+" tok" : "n/a");
    const pct = Math.max(2, Math.round(vals[i]*100/max));
    return `<div class="mbar"><div class="mbtop"><span class="kbadge">${esc(t.kind||"?")}</span>` +
      `<span class="mbid mono">${who}</span><span class="mbval">${esc(val)}</span></div>` +
      `<div class="mbtrack"><div class="mbfill" style="width:${pct}%"></div></div></div>`;
  }).join("");
  return `<div class="stiles">${tiles}</div>` +
    (bars ? `<h3>Top expensive</h3>${bars}` : `<p class="dim">no cost records yet</p>`);
}
// -- chat send + session restart --------------------------------------------
const history = []; let histPos = -1;   // -1 = not navigating; classic REPL recall
function growInput(){ const t = el("chatin"); t.style.height = "auto";
  t.style.height = Math.min(t.scrollHeight, 126) + "px"; }   // cap ≈ CSS max-height 9em
function stripPaste(s){ const m = /^\/paste\n([\s\S]*)\n\/end$/.exec(s||""); return m ? m[1] : (s||""); }
async function sendLine(){
  const v = el("chatin").value; if (!v.trim()) return;
  history.push(v); histPos = -1;
  append("user", "❯ " + v); el("chatin").value = ""; el("chatin").style.height = "auto";
  // A line starting with ! or / runs LOCALLY (harness command / REPL command) — it
  // emits no turn-start/turn-end, so the spinner would hang forever. Skip busyOn().
  if (!/^\s*[!/]/.test(v)) busyOn();
  // P5: a multi-line message is framed as ONE /paste…/end REPL block (single POST); the
  // echo/busy check above use the raw text, only the wire payload carries the framing.
  const payload = v.includes("\n") ? "/paste\n" + v + "\n/end" : v;
  const res = await jpost("/api/chat/send", {session: curSession, line: payload});
  if (!res.ok){ busyOff(); append("err", "(bridge not ready / send failed)"); }
}
el("send").onclick = sendLine;
el("stopbtn").onclick = async () => {
  const res = await jpost("/api/chat/stop", {session: curSession});
  if (!res.ok) append("err", "(no turn to stop / bridge not ready)");
};
// -- attachments: 📎 picker + drag-and-drop → POST /api/chat/upload → @mention --
async function uploadFiles(files){
  for (const f of files){
    if (f.size > 8 * 1024 * 1024){ append("err", `(${f.name}: 8MB max)`); continue; }
    const b64 = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",", 2)[1] || "");
      r.onerror = () => rej(r.error);
      r.readAsDataURL(f);
    }).catch(() => null);
    if (b64 === null){ append("err", `(failed reading ${f.name})`); continue; }
    const res = await jpost("/api/chat/upload", {session: curSession, name: f.name, data: b64});
    if (res && res.ok && res.path){
      const t = el("chatin");
      t.value = (t.value && !/\s$/.test(t.value) ? t.value + " " : t.value) + "@" + res.path + " ";
      growInput(); t.focus();
      append("dim", `📎 ${f.name} → ${res.path}`);
    } else append("err", `(upload of ${f.name} failed: ${res && res.error || "no response"})`);
  }
}
el("attach").onclick = () => el("filein").click();
el("filein").onchange = () => { uploadFiles([...el("filein").files]); el("filein").value = ""; };
for (const zone of [transcript, el("chatin")]){
  zone.addEventListener("dragover", e => { e.preventDefault(); zone.classList.add("dropping"); });
  zone.addEventListener("dragleave", () => zone.classList.remove("dropping"));
  zone.addEventListener("drop", e => {
    e.preventDefault(); zone.classList.remove("dropping");
    if (e.dataTransfer && e.dataTransfer.files.length) uploadFiles([...e.dataTransfer.files]);
  });
}
el("chatin").addEventListener("input", growInput);
el("chatin").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey){ e.preventDefault(); sendLine(); return; }
  if (e.key === "Enter") return;              // Shift+Enter → default newline
  if (el("chatin").value.includes("\n")) return;   // history recall only on single-line input
  if (e.key === "ArrowUp"){
    if (histPos === -1) histPos = history.length;
    if (histPos > 0){ histPos--; el("chatin").value = history[histPos]; e.preventDefault(); }
  } else if (e.key === "ArrowDown"){
    if (histPos === -1) return;
    if (histPos < history.length - 1){ histPos++; el("chatin").value = history[histPos]; }
    else { histPos = -1; el("chatin").value = ""; }
    e.preventDefault();
  }
});
async function doRestart(){
  // Restart THIS session in place, reusing the server's overseer default engine
  // (engine is chosen only via /config now — no per-session picker).
  await jpost("/api/chat/restart", {session: curSession});
  busyOff(); append("dim", "— session restarted —");
}

// -- P6 markdown: assistant reply lines arrive one-per-SSE-frame BETWEEN turn-end and
// the next ready/exit. Buffer them there, then render the whole reply as ONE `.ln md`
// block via MD.renderInto. err/you/tool lines bypass the buffer (see onmessage/handleEvt).
let mdBuf = null;
function renderMd(text){
  if (!text.trim()) return;                 // a turn with only tool activity → nothing to render
  if (text.includes("/back")) sawBack = true;  // SPEC-146: farewell ritual names /back
  const d = document.createElement("div"); d.className = "ln md";
  MD.renderInto(d, text);
  transcript.insertBefore(d, busyEl);
}
// SPEC-146 room exit affordance: when a ROOM turn ends with the overseer's
// farewell (the ritual names /back), a centered 🚪 button under the last
// message sends /back through the same chat pipe — one click leaves the room.
let sawBack = false, leaveEl = null;
function removeLeaveBtn(){ if (leaveEl){ leaveEl.remove(); leaveEl = null; } }
function maybeLeaveBtn(role){
  if (!role || role === "router"){ removeLeaveBtn(); return; }  // back at the desk
  if (leaveEl || !sawBack) return;
  leaveEl = document.createElement("div"); leaveEl.className = "ln leaveroom";
  const b = document.createElement("button");
  b.className = "act"; b.textContent = "🚪 Sair da sala";
  b.title = "sends /back — returns to the porteiro (front desk)";
  b.onclick = () => { removeLeaveBtn(); jpost("/api/chat/send", {session: curSession, line: "/back"}); };
  leaveEl.appendChild(b);
  transcript.insertBefore(leaveEl, busyEl);
}
function flushMd(){
  if (mdBuf === null) return;
  const buf = mdBuf; mdBuf = null;
  renderMd(buf.join("\n"));
}
// P8 plan approval strip: render the plan text as markdown + Approve / Keep planning.
// Approve POSTs the same chat pipe with "/approve" (the CLI flips mode + proceeds).
function renderPlan(text){
  const md = document.createElement("div"); md.className = "ln md"; MD.renderInto(md, text||"");
  transcript.insertBefore(md, busyEl);
  const strip = document.createElement("div"); strip.className = "ln approve";
  const ap = document.createElement("button"); ap.className = "act"; ap.textContent = "Approve";
  const kp = document.createElement("button"); kp.className = "pillbtn"; kp.textContent = "Keep planning";
  ap.onclick = () => { strip.remove(); jpost("/api/chat/send", {session: curSession, line: "/approve"}); };
  kp.onclick = () => strip.remove();
  strip.appendChild(ap); strip.appendChild(kp);
  transcript.insertBefore(strip, busyEl);
}
// P8 questions: reuse promptModal's <select>; each answer is sent as the next user
// message (`answer: <choice>`). Multiple questions render sequentially.
async function askQuestions(questions){
  for (const q of (questions||[])){
    const choice = await promptModal(q.q || "choose an option", {options: q.options || []});
    if (choice == null) return;               // cancelled → stop the sequence
    await jpost("/api/chat/send", {session: curSession, line: "answer: " + choice});
  }
}

// -- SSE: evt drives state; err dims; everything else is a plain line --------
function handleEvt(d){
  if (!d || !d.event) return;
  if (d.event === "ready"){ flushMd(); readyInfo = d; if (d.mode) setMode(d.mode);
    el("targetLabel").textContent = d.target ? "→ " + d.target : "";
    curTarget = d.target || null; updateOnboardChip();
    renderEngineChip(); busyOff();
    maybeLeaveBtn(d.role); }  // SPEC-146: room farewell → centered 🚪 leave button
  else if (d.event === "turn-start"){ turnTok = 0; sawBack = false; removeLeaveBtn(); busyOn(); }
  // chat-status-line: one frame per assistant API message; output tokens accumulate
  else if (d.event === "usage"){ turnTok += (d.outputTokens || 0); }
  // room-chat fix: mid-turn assistant text streams live (long room turns used to
  // show only tool/plan events until the final reply). Renders NOW, outside mdBuf.
  else if (d.event === "text"){ renderMd(d.text || ""); }
  // SPEC-114 v13 verbose chat → chat-tool-chips: a mid-turn tool call renders a
  // native <details> chip (icon + name + arg; expand shows the capped input and
  // the matching tool-result fills the output section by tool_use id).
  // Does NOT toggle the spinner — the turn stays busy until turn-end/ready.
  else if (d.event === "tool"){
    const icons = {Read:"📖", Edit:"✏️", Write:"✏️", NotebookEdit:"✏️", Bash:"🖥️",
                   Grep:"🔎", Glob:"🔎", WebFetch:"🌐", WebSearch:"🌐", TodoWrite:"📋"};
    const m = readyInfo.model ? `<span class="tmodel">${esc(readyInfo.model)}</span> ` : "";
    const arg = d.arg ? " " + esc(String(d.arg)) : "";
    const det = document.createElement("details");
    det.className = "ln tchip";
    // chat-chip-render: a diff colorizes inline (colorizeDiff esc()s every line, so
    // its innerHTML is safe); code is shown esc()'d and lazily highlighted on expand;
    // any other input stays esc()'d text — raw input is NEVER innerHTML'd directly.
    const counts = d.diffPretty && diffCounts(d);
    const inHtml = d.diffPretty
      ? `${counts ? `<div class="tprev block">⎿ ${esc(counts)}</div>` : ""}` +
        `<pre class="tchip-in">${colorizeNumDiff(d.diffPretty)}</pre>`
      : d.diff
      ? `<pre class="tchip-in">${colorizeDiff(d.diff)}</pre>`
      : `<pre class="tchip-in">${esc((d.code || d.inputDigest) || "(no input captured)")}</pre>`;
    // SPEC-147: diff chips get an open-in-pane ⧉ (the pane fetches the UNCAPPED diff)
    const wsBtn = (d.diff || d.diffPretty) ? `<button class="wsopen" title="open the full diff in the pane">⧉</button>` : "";
    det.innerHTML =
      `<summary>${m}${icons[d.name] || "🔧"} <b>${esc(d.name || "?")}</b>${arg}${wsBtn}${chipPreview(d)}</summary>` +
      inHtml +
      `<pre class="tchip-out dim">(no output yet)</pre>`;
    if (d.id) det.dataset.tid = d.id;                     // SPEC-147: /api/chat/diff key
    if (d.diff || d.diffPretty) det.dataset.diff = "1";   // chip-preview: a diff preview is never swapped for the result
    // Only a Read chip (language, but no code/diff input) highlights its RESULT digest;
    // Write/Edit carry a language for the INPUT render, and their result is a status line.
    if (d.language && !d.code && !d.diff) det.dataset.lang = d.language;
    // chip-diff-v2: a Write-update chip renders its numbered diff — highlighting
    // the raw code would clobber it on expand, so HL only runs diffless.
    if (d.code && !d.diffPretty) hlWhenOpen(det, det.querySelector(".tchip-in"), d.code, d.language || "");
    if (d.id) toolChips[d.id] = det;
    transcript.insertBefore(det, busyEl);
    // chat-gate-tracker: a Bash gate command starts a gate → HUD sub-tracker chip.
    if (d.name === "Bash"){ const ge = gateFromCmd(d.arg); if (ge) addGate(ge); }
  }
  else if (d.event === "tool-result"){
    const det = d.id && toolChips[d.id];
    if (det){
      // chip-error-color: a failed call flips the chip red and gets a ✗ prefix.
      // Successful chips are untouched (the event omits isError entirely).
      if (d.isError && !det.classList.contains("failed")){
        det.classList.add("failed");
        det.querySelector("summary").insertAdjacentText("afterbegin", "✗ ");
      }
      const out = det.querySelector(".tchip-out");
      if (out){
        out.textContent = d.digest || "(empty result)";   // immediate plain fallback
        out.classList.remove("dim");
        // M1 (codex file_change): a result-borne derived diff upgrades the chip —
        // colorized diff in the output section + the >=5-line hunk preview on the
        // collapsed summary, matching claude Edit chips. colorizeDiff esc()s lines.
        if (d.diffPretty){   // chip-diff-v2 (codex parity): numbered body + counts
          det.dataset.diff = "1";
          if (!det.querySelector(".wsopen")){  // SPEC-147: result-borne diffs get ⧉ too
            const b = document.createElement("button");
            b.className = "wsopen"; b.title = "open the full diff in the pane"; b.textContent = "⧉";
            const s = det.querySelector("summary b");
            if (s) s.after(b);
          }
          const head = diffCounts(d);
          out.innerHTML = (head ? `<span class="dim">⎿ ${esc(head)}</span>\n` : "") +
                          colorizeNumDiff(d.diffPretty);
          let prev = det.querySelector("summary .tprev");
          if (!prev){ prev = document.createElement("div");
                      det.querySelector("summary").appendChild(prev); }
          prev.className = "tprev block";
          prev.innerHTML = (head ? `⎿ ${esc(head)}\n` : "") +
            colorizeNumDiff(d.diffPretty.split("\n").slice(0, PREV_DIFF_LINES).join("\n"));
        }
        else if (d.diff){
          det.dataset.diff = "1";
          out.innerHTML = colorizeDiff(d.diff);
          const body = d.diff.split("\n").filter(l => !/^(--- |\+\+\+ )/.test(l));
          let prev = det.querySelector("summary .tprev");
          if (!prev){ prev = document.createElement("div");
                      det.querySelector("summary").appendChild(prev); }
          prev.className = "tprev block";
          prev.innerHTML = colorizeDiff(body.slice(0, PREV_DIFF_LINES).join("\n"));
        }
        // chat-chip-render: a Read chip carries a language → highlight the result
        // digest on first expand (as-is; HL degrades to plain text on its own).
        else if (det.dataset.lang && d.digest) hlWhenOpen(det, out, d.digest, det.dataset.lang);
      }
      // chip-preview: the collapsed line flips to the result (CLI's `⎿ …`) — except
      // on diff chips, whose hunk preview says more than Edit's status line.
      if (!det.dataset.diff){
        const line = previewLine(d.digest);
        if (line){
          let prev = det.querySelector("summary .tprev");
          if (!prev){ prev = document.createElement("div"); prev.className = "tprev";
                      det.querySelector("summary").appendChild(prev); }
          prev.textContent = "⎿ " + line;
        }
      }
    }
  }
  // M3 (codex app-server): live command output streams into the chip while it runs
  // (the tool-result overwrite at completion stays authoritative).
  else if (d.event === "tool-delta"){
    const det = d.id && toolChips[d.id];
    if (det && d.chunk){
      const out = det.querySelector(".tchip-out");
      if (out){
        if (out.classList.contains("dim")){ out.textContent = ""; out.classList.remove("dim"); }
        out.textContent += d.chunk;
      }
    }
  }
  // M3: the aggregated turn diff — ONE collapsible block per turn, latest wins.
  else if (d.event === "turn-diff"){
    if (d.diff){
      if (!turnDiffEl || !transcript.contains(turnDiffEl)){
        turnDiffEl = document.createElement("details");
        turnDiffEl.className = "ln tchip tdiff";
        turnDiffEl.innerHTML = '<summary>🧾 <b>diff do turno</b></summary><pre class="tchip-in"></pre>';
        transcript.insertBefore(turnDiffEl, busyEl);
      }
      turnDiffEl.querySelector(".tchip-in").innerHTML = colorizeDiff(d.diff);
    }
  }
  // turn-end opens the markdown buffer: the reply lines that follow accumulate until
  // the next ready/exit flushes them as one rendered block.
  else if (d.event === "turn-end"){ lastTurn = d; renderTelemetry(); mdBuf = []; turnDiffEl = null; }
  // P8 derived events: a plan (approval strip) or a question (sequential modal).
  else if (d.event === "plan"){ flushMd(); renderPlan(d.text || ""); }
  // chat-plan-hud: TodoWrite live steps → the floating card (last frame wins;
  // a finished plan flushes into the transcript as history and hides the card).
  else if (d.event === "plan-steps"){ renderPlanSteps(d.steps || []); }
  else if (d.event === "question"){ flushMd(); askQuestions(d.questions || []); }
  else if (d.event === "exit"){ flushMd(); busyOff(); loadSessions();  // mark this tab dead in the bar
    append("dim", null, `bridge closed (rc ${esc(d.rc)}) — <a href="#" id="rst">Restart</a>`);
    const a = el("rst"); if (a) a.onclick = e => { e.preventDefault(); doRestart(); }; }
}
// -- chat-plan-hud: floating minimizable card above the input row -----------
let planMinimized = false;
function renderPlanSteps(steps){
  const card = el("planCard");
  if (!steps.length){ card.style.display = "none"; return; }
  const done = steps.filter(s => s.status === "completed").length;
  el("planTitle").textContent = `Plan (${done}/${steps.length})`;
  if (done === steps.length){
    append("dim", null, "plan complete: " + steps.map(s => "✔ " + esc(s.text)).join(" · "));
    card.style.display = "none";
    return;
  }
  const marks = {completed: "✔", in_progress: "▸", pending: "○"};
  // chat-status-line: the in_progress row carries a live `(elapsed · ↓ tokens ·
  // effort)` suffix, updated by the busy ticker (claude-CLI look).
  el("planSteps").innerHTML = steps.map(s =>
    `<li class="ps-${esc(s.status)}">${marks[s.status] || "○"} ${esc(s.text)}` +
    `${s.status === "in_progress" ? '<span id="psLive" class="dim"></span>' : ""}</li>`).join("");
  el("planSteps").style.display = planMinimized ? "none" : "block";
  card.style.display = "block";
}
el("planMin").onclick = () => {
  planMinimized = !planMinimized;
  el("planSteps").style.display = planMinimized ? "none" : "block";
  el("planMin").textContent = planMinimized ? "+" : "–";
};
// -- chat-gate-tracker: gate sub-tracker under the plan HUD (READ-ONLY display) ----
// Detection is a deterministic regex over the Bash tool command (no LLM). Status is
// NEVER invented here: it comes from quality-state via st.gates (assembled by
// ui_panel._gates every poll). Terminal gates flush to history, like the plan.
let gateEvents = [], lastGates = {};
function gateFromCmd(cmd){
  // Twin of harness_ui_page.gate_from_cmd (Python, unit-driven) — keep the token
  // rules in sync. The overseer runs the ladder via spec_test_gate.py <gate> /
  // harness.py test <gate> / harness-test.py <gate>; --target <name> ⇒ target scope.
  if (!cmd) return null;
  const m = String(cmd).match(/(?:spec_test_gate\.py|harness-test\.py|harness\.py\s+test)\s+(.*)/);
  if (!m) return null;
  const toks = m[1].split(/\s+/);
  let target = null, gate = null, skip = false;
  for (let i = 0; i < toks.length; i++){
    const t = toks[i];
    if (skip){ skip = false; continue; }
    if (t.indexOf("--target=") === 0){ target = t.slice(9); continue; }
    if (t === "--target"){ if (i + 1 < toks.length){ target = toks[i + 1]; skip = true; } continue; }
    if (t.charAt(0) === "-") continue;
    if (gate === null && /^[a-z][a-z-]*$/.test(t)) gate = t;
  }
  if (gate === null) return null;
  return {event: "gate", scope: target ? "target" : "harness", target: target,
          gate: gate, status: "running"};
}
function addGate(ge){
  const key = ge.scope + "|" + (ge.target || "") + "|" + ge.gate;
  if (!gateEvents.some(g => g.key === key)){ ge.key = key; ge.seenAt = Date.now(); gateEvents.push(ge); }
  renderGateSub(lastGates);
}
function gateStatus(g, gates){
  gates = gates || {};
  let last;
  if (g.scope === "target"){ const t = gates.target; last = (t && t.name === g.target) ? t.last : null; }
  else last = gates.last;
  if (!last || last.gate !== g.gate) return "running";
  // authoritative + fresh: only settle when THIS run's quality-state is newer than
  // when the gate was seen starting (a stale prior result must not settle it early).
  const at = Date.parse(last.at || "");
  if (isFinite(at) && at < g.seenAt - 2000) return "running";
  return last.status || "running";
}
function renderGateSub(gates){
  const card = el("gateCard");
  const still = [];
  for (const g of gateEvents){                         // settle terminal gates → history
    const s = gateStatus(g, gates);
    if (s && s !== "running"){
      const mk = s === "pass" ? "✓" : "✗";
      const scope = g.scope === "target" ? "target:" + g.target : "harness";
      append("dim", null, "↳ gate " + esc(g.gate) + " " + mk + " " + esc(scope));
    } else still.push(g);
  }
  gateEvents = still;
  if (!gateEvents.length){ card.style.display = "none"; return; }
  el("gateSub").innerHTML = gateEvents.map(g => g.scope === "target"
    ? `<span class="gsub tgt" title="running (target repo)">target <span class="mono">${esc(g.target)}</span>: ${esc(g.gate)} ▸</span>`
    : `<span class="gtier on none" title="running (harness)">${esc(g.gate)} ▸</span>`
  ).join("");
  card.style.display = "block";
}
let sse = null;
let toolChips = {};   // chat-tool-chips: tool_use id → chip element (per transcript)
let turnDiffEl = null; // M3: the current turn's aggregated-diff block (reset at turn-end)
function clearTranscript(){
  transcript.innerHTML = ""; transcript.appendChild(busyEl); busyOff(); lastBlank = false; mdBuf = null;
  toolChips = {}; turnDiffEl = null;
  el("planCard").style.display = "none";
  gateEvents = []; el("gateCard").style.display = "none";   // chat-gate-tracker resets with the transcript
}
function startSSE(){
  if (sse) sse.close();   // re-point: a session switch closes the old stream first
  sse = new EventSource(`/api/chat/stream?session=${encodeURIComponent(curSession)}&token=${encodeURIComponent(TOKEN)}`);  // EventSource can't set headers
  // R24: every (re)connect the server replays that session's transcript from history,
  // so wipe the pane on open and let the replay rebuild it — no stacked duplicate.
  sse.onopen = clearTranscript;
  sse.onmessage = ev => {
    let it; try { it = JSON.parse(ev.data); } catch(e){ return; }
    // Sticky auto-scroll is decided ONCE per SSE frame, here: handlers may grow
    // EXISTING content (tool-result ⎿ previews, turn-diff), not just insert lines,
    // and any growth without this re-pin unsticks the pane for the whole turn.
    const stick = atBottom();
    try {
      if (it.stream === "evt") handleEvt(it.data);
      else if (it.stream === "err") append("err", it.line);
      else if (it.stream === "you") append("user", "❯ " + stripPaste(it.line));   // replayed user line (P5: unframe /paste…/end)
      else if (mdBuf !== null) mdBuf.push(it.line);   // buffering an assistant turn → render as markdown on flush
      else append("", it.line);
    } finally {
      if (stick) transcript.scrollTop = transcript.scrollHeight;
    }
  };
}

// -- session bar (SPEC-114 v11): tabs + Nova sessão + ✕; all overseer-default engine --
let curSession = "main";
async function loadSessions(){
  let list = [];
  try { list = await jget("/api/chat/sessions"); } catch(e){}
  renderSessionBar(Array.isArray(list) ? list : []);
}
function renderSessionBar(list){
  if (!list.some(s => s.id === curSession))       // always show the active session,
    list = list.concat([{id: curSession, label: curSession, alive: true}]);  // even pre-create
  const tabs = list.map(s => {
    const act = s.id === curSession ? " active" : "";
    const dead = s.alive ? "" : ' <span class="sdead" title="bridge closed">•</span>';
    const x = list.length > 1 ? `<span class="sx" data-close="${esc(s.id)}" title="close session">✕</span>` : "";
    return `<span class="stab${act}" data-sel="${esc(s.id)}" title="session ${esc(s.label||s.id)}">${esc(s.label||s.id)}${dead}${x}</span>`;
  }).join("");
  el("sessionbar").innerHTML = tabs +
    `<button class="snew" id="snew" title="new session (default overseer engine)">+ New session</button>`;
}
async function newSession(){
  const res = await jpost("/api/chat/new", {});
  if (res && res.id){ curSession = res.id; startSSE(); await loadSessions(); }
}
function switchSession(id){
  if (id === curSession) return;
  curSession = id; startSSE();   // onopen clears; server replays that session's history
  loadSessions();
}
async function closeSession(id){
  await jpost("/api/chat/close", {session: id});
  if (id === curSession){
    let list = []; try { list = await jget("/api/chat/sessions"); } catch(e){}
    curSession = (Array.isArray(list) && list[0] && list[0].id) || "main";
    startSSE();   // reconnect to the surviving (or re-created "main") session
  }
  await loadSessions();
}
el("sessionbar").addEventListener("click", async e => {
  const closeId = e.target.dataset && e.target.dataset.close;
  if (closeId){ e.stopPropagation(); await closeSession(closeId); return; }
  if (e.target.id === "snew"){ await newSession(); return; }
  const tab = e.target.closest("[data-sel]");
  if (tab) switchSession(tab.dataset.sel);
});

// -- resizable columns (native pointer events + localStorage persist) --------
function setupSplit(handle){
  const side = handle.dataset.side;                    // "left" | "right"
  const panel = document.querySelector("." + side);
  const key = side === "left" ? "harness.panel.leftW" : "harness.panel.rightW";
  const saved = localStorage.getItem(key);
  if (saved) panel.style.width = saved;
  let startX = 0, startW = 0, dragging = false;
  handle.addEventListener("pointerdown", e => {
    dragging = true; startX = e.clientX; startW = panel.getBoundingClientRect().width;
    handle.setPointerCapture(e.pointerId);
  });
  handle.addEventListener("pointermove", e => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    let w = side === "left" ? startW + dx : startW - dx;
    w = Math.max(192, Math.min(window.innerWidth * 0.45, w));  // 12rem .. ~45vw
    panel.style.width = w + "px";
  });
  handle.addEventListener("pointerup", e => {
    dragging = false; handle.releasePointerCapture(e.pointerId);
    localStorage.setItem(key, panel.style.width);
  });
  handle.addEventListener("dblclick", () => {
    panel.style.width = ""; localStorage.removeItem(key);      // back to CSS default
  });
}
document.querySelectorAll(".split").forEach(setupSplit);

// -- SPEC-115 config view: model-card grid + role-CRUD-via-modal + advanced JSON --
const KNOWN_EFFORTS = ["low", "medium", "high", "xhigh", "max"];
let cfg = null;      // last /api/routing snapshot
let queueTimer = null;
function switchView(v){
  const isPanel = v === "panel", isCfg = v === "config", isCompose = v === "compose",
        isTasks = v === "tasks", isQueue = v === "queue", isChangelog = v === "changelog",
        isMemory = v === "memory", isSpecs = v === "specs", isResearch = v === "research",
        isExperiments = v === "experiments", isWiki = v === "wiki", isGraphs = v === "graphs",
        isFallbacks = v === "fallbacks";
  document.querySelector(".body").style.display = isPanel ? "flex" : "none";
  el("viewConfig").style.display = isCfg ? "block" : "none";
  el("viewCompose").style.display = isCompose ? "block" : "none";
  el("viewTasks").style.display = isTasks ? "block" : "none";
  el("viewQueue").style.display = isQueue ? "block" : "none";
  el("viewChangelog").style.display = isChangelog ? "block" : "none";
  el("viewMemory").style.display = isMemory ? "block" : "none";
  el("viewSpecs").style.display = isSpecs ? "block" : "none";
  el("viewWiki").style.display = isWiki ? "block" : "none";
  el("viewResearch").style.display = isResearch ? "block" : "none";
  el("viewExperiments").style.display = isExperiments ? "block" : "none";
  el("viewGraphs").style.display = isGraphs ? "block" : "none";
  el("viewFallbacks").style.display = isFallbacks ? "block" : "none";
  el("navPanel").classList.toggle("navsel", isPanel);
  el("navConfig").classList.toggle("navsel", isCfg);
  el("navCompose").classList.toggle("navsel", isCompose);
  el("navTasks").classList.toggle("navsel", isTasks);
  el("navQueue").classList.toggle("navsel", isQueue);
  el("navChangelog").classList.toggle("navsel", isChangelog);
  el("navMemory").classList.toggle("navsel", isMemory);
  el("navSpecs").classList.toggle("navsel", isSpecs);
  el("navWiki").classList.toggle("navsel", isWiki);
  el("navResearch").classList.toggle("navsel", isResearch);
  el("navExperiments").classList.toggle("navsel", isExperiments);
  el("navGraphs").classList.toggle("navsel", isGraphs);
  el("navFallbacks").classList.toggle("navsel", isFallbacks);
  // the selected item may be hidden inside the closed Advanced dropdown — mirror
  // its state on the summary so the header still shows where you are.
  el("navAdvT").classList.toggle("navsel", isCompose || isMemory);
  if (isCfg) loadConfig();
  if (isCompose) loadCompose();
  if (isTasks) loadTasks();
  if (isChangelog) loadChangelog();
  if (isMemory) loadMemory();
  if (isSpecs) loadSpecs();
  if (isWiki) loadWiki();
  if (isResearch) loadResearch();
  if (isExperiments) loadExperiments();
  if (isGraphs) loadGraphs();
  if (isFallbacks) loadFallbacks();
  // queue is the one LIVE view: poll every 3s only while visible.
  if (queueTimer){ clearInterval(queueTimer); queueTimer = null; }
  if (isQueue){ loadQueue(); queueTimer = setInterval(loadQueue, 3000); }
}
el("navConfig").onclick = () => switchView("config");
// SPEC-147 v2 (owner feedback): the Chat tab HOSTS the workspace — clicking it
// while the chat view is already showing toggles the vibe/copilot pane instead
// of being a no-op (there is no separate header mode button).
el("navPanel").onclick = () => {
  const chatShowing = document.querySelector(".body").style.display !== "none";
  if (chatShowing) WS.togglePane();
  else switchView("panel");
};
el("navCompose").onclick = () => switchView("compose");
el("navTasks").onclick = () => switchView("tasks");
el("navQueue").onclick = () => switchView("queue");
el("navChangelog").onclick = () => switchView("changelog");
el("navMemory").onclick = () => switchView("memory");
el("navSpecs").onclick = () => switchView("specs");
el("navWiki").onclick = () => switchView("wiki");
el("navResearch").onclick = () => switchView("research");
el("navExperiments").onclick = () => switchView("experiments");
el("navGraphs").onclick = () => switchView("graphs");
el("navFallbacks").onclick = () => switchView("fallbacks");
// Advanced dropdown: picking an item closes it; so does clicking anywhere outside.
el("navAdvanced").addEventListener("click", e => {
  if (e.target.closest("button")) el("navAdvanced").removeAttribute("open");
});
document.addEventListener("click", e => {
  const d = el("navAdvanced");
  if (d.open && !d.contains(e.target)) d.removeAttribute("open");
});

// GUI-SH2 legacy deep-link: the React shell links here as /?token=...#view=<v> (same
// origin "/", the session token preserved, hash "#view=<viewId>"). On load AND on
// hashchange, route a KNOWN view id (the exact set switchView handles) to switchView;
// an unknown id is ignored. No #view hash present => no-op (the panel's default view
// stays untouched, so existing behavior/tests are unaffected).
const DEEP_LINK_VIEWS = new Set(["panel","config","compose","tasks","queue","changelog",
  "memory","specs","research","experiments","graphs","fallbacks"]);
function routeDeepLink(){
  const m = /(?:^|[#&])view=([\w-]+)/.exec(location.hash || "");
  if (m && DEEP_LINK_VIEWS.has(m[1])) switchView(m[1]);
}
window.addEventListener("hashchange", routeDeepLink);
routeDeepLink();

// -- memory snapshot (M5.mem): scope×purpose cards, redacted previews --------
async function loadMemory(){
  const box = el("memGrid");
  let data = null;
  try { data = await jget("/api/memory"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.sources)){
    box.innerHTML = '<p class="jsonerr">memory snapshot unavailable</p>'; return;
  }
  const scopes = [...new Set(data.sources.map(s => s.scope))];
  box.innerHTML = scopes.map(scope => {
    const cards = data.sources.filter(s => s.scope === scope).map(s =>
      `<div class="memcard${s.exists ? "" : " memabsent"}" data-id="${esc(s.id)}">` +
      `<div class="memtop"><b>${esc(s.purpose)}</b>` +
      `<span class="dim">${s.exists ? esc((s.mtime || "").slice(0, 16)) : "absent"}</span></div>` +
      `<div class="dim mono" style="font-size:0.68rem">${esc(s.id)}</div>` +
      (s.note ? `<div class="dim" style="font-size:0.7rem">${esc(s.note)}</div>` : "") +
      (s.preview ? `<pre class="memprev">${esc(s.preview)}</pre>` : "") +
      `</div>`).join("");
    return `<h3 class="memscope">${esc(scope)}</h3><div class="memrow">${cards}</div>`;
  }).join("");
  for (const c of box.querySelectorAll(".memcard[data-id]")) c.onclick = async () => {
    const d = await jget("/api/memory/file?id=" + encodeURIComponent(c.dataset.id));
    el("memDlgT").textContent = c.dataset.id;
    fillDocDlg("memDlgBody", d);
    el("memDlg").showModal();
  };
}

// -- specs snapshot (SPEC-134): the SDD inventory by scope, click opens the body -
async function loadSpecs(){
  const box = el("specGrid");
  let data = null;
  try { data = await jget("/api/specs"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.specs)){
    box.innerHTML = '<p class="jsonerr">specs snapshot unavailable</p>'; return;
  }
  const scopes = [...new Set(data.specs.map(s => s.scope))];
  box.innerHTML = scopes.map(scope => {
    const group = data.specs.filter(s => s.scope === scope);
    const cards = group.map(s =>
      `<div class="memcard" data-path="${esc(s.id)}">` +
      `<div class="memtop"><b>${esc(s.title || s.id)}</b>` +
      `<span class="dim">${esc((s.mtime || "").slice(0, 10))}</span></div>` +
      `<div class="dim mono" style="font-size:0.68rem">${esc(s.id)}</div>` +
      `<div class="specbadges">` +
      (s.legacyFrozen ? `<span class="esub">legacy-frozen</span>` : "") +
      `<span class="dim" style="font-size:0.7rem">${s.gherkinIds} gherkin id${s.gherkinIds === 1 ? "" : "s"}</span>` +
      `</div></div>`).join("");
    return `<h3 class="memscope">${esc(scope)} · ${group.length}</h3><div class="memrow">${cards}</div>`;
  }).join("");
  for (const c of box.querySelectorAll(".memcard[data-path]")) c.onclick = async () => {
    const d = await jget("/api/specs/file?path=" + encodeURIComponent(c.dataset.path));
    el("specDlgT").textContent = c.dataset.path;
    fillDocDlg("specDlgBody", d);
    el("specDlg").showModal();
  };
}

// -- wiki screen (wiki-screen): docs/wiki two-pane reader. /api/wiki (the docs-tree
// subtree) builds the sidebar once; /wiki/<rel>?token= serves each page's markdown
// as text -> MD.renderInto. Relative .md cross-links (a.mdrel, no href) resolve
// CLIENT-side against the current page dir; the SERVER guard (_send_wiki) is the
// real boundary. A target that escapes the wiki degrades to a "canonical source:"
// line and is NEVER fetched through /wiki/.
let wikiCur = "";   // dir of the open page (posix, no trailing slash) -- mdrel resolution base
async function loadWiki(){
  const nav = el("wikiNav");
  let data = null;
  try { data = await jget("/api/wiki"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.pages)){
    nav.innerHTML = '<p class="jsonerr">wiki unavailable</p>'; return;
  }
  // docs-tree rows, depth-first: strip the docs/wiki/ prefix, dirs -> headers,
  // md -> clickable rows, indent by depth (top wiki level is depth 2).
  nav.innerHTML = data.pages.map(r => {
    const rel = r.path.slice("docs/wiki/".length);
    const name = rel.split("/").pop();
    const pad = "padding-left:" + (0.35 + Math.max(0, r.depth - 2) * 0.8) + "rem";
    if (r.kind === "dir") return `<div class="wikidir" style="${pad}">${esc(name)}</div>`;
    if (r.kind === "md")  return `<button class="wikipage" style="${pad}" data-rel="${esc(rel)}">${esc(name)}</button>`;
    return "";
  }).join("");
  for (const b of nav.querySelectorAll(".wikipage[data-rel]")) b.onclick = () => openWiki(b.dataset.rel);
  openWiki("index.md");   // land on the wiki home
}
async function openWiki(rel){
  const pane = el("wikiBody");
  let text = "";
  try {
    const url = "/wiki/" + rel.split("/").map(encodeURIComponent).join("/") + "?token=" + encodeURIComponent(TOKEN);
    const r = await fetch(url, {headers: H});
    if (!r.ok){ pane.textContent = "page not found: " + rel; return; }
    text = await r.text();
  } catch (e) { pane.textContent = "wiki page unavailable"; return; }
  wikiCur = rel.includes("/") ? rel.slice(0, rel.lastIndexOf("/")) : "";
  MD.renderInto(pane, text);
  for (const b of el("wikiNav").querySelectorAll(".wikipage")) b.classList.toggle("sel", b.dataset.rel === rel);
}
// Pure client-side path normalization: join an mdrel href to the current page dir,
// collapse ./ and ../ segments. Returns the docs/wiki-relative path when it stays
// INSIDE the wiki root, else null (an escape -> caller degrades). Strips #anchors.
// Not a security control -- _send_wiki's resolve+relative_to guard is the boundary.
function normWiki(dir, href){
  const hash = href.indexOf("#"); if (hash >= 0) href = href.slice(0, hash);
  if (!href) return null;
  const stack = (href[0] === "/") ? [] : (dir ? dir.split("/") : []);
  for (const p of href.split("/")){
    if (p === "" || p === ".") continue;
    if (p === ".."){ if (!stack.length) return null; stack.pop(); continue; }  // escapes above wiki root
    stack.push(p);
  }
  return stack.length ? stack.join("/") : null;
}
// ONE delegated click on the content pane: an mdrel cross-link normalizes to a wiki
// page and opens it, or degrades to a canonical-source note (never fetched via /wiki/).
el("wikiBody").addEventListener("click", e => {
  const a = e.target.closest("a.mdrel"); if (!a) return;
  e.preventDefault();
  const rel = normWiki(wikiCur, a.dataset.href || "");
  if (rel != null){ openWiki(rel); return; }
  const line = document.createElement("div"); line.className = "wikisrc";
  line.textContent = "canonical source: " + (a.dataset.href || "").replace(/^\.\//, "");
  el("wikiBody").appendChild(line);
});
el("specRefresh").onclick = () => loadSpecs();

// -- research snapshot (SPEC-135): throwaway rounds, click opens the round doc --
async function loadResearch(){
  const box = el("researchGrid");
  let data = null;
  try { data = await jget("/api/research"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.rounds)){
    box.innerHTML = '<p class="jsonerr">research snapshot unavailable</p>'; return;
  }
  if (!data.rounds.length){
    box.innerHTML = '<p class="dim">no research rounds under docs/research/</p>'; return;
  }
  box.innerHTML = '<div class="memrow">' + data.rounds.map(r => {
    const wfs = (r.linkedWfs || []).length;
    return `<div class="memcard" data-slug="${esc(r.slug)}">` +
      `<div class="memtop"><b>${esc(r.slug)}</b>` +
      `<span class="dim">${r.tracked ? "tracked" : "untracked"}</span></div>` +
      `<div class="dim mono" style="font-size:0.68rem">${esc(r.path || "")}</div>` +
      `<div class="specbadges">` +
      `<span class="dim" style="font-size:0.7rem">${wfs} workflow${wfs === 1 ? "" : "s"}</span>` +
      `<span class="dim" style="font-size:0.7rem">${r.recordsRefs} record${r.recordsRefs === 1 ? "" : "s"}</span>` +
      `</div></div>`;
  }).join("") + '</div>';
  // GUI-RS1: a card now opens the ROUND VIEW (source lanes), not the doc dialog
  // directly — the whole-doc dialog stays reachable from the round view's `open doc`.
  for (const c of box.querySelectorAll(".memcard[data-slug]"))
    c.onclick = () => openRound(c.dataset.slug);
}
el("researchRefresh").onclick = () => loadResearch();

// -- research ROUND VIEW (GUI-RS1): rounds grid -> per-round SOURCE LANES, one
// lane card per WORKER of the round's linked workflows. Counts map to NAMED real
// worker-result fields (found<-itemsAnalyzed, findings<-findings) + the reduce
// artifact (retained<-dedupedFindings); a count with no real field renders an
// honest "—", NEVER an invented number. There is NO per-worker chat/log embed
// (the one-chat-per-worker antipattern) — a card CLICK reuses the shared worker
// inspector (openWorker), no new inspector is built here.
function laneStatusPill(st){
  st = String(st || "");
  if (st === "done" || st === "succeeded") return "ok";
  if (st === "failed" || st === "blocked") return "bad";
  if (st === "partial") return "queue";
  if (["running", "queued", "pending"].includes(st)) return "run";
  return "done";
}
function laneCard(w){
  const dash = '<span class="dim" title="no per-worker field">—</span>';
  // TODO(gui-rs1): worker *.result.json has NO per-worker dedup/retained field —
  // dedup/retained are reduce-stage aggregates (reducer.result.json
  // dedupedFindings, surfaced in the convergence footer), so both dash here.
  const found = w.found != null ? String(w.found) : dash;
  const findings = w.findings != null ? w.findings : 0;
  const clk = w.workerId ? ' clickable" data-wf="' + esc(w.workflowId || "") +
              '" data-worker="' + esc(w.workerId) : "";
  return '<div class="lanecard' + clk + '">' +
    '<div class="lanerole mono">' + esc(w.workerRole || w.workerId || "worker") + '</div>' +
    '<div class="dim mono" style="font-size:0.68rem">' + esc(w.workflowId || "") + '</div>' +
    '<div class="lanestat"><span class="pill ' + laneStatusPill(w.status) + '">' +
      esc(w.status || "?") + '</span></div>' +
    '<div class="lanecounts mono">' + found + ' <span class="lanearrow">→</span> ' +
      dash + ' <span class="lanearrow">→</span> ' + dash + '</div>' +
    '<div class="specbadges"><span class="cchip">' + findings +
      ' finding' + (findings === 1 ? "" : "s") + '</span></div></div>';
}
function renderRoundView(slug, d){
  const box = el("researchGrid");
  const waves = d.waves || [];
  const q = d.question
    ? '<div class="roundq">' + esc(d.question) + '</div>'
    : '<div class="roundq dim">question: not parsed — open the doc</div>';
  const tracked = d.tracked ? '<span class="pill ok">tracked</span>'
                            : '<span class="pill done">untracked</span>';
  let lanes;
  if (!waves.length){
    lanes = '<p class="dim">no linked workflows — narrative round</p>';
  } else {
    const multi = waves.length > 1;
    lanes = waves.map(wv => {
      const cards = (wv.workers || [])
        .map(w => laneCard(Object.assign({workflowId: wv.workflowId}, w))).join("")
        || '<p class="dim">no workers</p>';
      const head = multi ? '<div class="wavehead dim mono">wave: ' + esc(wv.workflowId) + '</div>' : "";
      return head + '<div class="lanestrip">' + cards + '</div>';
    }).join("");
  }
  const allW = waves.reduce((a, wv) => a.concat(wv.workers || []), []);
  const n = allW.length;
  const m = allW.reduce((a, w) => a + (w.findings || 0), 0);
  const kv = waves.map(wv => wv.retained).filter(v => v != null);
  const k = kv.length ? kv.reduce((a, b) => a + b, 0) : null;
  const footer = waves.length
    ? '<div class="convfoot dim mono">' + n + ' worker' + (n === 1 ? "" : "s") +
      ' · ' + m + ' finding' + (m === 1 ? "" : "s") + ' · ' +
      (k != null ? k : "—") + ' retained</div>'
    : "";
  const lanesBody = lanes + footer;   // RS1's strip + convergence footer, unchanged
  box.innerHTML =
    '<div class="roundview"><div class="roundhead">' +
      '<button class="act" id="roundBack" style="height:26px">← rounds</button>' +
      '<h2 class="mono" style="margin:0 6px">' + esc(slug) + '</h2>' + tracked +
      '<button class="act" id="roundDoc" style="height:26px;margin-left:8px">open doc</button>' +
      '<button class="act" id="roundRefresh" style="height:26px;margin-left:6px" title="refresh">↻</button>' +
    '</div>' + q +
    '<div class="roundtabs">' +
      '<button class="rpillbtn on" id="tabLanes">Lanes</button>' +
      '<button class="rpillbtn" id="tabClaims" title="claim-evidence matrix: supporting vs contradicting, side by side">Claims</button>' +
      '<button class="rpillbtn" id="tabConsensus" title="calibrated consensus: the round doc framed by named real signals — no re-synthesis, no single number, dissent never hidden">Consensus</button>' +
    '</div><div id="roundBody"></div></div>';
  el("roundBack").onclick = () => loadResearch();
  el("roundRefresh").onclick = () => openRound(slug);
  el("roundDoc").onclick = async () => {
    const doc = await jget("/api/research/file?slug=" + encodeURIComponent(slug));
    el("researchDlgT").textContent = slug;
    fillDocDlg("researchDlgBody", doc);
    el("researchDlg").showModal();
  };
  // subtabs: DISPLAY toggle only, no refetch (all three read the payload `d`)
  const onlyTab = id => ["tabLanes", "tabClaims", "tabConsensus"].forEach(t =>
    el(t).classList.toggle("on", t === id));
  const showLanes = () => {
    el("roundBody").innerHTML = lanesBody;
    onlyTab("tabLanes");
    // card click reuses the SHARED worker inspector — no per-worker embed
    el("roundBody").querySelectorAll(".lanecard.clickable").forEach(c =>
      c.onclick = () => openWorker(c.dataset.wf, c.dataset.worker));
  };
  const showClaims = () => {
    el("roundBody").innerHTML = renderClaimsTable(d);
    onlyTab("tabClaims");
  };
  const showConsensus = () => {
    el("roundBody").innerHTML = renderConsensus(slug, d);
    onlyTab("tabConsensus");
    wireReportPane(slug);   // inline doc via the shared MD pipeline — no new route
  };
  el("tabLanes").onclick = showLanes;
  el("tabClaims").onclick = showClaims;
  el("tabConsensus").onclick = showConsensus;
  showLanes();
}
// GUI-RS2 confidence: DERIVED ONLY from the two named real signals — reduce
// conflicts (dissent) and replications (sourceWorkerIds len). Never a fabricated
// High: unknown/low replications degrade to Preliminary. The `why` is the tooltip
// text naming the inputs (confidence is never just a number, dissent never hidden).
function claimConfidence(nConf, reps){
  if (nConf >= 1) return {label: "Contested", cls: "bad",
    why: "confidence(conflicts, replications): " + nConf + " conflict" +
         (nConf === 1 ? "" : "s") + " referencing this claim -> Contested"};
  if (reps == null || reps < 2) return {label: "Preliminary", cls: "done",
    why: "confidence(conflicts, replications): 0 conflicts, replications " +
         (reps == null ? "unknown (sourceWorkerIds absent)" : "=" + reps + " (<2)") +
         " -> Preliminary"};
  return {label: "High", cls: "ok",
    why: "confidence(conflicts, replications): 0 conflicts, replications=" +
         reps + " (>=2) -> High"};
}
// evidence[] items -> supporting cell. A `[web]`/`[repo]`/`[judgment]` source
// prefix renders as a small chip (title=full string); no prefix -> plain text.
// The evidence text is ALWAYS shown (contradicting evidence is never hidden).
function evidenceChips(evList){
  return (evList || []).map(e => {
    const s = String(e), full = esc(s), m = s.match(/^\s*\[([a-zA-Z]+)\]\s*(.*)$/);
    return m
      ? '<span class="cchip claimtag" title="' + full + '">' + esc(m[1]) + '</span><span title="' + full + '">' + esc(m[2]) + '</span>'
      : '<span title="' + full + '">' + esc(s) + '</span>';
  }).join("<br>");
}
// GUI-RS2 Claims matrix: one row per deduped claim (fallback: raw worker findings
// union with an honest `no reduce` badge). SUPPORTING and CONTRADICTING sit in
// SEPARATE columns side by side — the contradicting cell is ALWAYS rendered
// (never collapsed behind the confidence pill). Unmatched conflicts surface in a
// footer row; nothing is hidden.
function renderClaimsTable(d){
  const waves = d.waves || [];
  const claims = waves.flatMap(w => (w.claims || []).map(c =>
    Object.assign({wf: w.workflowId, reduced: w.reduced}, c)));
  const conflicts = waves.flatMap(w => w.conflicts || []);
  if (!claims.length)
    return '<p class="dim">no claims — no reduce artifact and no worker findings for this round</p>';
  const raw = waves.some(w => (w.claims || []).length && !w.reduced);
  const badge = raw
    ? '<div style="margin-bottom:6px"><span class="pill queue" title="no reducer.result.json — rows are the raw per-worker findings union, not deduped">no reduce — raw findings</span></div>'
    : "";
  const matched = new Set();
  const rows = claims.map(c => {
    const cf = conflicts.filter(x => x.title && x.title === c.title);
    cf.forEach(x => matched.add(x.title));
    const conf = claimConfidence(cf.length, c.replications);
    // CONTRADICTING cell: ALWAYS present (dissent-visibility acceptance). The
    // pill only labels; it never gates whether the dissent renders.
    const contra = cf.length
      ? cf.map(x => (x.recommendations || []).map(r =>
          '<div class="claimx" title="' + esc(r) + '">' + esc(r) + '</div>').join("") +
          '<div class="dim" style="font-size:0.68rem">workers: ' + esc((x.workers || []).join(", ")) + '</div>'
        ).join("")
      : '<span class="dim">—</span>';
    const reps = c.replications != null ? String(c.replications)
      : '<span class="dim" title="TODO(gui-rs2): no sourceWorkerIds provenance on this claim">—</span>';
    return '<tr>' +
      '<td><div>' + esc(c.title || "(untitled)") + '</div>' +
        (c.category ? '<div class="dim" style="font-size:0.68rem">' + esc(c.category) + '</div>' : "") + '</td>' +
      '<td class="claimev">' + (evidenceChips(c.evidence) || '<span class="dim">—</span>') + '</td>' +
      '<td class="claimev">' + contra + '</td>' +
      '<td class="mono">' + reps + '</td>' +
      '<td><span class="pill ' + conf.cls + '" title="' + esc(conf.why) + '">' + conf.label + '</span></td>' +
      '</tr>';
  }).join("");
  const unmatched = conflicts.filter(x => x.title && !matched.has(x.title)).length;
  const foot = unmatched
    ? '<tr><td colspan="5" class="dim">unmatched conflicts: ' + unmatched + ' (recorded, never hidden)</td></tr>'
    : "";
  return badge + '<div class="claimswrap"><table><thead><tr>' +
    '<th>claim</th><th>supporting</th><th>contradicting</th><th>replications</th><th>confidence</th>' +
    '</tr></thead><tbody>' + rows + foot + '</tbody></table></div>';
}
// -- consensus subtab (GUI-RS3): the round doc framed by NAMED REAL SIGNALS, with
// the doc's OWN prose rendered inline below. THREE hard rules: (1) NO re-synthesis
// — every header line is a named field (d.title/d.phases, RS2 claims/conflicts,
// RS1 worker status) or an honest fallback; the prose is the doc's, via MD. (2)
// NEVER a single-number consensus — confidence is the aggregate of the SAME RS2
// per-claim pills (N High · M Contested · K Preliminary) + a formula tooltip. (3)
// dissent is NEVER hidden — every conflict renders; zero -> the honest dim line.
function consSec(label, body){
  return '<div class="conssec"><div class="conslabel">' + label + '</div>' + body + '</div>';
}
// CALIBRATED CONFIDENCE: tally of claimConfidence() — the EXACT RS2 pill function —
// over the claims. Reads ONLY its .label output (no new signal); never one number.
function consensusConfidence(claims, conflicts){
  const tally = {High: 0, Contested: 0, Preliminary: 0};
  for (const c of claims){
    const nConf = conflicts.filter(x => x.title && x.title === c.title).length;
    const lbl = claimConfidence(nConf, c.replications).label;
    if (tally[lbl] != null) tally[lbl]++;
  }
  return tally;
}
// SOURCES: the SAME evidence prefixes RS2 chips render, counted by class. The
// web/internal separation is a hard rule — [web] is flagged untrusted, [repo]
// internal; an unrecognized/absent prefix is honestly bucketed [unlabeled], never
// folded into judgment.
function consensusSources(claims){
  const b = {web: 0, repo: 0, judgment: 0, other: 0};
  for (const c of claims) for (const e of (c.evidence || [])){
    const m = String(e).match(/^\s*\[([a-zA-Z]+)\]/);
    const t = m ? m[1].toLowerCase() : "";
    if (t === "web") b.web++; else if (t === "repo") b.repo++;
    else if (t === "judgment") b.judgment++; else b.other++;
  }
  if (!(b.web + b.repo + b.judgment + b.other)) return '<div class="dim">no evidence rows parsed</div>';
  const chips = [
    '<span class="cchip" title="external/web sources — untrusted until independently verified">[web] ' + b.web + ' (untrusted until verified)</span>',
    '<span class="cchip" title="internal repo/harness sources">[repo] ' + b.repo + ' (internal)</span>',
    '<span class="cchip" title="analyst judgment — no external citation">[judgment] ' + b.judgment + '</span>'];
  if (b.other) chips.push('<span class="cchip broken" title="evidence rows with no recognized [class] prefix — class not asserted">[unlabeled] ' + b.other + '</span>');
  return '<div class="consrow">' + chips.join("") + '</div>';
}
// DISSENTING: every conflict, grouped by category (title + workers + each
// recommendation). Zero conflicts -> the honest dim line, NOT a hidden section.
function consensusDissent(conflicts){
  if (!conflicts.length) return '<div class="dim">no recorded conflicts</div>';
  const byCat = {};
  for (const c of conflicts){ const cat = c.category || "uncategorized"; (byCat[cat] = byCat[cat] || []).push(c); }
  return Object.keys(byCat).map(cat =>
    '<div class="dim mono" style="font-size:0.68rem">' + esc(cat) + '</div>' +
    byCat[cat].map(c => '<div class="consconflict"><div>' + esc(c.title || "(untitled)") + '</div>' +
      '<div class="dim" style="font-size:0.68rem">workers: ' + esc((c.workers || []).join(", ")) + '</div>' +
      (c.recommendations || []).map(r => '<div class="claimx" title="' + esc(r) + '">' + esc(r) + '</div>').join("") +
    '</div>').join("")).join("");
}
// AGENTS: worker status counts + roles, straight from the RS1 lanes data (each
// wave's workers[], reusing laneStatusPill for the status color).
function consensusAgents(workers){
  if (!workers.length) return '<div class="dim">no linked workers</div>';
  const counts = {}, roles = [];
  for (const w of workers){
    const s = w.status || "?"; counts[s] = (counts[s] || 0) + 1;
    if (w.workerRole && !roles.includes(w.workerRole)) roles.push(w.workerRole);
  }
  const pills = Object.keys(counts).map(s =>
    '<span class="pill ' + laneStatusPill(s) + '">' + esc(s) + ' ' + counts[s] + '</span>').join(" ");
  const roleLine = roles.length
    ? '<div class="dim" style="font-size:0.7rem">roles: ' + esc(roles.join(", ")) + '</div>' : "";
  return '<div class="consrow">' + pills + '</div>' + roleLine;
}
function renderConsensus(slug, d){
  const waves = d.waves || [];
  const claims = waves.flatMap(w => w.claims || []);
  const conflicts = waves.flatMap(w => w.conflicts || []);
  const workers = waves.flatMap(w => w.workers || []);
  const phases = d.phases || [];
  // POSITION: the doc's OWN parsed title + phase list, or the honest fallback —
  // NEVER a generated summary (the prose lives in the report below).
  const position = d.title
    ? '<div class="consposition">' + esc(d.title) + '</div>' +
      (phases.length ? '<div class="dim" style="font-size:0.7rem">phases parsed: ' + esc(phases.join(", ")) + '</div>' : "")
    : '<div class="dim">position: see the report below</div>';
  // CALIBRATED CONFIDENCE: the aggregate, never one number; tooltip = the formula.
  const t = consensusConfidence(claims, conflicts);
  const why = "aggregate of per-claim confidence(conflicts, replications): Contested = >=1 conflict on the claim title; High = 0 conflicts and replications>=2; else Preliminary";
  const confidence = '<div class="consrow" title="' + esc(why) + '">' +
    '<span class="pill ok">' + t.High + ' High</span><span>·</span>' +
    '<span class="pill bad">' + t.Contested + ' Contested</span><span>·</span>' +
    '<span class="pill done">' + t.Preliminary + ' Preliminary</span></div>';
  return '<div class="conscard">' +
    consSec("Position", position) +
    consSec("Calibrated confidence", confidence) +
    consSec("Sources", consensusSources(claims)) +
    consSec("Dissenting", consensusDissent(conflicts)) +
    consSec("Agents", consensusAgents(workers)) +
    consSec("Stopping rule", '<div class="dim">stopping rule: not parsed — declared in the doc below</div>') +
    '</div>' +
    '<div class="consreport"><div class="conslabel">Report — canonical source: docs/research/' + esc(slug) + '.md</div>' +
    '<div id="consensusReport" class="md">loading report…</div></div>';
}
// The report pane: the round doc rendered inline via the SHARED MD pipeline (no
// dialog). Refs follow the MD module's rules — http(s) open in a tab; a relative
// .md ref (a.mdrel) degrades to a canonical-source line, wiki precedent, NEVER
// fetched (research docs aren't wiki pages). Feeds from the existing doc route.
function wireReportPane(slug){
  const pane = el("consensusReport");
  if (!pane) return;
  pane.addEventListener("click", e => {
    const a = e.target.closest("a.mdrel"); if (!a) return;
    e.preventDefault();
    const line = document.createElement("div"); line.className = "wikisrc";
    line.textContent = "canonical source: " + (a.dataset.href || "").replace(/^\.\//, "");
    pane.appendChild(line);
  });
  jget("/api/research/file?slug=" + encodeURIComponent(slug)).then(doc => {
    pane.textContent = "";
    if (doc && doc.error){ pane.textContent = doc.error; return; }
    MD.renderInto(pane, (doc && doc.body) || "(empty)");
  }).catch(() => { pane.textContent = "report unavailable"; });
}
async function openRound(slug){
  const box = el("researchGrid");
  box.innerHTML = '<p class="dim">loading round…</p>';
  let d = null;
  // ONE fetch with claims=1 -> both subtabs render from the same payload (no refetch)
  try { d = await jget("/api/research/round?slug=" + encodeURIComponent(slug) + "&claims=1"); } catch (e) { d = null; }
  if (!d || d.error){
    box.innerHTML = '<p class="jsonerr">round unavailable</p>' +
      '<button class="act" onclick="loadResearch()">← rounds</button>';
    return;
  }
  renderRoundView(slug, d);
}

// -- research run form (GUI-RS4): the Phase-0 scaffold. It composes a STRUCTURED task
// (never raw JSON) and CREATES a round via cfgPost("research-plan") -> workflow plan
// --profile with the profile's own branches + a DECLARED width (D010). Create-only: the
// round is started deliberately on the Queue screen (workflow-start), never from here.
// The exploratory width BLOCKS submit without a justification (client mirror of the
// server _research_plan_reason gate); the justification also lands INSIDE the task packet.
function rfWidthToggle(){ el("rfWhyReq").style.display = el("rfWidth").value === "exploratory" ? "" : "none"; }
el("rfWidth").onchange = rfWidthToggle;
function rfTaskText(q, c, b, mode, why){
  return "Research round\nQuestion: " + q + "\nCriteria: " + c + "\nBudget: " + b
    + "\nWidth: " + mode + " -- justification: " + why;
}
el("rfCreate").onclick = async () => {
  const q = el("rfQuestion").value.trim(), c = el("rfCriteria").value.trim(),
        b = el("rfBudget").value.trim(), mode = el("rfWidth").value,
        why = el("rfWhy").value.trim(), profile = el("rfProfile").value, msg = el("rfMsg");
  if (!q || !c || !b){ msg.textContent = "question, success criteria and budget are required"; return; }
  if (mode === "exploratory" && !why){ msg.textContent = "width justification is required for exploratory fan-out (D010)"; return; }
  const task = rfTaskText(q, c, b, mode, why);
  msg.textContent = "creating...";
  const res = await cfgPost("research-plan", {profile, task, widthMode: mode, widthWhy: why});
  if (res.ok){
    const wfid = (String(res.output || "").match(/WF-[0-9A-Za-z_.-]+/) || [])[0] || "";
    msg.textContent = "created " + (wfid || "round") + " -- start it on the Queue screen (create-only)";
    loadResearch();
  } else {
    msg.textContent = "refused/failed: " + (res.refused || res.output || res.rc);
  }
};

// -- experiments board (SPEC-116): read-only lifecycle lanes, click opens card --
const EXP_LANE = {proposed: "Proposed", active: "Active", shipped: "Shipped", shelved: "Shelved"};
let expById = {};
async function loadExperiments(){
  const box = el("expBoard");
  let data = null;
  try { data = await jget("/api/experiments"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.experiments)){
    box.innerHTML = '<p class="jsonerr">experiments snapshot unavailable</p>'; return;
  }
  if (!data.experiments.length){
    box.innerHTML = '<p class="dim">no experiments in .harness/state/experiments.json</p>'; return;
  }
  expById = {};
  for (const e of data.experiments) expById[e.id] = e;
  const order = (data.order && data.order.length) ? data.order : ["proposed", "active", "shipped", "shelved"];
  box.innerHTML = '<div class="tlanes">' + order.map(st => {
    const group = data.experiments.filter(e => e.status === st);
    const cards = group.map(e => {
      const nms = (e.measurements || []).length, overdue = (e.overdueDays || 0) > 0;
      return `<button type="button" class="tcard expcard" data-id="${esc(e.id)}" aria-label="Open experiment ${esc(e.id)}">` +
        `<div class="expcardhead"><b class="mono">${esc(e.id)}</b></div>` +
        `<div class="ttl">${esc(e.title || e.id)}</div>` +
        `<div class="specbadges">` +
        `<span class="expbadge expmeasure">${nms} measurement${nms === 1 ? "" : "s"}</span>` +
        (e.reviewBy ? `<span class="expbadge expreview${overdue ? " overdue" : ""}" title="${overdue ? `${e.overdueDays} days past reviewBy` : "Active-card review date"}">review by ${esc(e.reviewBy.slice(0, 10))}${overdue ? ` · ${e.overdueDays}d overdue` : ""}</span>` : "") +
        `</div></button>`;
    }).join("");
    return `<div class="tlane${EXP_LANE[st] ? ` exp-${st}` : ""}"><h3><span>${esc(EXP_LANE[st] || st)}</span><span class="expcount">${group.length}</span></h3>` +
           (cards || '<p class="expempty">No cards</p>') + `</div>`;
  }).join("") + '</div>';
  for (const c of box.querySelectorAll(".tcard[data-id]")) c.onclick = () => openExperiment(c.dataset.id);
}
function expField(label, val){
  return val ? `<div class="expfld"><span class="expk">${esc(label)}</span><span>${esc(val)}</span></div>` : "";
}
// experiment card modal: refine (read-only model proposal, owner-approved
// append) → change status (activate / verdict) → start (route --task --dispatch)
let expCur = null, expProposalFile = null;
async function openExperiment(id){
  const e = expById[id]; if (!e) return;
  expCur = e; expProposalFile = null;
  const ms = (e.measurements || []).map(m =>
    `<li><span class="mono dim">${esc((m.at || "").slice(0, 16))}</span> ${esc(m.value)}${m.note ? ` — ${esc(m.note)}` : ""}</li>`).join("");
  el("expDlgT").textContent = e.id + " · " + (e.status || "");
  el("expDlgBody").innerHTML =
    `<h3 style="margin:0 0 .5rem">${esc(e.title || e.id)}</h3>` +
    expField("hypothesis", e.hypothesis) + expField("metric", e.metric) + expField("baseline", e.baseline) +
    expField("success", e.successCriteria) + expField("abandon", e.abandonCriteria) + expField("reversal", e.reversalPlan) +
    expField("source", e.source) +
    expField("reviewBy", e.reviewBy ? e.reviewBy.slice(0, 16) + ((e.overdueDays || 0) > 0 ? ` (${e.overdueDays}d overdue)` : "") : "") +
    expField("verdict", e.verdict) + expField("evidence", e.evidence) + expField("reopen", e.reopenTrigger) +
    expField("dispatched", e.dispatch && e.dispatch.pid ? `pid ${e.dispatch.pid} · ${(e.dispatch.at || "").slice(0, 16)}` : "") +
    `<div class="expfld"><span class="expk">measures</span><span>${ms ? `<ul style="margin:.2rem 0 0;padding-left:1rem">${ms}</ul>` : "(none)"}</span></div>` +
    (e.plan ? `<h3>Plan${e.planRefinedAt ? ` <span class="dim mono" style="font-size:0.7rem">refined ${esc(e.planRefinedAt.slice(0, 16))}</span>` : ""}</h3><div class="tkpre mono">${esc(e.plan)}</div>` : "");
  const settled = e.status !== "proposed" && e.status !== "active";
  el("expRefine").disabled = settled;
  el("expDispatch").disabled = settled;
  el("expStatus").disabled = settled;
  el("expStatus").textContent = e.status === "proposed" ? "Activate" : "Verdict…";
  el("expProposalWrap").style.display = "none";
  el("expProposal").textContent = ""; el("expPropFile").textContent = "";
  el("expOut").textContent = "";
  try { if (!cfg || !cfg.cards) cfg = await jget("/api/routing"); } catch (err) {}
  el("expModel").innerHTML = '<option value="">model: plan-profile default</option>' +
    (((cfg && cfg.cards) || []).map(c => `<option value="${esc(c.id)}">${esc(c.id)}${c.engine ? " (" + esc(c.engine) + ")" : ""}</option>`).join(""));
  el("expDlg").showModal();
}
el("expRefresh").onclick = () => loadExperiments();
el("expRefine").onclick = async () => {
  if (!expCur) return;
  const mid = el("expModel").value;
  const card = ((cfg && cfg.cards) || []).find(c => c.id === mid);
  if (!(await confirmModal(`Refine plan for ${expCur.id}? Runs a bounded READ-ONLY model plan run: `
    + `harness.py experiment refine ${expCur.id}${mid ? " --model " + mid : ""}`))) return;
  const b = el("expRefine"); b.disabled = true;
  el("expOut").textContent = "refining… (read-only model run — this can take a few minutes)";
  const params = {id:expCur.id, confirm:true};
  if (mid) params.model = mid;
  if (card && card.defaultReasoning) params.effort = card.defaultReasoning;
  if (card && (card.engine === "codex" || card.engine === "claude")) params.executor = card.engine;
  const res = await jpost("/api/action", {action:"experiment-refine", params});
  b.disabled = false;
  if (!res.ok){ el("expOut").textContent = "refused/failed: " + (res.refused || res.output || res.rc); return; }
  const m = (res.output || "").match(/^PROPOSAL_FILE: (\S+)$/m);
  expProposalFile = m ? m[1] : null;
  el("expProposal").textContent = (res.output || "").replace(/^PROPOSAL_FILE: \S+\s*/, "");
  el("expPropFile").textContent = expProposalFile || "";
  el("expProposalWrap").style.display = "";
  el("expOut").textContent = expProposalFile
    ? "proposal ready — review it, then Accept to append it to the plan"
    : "no proposal file in the output — see above";
};
el("expAccept").onclick = async () => {
  if (!expCur || !expProposalFile) return;
  if (!(await confirmModal(`Append the refined proposal to ${expCur.id}'s plan? `
    + `Runs: harness.py experiment plan ${expCur.id} --from-run ${expProposalFile}`))) return;
  const res = await jpost("/api/action", {action:"experiment-plan-append",
    params:{id:expCur.id, fromRun:expProposalFile, confirm:true}});
  if (!res.ok){ el("expOut").textContent = "refused/failed: " + (res.refused || res.output || res.rc); return; }
  expCur.plan = (expCur.plan ? expCur.plan + "\n\n---\n\n" : "") + el("expProposal").textContent.trim();
  el("expProposalWrap").style.display = "none"; expProposalFile = null;
  el("expOut").textContent = "plan updated (refinement link kept on the card)";
  loadExperiments();
};
el("expDiscardProp").onclick = () => {
  el("expProposalWrap").style.display = "none"; expProposalFile = null;
  el("expOut").textContent = "proposal discarded (file stays under .harness/runs/)";
};
el("expStatus").onclick = async () => {
  if (!expCur) return;
  let res;
  if (expCur.status === "proposed"){
    if (!(await confirmModal(`Activate ${expCur.id}? proposed → active, stamps a reviewBy nag (+14d). `
      + `Runs: harness.py experiment activate ${expCur.id}`))) return;
    res = await jpost("/api/action", {action:"experiment-activate", params:{id:expCur.id, confirm:true}});
  } else if (expCur.status === "active"){
    const v = await promptModal(`Verdict for ${expCur.id}? (shipped needs ≥1 measurement; `
      + `shelved needs evidence + reopen trigger)`, {options:["shipped", "shelved"]});
    if (!v) return;
    const params = {id:expCur.id, decision:v, confirm:true};
    if (v === "shelved"){
      const ev = await promptModal("Evidence the reversal ran (required to shelve):"); if (!ev) return;
      const ro = await promptModal("Reopen trigger — what would reopen this experiment:"); if (!ro) return;
      params.evidence = ev; params.reopen = ro;
    }
    res = await jpost("/api/action", {action:"experiment-verdict", params});
  } else return;
  if (!res.ok){ el("expOut").textContent = "refused/failed: " + (res.refused || res.output || res.rc); return; }
  el("expDlg").close();
  loadExperiments();
};
el("expDispatch").onclick = async () => {
  if (!expCur) return;
  // Start = a visible chat with the porteiro, not a silent detached worker (incident
  // 2026-07-17: two blind clicks double-dispatched EXP-2). The porteiro's own
  // `route --task` (no --dispatch) opens the overseer room per SPEC-146; the AFK
  // detached path survives as the CLI verb `harness.py experiment dispatch`.
  if (!(await confirmModal(`Start ${expCur.id}? Opens a chat with the porteiro carrying the start demand — `
    + `it triages and routes there (WITHHELD/REFUSED is relayed in-chat, the card stays put)`))) return;
  const line = `Run experiment ${expCur.id}: ${expCur.title || ""}`.trim()
    + ` — triage and route this experiment start; the card + approved plan are in the registry`
    + ` (harness.py experiment show ${expCur.id}).`;
  el("expDlg").close();
  switchView("panel");
  await newSession();
  el("chatin").value = line;
  await sendLine();
};

// -- graphs screen (B3): provider toolbar + metric tiles + exploration tables ----
// Read-only /api/graph snapshot. The two actions (Apply provider / Rebuild) route through
// the shared confirm -> jpost("/api/action") path; a refusal prints VERBATIM into #grStatus
// (measure-honesty: nothing on this screen is synthesized — a missing stamp shows the exact
// CLI "(pre-stamp build)" string, an absent graph shows the honest empty-state, never a fake).
async function loadGraphs(){
  el("grStatus").textContent = "";
  let d = null;
  try { d = await jget("/api/graph"); } catch (e) { d = null; }
  if (!d || d.error || !Array.isArray(d.registry)){
    el("grTiles").innerHTML = `<p class="jsonerr">graph snapshot unavailable${d && d.error ? " (" + esc(d.error) + ")" : ""}</p>`;
    el("grArtifacts").innerHTML = ""; el("grConsumption").textContent = "";
    el("grMostImported").innerHTML = el("grTopFanout").innerHTML = el("grCommunities").innerHTML = "";
    return;
  }
  el("grProviderSel").innerHTML = d.registry.map(r =>
    `<option value="${esc(r.name)}"${r.name === d.provider ? " selected" : ""}${r.available ? "" : " disabled"}>` +
    `${esc(r.name)} · ${esc(r.kind)}${r.available ? "" : " (unavailable)"}</option>`).join("");
  const m = d.metrics || {}, s = m.stats || {}, f = m.freshness || {};
  const gen = s.generatedAt || "(pre-stamp build)";   // R6: never fabricate a stamp
  const fresh = f.stale === false;
  const badge = `<span class="grbadge ${fresh ? "fresh" : "stale"}">` +
    (fresh ? "fresh" : "STALE — " + esc(f.reason || "unknown")) + `</span>`;
  const tile = (k, v) => `<div class="grtile"><div class="grk">${esc(k)}</div><div class="grv">${v}</div></div>`;
  const num = x => x != null ? esc(x) : "—";
  el("grTiles").innerHTML =
    tile("provider", esc(d.provider || "—")) +
    tile("files parsed", num(s.filesParsed)) +
    tile("edges", num(s.edges)) +
    tile("parse errors", num(s.parseErrors)) +
    tile("duration", s.durationS != null ? esc(s.durationS) + "s" : "—") +
    tile("generated at", esc(gen)) +
    tile("freshness", badge);
  const arts = m.artifacts || {};
  const arows = Object.keys(arts).map(name => {
    const a = arts[name];
    return `<tr><td class="mono">${esc(name)}</td>` +
      `<td class="grcount">${a ? esc(a.bytes) + " B" : "—"}</td>` +
      `<td class="mono dim">${a ? esc(a.mtime) : "—"}</td></tr>`;
  }).join("");
  el("grArtifacts").innerHTML =
    `<div class="grtable"><table><tr><th>artifact</th><th>bytes</th><th>modified</th></tr>${arows}</table></div>`;
  const c = m.consumption || {};
  el("grConsumption").textContent =
    `enrichment: ${c.enrichedFiles || 0} files · ${c.inputTokens || 0} in / ${c.outputTokens || 0} out tokens`;
  // exploration: the honest empty-state -> "no graph built" ONLY when graph.json is missing
  // (freshness.reason), else an em-dash (a real graph that simply has an empty table).
  const empty = f.reason === "graph.json missing" ? "no graph built — Rebuild to generate" : "—";
  const ex = d.exploration || {};
  grRenderRanked("grMostImported", ex.mostImported, "id", empty);
  grRenderRanked("grTopFanout", ex.topFanout, "id", empty);
  grRenderRanked("grCommunities", ex.communities, "name", empty);
}
function grRenderRanked(id, rows, key, empty){
  rows = rows || [];
  if (!rows.length){ el(id).innerHTML = `<p class="dim">${esc(empty)}</p>`; return; }
  el(id).innerHTML = "<table><tbody>" + rows.map(r =>
    `<tr><td class="mono">${esc(r[key])}</td><td class="grcount">${esc(r.count)}</td></tr>`).join("") + "</tbody></table>";
}
async function grAction(action, params, cmd){
  if (!(await confirmModal(`${action} — runs: harness.py ${cmd}`))) return;
  el("grStatus").textContent = "running…";
  const res = await jpost("/api/action", {action, params: {...params, confirm: true}});
  el("grStatus").textContent = res.ok ? "ok" : "refused/failed: " + (res.refused || res.output || res.rc);
  if (res.ok) loadGraphs();
}
el("grRefresh").onclick = () => loadGraphs();
el("grApply").onclick = () => {
  const name = el("grProviderSel").value;
  if (!name) return;
  grAction("graph-provider-set", {name}, "graph set " + name);
};
el("grRebuild").onclick = () => grAction("graph-rebuild", {}, "graph-build-code-ast");

// -- changelog (M5.rec): commit timeline + secret-redacted diff dialog -------
async function loadChangelog(){
  const box = el("clTable");
  const params = new URLSearchParams();
  if (el("clBranch").value) params.set("branch", el("clBranch").value);
  if (el("clQ").value.trim()) params.set("q", el("clQ").value.trim());
  if (el("clHash").value.trim()) params.set("hash", el("clHash").value.trim());
  let data = null;
  try { data = await jget("/api/commits?" + params.toString()); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.commits)){
    box.innerHTML = '<p class="jsonerr">commits unavailable</p>'; return;
  }
  const sel = el("clBranch");
  if (sel.options.length <= 1 && Array.isArray(data.branches)){
    for (const b of data.branches){
      const o = document.createElement("option"); o.value = b; o.textContent = b;
      sel.appendChild(o);
    }
  }
  if (data.error){ box.innerHTML = `<p class="jsonerr">${esc(data.error)}</p>`; return; }
  box.innerHTML = data.commits.map(c =>
    `<div class="clrow" data-sha="${esc(c.sha)}"><span class="mono dim">${esc(c.sha.slice(0, 9))}</span>` +
    `<span class="cldate dim">${esc((c.date || "").slice(0, 10))}</span>` +
    `<b>${esc(c.subject)}</b>` +
    (c.decorations ? `<span class="cldeco">${esc(c.decorations)}</span>` : "") +
    `</div>`).join("") || '<p class="dim">no commits match</p>';
  for (const row of box.querySelectorAll(".clrow"))
    row.onclick = () => openCommit(row.dataset.sha);
}
async function openCommit(sha){
  const d = await jget("/api/commit?sha=" + encodeURIComponent(sha));
  el("commitDlgT").textContent = "commit " + sha.slice(0, 12) + (d.truncated ? " (truncated)" : "");
  el("commitDlgBody").innerHTML = d.error ? esc(d.error) : colorizeDiff(d.body || "");
  el("commitDlg").showModal();
}
el("clApply").onclick = () => loadChangelog();

// -- GUI-AC3 Audit subtab: tamper-evident chain status (the REAL server-side chain
// verifier — no verification logic here) + causal parent tree. DISPLAY-toggle idiom (clone of the research
// roundtabs); Audit loads lazily on first show. Chain status is COMPUTED tri-state:
// intact / broken / unverifiable — the last is the HONEST expected state for legacy
// rows (no hash-chained critical events), never a fake integrity badge.
const clOnlyTab = id => ["clTabTimeline", "clTabAudit"].forEach(t =>
  el(t).classList.toggle("on", t === id));
el("clTabTimeline").onclick = () => {
  clOnlyTab("clTabTimeline"); el("clMain").style.display = ""; el("clAudit").style.display = "none";
};
el("clTabAudit").onclick = () => {
  clOnlyTab("clTabAudit"); el("clMain").style.display = "none"; el("clAudit").style.display = ""; loadAudit();
};
el("clAuditRefresh").onclick = () => loadAudit();
// status -> {pill class, label, why-tooltip}. unverifiable uses the muted .pill.done.
const AUDIT_STATUS = {
  intact: {cls: "ok", label: "intact",
    why: "every hash-chained critical row links to the prior — the server-side chain verifier reports ok"},
  broken: {cls: "bad", label: "broken",
    why: "the hash-chain fails to link — a critical row was edited, reordered, or removed"},
  unverifiable: {cls: "done", label: "unverifiable",
    why: "no hash-chained (critical) rows in the window — legacy/non-critical events are not tamper-evident (the honest expected state)"},
};
async function loadAudit(){
  const box = el("auditChain"), tree = el("auditTree");
  box.innerHTML = '<p class="dim">verifying…</p>'; tree.innerHTML = "";
  let d = null;
  try { d = await jget("/api/audit"); } catch (e) { d = null; }
  if (!d || !d.chain){ box.innerHTML = '<p class="jsonerr">audit unavailable</p>'; return; }
  const c = d.chain, st = AUDIT_STATUS[c.status] || AUDIT_STATUS.unverifiable, cn = d.counts || {};
  const brk = c.status === "broken"
    ? `<div class="auditbreak">first break at row ${esc(String(c.firstBreakAt))}` +
      (c.firstBreakEvent ? ` · <span class="mono">${esc(c.firstBreakEvent)}</span>` : "") +
      `<div class="dim">${esc(c.reason || "")}</div></div>` : "";
  box.innerHTML =
    `<div class="auditstat"><span class="pill ${st.cls}" title="${esc(st.why)}">chain: ${esc(st.label)}</span>` +
    `<span class="dim mono">verified ${cn.hashed || 0}/${cn.total || 0} rows · ${esc((c.checkedAt || "").slice(0, 19))}` +
    (cn.skipped ? ` · ${cn.skipped} unparseable skipped` : "") + `</span></div>` + brk;
  tree.innerHTML = renderAuditTree(d.events || []);
}
// causal parent DAG as an indented tree over the shown window. A row whose parent is
// OUTSIDE the window renders a dim 'parent outside window' stub (no synthetic root).
function renderAuditTree(events){
  if (!events.length) return '<p class="dim">no events in the log</p>';
  const byId = {}; events.forEach(e => byId[e.eventId] = e);
  const children = {}, roots = [];
  events.forEach(e => {
    if (e.parentInWindow && byId[e.parentEventId]) (children[e.parentEventId] = children[e.parentEventId] || []).push(e);
    else roots.push(e);   // no parent, or parent outside the shown window
  });
  const seen = new Set();
  const row = (e, depth) => {
    if (seen.has(e.eventId)) return "";   // cycle guard
    seen.add(e.eventId);
    const stub = (e.parentEventId && !e.parentInWindow)
      ? '<span class="dim auditout" title="parent ' + esc(e.parentEventId) + ' is outside the shown window">↑ parent outside window</span>' : "";
    const hb = e.hashed ? '<span class="pill ok" title="hash-chained critical row (tamper-evident)">chained</span>' : "";
    return `<div class="auditrow" style="margin-left:${depth * 18}px">` +
      `<span class="mono dim">${esc((e.eventId || "").slice(0, 8))}</span> ` +
      `<b>${esc(e.event || "?")}</b>${hb} ` +
      `<span class="cldate dim">${esc((e.timestamp || "").slice(0, 19))}</span> ${stub}</div>` +
      (children[e.eventId] || []).map(ch => row(ch, depth + 1)).join("");
  };
  return roots.map(r => row(r, 0)).join("") || '<p class="dim">no events</p>';
}

// -- work queue (B0): live WFs + per-worker stage chips over /api/queue ------
async function loadQueue(){
  const box = el("queueBoard");
  let data = null;
  try { data = await jget("/api/queue"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.workflows)){
    box.innerHTML = '<p class="jsonerr">queue unavailable</p>'; return;
  }
  if (!data.workflows.length){
    box.innerHTML = '<p class="dim">no active workflows</p>'; return;
  }
  box.innerHTML = data.workflows.map(wf => {
    const counts = Object.entries(wf.counts || {}).map(([s, n]) => `${s} ${n}`).join(" · ");
    const scope = wf.target ? `<span class="qscope mono">target ${esc(wf.target)}</span>` : "";
    const rows = (wf.workers || []).map(w => {
      // queue-cancel-worker (B1): pending/queued/running rows get a per-worker
      // cancel — confirm dialog, then the SAME recovery-gated workflow-cancel
      // action with workerId (server re-validates ids before any argv).
      const cancellable = ["pending", "queued", "running"].includes(w.status);
      const btn = cancellable
        ? `<button class="act danger qcancel" data-wf="${esc(wf.workflowId)}" data-worker="${esc(w.workerId)}">✕</button>` : "";
      return `<div class="qrow"><span class="qst qst-${esc(w.status)}">${esc(w.status)}</span>` +
      `<b>${esc(w.workerId)}</b> <span class="qstage">${esc(w.stage)}</span>` +
      `<span class="dim">${esc(w.unit || "")}</span>${btn}</div>`;
    }).join("");
    return `<div class="qwf"><div class="qhead"><b>${esc(wf.workflowId)}</b>` +
           `<span class="qphase">${esc(wf.phaseLabel)}</span>${scope}` +
           `<span class="dim" style="margin-left:auto">${esc(counts)}</span></div>` +
           `<div class="dim qtask">${esc(wf.task || "")}</div>${rows}</div>`;
  }).join("");
  for (const b of box.querySelectorAll(".qcancel")) b.onclick = async () => {
    const cmd = `workflow cancel ${b.dataset.wf} --worker-id ${b.dataset.worker}`;
    if (!(await confirmModal(`Cancel worker ${b.dataset.worker}? Runs: harness.py ${cmd}`))) return;
    b.disabled = true;
    const res = await jpost("/api/action", {action: "workflow-cancel",
      params: {wfid: b.dataset.wf, workerId: b.dataset.worker, confirm: true}});
    if (!res.ok) await alertModal("refused/failed: " + (res.refused || res.output || res.rc));
    loadQueue();
  };
}

// -- tasks board (A0): derived Kanban over /api/tasks; store cards open the
// task modal (notes → refine → dispatch) and carry done/delete buttons --------
const TASK_STORE_SRC = ".harness/state/tasks.json";
let taskRowById = {};   // store rows only, for the modal
async function loadTasks(){
  const box = el("tasksBoard");
  let data = null;
  try { data = await jget("/api/tasks"); } catch (e) { data = null; }
  if (!data || !Array.isArray(data.rows)) {
    box.innerHTML = '<p class="jsonerr">tasks board unavailable</p>';
    return;
  }
  taskRowById = {};
  for (const r of data.rows) if (r.source === TASK_STORE_SRC) taskRowById[r.id] = r;
  const lanes = ["backlog", "queued", "running", "review", "done"];
  const renderLanes = rows => lanes.map(lane => {
    const laneRows = rows.filter(r => r.lane === lane);
    const cards = laneRows.slice(0, 250).map(r => {
      const store = r.source === TASK_STORE_SRC;
      const btns = store && lane !== "done"
        ? `<span class="tbtns"><button class="act" data-tdone="${esc(r.id)}" title="mark done — harness.py tasks close ${esc(r.id)}">✓</button>` +
          `<button class="act danger" data-tdel="${esc(r.id)}" title="delete — harness.py tasks delete ${esc(r.id)}">×</button></span>` : "";
      const chips = (r.plan ? ' <span class="dim" title="has a plan">📋</span>' : "") +
                    (r.dispatch && r.dispatch.pid ? ' <span class="dim" title="dispatched">🚀</span>' : "");
      return `<div class="tcard"${store ? ` data-tid="${esc(r.id)}"` : ""}>${btns}` +
        `<span class="tcat tcat-${esc(r.category)}">${esc(r.category)}</span>` +
        `<b>${esc(r.id)}</b>${r.size ? ' <span class="dim">' + esc(r.size) + "</span>" : ""}${chips}` +
        `<div class="ttl">${esc(r.title)}</div></div>`;
    }).join("");
    return `<div class="tlane"><h3>${esc(lane)} <span class="dim">${laneRows.length}</span></h3>` +
           (cards || '<p class="dim">empty</p>') + "</div>";
  }).join("");
  el("tasksSummary").textContent =
    data.count + " rows · " +
    Object.entries(data.categoryCounts || {}).map(([c, n]) => c + " " + n).join(" · ");
  // SPEC-110: harness board, then one kanban group per registered target (read-only).
  const groups = Array.isArray(data.targetGroups) ? data.targetGroups : [];
  const targetSection = groups.map(g =>
    `<h3 class="tgt-head">target ${esc(g.name)} <span class="dim">${g.count} task${g.count === 1 ? "" : "s"}</span></h3>` +
    (g.count ? `<div class="tlanes">${renderLanes(g.rows)}</div>`
             : '<p class="dim">target has no tasks</p>')).join("");
  box.innerHTML = `<div class="tlanes">${renderLanes(data.rows)}</div>` + targetSection;
  box.querySelectorAll(".tcard[data-tid]").forEach(c => c.onclick = () => {
    const r = taskRowById[c.dataset.tid]; if (r) openTaskDlg(r);
  });
  const cardAct = (attr, action, verb) => box.querySelectorAll(`button[${attr}]`).forEach(b => b.onclick = async ev => {
    ev.stopPropagation();  // the card behind it opens the modal
    const id = b.getAttribute(attr);
    if (!(await confirmModal(`${verb} ${id}? Runs: harness.py tasks ${action === "task-close" ? "close" : "delete"} ${id}`))) return;
    b.disabled = true;
    const res = await jpost("/api/action", {action, params:{id, confirm:true}});
    if (!res.ok) await alertModal("refused/failed: " + (res.refused || res.output || res.rc));
    loadTasks();
  });
  cardAct("data-tdone", "task-close", "Mark done");
  cardAct("data-tdel", "task-delete", "Delete");
}

// -- task modal: notes (planner input) → refine (read-only model proposal,
// owner-approved append) → send to agent (route --task --dispatch) ----------
let tkCur = null, tkProposalFile = null;
async function openTaskDlg(r){
  tkCur = r; tkProposalFile = null;
  el("tkTitle").textContent = r.id;
  el("tkMeta").textContent = [r.title, r.category, r.size, r.priority, "lane " + r.lane,
    r.planRefinedAt ? "plan refined " + r.planRefinedAt : "",
    r.dispatch && r.dispatch.pid ? "dispatched pid " + r.dispatch.pid : ""].filter(Boolean).join(" · ");
  el("tkNotes").value = r.notes || "";
  el("tkPlan").textContent = r.plan || "(no plan yet — add notes and refine)";
  el("tkProposalWrap").style.display = "none";
  el("tkProposal").textContent = ""; el("tkPropFile").textContent = "";
  el("tkOut").textContent = "";
  try { if (!cfg || !cfg.cards) cfg = await jget("/api/routing"); } catch (e) {}
  const cards = (cfg && cfg.cards) || [];
  el("tkModel").innerHTML = '<option value="">model: plan-profile default</option>' +
    cards.map(c => `<option value="${esc(c.id)}">${esc(c.id)}${c.engine ? " (" + esc(c.engine) + ")" : ""}</option>`).join("");
  el("taskDlg").showModal();
}
el("tkSaveNotes").onclick = async () => {
  if (!tkCur) return;
  // the deliberate "Save notes" click is the confirm — a modal here would nag every save
  const res = await jpost("/api/action", {action:"task-note",
    params:{id:tkCur.id, text:el("tkNotes").value, confirm:true}});
  el("tkOut").textContent = res.ok ? "notes saved" : "refused/failed: " + (res.refused || res.output || res.rc);
  loadTasks();
};
el("tkRefine").onclick = async () => {
  if (!tkCur) return;
  const mid = el("tkModel").value;
  const card = ((cfg && cfg.cards) || []).find(c => c.id === mid);
  if (!(await confirmModal(`Refine plan for ${tkCur.id}? Runs a bounded READ-ONLY model plan run: `
    + `harness.py tasks refine ${tkCur.id}${mid ? " --model " + mid : ""}`))) return;
  const b = el("tkRefine"); b.disabled = true;
  el("tkOut").textContent = "refining… (read-only model run — this can take a few minutes)";
  const params = {id:tkCur.id, confirm:true};
  if (mid) params.model = mid;
  if (card && card.defaultReasoning) params.effort = card.defaultReasoning;
  if (card && (card.engine === "codex" || card.engine === "claude")) params.executor = card.engine;
  const res = await jpost("/api/action", {action:"task-refine", params});
  b.disabled = false;
  if (!res.ok){ el("tkOut").textContent = "refused/failed: " + (res.refused || res.output || res.rc); return; }
  const m = (res.output || "").match(/^PROPOSAL_FILE: (\S+)$/m);
  tkProposalFile = m ? m[1] : null;
  el("tkProposal").textContent = (res.output || "").replace(/^PROPOSAL_FILE: \S+\s*/, "");
  el("tkPropFile").textContent = tkProposalFile || "";
  el("tkProposalWrap").style.display = "";
  el("tkOut").textContent = tkProposalFile
    ? "proposal ready — review it, then Accept to append it to the plan"
    : "no proposal file in the output — see above";
};
el("tkAccept").onclick = async () => {
  if (!tkCur || !tkProposalFile) return;
  if (!(await confirmModal(`Append the refined proposal to ${tkCur.id}'s plan? `
    + `Runs: harness.py tasks plan ${tkCur.id} --from-run ${tkProposalFile}`))) return;
  const res = await jpost("/api/action", {action:"task-plan-append",
    params:{id:tkCur.id, fromRun:tkProposalFile, confirm:true}});
  if (!res.ok){ el("tkOut").textContent = "refused/failed: " + (res.refused || res.output || res.rc); return; }
  el("tkPlan").textContent = (tkCur.plan ? tkCur.plan + "\n\n---\n\n" : "") + el("tkProposal").textContent.trim();
  tkCur.plan = el("tkPlan").textContent;
  el("tkProposalWrap").style.display = "none"; tkProposalFile = null;
  el("tkOut").textContent = "plan updated (refinement link kept on the task)";
  loadTasks();
};
el("tkDiscardProp").onclick = () => {
  el("tkProposalWrap").style.display = "none"; tkProposalFile = null;
  el("tkOut").textContent = "proposal discarded (file stays under .harness/runs/)";
};
el("tkDispatch").onclick = async () => {
  if (!tkCur) return;
  if (!(await confirmModal(`Send ${tkCur.id} (card + plan) to an agent via the porteiro? `
    + `Runs: harness.py tasks dispatch ${tkCur.id} — route --task --dispatch guardrails apply `
    + `(a WITHHELD/REFUSED route is relayed, the task stays put)`))) return;
  const b = el("tkDispatch"); b.disabled = true;
  el("tkOut").textContent = "dispatching via the porteiro…";
  const res = await jpost("/api/action", {action:"task-dispatch", params:{id:tkCur.id, confirm:true}});
  b.disabled = false;
  el("tkOut").textContent = (res.ok ? "" : "refused/failed: ") + (res.refused || res.output || res.rc || "");
  loadTasks();
};
async function loadConfig(){
  cfg = await jget("/api/routing");
  renderCards(cfg.cards || []);
  renderKeys(cfg.configKeys || []);
  renderRouting(cfg.routing || {}, cfg.targets || []);
  activeProfileName = (cfg.routing || {}).activeProfile || "canonical";  // keep the header chip honest
  updateOnboardChip();
  loadCapabilities();  // CAP.2: read-only skills+MCP grids in the same Config view
}

// -- CAP.2 capability panels: read-only skills + MCP grids, click opens a viewer --
async function loadCapabilities(){
  let data = null;
  try { data = await jget("/api/capabilities"); } catch (e) { data = null; }
  renderSkillsGrid(data && data.skills);
  renderMcpGrid(data && data.mcp);
  loadAccessMatrix();  // GUI-RG4/RG5: Roles × Resources matrix inside the same Capabilities view
}
function refChips(refs){
  return (refs || []).map(r => `<span class="esub" title="${esc(r.ref)}">${esc(r.kind)}</span>`).join("");
}
// CAP.3: advisory-only badge on target-scoped cards whose capability is present
// on the target but NOT declared in its target.json. Surfaces the gap; enforces
// nothing (no block, no /api/action).
function undeclaredBadge(undeclared){
  return undeclared ? `<span class="esub" title="present on the target, not declared in its target.json (advisory)">undeclared</span>` : "";
}
function renderSkillsGrid(skills){
  const box = el("skillsGrid");
  if (!Array.isArray(skills)){ box.innerHTML = '<p class="jsonerr">capabilities snapshot unavailable</p>'; return; }
  if (!skills.length){ box.innerHTML = '<p class="dim">no skills declared in any scope</p>'; return; }
  const scopes = [...new Set(skills.map(s => s.scope))];
  box.innerHTML = scopes.map(scope => {
    const cards = skills.filter(s => s.scope === scope).map(s => {
      const statuses = Object.entries(s.statuses || {}).map(([v, st]) => v + "=" + st).join(" ");
      const refs = (s.referencedBy || []).length;
      return `<div class="memcard" data-id="${esc(s.id)}">` +
        `<div class="memtop"><b>${esc(s.name)}</b>` +
        `<span class="dim">${s.hasScripts ? "scripts" : ""}</span></div>` +
        `<div class="dim mono" style="font-size:0.68rem">${esc(statuses)}</div>` +
        `<div class="specbadges">${refChips(s.referencedBy)}` +
        undeclaredBadge(s.undeclared) +
        `<span class="dim" style="font-size:0.7rem">${refs} ref${refs === 1 ? "" : "s"}</span>` +
        `</div></div>`;
    }).join("");
    return `<h3 class="memscope">${esc(scope)}</h3><div class="memrow">${cards}</div>`;
  }).join("");
  for (const c of box.querySelectorAll(".memcard[data-id]")) c.onclick = async () => {
    const d = await jget("/api/capabilities/file?id=" + encodeURIComponent(c.dataset.id));
    el("capDlgT").textContent = c.dataset.id;
    fillDocDlg("capDlgBody", d);
    el("capDlg").showModal();
  };
}
function renderMcpGrid(mcp){
  const box = el("mcpGrid");
  if (!Array.isArray(mcp)){ box.innerHTML = '<p class="jsonerr">capabilities snapshot unavailable</p>'; return; }
  if (!mcp.length){  // policy empty-state: teach the grant paths before any server exists
    box.innerHTML = '<p class="dim">no MCP servers declared in any scope · access is deny-by-default per scope.</p>' +
      '<table><thead><tr><th>grant path</th><th>scope</th></tr></thead><tbody>' +
      '<tr><td class="mono">.harness/capabilities.json mcpServers{}</td><td>harness</td></tr>' +
      '<tr><td class="mono">.harness/targets/&lt;name&gt;/target.json mcp.servers</td><td>target (strict-mcp-config)</td></tr>' +
      '<tr><td class="mono">.harness/services.json mcp entries</td><td>svc-registry lifecycle</td></tr>' +
      '</tbody></table>';
    return;
  }
  const scopes = [...new Set(mcp.map(s => s.scope))];
  box.innerHTML = scopes.map(scope => {
    const cards = mcp.filter(s => s.scope === scope).map(s => {
      const env = (s.envKeys || []).join(", ");
      const cmd = Array.isArray(s.command) ? s.command.join(" ") : (s.command || s.url || "");
      return `<div class="memcard mcpcard" data-mid="${esc(s.id)}">` +
        `<div class="memtop"><b>${esc(s.name)}</b><span class="dim">${esc(s.declaredIn || "")}</span></div>` +
        `<div class="dim mono" style="font-size:0.68rem">${esc(cmd)}</div>` +
        `<div class="specbadges">${undeclaredBadge(s.undeclared)}<span class="dim" style="font-size:0.7rem">env: ${env ? esc(env) : "none"} (names only)</span></div>` +
        `</div>`;
    }).join("");
    return `<h3 class="memscope">${esc(scope)}</h3><div class="memrow">${cards}</div>`;
  }).join("");
  for (const c of box.querySelectorAll(".mcpcard")) c.onclick = () => {
    const row = mcp.find(s => s.id === c.dataset.mid);
    el("capDlgT").textContent = row.id;
    const jbox = el("capDlgBody"); jbox.textContent = "";
    const jpre = document.createElement("pre"); jpre.className = "mono"; jbox.appendChild(jpre);
    // "javascript": no json grammar is vendored; the js one parses JSON fine
    HL.highlightBlock(jpre, JSON.stringify(row, null, 2), "javascript");  // already env-masked server-side
    el("capDlg").showModal();
  };
}
// -- GUI-RG4/RG5 access matrix: Roles × Resources + role card + declared/effective --
// Measure-honesty on the client too: a null cell is rendered as `no source`, never a
// guessed state; colors are SEMANTIC (per state), never per-vendor.
let amData = null;
const AM_LEGEND = '<div class="dim" style="font-size:0.7rem;margin-top:0.5rem">'
  + 'states: <span class="amcell" data-state="allowed">allowed</span>/'
  + '<span class="amcell" data-state="denied">denied</span> (agent tools) · '
  + '<span class="amcell" data-state="scoped">scoped</span> (tokenEconomy allowlist) · '
  + '<span class="amcell" data-state="approval-required">approval-required</span> (SPEC-146 room). '
  + '<span class="amcell" data-state="temporarily-revoked">temporarily-revoked</span> / '
  + '<span class="amcell" data-state="inherited">inherited</span> / incident-override + capability '
  + 'supportState (<span class="amcell" data-state="degraded">degraded</span>/emulated/unsupported) '
  + 'surface per-role in the role card + policy pane. A cell with no named source renders '
  + '<span class="amnosrc">no source</span>. The spec’s Production column has no harness '
  + 'source — legend-only, never a rendered column.</div>';
async function loadAccessMatrix(){
  let data = null;
  try { data = await jget("/api/access-matrix"); } catch (e) { data = null; }
  renderAccessMatrix(data);
}
function amCell(cell){
  if (!cell) return '<span class="amnosrc" title="no named source field in this harness">no source</span>';
  return `<span class="amcell" data-state="${esc(cell.state)}" title="${esc(cell.source || "")}">${esc(cell.state)}</span>`;
}
function renderAccessMatrix(data){
  amData = data;
  const box = el("accessMatrix");
  const roles = data && data.roles, cols = (data && data.columns) || [];
  if (!Array.isArray(roles)){ box.innerHTML = '<p class="jsonerr">access matrix unavailable</p>'; return; }
  if (!roles.length){ box.innerHTML = '<p class="dim">no task-profile roles declared</p>'; return; }
  const head = '<tr><th>role</th>' + cols.map(c => `<th>${esc(c.label)}</th>`).join("") + '</tr>';
  const rows = roles.map((r, i) => {
    const cells = cols.map(c => `<td>${amCell((r.cells || {})[c.key])}</td>`).join("");
    return `<tr><td class="amrole" data-ri="${i}" title="${esc(r.description || "")}">${esc(r.role)}` +
      (r.risk ? ` <span class="dim">${esc(r.risk)}</span>` : "") + `</td>${cells}</tr>`;
  }).join("");
  box.innerHTML = `<table class="amtbl"><thead>${head}</thead><tbody>${rows}</tbody></table>` + AM_LEGEND;
  for (const c of box.querySelectorAll("td.amrole")) c.onclick = () => openAmRole(amData.roles[+c.dataset.ri]);
}
function amHop(h){ return h ? esc((h.card || "") + "@" + (h.executor || "") + (h.effort ? " · " + h.effort : "")) : "none"; }
function amChain(chain){
  if (!Array.isArray(chain) || !chain.length) return '<span class="dim">no chain (canonical single-attempt)</span>';
  return chain.map(lv => {
    const circ = lv.circuit && lv.circuit.state === "open"
      ? ` <span class="amcell" data-state="temporarily-revoked">circuit open</span>` : "";
    return `<span class="mono">${esc(lv.position)}: ${esc(lv.card)}${lv.effort ? "·" + esc(lv.effort) : ""}@${esc(lv.executor || "")}</span>${circ}`;
  }).join('<span class="dim"> → </span>');
}
function amList(v){
  if (!Array.isArray(v)) return '<span class="amnosrc">no source</span>';
  return v.length ? esc(v.join(", ")) : '[] <span class="dim">(none allowed)</span>';
}
function openAmRole(r){
  const c = r.card || {}, p = r.policy || {}, ev = c.evidenceContract || {}, decl = p.declared || {};
  const support = (c.supportStates || []).map(s =>
    `<span class="amcell" data-state="${esc(s.state)}">${esc(s.skill)}=${esc(s.state)} (${esc(s.vendor)})</span>`
  ).join(" ") || '<span class="dim">all native</span>';
  const evSecs = (ev.sections || []).length
    ? (ev.sections || []).map(s => `<span class="esub">${esc(s)}</span>`).join(" ")
    : '<span class="amnosrc">no source</span>';
  const divs = (p.divergences || []).map(d => {
    if (d.state === "inherited")
      return `<div><span class="amcell" data-state="inherited">inherited</span> <span class="dim">${esc(d.reason)}</span></div>`;
    return `<div><span class="amcell" data-state="${esc(d.state)}">${esc(d.state)}</span> ${esc(d.resource || "")}: ` +
      `declared <span class="mono">${esc(d.declared || "none")}</span> → effective <span class="mono">${esc(d.effective || "none")}</span>` +
      `<div class="dim">${esc(d.reason || "")}</div></div>`;
  }).join("") || '<span class="dim">declared == effective (no divergence)</span>';
  el("capDlgT").textContent = "role: " + r.role;
  el("capDlgBody").innerHTML =
    `<div class="amrolecard">` +
    `<p>${esc(r.description || "")}${r.risk ? ` <span class="dim">risk: ${esc(r.risk)}</span>` : ""}</p>` +
    `<h3>Spawn (declared)</h3><pre class="mono">${esc(JSON.stringify(c.spawn || null, null, 2))}</pre>` +
    `<h3>Tools</h3><div class="mono">${esc((c.tools || []).join(", ") || "none")}</div>` +
    `<h3>Resource allowlists <span class="dim">(SPEC-143 s2)</span></h3>` +
    `<div>skills: <span class="mono">${amList(c.allowedSkills)}</span></div>` +
    `<div>mcp: <span class="mono">${amList(c.allowedMcp)}</span></div>` +
    `<h3>Capability supportState</h3><div>${support}</div>` +
    `<h3>Fallback chain <span class="dim">(reused RG2)</span></h3><div>${amChain(c.chain)}</div>` +
    `<h3>Evidence contract <span class="dim">(pointer)</span></h3>` +
    `<div class="mono">${esc(ev.pointer || "")}${ev.present ? "" : ' <span class="amnosrc">(contract file absent)</span>'}</div>` +
    `<div>${evSecs}</div>` +
    `<h3>Policy — declared vs effective <span class="dim">(RG5)</span></h3>` +
    `<div>profile: <span class="mono">${esc(p.profile || "")}</span> · source: <span class="mono">${esc(p.source || "")}</span></div>` +
    `<div>declared primary: <span class="mono">${amHop(decl.primary)}</span>${decl.inherited ? ' <span class="amcell" data-state="inherited">inherited</span>' : ""}</div>` +
    `<div>effective primary: <span class="mono">${amHop(p.effectivePrimary)}</span></div>` +
    `<h4>Divergences</h4>${divs}` +
    `</div>`;
  el("capDlg").showModal();
}
// cfgPost: raw allowlisted action (browser confirm already given by the caller).
// cfgAction wraps it with the alert+reload flow used by the profile/target chips.
async function cfgPost(action, params){ return jpost("/api/action", {action, params: {...params, confirm: true}}); }
async function cfgAction(action, params){
  const res = await cfgPost(action, params);
  if (!res.ok) await alertModal("refused/failed: " + (res.refused || res.output || res.rc));
  await loadConfig();
  return res;
}

// -- config-keys-gui: vault key management. Presence table + a WRITE-ONLY set dialog.
// The secret value goes straight to cfgPost("keys-set") -> subprocess stdin (never argv,
// never echoed); unset confirms by the KEY NAME only (S3). Reloads after any action.
let keyName = null;
function renderKeys(keys){
  const box = el("keysBody");
  if (!Array.isArray(keys) || !keys.length){ box.innerHTML = '<p class="dim">no expected env keys</p>'; return; }
  box.innerHTML = '<table class="keystbl"><thead><tr><th>name</th><th>present</th><th>source</th>' +
    '<th>backend</th><th>last rotated</th><th></th></tr></thead><tbody>' +
    keys.map(k => `<tr><td class="mono">${esc(k.name)}</td>` +
      `<td>${k.present ? "&check;" : "&mdash;"}</td>` +
      `<td>${esc(k.source)}</td><td>${esc(k.backend || "")}</td>` +
      `<td class="mono dim">${esc(k.lastRotated || "")}</td>` +
      `<td><button class="pillbtn" data-kset="${esc(k.name)}">set&hellip;</button>` +
      (k.present ? ` <button class="pillbtn" data-kunset="${esc(k.name)}">unset</button>` : "") +
      `</td></tr>`).join("") + '</tbody></table>';
  box.querySelectorAll("button[data-kset]").forEach(b => b.onclick = () => openKeyDlg(b.dataset.kset));
  box.querySelectorAll("button[data-kunset]").forEach(b => b.onclick = () => unsetKey(b.dataset.kunset));
}
function openKeyDlg(name){
  keyName = name;
  el("keyDlgT").textContent = name;         // S3: the dialog names the KEY NAME only
  el("keyVal").value = ""; el("keyErr").textContent = "";
  el("keyDlg").showModal();
  el("keyVal").focus();
}
el("keySave").onclick = async () => {
  if (!keyName) return;
  const value = el("keyVal").value;
  if (!value){ el("keyErr").textContent = "value is required"; return; }  // client mirror of the S4 server guard
  const res = await cfgPost("keys-set", {name: keyName, value});          // value -> stdin, never argv
  el("keyVal").value = "";                                                // never linger in the DOM
  if (res.ok){ el("keyDlg").close(); await loadConfig();
    await alertModal("stored " + keyName + " in the OS vault (value not echoed)"); }
  else el("keyErr").textContent = res.refused || res.output || "refused";
};
el("keyCancel").onclick = () => { el("keyVal").value = ""; el("keyDlg").close(); };
async function unsetKey(name){
  if (!(await confirmModal(`Remove ${name} from the OS vault? Runs: keys unset ${name}`))) return;
  const res = await cfgPost("keys-unset", {name});
  if (!res.ok) await alertModal("refused/failed: " + (res.refused || res.output || res.rc));
  await loadConfig();
}
function cardIdSet(){ return new Set((cfg.cards || []).map(c => c.id)); }
function provClass(p){ return /anthropic/i.test(p||"") ? "anthropic" : /openai/i.test(p||"") ? "openai" : ""; }
function effortsFor(cardId){ const c = (cfg.cards||[]).find(x => x.id===cardId); return (c && c.reasoning) || ["low","medium","high"]; }
function specOf(e){ return e.effort ? e.card+":"+e.effort : e.card; }
function catalogFor(engine){ return (cfg.catalog || []).filter(m => m.engine === engine); }
function overseerPrimaryCard(){ const p = (((cfg.routing||{}).roles||{}).overseer||{}).primary; return (p && p.card) || null; }

// -- model-card grid: single default lives on the overseer role, not a per-card star
function renderCards(cards){
  const ovCard = overseerPrimaryCard();
  el("cardGrid").innerHTML = cards.map(c => {
    const pills = (c.reasoning || []).map(r =>
      `<span class="rpill ${r===c.defaultReasoning?'def':''}">${esc(r)}</span>`).join("");
    return `<div class="mcard" data-id="${esc(c.id)}">
      ${c.id===ovCard?'<span class="overseerbadge" title="harness default model (overseer role)">overseer</span>':''}
      <span class="mprov ${provClass(c.provider)}">${esc(c.provider||c.engine)}</span>
      <div class="mname">${esc(c.name||c.id)}</div><div class="mid mono">${esc(c.id)}</div>
      <div class="mpills">${pills}</div>
      ${c.contextWindow?`<div class="mctx">ctx ${esc(c.contextWindow)}</div>`:''}</div>`;
  }).join("") + `<div class="mcard add" id="cardAdd">+ new card</div>`;
  el("cardGrid").querySelectorAll(".mcard[data-id]").forEach(d =>   // GUI-RG1: click opens the 4-layer detail; Edit lives inside it
    d.onclick = () => openModelCard(cards.find(c => c.id === d.dataset.id)));
  el("cardAdd").onclick = () => openCard(null);
}

// -- GUI-RG1 4-layer model card: read-only detail (declared/external/measured/
// operational + role strip), fetched per-card; Edit re-opens the existing form.
let currentModelCard = null;
function mcStatLine(label, s){
  if (!s || !s.count) return "";
  const bits = [];
  if (s.median!=null) bits.push("med "+esc(s.median));
  if (s.p95!=null) bits.push("p95 "+esc(s.p95));
  return `<div class="mcstat"><span class="mcstatk">${esc(label)}:</span> ${bits.join(" · ")||"n/a"} <span class="dim">(n ${esc(s.count)})</span></div>`;
}
function mcTags(dec){
  const t = [];
  if (dec.openWeights===true) t.push("open-weights"); else if (dec.openWeights===false) t.push("closed-weights");
  if (dec.vision===true) t.push("vision");
  return t.map(x=>`<span class="mctag">${esc(x)}</span>`).join("");
}
function mcWin(w){ return w ? esc(w.from)+" → "+esc(w.to) : "no window"; }
async function openModelCard(card){
  if (!card) return;
  currentModelCard = card;
  el("mcEdit").onclick = () => { el("mcDlg").close(); openCard(currentModelCard); };
  el("mcDlgT").textContent = card.name || card.id;
  el("mcDlgBody").innerHTML = `<p class="dim">loading…</p>`;
  el("mcDlg").showModal();
  let d = null;
  try { d = await jget("/api/models/card?id="+encodeURIComponent(card.id)); } catch(e){ d = null; }
  if (!d || d.found === false){
    el("mcDlgBody").innerHTML = `<p class="dim">no card data for ${esc(card.id)}${d && d.error ? " ("+esc(d.error)+")" : ""}</p>`;
    return;
  }
  const h = d.header||{}, dec = d.declared||{}, ext = d.external||{}, meas = d.measured||{}, op = d.operational||{};
  // HEADER: the accounting badge governs every number below
  let html = `<div class="mcmeta">
    <span class="mcacct ${esc(h.accounting)}">${esc(h.accounting)}</span>
    ${d.health ? `<span class="mchealth ${d.health==="healthy"?"healthy":"open"}">${esc(d.health)}</span>` : ""}
    <span class="mprov">${esc(h.provider||h.engine||"")}</span>
    <span class="mcengine">${esc(h.engine||"")}</span>
    <span class="mid mono">${esc(h.id)}</span></div>`;
  // L1 DECLARED
  const eff = (dec.reasoning||[]).map(r=>`<span class="rpill ${r===dec.defaultReasoning?'def':''}">${esc(r)}</span>`).join("");
  html += `<div class="mcsec"><div class="mclabel">L1 · declared (vendor)</div>
    <dl class="mckv">
      <dt>id</dt><dd class="mono">${esc(dec.id)}</dd>
      <dt>context window</dt><dd>${dec.contextWindow!=null?esc(dec.contextWindow)+` <span class="dim">declared</span>`:`<span class="dim">not declared</span>`}</dd>
      <dt>reasoning</dt><dd>${eff||`<span class="dim">—</span>`}</dd>
      <dt>tags</dt><dd>${mcTags(dec)||`<span class="dim">—</span>`}</dd>
      <dt>description</dt><dd>${esc(dec.description||"")||`<span class="dim">—</span>`}</dd>
    </dl>
    ${dec.catalogNote ? `<div class="mcnote">${esc(dec.catalogNote.value)} <span class="mono dim">— ${esc(dec.catalogNote.source)}</span></div>` : ""}</div>`;
  // L2 EXTERNAL EVIDENCE (honestly sparse)
  let l2 = (ext.probes||[]).map(p=>`<div class="mcprobe">"${esc(p.text)}"${p.at?`<span class="dim">${esc(p.at)}</span>`:""}</div>`).join("");
  l2 += (ext.docLinks||[]).map(x=>`<div class="mcprobe mono dim">${esc(x.title)} → ${esc(x.path)}</div>`).join("");
  html += `<div class="mcsec"><div class="mclabel">L2 · external evidence</div>${l2||`<p class="dim">no external evidence recorded</p>`}</div>`;
  // L3 HARNESS-MEASURED (exact-id join; every stat carries its source + window)
  let l3 = "";
  const ct = meas.chatTurns;
  if (ct){
    l3 += `<div class="mcbasis ${ct.basis==="measured"?"measured":""}">chat turns · ${esc(ct.basis)}</div>`;
    l3 += mcStatLine("in tokens", ct.inTokens)+mcStatLine("out tokens", ct.outTokens)
        + mcStatLine("cost usd", ct.costUsd)+mcStatLine("duration s", ct.durationS);
    l3 += `<div class="mcprov mono">${esc(ct.source)} · ${mcWin(ct.window)}</div>`;
  }
  const dl = meas.delegations;
  if (dl){
    l3 += `<div class="mcbasis">delegations · ${esc(dl.basis)}</div>`;
    l3 += mcStatLine("est tokens", dl.estTokens)+mcStatLine("tool uses", dl.toolUses);
    const oc = Object.entries(dl.outcomes||{}).map(([k,v])=>esc(k)+" "+esc(v)).join(" · ");
    if (oc) l3 += `<div class="mcstat"><span class="mcstatk">outcomes:</span> ${oc}</div>`;
    l3 += `<div class="mcprov mono">${esc(dl.source)} · ${mcWin(dl.window)}</div>`;
  }
  if (!ct && !dl) l3 = `<p class="dim">no measured records for this card id (exact-id attribution)</p>`;
  if (meas.unattributedNote) l3 += `<div class="mcnote">${esc(meas.unattributedNote)}</div>`;
  html += `<div class="mcsec"><div class="mclabel">L3 · harness-measured</div>${l3}</div>`;
  // L4 OPERATIONAL HISTORY
  let l4 = "";
  const tr = op.trackRecord;
  l4 += `<div class="mcstat"><span class="mcstatk">track record:</span> ${tr?`kept ${esc(tr.kept)} · rejected ${esc(tr.rejected)} · reworked ${esc(tr.reworked)} · usefulRate ${esc(tr.usefulRate)} <span class="dim">(judged ${esc(tr.judged)})</span>`:`<span class="dim">no judged delegations</span>`}</div>`;
  const fell = op.fellBackTo||[];
  l4 += fell.length ? fell.map(f=>`<div class="mcfell">${esc(f.workflowId)} · ${esc(f.worker||"?")} · ${esc(f.reason||"")} <span class="dim">${esc(f.at||"")}</span></div>`).join("")
                    : `<div class="mcstat"><span class="mcstatk">fallbacks:</span> <span class="dim">no fallback events</span></div>`;
  const cir = op.circuit;
  l4 += `<div class="mcstat"><span class="mcstatk">circuit:</span> ${cir?`${esc(cir.label)} — <span class="${cir.state==="open"?"":"dim"}">${esc(cir.state)}</span>`:`<span class="dim">no engine circuit tripped</span>`}</div>`;
  (op.discoveryGates||[]).forEach(g=>{ l4 += `<div class="mcstat"><span class="mcstatk">discovery gate:</span> ${esc(g.name)} — <span class="${g.available?"":"dim"}">${g.available?"available":"closed"}</span></div>`; });
  html += `<div class="mcsec"><div class="mclabel">L4 · operational history</div>${l4}</div>`;
  // ROLES strip (routed / judged / discovery-gate — the exhaustive vocabulary)
  const rp = (d.roles||[]).map(r=>{
    if (r.kind==="routed") return `<span class="mcpill routed">routed ${esc(r.position)} ${esc(r.role)}</span>`;
    if (r.kind==="judged") return `<span class="mcpill judged">judged: ${esc(r.judged)} · usefulRate ${esc(r.usefulRate)}</span>`;
    if (r.kind==="discovery-gate") return `<span class="mcpill gate ${r.available?"":"closed"}">discovery gate: ${r.available?"available":"closed"}</span>`;
    return "";
  }).join("");
  html += `<div class="mcsec"><div class="mclabel">roles</div><div class="mcpills">${rp||`<span class="dim">no routed role, no judged history</span>`}</div></div>`;
  el("mcDlgBody").innerHTML = html;
}

// -- GUI-RG2/RG3: Fallbacks view — per-role ORDERED vertical sequence + simulate route.
// A chain is a SEQUENCE, never a free graph: primary → fallback-n → the ALWAYS-present
// human-escalation terminator. EDIT reuses the EXISTING SPEC-115 role editor (openRoleDlg)
// — there is NO second editor here. Data: /api/fallbacks (trigger/circuit/cost joins) +
// /api/routing (cfg, which openRoleDlg reads).
let fbData = null;
async function loadFallbacks(){
  const box = el("fbStacks");
  box.innerHTML = `<p class="dim">loading…</p>`;
  try { if (!cfg || !cfg.cards) cfg = await jget("/api/routing"); } catch(e){}  // openRoleDlg needs cfg
  try { fbData = await jget("/api/fallbacks"); } catch(e){ fbData = null; }
  const roles = (fbData && fbData.roles) || [];
  if (!roles.length){ box.innerHTML = `<p class="dim">no routed roles${fbData && fbData.error ? " ("+esc(fbData.error)+")" : ""}</p>`; return; }
  box.innerHTML = roles.map(fbRoleCard).join("");
  // edit chain: REUSE the existing role editor dialog (SPEC-115) — no new editor built.
  box.querySelectorAll("button[data-editrole]").forEach(b =>
    b.onclick = () => openRoleDlg(b.dataset.editrole));
}
function fbRoleCard(r){
  return `<div class="fbrole">
    <div class="fbrolehead"><h3>${esc(r.role)}</h3>
      ${r.risk?`<span class="risk ${esc(r.risk)}" style="font-size:0.7rem;text-transform:uppercase">${esc(r.risk)}</span>`:""}
      ${r.chatContext?`<span class="robadge" title="chat-context role: build_engine/midrun also walks on a construction failure">chat</span>`:""}</div>
    ${r.description?`<p class="fbroledesc">${esc(r.description)}</p>`:""}
    <div class="fbstack">${fbStack(r.levels||[])}</div>
    <div class="fbedit"><button class="act" data-editrole="${esc(r.role)}" title="edit this chain in the role editor (SPEC-115)">edit chain</button></div>
  </div>`;
}
// The vertical stack builder: each REAL level, then the human-escalation terminator is
// ALWAYS appended as the true chain end (rendered, never implied).
function fbStack(levels){
  let html = (levels||[]).map((lv,i) => (i?`<div class="fbarrow">↓</div>`:"") + fbLevel(lv)).join("");
  if (html) html += `<div class="fbarrow">↓</div>`;
  html += fbTerminator();
  return html;
}
function fbLevel(lv){
  const trig = (lv.triggers||[]).map(t=>`<code>${esc(t)}</code>`).join("");
  const chips = [];
  if (lv.circuit) chips.push(`<span class="mchealth ${lv.circuit.state==="open"?"open":"healthy"}" title="${esc(lv.circuit.label)}">circuit ${esc(lv.circuit.state||"?")}</span>`);
  if (lv.health) chips.push(`<span class="mchealth ${lv.health==="healthy"?"healthy":"open"}" title="RG1 card health">${esc(lv.health)}</span>`);
  const cost = [];  // dim mono ONLY where the RG1 measured stats have data (exact join)
  if (lv.cost) cost.push(`cost med $${esc(lv.cost.median)} (n ${esc(lv.cost.count)})`);
  if (lv.latency) cost.push(`lat med ${esc(lv.latency.median)}s (n ${esc(lv.latency.count)})`);
  return `<div class="fblevel ${lv.position==="primary"?"primary":""}">
    <div class="fblevelhead">
      <span class="fbpos">${esc(lv.position)}</span>
      <span class="fbcard mono">${esc(lv.card)}${lv.effort?" · "+esc(lv.effort):""}</span>
      <span class="fbexec">${esc(lv.executor||"?")}</span>
      ${lv.engine && lv.engine!==lv.executor?`<span class="mcengine">${esc(lv.engine)}</span>`:""}
    </div>
    <div class="fbtrig"><span class="fbtrigk">on</span>${trig||`<span class="dim">no classified triggers</span>`}</div>
    ${(chips.length||cost.length)?`<div class="fbmeta">${chips.join("")}${cost.length?`<span class="fbcost">${cost.join(" · ")}</span>`:""}</div>`:""}
  </div>`;
}
// human-escalation terminator: the STATIC chain end (SPEC-165 exhaustion / the chat
// operator's /model, /config). ALWAYS present — it IS the real end of every chain.
function fbTerminator(){
  return `<div class="fblevel term">
    <div class="fblevelhead"><span class="fbpos">human escalation</span>
      <span class="fbcard">operator</span></div>
    <div class="fbtrig"><span class="fbtrigk">on</span>chain exhausted → <code>/model</code> <code>/config</code></div>
  </div>`;
}
// RG3 simulate: the READ-ONLY, non-spawning classify (route-triage). The result renders
// ONLY the classifier's own output (floor line + handles, surfaced VERBATIM) + the router
// chain from fbData — never a fabricated explanation of the decision.
async function fbSimulate(){
  const demand = (el("fbDemand").value||"").trim();
  const hints = (el("fbHints").value||"").trim();
  const full = (demand + (hints?" "+hints:"")).trim();
  el("fbSimStatus").textContent = "";
  el("fbSimOut").innerHTML = "";
  if (!full){ el("fbSimStatus").textContent = "enter a demand"; return; }
  el("fbSimStatus").textContent = "classifying…";
  const res = await jpost("/api/action", {action:"route-triage", params:{demand: full}});
  el("fbSimStatus").textContent = "";
  if (!res || !res.ok){ el("fbSimOut").innerHTML = `<p class="jsonerr">${esc((res&&(res.refused||res.output))||"failed")}</p>`; return; }
  fbRenderSim(res.output||"");
}
function fbRenderSim(out){
  const floor = (/^deterministic floor:.*$/m.exec(out)||[])[0] || "";
  const handles = (/^covered-doc handles:.*$/m.exec(out)||[])[0] || "";
  const router = ((fbData&&fbData.roles)||[]).find(r => r.role === "router");
  let html = "";
  if (floor) html += `<div class="mcstat"><span class="mcstatk">classified floor:</span> <span class="mono">${esc(floor.replace(/^deterministic floor:\s*/,""))}</span></div>`;
  if (handles) html += `<div class="mcstat"><span class="mcstatk">covered-doc handles:</span> <span class="mono">${esc(handles.replace(/^covered-doc handles:\s*/,""))}</span></div>`;
  html += `<div class="mclabel" style="margin-top:0.5rem">router chain — the answer role walks this</div>`;
  html += router ? `<div class="fbstack">${fbStack(router.levels||[])}</div>`
                 : `<p class="dim">no <span class="mono">router</span> role in routing (the SPEC-144 classify path uses the front-desk router when configured)</p>`;
  html += `<div class="mclabel" style="margin-top:0.5rem">classifier output — route &lt;demand&gt; --triage-prompt</div>`;
  html += `<div class="fbsimraw">${esc(out)}</div>`;
  el("fbSimOut").innerHTML = html;
}
el("fbRefresh").onclick = () => loadFallbacks();
el("fbSimBtn").onclick = fbSimulate;

// -- card form (SPEC-111 R17): enumerable fields are selectors, catalog auto-fills
let editingCard = null, cardReasoning = [];
function engineList(){
  return [...new Set([...(cfg.catalog||[]).map(m=>m.engine), ...(cfg.cards||[]).map(c=>c.engine), "openai"])];
}
function renderReasoningPills(){
  el("cReasoningPills").innerHTML = KNOWN_EFFORTS.map(lvl =>
    `<button type="button" class="rpillbtn ${cardReasoning.includes(lvl)?'on':''}" data-lvl="${lvl}">${lvl}</button>`).join("");
  el("cReasoningPills").querySelectorAll(".rpillbtn").forEach(b => b.onclick = () => {
    const lvl = b.dataset.lvl;
    cardReasoning = cardReasoning.includes(lvl) ? cardReasoning.filter(x=>x!==lvl) : [...cardReasoning, lvl];
    cardReasoning = KNOWN_EFFORTS.filter(x => cardReasoning.includes(x));  // keep ladder order
    renderReasoningPills(); syncDefReason(el("cDefReason").value);
  });
}
function syncDefReason(cur){
  const levels = cardReasoning.length ? cardReasoning : KNOWN_EFFORTS;
  el("cDefReason").innerHTML = `<option value="">(none)</option>` +
    levels.map(l => `<option value="${esc(l)}" ${l===cur?'selected':''}>${esc(l)}</option>`).join("");
}
function applyCatalogAutofill(m){
  el("cName").value = m.name||""; el("cProvider").value = m.provider||"";
  cardReasoning = [...(m.reasoning||[])]; renderReasoningPills(); syncDefReason(m.defaultReasoning||"");
  el("cCtx").value = ""; el("cCtx").placeholder = m.contextWindow ? String(m.contextWindow) : "";
  el("cCtx").title = m.note || (m.contextWindow ? "catalog: "+m.contextWindow+" tokens" : "");
}
function populateModelSel(engine, currentId){
  const cat = catalogFor(engine);
  const inCat = currentId && cat.some(m => m.id===currentId);
  el("cModelSel").innerHTML = cat.map(m =>
      `<option value="${esc(m.id)}" ${m.id===currentId?'selected':''}>${esc(m.name||m.id)} (${esc(m.id)})</option>`).join("") +
    `<option value="__custom__" ${currentId && !inCat ? 'selected':''}>custom…</option>`;
  el("cModelSel").disabled = !!editingCard;
  const custom = !!currentId && !inCat;
  el("cIdCustomWrap").style.display = custom ? "" : "none";
  if (custom){ el("cId").value = currentId; el("cId").disabled = !!editingCard; }
}
el("cModelSel").onchange = () => {
  const v = el("cModelSel").value, custom = v === "__custom__";
  el("cIdCustomWrap").style.display = custom ? "" : "none";
  if (custom){ el("cId").value = ""; el("cId").disabled = false; }
  else { const m = catalogFor(el("cEngine").value).find(x => x.id===v); if (m) applyCatalogAutofill(m); }
};
el("cEngine").onchange = () => { if (!editingCard) populateModelSel(el("cEngine").value, null); };
function openCard(c){
  editingCard = c || null;
  el("cardDlgT").textContent = c ? "Edit card" : "New card";
  const engines = engineList(), eng = c ? c.engine : engines[0];
  el("cEngine").innerHTML = engines.map(e => `<option ${e===eng?'selected':''}>${esc(e)}</option>`).join("");
  el("cEngine").disabled = !!c;
  populateModelSel(eng, c ? c.id : (catalogFor(eng)[0]||{}).id || null);
  if (c){
    el("cName").value = c.name||""; el("cProvider").value = c.provider||"";
    cardReasoning = [...(c.reasoning||[])]; el("cCtx").value = c.contextWindow||""; el("cCtx").placeholder = "";
    renderReasoningPills(); syncDefReason(c.defaultReasoning||"");
  } else {
    const m = catalogFor(eng)[0];
    if (m) applyCatalogAutofill(m); else { cardReasoning = []; renderReasoningPills(); syncDefReason(""); el("cCtx").value=""; }
  }
  el("cardDel").style.display = c ? "" : "none";
  el("cardErr").textContent = "";
  el("cardDlg").showModal();
}
el("cardSave").onclick = async () => {
  const engine = el("cEngine").value.trim();
  const custom = el("cModelSel").value === "__custom__";
  const id = editingCard ? editingCard.id : (custom ? el("cId").value.trim() : el("cModelSel").value);
  const defReason = el("cDefReason").value;
  if (!id){ el("cardErr").textContent = "id is required"; return; }        // client-side mirror of the server guard
  if (!engine){ el("cardErr").textContent = "engine is required"; return; }
  if (defReason && cardReasoning.length && !cardReasoning.includes(defReason)){
    el("cardErr").textContent = "defaultReasoning must be one of the selected reasoning levels"; return; }
  if (!(await confirmModal(`${editingCard?'Update':'Add'} the card "${id}"? Runs: models ${editingCard?'set':'add'}`))) return;
  const p = {id, engine, name: el("cName").value.trim(), provider: el("cProvider").value.trim(),
    reasoning: cardReasoning, defaultReasoning: defReason,
    contextWindow: el("cCtx").value ? Number(el("cCtx").value) : null};
  const res = await cfgPost(editingCard ? "models-set" : "models-add", p);
  if (res.ok){ el("cardDlg").close(); await loadConfig(); } else el("cardErr").textContent = res.refused || res.output || "";
};
el("cardDel").onclick = async () => {
  if (!editingCard) return;
  if (!(await confirmModal(`Delete card ${editingCard.id}? (the server refuses if it is referenced)`))) return;
  const res = await cfgPost("models-remove", {id: editingCard.id});
  if (res.ok){ el("cardDlg").close(); await loadConfig(); } else el("cardErr").textContent = res.refused || res.output || "";
};

// -- routing matrix: read-only summary rows; the whole row opens the role editor
function renderRouting(routing, targets){
  const ids = cardIdSet();
  const active = routing.activeProfile || "canonical";
  const editable = active !== "canonical";
  const opts = ["canonical", ...(routing.profiles||[])].map(n =>
    `<option value="${esc(n)}" ${n===active?'selected':''}>${esc(n)}</option>`).join("");
  el("profileBar").innerHTML =
    `<span class="activepill">${esc(active)}</span>` +
    (editable ? "" : `<span class="robadge">derived · read-only (edit a role to fork)</span>`) +
    `<select id="profSel">${opts}</select>` +
    `<button class="pillbtn" id="profSaveAs">save as…</button>` +
    `<button class="pillbtn" id="profRestore">restore canonical</button>`;
  el("profSel").onchange = () => cfgAction("routing-profile-use", {name: el("profSel").value});
  el("profSaveAs").onclick = async () => { const n = await promptModal("name of the new profile (copies the current resolution):");
    if (n) cfgAction("routing-profile-save", {name: n}).then(() => cfgAction("routing-profile-use", {name: n})); };
  el("profRestore").onclick = () => cfgAction("routing-restore-canonical", {});
  const per = routing.perTarget || {};
  el("targetChips").innerHTML = targets.length ? targets.map(t =>   // R33: t = {name, root}
    `<span class="cchip" title="${esc(t.root)}">${esc(t.name)} → ${esc(per[t.name]||"(canonical)")}
       <button data-t="${esc(t.name)}" data-act="assign" title="assign profile">✎</button>
       ${per[t.name]?`<button data-t="${esc(t.name)}" data-act="clear" title="clear">×</button>`:''}</span>`).join("")
    : '<span class="robadge">no target registered</span>';
  el("targetChips").querySelectorAll("button[data-t]").forEach(b => b.onclick = async () => {
    if (b.dataset.act === "clear") return cfgAction("routing-target-clear", {target: b.dataset.t});
    const pf = await promptModal(`profile for target ${b.dataset.t}:`, {value: per[b.dataset.t]||active});
    if (pf) cfgAction("routing-target-assign", {target: b.dataset.t, profile: pf});
  });
  const roles = routing.roles || {};
  el("routeMatrix").innerHTML = Object.keys(roles).map(role => {
    const r = roles[role];
    const chain = [r.primary, ...(r.fallbacks||[])].filter(Boolean);
    const chips = chain.length ? chain.map((e,i) => (i?'<span class="arrow">→</span>':'') +
      `<span class="cchip ${i?'':'primary'} ${e.card && !ids.has(e.card)?'broken':''}">${esc(e.card+(e.effort?'·'+e.effort:''))}</span>`
    ).join("") : '<span class="robadge">—</span>';
    const diet = r.contextDiet ? `<span class="robadge" title="context diet (SPEC-118)">✂ ${
      [r.contextDiet.vendorUserLayer===false?"user-layer":"",
       r.contextDiet.canonicalReinject===false?"pack":"",
       Array.isArray(r.contextDiet.keepTools)?"tools:"+(r.contextDiet.keepTools.join(",")||"none"):""]
      .filter(Boolean).map(esc).join(" · ")}</span>` : "";
    return `<div class="mrow" data-role="${esc(role)}" tabindex="0" role="button" aria-label="edit routing for ${esc(role)}">
      <div class="mrole">${esc(role)}<span class="risk ${esc(r.risk||'')}">${esc(r.risk||'')}</span></div>
      <div class="chain">${chips}${diet}</div><span class="edithint">edit ✎</span></div>`;
  }).join("") || '<p class="dim">no roles</p>';
  el("routeMatrix").querySelectorAll(".mrow[data-role]").forEach(d => {
    d.onclick = () => openRoleDlg(d.dataset.role);
    d.onkeydown = e => { if (e.key==="Enter"||e.key===" "){ e.preventDefault(); openRoleDlg(d.dataset.role); } };
  });
}

// -- role editor dialog: ordered primary+fallback chain; canonical forks on save
let roleState = null;
function cardOptgroups(sel){
  const byEngine = {};
  (cfg.cards||[]).forEach(c => { (byEngine[c.engine] = byEngine[c.engine]||[]).push(c); });
  return Object.keys(byEngine).map(eng => `<optgroup label="${esc(eng)}">` +
    byEngine[eng].map(c => `<option value="${esc(c.id)}" ${c.id===sel?'selected':''}>${esc(c.name||c.id)} (${esc(c.id)})</option>`).join("") +
    `</optgroup>`).join("");
}
// SPEC-118 capability names — keep in sync with context_diet.CLAUDE_CAPABILITY_TOOLS
const DIET_CAPS = ["exec","todo","read","edit","web","agents","skills","plan"];
function renderDietBox(diet){
  const d = diet || {};
  el("dietUser").checked = d.vendorUserLayer === false;
  el("dietPack").checked = d.canonicalReinject === false;
  const trim = Array.isArray(d.keepTools);
  el("dietTrim").checked = trim;
  el("dietCaps").innerHTML = DIET_CAPS.map(c =>
    `<label style="margin-right:0.6rem"><input type="checkbox" class="dietcap" value="${c}"
      ${(!trim || d.keepTools.includes(c))?'checked':''} ${trim?'':'disabled'}> ${c}</label>`).join("");
  el("dietTrim").onchange = () => {
    const on = el("dietTrim").checked;
    document.querySelectorAll(".dietcap").forEach(x => { x.disabled = !on; });
  };
}
function dietParams(diet0){
  const user = el("dietUser").checked, pack = el("dietPack").checked, trim = el("dietTrim").checked;
  const kept = [...document.querySelectorAll(".dietcap:checked")].map(x => x.value);
  if (!user && !pack && !trim) return diet0 ? {clear: true} : null;  // no cuts: clear or skip
  return {userLayer: user?"off":"on", reinject: pack?"off":"on",
          keep: trim ? kept.join(",") : "off"};
}
function openRoleDlg(role){
  const r = ((cfg.routing||{}).roles||{})[role] || {};
  const chain = [r.primary, ...(r.fallbacks||[])].filter(Boolean).map(e => ({card: e.card, effort: e.effort||""}));
  if (!chain.length) chain.push({card: (cfg.cards[0]||{}).id||"", effort: ""});
  roleState = {role, chain, diet0: r.contextDiet || null};
  renderDietBox(r.contextDiet);
  el("roleDlgT").innerHTML = esc(role) + (r.risk?`<span class="rolerisk risk ${esc(r.risk)}">${esc(r.risk)}</span>`:"");
  el("roleDesc").textContent = r.description || "";
  const forking = (cfg.routing.activeProfile || "canonical") === "canonical";
  el("roleFork").style.display = forking ? "" : "none";
  if (forking) el("roleForkName").value = "custom";
  el("roleProfLabel").textContent = forking ? "" : "active profile: " + cfg.routing.activeProfile;
  el("roleErr").textContent = "";
  renderRoleChain();
  el("roleDlg").showModal();
}
function renderRoleChain(){
  const box = el("roleChain");
  box.innerHTML = roleState.chain.map((e,i) => {
    const label = i===0 ? "primary" : "fallback "+i;
    const efforts = effortsFor(e.card);
    return `<div class="rentry" data-i="${i}"><span class="rlabel">${label}</span>
      <select class="rcard" data-i="${i}">${cardOptgroups(e.card)}</select>
      <select class="reff" data-i="${i}">${["", ...efforts].map(x =>
        `<option value="${esc(x)}" ${x===e.effort?'selected':''}>${x?esc(x):'(default)'}</option>`).join("")}</select>
      <button class="ebtn" data-act="up" data-i="${i}" ${i===0?'disabled':''}>↑</button>
      <button class="ebtn" data-act="down" data-i="${i}" ${i===roleState.chain.length-1?'disabled':''}>↓</button>
      <button class="ebtn" data-act="rm" data-i="${i}" ${roleState.chain.length===1?'disabled':''}>×</button></div>`;
  }).join("") + `<button class="pillbtn" id="roleAdd" style="margin-top:0.4rem">+ add model</button>`;
  box.querySelectorAll(".rcard").forEach(s => s.onchange = () => {
    const i = Number(s.dataset.i); roleState.chain[i] = {card: s.value, effort: ""}; renderRoleChain();
  });
  box.querySelectorAll(".reff").forEach(s => s.onchange = () => { roleState.chain[Number(s.dataset.i)].effort = s.value; });
  box.querySelectorAll(".ebtn").forEach(b => b.onclick = () => {
    const i = Number(b.dataset.i), a = b.dataset.act, ch = roleState.chain;
    if (a==="rm") ch.splice(i,1);
    else if (a==="up" && i>0) [ch[i-1],ch[i]]=[ch[i],ch[i-1]];
    else if (a==="down" && i<ch.length-1) [ch[i+1],ch[i]]=[ch[i],ch[i+1]];
    renderRoleChain();
  });
  el("roleAdd").onclick = () => { roleState.chain.push({card:(cfg.cards[0]||{}).id||"", effort:""}); renderRoleChain(); };
}
el("roleSave").onclick = async () => {
  const chain = roleState.chain.filter(e => e.card);
  if (!chain.length){ el("roleErr").textContent = "add at least the primary model"; return; }
  const role = roleState.role, primary = specOf(chain[0]), fallbacks = chain.slice(1).map(specOf);
  const active = cfg.routing.activeProfile || "canonical";
  let res;
  const dp = dietParams(roleState.diet0);  // null = diet untouched-and-absent
  if (active === "canonical"){
    const name = el("roleForkName").value.trim() || "custom";
    if (!(await confirmModal(`The canonical profile is read-only. Create the profile "${name}" and activate it?\n\n`
        + `Runs: routing profile save ${name} → set-role ${role}${dp?" → routing diet":""} → profile use ${name}`))) return;
    res = await cfgPost("routing-profile-save", {name});
    if (res.ok) res = await cfgPost("routing-set-role", {profile: name, role, primary, fallbacks});
    if (res.ok && dp) res = await cfgPost("routing-diet", {profile: name, role, ...dp});
    if (res.ok) res = await cfgPost("routing-profile-use", {name});
  } else {
    if (!(await confirmModal(`Save role "${role}" in profile "${active}"? Runs: routing set-role${dp?" + routing diet":""}`))) return;
    res = await cfgPost("routing-set-role", {profile: active, role, primary, fallbacks});
    if (res.ok && dp) res = await cfgPost("routing-diet", {profile: active, role, ...dp});
  }
  if (res.ok){ el("roleDlg").close(); await loadConfig(); } else el("roleErr").textContent = res.refused || res.output || "failed";
};

// -- advanced JSON: a meaningful template (the expanded canonical resolution) when empty
function routingTemplate(){
  const roles = {};
  Object.keys((cfg.routing||{}).roles||{}).forEach(role => {
    const r = cfg.routing.roles[role];
    roles[role] = {primary: r.primary || null, fallbacks: r.fallbacks || []};
  });
  return {schemaVersion: 1, activeProfile: "example", profiles: {example: {roles}}, perTarget: {}};
}
el("advCardsBtn").onclick = () => { el("advCardsTa").value = JSON.stringify(cfg?cfg.cardsRaw:{}, null, 2);
  el("advCardsErr").textContent = ""; el("advCards").showModal(); };
el("advRoutingBtn").onclick = () => {
  const hasProfiles = cfg && (cfg.routing.profiles||[]).length;
  el("advRoutingTa").value = JSON.stringify(hasProfiles ? cfg.routingRaw : routingTemplate(), null, 2);
  el("advRoutingErr").textContent = ""; el("advRouting").showModal();
};
el("advCardsApply").onclick = async () => {
  let doc; try { doc = JSON.parse(el("advCardsTa").value); } catch(e){ el("advCardsErr").textContent = "Invalid JSON: "+e.message; return; }
  const res = await cfgAction("models-replace", {json: JSON.stringify(doc)});
  if (res.ok) el("advCards").close(); else el("advCardsErr").textContent = res.refused || res.output || "";
};
el("advRoutingApply").onclick = async () => {
  let doc; try { doc = JSON.parse(el("advRoutingTa").value); } catch(e){ el("advRoutingErr").textContent = "Invalid JSON: "+e.message; return; }
  const res = await cfgAction("routing-replace", {json: JSON.stringify(doc)});
  if (res.ok) el("advRouting").close(); else el("advRoutingErr").textContent = res.refused || res.output || "";
};

// -- SPEC-114 R30: onboarding dialog (repo + routing profile) + header chip ----
// localStorage flag = pure UI state (like the column widths), not harness state.
const REPO = "__HARNESS_REPO__", ROOT_PATH = __HARNESS_ROOT__, LS_ONB = "harness.panel.onboarded";
let curTarget = null, activeProfileName = "canonical", obPer = {};
function updateOnboardChip(){
  el("onboardChip").textContent = "📁 " + (curTarget || REPO) + " · profile " + activeProfileName;
}
// R34: options show the NAME only — full paths in the <option> text blew up the
// select width. The path lives in the title tooltip and the #obRepoPath caption below.
function repoOptions(targets, active){
  return `<option value="" title="${esc(ROOT_PATH)}">this repo (${esc(REPO)})</option>` +
    (targets || []).map(t => `<option value="${esc(t.name)}" ${t.name===active?'selected':''}` +
      ` title="${esc(t.root)}">${esc(t.name)}</option>`).join("");
}
// R34/R35: caption shows the selected repo's full path (covers "este repo"); and,
// per the last-used-per-repo policy, the profile select auto-syncs to what this
// repo remembers (perTarget[t], else the active profile). Replaces the bind checkbox.
function obSyncRepo(){
  const t = el("obRepo").value, opt = el("obRepo").selectedOptions[0];
  el("obRepoPath").textContent = opt ? (opt.title || "") : "";   // .title is the raw path (browser un-escapes)
  const remembered = (t && obPer[t]) ? obPer[t] : activeProfileName;
  if ([...el("obProfile").options].some(o => o.value === remembered)) el("obProfile").value = remembered;
  el("obRememberInfo").textContent = (t && obPer[t]) ? `this repo remembers profile ${obPer[t]}` : "";
}
// R32: re-fetch targets after registering one, repopulate the select, select the new
// target, and re-run obSyncRepo so the path caption + remembered profile follow it.
async function refreshTargets(selectName){
  const r = await jget("/api/routing");
  obPer = (r.routing || {}).perTarget || {};
  el("obRepo").innerHTML = repoOptions(r.targets, selectName || r.activeTarget || "");
  obSyncRepo();
}
async function openOnboard(){
  const r = await jget("/api/routing"), rt = r.routing || {};
  activeProfileName = rt.activeProfile || "canonical";
  obPer = rt.perTarget || {};
  const active = r.activeTarget || "";
  el("obRepo").innerHTML = repoOptions(r.targets, active);
  el("obProfile").innerHTML = ["canonical", ...(rt.profiles || [])].map(p =>
    `<option value="${esc(p)}" ${p===activeProfileName?'selected':''}>${esc(p)}${p===activeProfileName?' (active)':''}</option>`).join("");
  el("obErr").textContent = ""; el("obAddArea").style.display = "none";
  obSyncRepo(); updateOnboardChip();
  el("onboardDlg").showModal();
}
el("onboardChip").onclick = openOnboard;
el("obRepo").onchange = obSyncRepo;
// R32: OS-native folder picker (server opens the dialog) → inline register-target area.
el("obBrowse").onclick = async () => {
  const res = await jpost("/api/pick-folder", {});
  const p = res && res.path;
  if (!p) return;                                     // cancel / headless — no-op
  el("obAddPath").value = p;
  el("obAddName").value = p.replace(/[\\/]+$/, "").split(/[\\/]/).pop() || "";
  el("obAddErr").textContent = ""; el("obAddArea").style.display = "";
};
el("obAddCancel").onclick = () => { el("obAddArea").style.display = "none"; };
el("obAddDo").onclick = async () => {
  const name = el("obAddName").value.trim(), pth = el("obAddPath").value;
  if (!name){ el("obAddErr").textContent = "name required"; return; }
  const res = await cfgPost("targets-add", {name, path: pth});   // mutating → confirm:true
  if (!res.ok){ el("obAddErr").textContent = res.refused || res.output || "failed to register"; return; }
  el("obAddArea").style.display = "none";
  await refreshTargets(name);                          // reload list + select the new target
};
el("obSkip").onclick = () => { localStorage.setItem(LS_ONB, "1"); el("onboardDlg").close(); };
el("obStart").onclick = async () => {
  const desired = el("obRepo").value, pf = el("obProfile").value;
  const r = await jget("/api/routing"), cur = r.activeTarget || "", curPf = (r.routing||{}).activeProfile || "canonical";
  el("obErr").textContent = "";
  const repoChanged = desired !== cur, profileChanged = pf !== curPf;
  // repo: `/repo <name>` switches; `/repo .` clears back to this repo (R28 piped unlock)
  if (repoChanged) await jpost("/api/chat/send", {session: curSession, line: desired ? "/repo " + desired : "/repo ."});
  if (profileChanged){ const res = await cfgAction("routing-profile-use", {name: pf});
    if (!res.ok){ el("obErr").textContent = res.refused || res.output || "failed to switch profile"; return; } }
  // R35 last-used-per-repo: remember P for this repo (non-canonical assigns; canonical
  // clears any stale binding). No target selected → nothing to remember.
  if (desired){
    const res = pf !== "canonical"
      ? await cfgAction("routing-target-assign", {target: desired, profile: pf})
      : await cfgAction("routing-target-clear", {target: desired});
    if (!res.ok){ el("obErr").textContent = res.refused || res.output || "failed to remember the profile"; return; } }
  // R38: a profile-only change has no live REPL signal — `/repo` covers the repo case
  // live (Fix A / R37), but a profile switch alone needs a fresh session to resolve the
  // new overseer, so restart this session (overseer default engine). Repo switch re-resolved.
  if (profileChanged && !repoChanged) await jpost("/api/chat/restart", {session: curSession});
  activeProfileName = pf; curTarget = desired || null;
  localStorage.setItem(LS_ONB, "1"); el("onboardDlg").close(); updateOnboardChip();
};
async function initOnboard(){
  try {
    const r = await jget("/api/routing");
    cfg = r;
    activeProfileName = (r.routing||{}).activeProfile || "canonical";
  } catch(e){}
  updateOnboardChip();
  if (!localStorage.getItem(LS_ONB)) openOnboard();   // first-run: auto-open
}

// -- N2 flow composer: derived SVG DAG + branch forms + validate-only compile ----
// The DAG is recomputed from the CURRENT form state on every edit (dagFor over
// currentView) — no stored coordinates, so the view can never drift. "Compile" POSTs
// to /api/compile, which runs `workflow plan --validate-only` server-side and writes
// nothing. There is NO apply/materialize action here — that stays out of scope (N2).
let composer = null;   // last /api/composer snapshot
let cmState = null;    // {profile, task, executor, branches:[{title,taskProfile,workerRole}]}
async function loadCompose(){
  composer = await jget("/api/composer");
  if (!composer || composer.error){
    el("cmReport").innerHTML = `<p class="jsonerr">composer unavailable: ${esc(composer && composer.error || "no response")}</p>`;
    return;
  }
  const profs = Object.keys(composer.profiles || {});
  el("cmProfile").innerHTML = profs.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  el("cmExecutor").innerHTML = (composer.executors || []).map(e => `<option value="${esc(e)}">${esc(e)}</option>`).join("");
  if (profs.length) selectProfile(profs[0]);
}
function selectProfile(name){
  const p = (composer.profiles || {})[name]; if (!p) return;
  el("cmProfile").value = name;
  cmState = {profile: name, task: "compose: validate the " + name + " flow",
    executor: el("cmExecutor").value || (composer.executors || [])[0] || "",
    branches: (p.branches || []).map(b => ({title: b.title || "", taskProfile: b.taskProfile || "", workerRole: b.workerRole || ""}))};
  el("cmTask").value = cmState.task;
  renderBranches();
  renderDag();
  el("cmReport").innerHTML = '<p class="dim">Compile to validate this composition — nothing is written.</p>';
}
function currentView(){
  // The DERIVED view of the current (edited) form state — dagFor recomputes from this
  // on every render, so the DAG can never drift from the composition (no cached coords).
  const base = (composer.profiles || {})[cmState.profile] || {};
  return {type: base.type, maxWorkers: base.maxWorkers, splitStrategy: base.splitStrategy,
    seeded: base.seeded, branches: cmState.branches};
}
function dagFor(view){
  const seeded = !!view.seeded;
  const nodes = [{id: "source", kind: "source", label: view.type || "workflow"}];
  const edges = [];
  const br = view.branches || [];
  if (br.length){
    br.forEach((b, i) => {
      const id = "b" + i;
      const label = [b.workerRole, b.taskProfile].filter(Boolean).join(" · ") || b.title || id;
      nodes.push({id, kind: "branch", label});
      edges.push({from: "source", to: id, kind: seeded ? "seed" : "fanout"});
      edges.push({from: id, to: "reduce", kind: "reduce"});
    });
  } else {
    nodes.push({id: "map", kind: "branch", label: "map · " + (view.splitStrategy || "roots") + " · ≤" + (view.maxWorkers || "")});
    edges.push({from: "source", to: "map", kind: seeded ? "seed" : "fanout"});
    edges.push({from: "map", to: "reduce", kind: "reduce"});
  }
  nodes.push({id: "reduce", kind: "reduce", label: "reduce"});
  return {nodes, edges, seeded};
}
function renderDag(keepReport){
  invalidateCreate();   // any DAG re-derivation = the composition changed → re-Compile before Create
  if (!keepReport && cmState) cmState.lastReport = null;   // an edit invalidates the stashed compile → budget badges clear
  const dag = dagFor(currentView());
  const branchNodes = dag.nodes.filter(n => n.kind === "branch");
  const NW = 150, NH = 44, GAP = 22, PADX = 18, PADY = 16, ROWGAP = 52;
  const cols = Math.max(1, branchNodes.length);
  const W = Math.max(cols * NW + (cols - 1) * GAP + 2 * PADX, 340);
  const rowY = {source: PADY, branch: PADY + NH + ROWGAP, reduce: PADY + 2 * (NH + ROWGAP)};
  const H = rowY.reduce + NH + PADY;
  const pos = {};
  pos["source"] = {x: W / 2 - NW / 2, y: rowY.source};
  pos["reduce"] = {x: W / 2 - NW / 2, y: rowY.reduce};
  branchNodes.forEach((n, i) => { pos[n.id] = {x: PADX + i * (NW + GAP), y: rowY.branch}; });
  const cx = id => pos[id].x + NW / 2, top = id => pos[id].y, bot = id => pos[id].y + NH;
  const paths = dag.edges.map(e => {
    const x1 = cx(e.from), y1 = bot(e.from), x2 = cx(e.to), y2 = top(e.to), my = (y1 + y2) / 2;
    const cls = e.kind === "reduce" ? "e-reduce" : (e.kind === "seed" ? "e-seed" : "e-fan");
    return `<path class="cmedge ${cls}" d="M${x1},${y1} C${x1},${my} ${x2},${my} ${x2},${y2}"/>`;
  }).join("");
  // E6: after a compile, render the report's per-worker token audit as node badges —
  // report.workers[i] maps to branch node i (branch order); NEVER recomputed here, and
  // only when every branch node has a matching worker (count mismatch → plain nodes).
  const workers = (cmState && cmState.lastReport && cmState.lastReport.workers) || [];
  const showBadges = workers.length === branchNodes.length;
  let bi = 0;
  const rects = dag.nodes.map(n => {
    const p = pos[n.id];
    let w = null;
    if (n.kind === "branch"){ if (showBadges) w = workers[bi]; bi++; }
    const st = w ? String(w.promptTokenBudgetStatus) : "";
    const labelY = w ? p.y + 16 : p.y + NH / 2 + 4;
    const badge = w
      ? `<rect class="tokbadge ${esc(st)}" x="${p.x + 8}" y="${p.y + 23}" width="${NW - 16}" height="15" rx="3"/>` +
        `<text class="tok" x="${p.x + NW / 2}" y="${p.y + 34}" text-anchor="middle">${esc(w.estimatedPromptTokens)} tok · ${esc(st)}</text>`
      : "";
    return `<g class="cmnode n-${esc(n.kind)}"><rect x="${p.x}" y="${p.y}" width="${NW}" height="${NH}" rx="7"/>` +
      `<text x="${p.x + NW / 2}" y="${labelY}" text-anchor="middle">${esc((n.label || "").slice(0, 26))}</text>` +
      badge + `</g>`;
  }).join("");
  const seedTag = dag.seeded ? `<text x="6" y="13" class="cmseed">seeded digest → branches</text>` : "";
  el("cmDag").innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px">${seedTag}${paths}${rects}</svg>`;
}
function renderBranches(){
  const forkjoin = ((composer.profiles || {})[cmState.profile] || {}).type === "fork-join";
  if (!forkjoin){
    el("cmBranches").innerHTML = '<p class="dim">map-reduce: shards derived from the split strategy at compile — not editable per branch. Compile validates the named profile.</p>';
    return;
  }
  const tpOpts = ['<option value="">(auto by keyword)</option>']
    .concat((composer.taskProfiles || []).map(t => `<option value="${esc(t)}">${esc(t)}</option>`)).join("");
  el("cmBranches").innerHTML = cmState.branches.map((b, i) =>
    `<div class="cmbranch">` +
      `<input class="cmb-title" data-i="${i}" value="${esc(b.title)}" placeholder="title">` +
      `<select class="cmb-tp" data-i="${i}">${tpOpts}</select>` +
      `<input class="cmb-role" data-i="${i}" value="${esc(b.workerRole)}" placeholder="workerRole">` +
      `<button class="pillbtn cmb-del" data-i="${i}" title="remove branch">✕</button>` +
    `</div>`).join("") +
    `<button class="pillbtn" id="cmAddBranch">+ branch</button>`;
  cmState.branches.forEach((b, i) => {
    const s = el("cmBranches").querySelector(`.cmb-tp[data-i="${i}"]`); if (s) s.value = b.taskProfile || "";
  });
  el("cmBranches").querySelectorAll(".cmb-title").forEach(inp => inp.oninput = e => {
    cmState.branches[+e.target.dataset.i].title = e.target.value; renderDag(); });
  el("cmBranches").querySelectorAll(".cmb-tp").forEach(s => s.onchange = e => {
    cmState.branches[+e.target.dataset.i].taskProfile = e.target.value; renderDag(); });
  el("cmBranches").querySelectorAll(".cmb-role").forEach(inp => inp.oninput = e => {
    cmState.branches[+e.target.dataset.i].workerRole = e.target.value; renderDag(); });
  el("cmBranches").querySelectorAll(".cmb-del").forEach(b => b.onclick = e => {
    cmState.branches.splice(+e.target.dataset.i, 1); renderBranches(); renderDag(); });
  el("cmAddBranch").onclick = () => {
    cmState.branches.push({title: "new branch", taskProfile: "", workerRole: "branch-worker"});
    renderBranches(); renderDag(); };
}
el("cmProfile").onchange = e => selectProfile(e.target.value);
el("cmExecutor").onchange = e => { if (cmState) cmState.executor = e.target.value; };
el("cmTask").oninput = e => { if (cmState){ cmState.task = e.target.value; renderDag(); } };   // task edit → stale report, badges clear (renderDag calls invalidateCreate)
el("cmCompile").onclick = doCompile;
el("cmCreate").onclick = doCreate;
// N2b: Create is enabled ONLY by a GREEN compile and re-disabled on ANY edit — you cannot
// materialize an uncompiled/edited composition. (The load-bearing guard is server-side: the
// composer-create action re-runs the same compile in-process and refuses unless valid.)
function invalidateCreate(){ const b = el("cmCreate"); if (b) b.disabled = true; }
async function doCompile(){
  if (!cmState) return;
  invalidateCreate();
  el("cmReport").innerHTML = '<p class="dim">compiling…</p>';
  const forkjoin = ((composer.profiles || {})[cmState.profile] || {}).type === "fork-join";
  const body = {profile: cmState.profile, task: cmState.task};
  if (forkjoin) body.branches = cmState.branches;   // per-branch objects (title/taskProfile/workerRole)
  const rep = await jpost("/api/compile", body);
  cmState.lastReport = rep || null;                       // E6: stash the token-audit so renderDag can badge the nodes
  el("cmReport").innerHTML = renderReport(rep);
  renderDag(true);                                        // draw per-worker budget badges (keepReport = don't clear the fresh stash)
  el("cmCreate").disabled = !rep || rep.valid !== true;   // GREEN compile → Create is unlocked (set AFTER renderDag's invalidateCreate)
}
async function doCreate(){
  if (!cmState || el("cmCreate").disabled) return;
  const forkjoin = ((composer.profiles || {})[cmState.profile] || {}).type === "fork-join";
  const branches = forkjoin ? cmState.branches : [];
  const argv = "workflow plan --profile " + cmState.profile + " --branch-json " + JSON.stringify(branches)
    + (cmState.task ? " --task …" : "");
  if (!(await confirmModal("Create workflow? Runs (CREATES, does not start):\n\n" + argv
      + "\n\nMaterializes a WF directory + prompts. No agent is spawned, no token spent."))) return;
  el("cmReport").innerHTML = '<p class="dim">creating…</p>';
  const res = await jpost("/api/action", {action: "composer-create",
    params: {profile: cmState.profile, task: cmState.task, branches, confirm: true}});
  invalidateCreate();   // a create consumes this compile; recompile to create again
  el("cmReport").innerHTML = renderCreateResult(res);
}
function renderCreateResult(res){
  if (!res) return '<p class="jsonerr">no response</p>';
  if (res.ok){
    const wfid = ((res.output || "").match(/WF-[0-9A-Za-z-]+/) || [""])[0];
    return `<div class="cmverdict ok">✓ created ${esc(wfid) || "(see output)"}</div>` +
      `<p class="dim">created — start it from the CLI/panel whenever you want</p>` +
      `<pre class="cmout">${colorizeDiff(res.output || "")}</pre>`;
  }
  const errs = res.errors || [];
  return `<div class="cmverdict bad">✗ ${esc(res.refused || "creation refused")}</div>` +
    (errs.length ? `<div class="cmerrs"><b>errors</b><ul>${errs.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>` : "") +
    (res.output ? `<pre class="cmout">${colorizeDiff(res.output)}</pre>` : "");
}
function taBadge(s){ return `<span class="badge2 ${s === "pass" ? "ok" : (s === "fail" ? "bad" : "none")}">${esc(s)}</span>`; }
function renderReport(r){
  if (!r) return '<p class="jsonerr">no response</p>';
  const ok = r.valid === true;
  const head = `<div class="cmverdict ${ok ? "ok" : "bad"}">${ok ? "✓ valid" : "✗ invalid"} ` +
    `<span class="dim" style="font-weight:400">· validate-only · nothing written</span></div>`;
  const t = r.tokenAudit;
  const ta = t ? `<div class="cmta">token audit: ${taBadge(t.status)} · worker-prompt ` +
    `${esc(t.totalWorkerPromptTokens)}/${esc(t.maxTotalWorkerPromptTokens)} · planned ` +
    `${esc(t.totalPlanned)}/${esc(t.maxTotalPlannedTokens)} tok</div>` : "";
  const workers = (r.workers || []).length
    ? `<table><tr><th>worker</th><th>role</th><th>taskProfile</th><th>prompt tok</th><th>budget</th></tr>` +
      r.workers.map(w => `<tr><td class="mono">${esc(w.workerId)}</td><td>${esc(w.workerRole)}</td>` +
        `<td>${esc(w.taskProfile)}</td><td>${esc(w.estimatedPromptTokens)}</td>` +
        `<td>${taBadge(w.promptTokenBudgetStatus)}</td></tr>`).join("") + `</table>` : "";
  const list = (arr, cls, title) => (arr || []).length
    ? `<div class="${cls}"><b>${title}</b><ul>${arr.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>` : "";
  return head + ta + workers + list(r.errors, "cmerrs", "errors") + list(r.warnings, "cmwarns", "warnings");
}

/*__WS_JS__*/

startSSE();
loadSessions();   // attach/create the "main" session on first load (chat works out of the box)
refresh();
initOnboard();
setInterval(refresh, 3000);
document.addEventListener("visibilitychange", refresh);
</script>
</body></html>
"""

# P6: inject the markdown renderer IIFE into PAGE at the placeholder (same trick as
# harness_ui.py's __HARNESS_TOKEN__ replace) — the module lives on its own to respect
# the file budget; the const MD is spliced in after esc()/HL are defined.
from harness_ui_page_md import MD_JS  # noqa: E402

PAGE = PAGE.replace("/*__MD_JS__*/", MD_JS)

# SPEC-147: chat-workspace module (CM6 modes + diff pane). The importmap is a
# STATIC <head> script (a map inserted after any module load is ignored); its
# URLs carry __HARNESS_TOKEN__, resolved by harness_ui._send_page. WS_JS lands
# before the boot calls; WS_CSS inside the page <style>.
from harness_ui_page_workspace import WS_CSS, WS_IMPORTMAP, WS_JS  # noqa: E402

PAGE = (PAGE.replace("/*__WS_CSS__*/", WS_CSS)
            .replace("/*__WS_IMPORTMAP__*/", WS_IMPORTMAP)
            .replace("/*__WS_JS__*/", WS_JS))


# -- chat-gate-tracker normalizer (deterministic, no LLM) --------------------
# Python twin of the PAGE's gateFromCmd(): the unit-drivable spec of the gate-
# command → normalized event mapping. Keep the token rules in sync with the JS.
import re as _re  # noqa: E402

_GATE_ANCHOR = _re.compile(r"(?:spec_test_gate\.py|harness-test\.py|harness\.py\s+test)\s+(.*)")
_GATE_TOKEN = _re.compile(r"^[a-z][a-z-]*$")


def gate_from_cmd(cmd: str | None) -> dict | None:
    """A Bash gate command → {event:"gate", scope, target, gate, status:"running"}, or None.

    Detection only (READ-ONLY): the overseer runs the ladder via
    `spec_test_gate.py <gate>` / `harness.py test <gate>` / `harness-test.py <gate>`;
    `--target <name>` (or `--target=<name>`) ⇒ target scope. Never runs or mutates a
    gate; authoritative pass/fail is read later from quality-state, not synthesized here.
    """
    if not cmd:
        return None
    m = _GATE_ANCHOR.search(str(cmd))
    if not m:
        return None
    toks = m.group(1).split()
    target = None
    gate = None
    skip = False
    for i, t in enumerate(toks):
        if skip:
            skip = False
            continue
        if t.startswith("--target="):
            target = t.split("=", 1)[1]
            continue
        if t == "--target":
            if i + 1 < len(toks):
                target = toks[i + 1]
                skip = True
            continue
        if t.startswith("-"):
            continue
        if gate is None and _GATE_TOKEN.match(t):
            gate = t
    if gate is None:
        return None
    return {"event": "gate", "scope": "target" if target else "harness",
            "target": target, "gate": gate, "status": "running"}


def _self_check() -> None:
    assert gate_from_cmd("python scripts/spec_test_gate.py feature") == {
        "event": "gate", "scope": "harness", "target": None, "gate": "feature", "status": "running"}
    assert gate_from_cmd("scripts/harness.py test commit")["gate"] == "commit"
    assert gate_from_cmd("harness-test.py spec-pack --no-project-commands")["gate"] == "spec-pack"
    t = gate_from_cmd("harness-test.py commit --target my-app")
    assert t["scope"] == "target" and t["target"] == "my-app" and t["gate"] == "commit", t
    assert gate_from_cmd("spec_test_gate.py --target=other feature")["target"] == "other"
    assert gate_from_cmd("spec_test_gate.py --target repo-x release")["gate"] == "release"
    assert gate_from_cmd("python scripts/harness.py status") is None
    assert gate_from_cmd("git commit -m x") is None
    assert gate_from_cmd("") is None and gate_from_cmd(None) is None
    print("harness_ui_page gate_from_cmd self-check ok")


if __name__ == "__main__":
    _self_check()
