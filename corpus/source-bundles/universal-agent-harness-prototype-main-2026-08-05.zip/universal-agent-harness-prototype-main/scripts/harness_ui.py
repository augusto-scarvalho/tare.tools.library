#!/usr/bin/env python3
"""SPEC-114 supervision panel: a loopback HTTP server + one inline web page.

127.0.0.1 only, per-session token on every route (public font binaries excepted),
stdlib http.server. All
mutating power routes through ui_panel.run_action (allowlisted harness
subcommands via subprocess — the same single write path agents get). The chat
tab is SSE (browser<-server) + POST (browser->server) over a ChatBridge that
pipes to `harness.py chat`; no PTY. The one WebSocket is the read-mostly LSP
bridge (GET /api/lsp -> pylsp, ide-lsp Lane A). Front-end is one self-contained
page (no external requests). This file lives outside harness_lib on purpose:
the inline front-end string is UI bulk, not library logic. That string (PAGE)
lives in scripts/harness_ui_page.py (MF split); this file keeps server/routes/
serve()/main() and imports it.
"""
from __future__ import annotations

import argparse
import atexit
import datetime as dt
import hashlib
import json
import re
import secrets
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness_lib import docs_tree, evidence_bundle, ide_integrate, ide_shard, records, research_admin, tasks_board, ui_commits, ui_events, ui_memory, ui_panel, ui_queue, ui_runtime, ui_specs  # noqa: E402
from harness_lib.common import read_json  # noqa: E402
from harness_ui_page import PAGE  # MF split: the inline UI string lives here  # noqa: E402

HEARTBEAT_S = 15
_GATE_STAGED_NAME = re.compile(r"gate-staged-\d{8}T\d{6}\.(?:log|marker)")


def integrate_file(root: Path, rel: str) -> dict:
    """Return one changed shard file, closed to the integration summary."""
    report = ide_integrate.summary(root)
    row = next((item for item in report["files"] if item["path"] == rel), None)
    if row is None:
        return {"error": "path is not in the integration summary"}
    shard = ide_shard.active_root(root)
    target = shard / Path(*PurePosixPath(rel).parts)
    try:
        target.resolve(strict=False).relative_to(shard.resolve())
    except (OSError, ValueError):
        return {"error": "path escapes the IDE shard"}
    base_path = row.get("oldPath") or rel
    shown = ide_integrate._run_git(
        ["show", f"{report['baseSha']}:{base_path}"], cwd=shard, timeout=60,
        check=False)
    base = shown.stdout if shown.returncode == 0 else ""
    try:
        current = target.read_bytes().decode("utf-8", errors="replace") if target.is_file() else ""
    except OSError as exc:
        return {"error": f"{type(exc).__name__}: {exc}"}
    return {"base": base, "current": current}


def integrate_gate(root: Path, name: str) -> dict:
    """Return a confined gate-staged marker and the last 16 KiB of its log."""
    if not _GATE_STAGED_NAME.fullmatch(name):
        return {"error": "invalid gate-staged artifact name"}
    stem = name.rsplit(".", 1)[0]
    runs = Path(root) / ".harness" / "runs"
    marker_path = runs / f"{stem}.marker"
    log_path = runs / f"{stem}.log"
    marker = read_json(marker_path, None)
    try:
        with log_path.open("rb") as fh:
            fh.seek(0, 2)
            fh.seek(max(0, fh.tell() - 16 * 1024))
            tail = fh.read().decode("utf-8", errors="replace")
    except OSError:
        tail = ""
    return {"name": stem, "marker": marker if isinstance(marker, dict) else None,
            "logTail": tail}


def research_snapshot(root: Path) -> dict:
    """SPEC-135 read-only research-round gallery index == the `research list`
    inventory (research_admin.rounds): one row {slug, path, tracked, linkedWfs,
    recordsRefs} per docs/research round (RESEARCH.md excluded). Calm-degrade to
    {rounds:[], error} — never a 500. (research_index.research_snapshot, which
    wraps this same inventory, stays the seat for the deferred rich inspector:
    title / phases / evidence.)"""
    try:
        return {"rounds": research_admin.rounds(root)}
    except Exception as exc:  # a hand-written docs tree must never 500 the panel
        return {"rounds": [], "error": f"{type(exc).__name__}"}


def research_file(root: Path, slug: str) -> dict:
    """ONE round's raw doc body — CLOSED to the gallery inventory (the
    /api/specs/file discipline: a slug not in the index refuses, so a traversal /
    unknown / absolute slug never resolves). Rounds are tracked public docs —
    served verbatim, no redaction."""
    inventory = {r["slug"] for r in research_snapshot(root).get("rounds", [])}
    if slug not in inventory:  # traversal / unknown / absolute all fall here
        return {"error": f"unknown research round: {slug}", "slug": slug}
    path = Path(root) / "docs" / "research" / f"{slug}.md"
    try:
        return {"slug": slug, "body": path.read_text(encoding="utf-8", errors="ignore")}
    except OSError:
        return {"error": "research round not present on this machine", "slug": slug}


def _claim_row(f: dict, *, reduced: bool) -> dict:
    """GUI-RS2: ONE claim row projected to the matrix's REAL fields.
    replications <- len(sourceWorkerIds) (the reducer's replication provenance);
    None for a raw-fallback finding (no dedup provenance exists -> the page dashes
    it + TODO names the field). Nothing is invented -- a count is len() of a real
    array, exactly the RS1 counts-not-content discipline."""
    swi = f.get("sourceWorkerIds")
    return {
        "id": str(f.get("id") or ""),
        "title": str(f.get("title") or ""),
        "category": str(f.get("category") or ""),
        "evidence": [str(e) for e in (f.get("evidence") or [])][:20],
        "replications": len(swi) if reduced and isinstance(swi, list) else None,
    }


def _wave_claims(red: dict, raw_findings: list) -> dict:
    """GUI-RS2 claims subtab: deduped CLAIM rows + reduce conflicts, projected to
    real fields only. reduced=True when the rows come from reduce dedupedFindings;
    False when they fall back to the raw per-worker findings union (no reducer
    artifact -> the page shows the honest `no reduce -- raw findings` badge).
    CONFIDENCE is NOT computed here -- the page derives it from the two real
    signals (conflicts + replications) so the formula stays auditable client-side.
    Conflict shape is pinned DATA-FIRST from workflow_reduce: {category,title,
    workers,recommendations}; a conflict matches a claim by TITLE (it carries no
    finding id)."""
    deduped = red.get("dedupedFindings") if isinstance(red, dict) else None
    if isinstance(deduped, list) and deduped:
        claims = [_claim_row(f, reduced=True) for f in deduped if isinstance(f, dict)]
        reduced = True
    else:  # fallback: raw per-worker findings union, no dedup provenance
        claims = [_claim_row(f, reduced=False) for f in raw_findings if isinstance(f, dict)]
        reduced = False
    conflicts = []
    for c in (red.get("conflicts") if isinstance(red, dict) else None) or []:
        if isinstance(c, dict):
            conflicts.append({
                "title": str(c.get("title") or ""),
                "category": str(c.get("category") or ""),
                "workers": [str(w) for w in (c.get("workers") or [])],
                "recommendations": [str(r) for r in (c.get("recommendations") or [])],
            })
    return {"claims": claims, "conflicts": conflicts, "reduced": reduced}


def _round_wave(root: Path, wfid: str, claims: bool = False) -> dict:
    """One linked WF's per-worker outcome cards + the reduce retained-count.
    COUNTS-NOT-CONTENT: every number is len() of a REAL worker-result / reduce
    array (no finding/summary bodies are served -- that is both the redaction
    stance and the structural block on the one-chat-per-worker antipattern).
    A missing array => None (the page renders an honest "-", never a synthesized
    count). GUI-RS2: when `claims` is set, ADDITIVELY attach the claim-evidence
    matrix rows/conflicts from the SAME reduce artifact RS1 already reads (no new
    source); the default (claims=False) response is byte-identical to RS1's."""
    base = Path(root) / ".harness" / "workflows" / "active" / wfid
    workers = []
    raw_findings: list = []
    wdir = base / "workers"
    if wdir.is_dir():
        for f in sorted(wdir.glob("*.result.json")):
            d = read_json(f, {}) or {}
            if not isinstance(d, dict):
                continue
            workers.append({
                "workerId": str(d.get("workerId") or f.name.split(".result.json")[0]),
                "workerRole": str(d.get("workerRole") or ""),
                "status": str(d.get("status") or ""),
                # found <- itemsAnalyzed (real); findings <- findings (real). No
                # per-worker dedup/retained field exists -> the page dashes those.
                "found": len(d["itemsAnalyzed"]) if isinstance(d.get("itemsAnalyzed"), list) else None,
                "findings": len(d["findings"]) if isinstance(d.get("findings"), list) else None,
            })
            if claims and isinstance(d.get("findings"), list):
                raw_findings.extend(d["findings"])  # only for the no-reduce fallback
    red = read_json(base / "reduce" / "reducer.result.json", {}) or {}
    retained = (len(red["dedupedFindings"])
                if isinstance(red, dict) and isinstance(red.get("dedupedFindings"), list) else None)
    wave = {"workflowId": wfid, "workers": workers, "retained": retained}
    if claims:
        wave.update(_wave_claims(red if isinstance(red, dict) else {}, raw_findings))
    return wave


def research_round(root: Path, slug: str, claims: bool = False) -> dict:
    """GUI-RS1 source-lane view of ONE round: the parsed question + per-worker
    outcome cards for the round's linked workflows, CLOSED to the gallery
    inventory (the research_file discipline). Fields map to NAMED real sources
    only: question<-research_index.parse_round; tracked/linkedWfs<-research_admin;
    per-worker found/findings<-worker *.result.json arrays; wave retained<-reduce
    dedupedFindings. Nothing is synthesized -- a missing count is null. GUI-RS2:
    `claims=True` ADDITIVELY attaches the claim-evidence matrix (claims/conflicts/
    reduced) per wave from the same reduce source; claims=False stays RS1-shaped.
    GUI-RS3: under the same `claims` gate the round doc's OWN parsed title/phases
    ride along (additive) so the consensus POSITION frames the report with named
    parse_round fields, never a generated summary; claims=False stays RS1-shaped."""
    from harness_lib import research_index  # local: the parse lives on this verb
    inventory = {r["slug"]: r for r in research_snapshot(root).get("rounds", [])}
    if slug not in inventory:  # traversal / unknown / absolute all fall here
        return {"error": f"unknown research round: {slug}", "slug": slug}
    row = inventory[slug]
    parsed = research_index.parse_round(Path(root) / "docs" / "research" / f"{slug}.md")
    linked = row.get("linkedWfs", []) or []
    out = {"slug": slug, "tracked": bool(row.get("tracked")),
           "question": str(parsed.get("question") or ""), "linkedWfs": linked,
           "waves": [_round_wave(root, wfid, claims=claims) for wfid in linked]}
    if claims:  # GUI-RS3: additive, gated -> claims=False stays byte-identical to RS1
        out["title"] = str(parsed.get("title") or "")
        out["phases"] = [int(p) for p in (parsed.get("phases") or []) if isinstance(p, int)]
    return out


def _graph_exploration(root: Path) -> dict:
    """graphs-screen (B3) R1 server-side exploration, read straight off graph.json
    (the 12-line GRAPH_REPORT carries no tables): most-imported by IN-degree, top
    fan-out by OUT-degree, community sizes by member count. Pure counts, no bodies;
    a missing/unreadable graph yields empty lists, so the page shows the honest
    empty-state keyed off metrics.freshness.reason (never a fabricated table)."""
    graph = read_json(Path(root) / "graphify-out" / "graph.json", None) or {}
    indeg: dict[str, int] = {}
    outdeg: dict[str, int] = {}
    for edge in graph.get("edges") or []:
        if not isinstance(edge, dict):
            continue
        src, tgt = str(edge.get("source") or ""), str(edge.get("target") or "")
        if src:
            outdeg[src] = outdeg.get(src, 0) + 1
        if tgt:
            indeg[tgt] = indeg.get(tgt, 0) + 1

    def _top(counts: dict[str, int]) -> list[dict]:
        # count desc, id asc -> deterministic ordering for the same graph (the panel and the
        # scenario must agree bit-for-bit); top 15 (R1).
        return [{"id": k, "count": v} for k, v in
                sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:15]]

    communities = graph.get("communities")
    comm: list[dict] = []
    if isinstance(communities, dict):
        comm = sorted(
            ({"name": str(k), "count": len(v) if hasattr(v, "__len__") else 0}
             for k, v in communities.items()),
            key=lambda c: (-c["count"], c["name"]))
    return {"mostImported": _top(indeg), "topFanout": _top(outdeg), "communities": comm}


def graphs_snapshot(root: Path) -> dict:
    """graphs-screen (B3) read-only snapshot (research_snapshot idiom, calm-degrade):
    active provider, the registry rows WITHOUT their command arrays (a provider's argv
    is tracked config, not GUI data — B3 says the GUI may only SELECT among registered
    names), the metrics snapshot verbatim (graph_providers.metrics), and the R1 server-
    side exploration tables. Never a 500 — a broken subject degrades to a shape-stable
    payload carrying an error string."""
    from harness_lib import graph_providers
    try:
        rows = [{"name": name, "kind": entry.get("kind"),
                 "available": bool(entry.get("available")), "detail": entry.get("detail")}
                for name, entry in sorted(graph_providers.registry(root).items())]
        return {"provider": graph_providers.active_name(root), "registry": rows,
                "metrics": graph_providers.metrics(root),
                "exploration": _graph_exploration(root)}
    except Exception as exc:  # a broken graph/config must never 500 the panel
        return {"provider": None, "registry": [], "metrics": {}, "exploration": {},
                "error": f"{type(exc).__name__}"}


_MC_ACCT_BADGE = {"native": "measured", "unknown": "estimate", "emulated": "emulated"}
# card engine -> discovery provider (SPEC-165 R9 _EXECUTOR_TO_PROVIDER, read-only mirror):
# the two engines whose cards ride the graphify text/image discovery chain.
_MC_DISCOVERY_ENGINES = {"gemini-compat": "gemini-api", "nvidia-compat": "nvidia-build"}


def _mc_accounting(root: Path, engine: str | None) -> tuple[str | None, str]:
    """(rawSemantics, badge) for a card's engine from executors.json. Unknown/absent
    semantics badge as `estimate` — the accounting badge governs every number below."""
    execs = (read_json(root / ".harness" / "routing" / "executors.json", {}) or {}).get("executors", {})
    sem = (execs.get(engine) or {}).get("accountingSemantics") if isinstance(execs, dict) else None
    return sem, _MC_ACCT_BADGE.get(sem, "estimate")


def _mc_probes(desc: str | None) -> list[dict]:
    """External-evidence probe excerpts = the parenthetical prose in a card description
    that names a `probe` (honestly sparse — the ONLY external signal we store). Date
    parsed when present; nothing synthesized."""
    out: list[dict] = []
    for m in re.finditer(r"\(([^()]*probe[^()]*)\)", desc or "", re.IGNORECASE):
        text = m.group(1).strip()
        dm = re.search(r"\d{4}-\d{2}-\d{2}", text)
        out.append({"text": text, "at": dm.group(0) if dm else None})
    return out


def _mc_window(rows: list[dict]) -> dict | None:
    ats = sorted(str(r.get("at")) for r in rows if r.get("at"))
    return {"from": ats[0], "to": ats[-1]} if ats else None


def _mc_fellback(root: Path, card_id: str) -> list[dict]:
    """Fallback events naming THIS card, scanned over active workflow payloads (the
    spawn-chain writes payload.fellBackTo={executor,card}+fallbackReason, harness.py).
    Reads worker result files + workflow.json worker arrays; a missing tree is []."""
    out: list[dict] = []
    active = root / ".harness" / "workflows" / "active"
    if not active.is_dir():
        return out
    for wf in sorted(p for p in active.iterdir() if p.is_dir()):
        files = sorted((wf / "workers").glob("*.json")) if (wf / "workers").is_dir() else []
        files.append(wf / "workflow.json")
        for f in files:
            if not f.is_file():
                continue
            doc = read_json(f, {})
            if not isinstance(doc, dict):
                continue
            recs = doc["workers"] if isinstance(doc.get("workers"), list) else [doc]
            for rec in recs:
                fb = rec.get("fellBackTo") if isinstance(rec, dict) else None
                if isinstance(fb, dict) and fb.get("card") == card_id:
                    out.append({"workflowId": wf.name, "worker": rec.get("workerId"),
                                "reason": rec.get("fallbackReason"),
                                "at": rec.get("finishedAt") or rec.get("updatedAt")})
    return out


def models_card_snapshot(root: Path, card_id: str) -> dict:
    """GUI-RG1 4-layer model card (research_snapshot/graphs_snapshot calm-degrade
    idiom — never 500; an unknown id degrades to a shape-stable {found:false}). Layers,
    each honestly separated because declared != measured:

    L1 DECLARED  — the cards_list vendor row + the KNOWN_MODELS catalog note.
    L2 EXTERNAL  — probe excerpts parsed from the description + the catalog doc link
                   (honestly sparse: there is no external evidence store).
    L3 MEASURED  — chat-turn (engine-reported) + delegation (chars/4 estimate) stats
                   over the cost ledger, joined by EXACT card-id match (never merges
                   `opus-4.8`/`orv-model` residue into `opus`); an unattributed bucket
                   note names the model ids that match no card. Reuses the existing
                   cost_metrics aggregations (_load/_stats) — zero new stat math.
    L4 OPERATIONAL — track-record outcomes (exact-id, summed over agentTypes) +
                   fellBackTo scans + the ENGINE-level executor circuit (labeled as
                   such) + discovery provider gates for discovery-chain engines.

    Plus a routing/judged/discovery-gate role strip and a NON-fabricated health pill.
    The accounting badge (native->measured / unknown->estimate / emulated->emulated)
    governs every number; codex accountingSemantics=unknown renders every gpt-* stat
    as estimate. Read-only."""
    root = Path(root)
    card_id = str(card_id or "")
    empty = {"cardId": card_id, "found": False, "header": {}, "declared": {},
             "external": {"probes": [], "docLinks": []},
             "measured": {"chatTurns": None, "delegations": None, "unattributedNote": None},
             "operational": {"trackRecord": None, "fellBackTo": [], "circuit": None,
                             "discoveryGates": []},
             "roles": [], "health": None}
    try:
        from harness_lib import cost_metrics, discovery, model_routing, track_record, ui_runtime
        cards = {c["id"]: c for c in model_routing.cards_list(root)}
        if card_id not in cards:
            return empty
        card = cards[card_id]
        engine = card.get("engine")
        sem, badge = _mc_accounting(root, engine)
        note = (next((m for m in model_routing.catalog_list() if m.get("id") == card_id), {}) or {}).get("note")

        header = {"id": card_id, "name": card.get("name") or card_id, "provider": card.get("provider"),
                  "engine": engine, "accounting": badge, "accountingSemantics": sem}
        declared = {"id": card_id, "name": card.get("name"), "provider": card.get("provider"),
                    "engine": engine, "contextWindow": card.get("contextWindow"),
                    "reasoning": card.get("reasoning") or [], "defaultReasoning": card.get("defaultReasoning"),
                    "openWeights": card.get("openWeights"), "vision": card.get("vision"),
                    "description": card.get("description"),
                    "catalogNote": ({"value": note, "source": "KNOWN_MODELS catalog"} if note else None)}

        doc_links = []
        if (root / "specs" / "40-features" / "model-routing.md").is_file():
            doc_links.append({"title": "model-routing.md — vendor catalog decision table",
                              "path": "specs/40-features/model-routing.md"})
        external = {"probes": _mc_probes(card.get("description")), "docLinks": doc_links}

        # L3: EXACT card-id join over the cost ledger (residue like opus-4.8/orv-model
        # never merges into opus). Reuse cost_metrics._load/_stats (existing aggregations).
        ledger = cost_metrics._load(root)
        known = set(cards)
        turns = [r for r in ledger if r.get("kind") == "chat-turn" and r.get("model") == card_id]
        delegs = [r for r in ledger if r.get("kind") == "delegation" and r.get("model") == card_id]

        def _num(rows, field):
            return cost_metrics._stats([float(r[field]) for r in rows if isinstance(r.get(field), (int, float))])

        chat_block = None
        if turns:
            chat_block = {"count": len(turns), "inTokens": _num(turns, "inTokens"),
                          "outTokens": _num(turns, "outTokens"), "costUsd": _num(turns, "costUsd"),
                          "durationS": _num(turns, "durationS"), "basis": badge,
                          "source": "cost-metrics.json chat-turn (engine-reported)",
                          "window": _mc_window(turns)}
        deleg_block = None
        if delegs:
            outcomes: dict[str, int] = {}
            for r in delegs:
                key = r.get("outcome") or "(unrated)"
                outcomes[key] = outcomes.get(key, 0) + 1
            deleg_block = {"count": len(delegs), "estTokens": _num(delegs, "estTokens"),
                           "toolUses": _num(delegs, "toolUses"), "outcomes": dict(sorted(outcomes.items())),
                           "basis": "estimate (chars/4)",
                           "source": "cost-metrics.json delegation (chars/4 estimate)",
                           "window": _mc_window(delegs)}
        unattributed = sorted({str(r.get("model")) for r in ledger
                               if r.get("kind") in ("chat-turn", "delegation")
                               and r.get("model") and r.get("model") not in known})
        unattributed_note = (f"{len(unattributed)} ledger model id(s) match no card — excluded from "
                             f"every card by exact-id attribution: {', '.join(unattributed[:8])}"
                             if unattributed else None)
        measured = {"chatTurns": chat_block, "delegations": deleg_block,
                    "unattributedNote": unattributed_note}

        # L4: track record (exact card id, summed over agentTypes) + fallbacks + circuit + gates
        agg = {"kept": 0, "partial": 0, "rejected": 0, "reworked": 0}
        for key, g in (track_record.summarize_track(root).get("groups") or {}).items():
            if key.split("|", 1)[0] == card_id:
                for k in agg:
                    agg[k] += int(g.get(k) or 0)
        judged = sum(agg.values())
        useful_rate = round((agg["kept"] + agg["reworked"]) / judged, 3) if judged else None
        track_block = ({**agg, "judged": judged, "usefulRate": useful_rate,
                        "source": "track_record over cost-metrics.json delegations"} if judged else None)

        circuit = None
        for c in ui_runtime._circuits(root):
            if c.get("executor") == engine:
                circuit = {"label": f"engine-level: {engine}", "executor": engine,
                           "state": c.get("state"), "lastFailureReason": c.get("lastFailureReason"),
                           "failureCount": c.get("failureCount")}
                break

        provider = _MC_DISCOVERY_ENGINES.get(engine)
        gates = []
        if provider:
            try:
                gates = [g for g in discovery._discover_provider_gates(root, "discovery-text")
                         if g.get("name") == provider]
            except Exception:
                gates = []
        operational = {"trackRecord": track_block, "fellBackTo": _mc_fellback(root, card_id),
                       "circuit": circuit, "discoveryGates": gates}

        # ROLES strip: routing positions + judged + discovery-gate (the exhaustive vocabulary)
        roles: list[dict] = []
        for role_name, rdef in sorted((model_routing.routing_show(root).get("roles") or {}).items()):
            primary = rdef.get("primary")
            if isinstance(primary, dict) and primary.get("card") == card_id:
                roles.append({"kind": "routed", "position": "primary", "role": role_name})
            for i, fb in enumerate(rdef.get("fallbacks") or []):
                if isinstance(fb, dict) and fb.get("card") == card_id:
                    roles.append({"kind": "routed", "position": f"fallback-{i + 1}", "role": role_name})
        if judged:
            roles.append({"kind": "judged", "judged": judged, "usefulRate": useful_rate})
        if provider:
            roles.append({"kind": "discovery-gate", "provider": provider,
                          "available": bool(gates and gates[0].get("available"))})

        # health pill (D3): ONLY on real signals — never fabricated
        health = None
        if circuit and circuit.get("state") == "open":
            health = "circuit open"
        elif useful_rate is not None and useful_rate >= 0.7 and judged >= 5:
            health = "healthy"  # circuit closed/absent + strong track record

        return {"cardId": card_id, "found": True, "header": header, "declared": declared,
                "external": external, "measured": measured, "operational": operational,
                "roles": roles, "health": health}
    except Exception as exc:  # calm-degrade: a broken source must never 500 the card
        return {**empty, "error": f"{type(exc).__name__}"}


# -- GUI-RG2: fallback as an ORDERED VERTICAL SEQUENCE (never a free graph) -----
# Trigger conditions are DERIVED from the real walk, never invented:
#  * spawn (SPEC-165 R7/R8, harness.py): _hop_usable circuit gate + _classify_spawn_
#    failure(runtimeLimits pattern lists) => rate-limit/auth/quota;
#  * chat (SPEC-166, chat_engines): build_engine construction failure + classify_turn_
#    failure (the SAME runtimeLimits keys).
# The map below is the ONE derivation source (rg23-2 asserts it): a runtimeLimits key
# present => that class can fire; absent => omitted (the walk cannot classify what the
# executor never declares).
_FB_LIMIT_CLASSES = (("rateLimitPatterns", "rate-limit"),
                     ("authFailurePatterns", "auth"),
                     ("quotaFailurePatterns", "quota"))
# chat-context roles: build_engine/midrun walk THESE on a CONSTRUCTION failure
# (binary/key missing) as well. == chat_engines.PROMPT_BY_ROLE keys (the roles that
# converse through a chat prompt). ponytail: pinned set; re-sync if PROMPT_BY_ROLE grows.
_FB_CHAT_ROLES = {"router", "route-overseer", "ui-overseer"}


def _fb_executor_triggers(root: Path, executor: str | None) -> list[str]:
    """Trigger classes the walk detects on THIS executor's hop, derived from real
    config: the runtimeLimits pattern lists present (rate-limit/auth/quota) + the
    structural `circuit open` pre-spawn gate (_hop_usable, always). No pattern list ->
    that class is omitted (honest to what the executor declares)."""
    execs = (read_json(root / ".harness" / "routing" / "executors.json", {}) or {}).get("executors", {})
    limits = ((execs.get(executor) or {}).get("runtimeLimits") or {}) if isinstance(execs, dict) else {}
    out = [label for key, label in _FB_LIMIT_CLASSES if limits.get(key)]
    out.append("circuit open")  # structural: every hop is circuit-gated (async_runtime._circuit_ok)
    return out


def _fb_circuit(root: Path, executor: str | None) -> dict | None:
    """The EXECUTOR-level circuit state (labeled), reusing ui_runtime._circuits (the
    RG1 L4 source). None when this executor never tripped a breaker (no fabrication)."""
    for c in ui_runtime._circuits(root):
        if c.get("executor") == executor:
            return {"executor": executor, "label": f"executor-level: {executor}",
                    "state": c.get("state"), "failureCount": c.get("failureCount"),
                    "lastFailureReason": c.get("lastFailureReason")}
    return None


def fallbacks_snapshot(root: Path) -> dict:
    """GUI-RG2 fallback view feed: per ROLE, the ordered PRIMARY -> FALLBACK-n vertical
    sequence (the human-escalation terminator is the client-rendered ALWAYS-present chain
    end). Each level joins REAL signals only — executor-derived trigger conditions
    (_fb_executor_triggers, + `construction failure` for chat-context roles), the
    executor circuit, and the RG1 measured cost/latency + health (exact card-id join via
    models_card_snapshot, per DISTINCT card; omitted where absent, never fabricated).
    Calm-degrade to {roles: []} — never a 500. The routing chains come from routing_show
    (the SAME resolved routing /api/routing serves), so this is purely additive."""
    root = Path(root)
    try:
        from harness_lib import model_routing
        roles_show = model_routing.routing_show(root).get("roles") or {}
    except Exception as exc:
        return {"roles": [], "error": f"{type(exc).__name__}"}
    card_cache: dict[str, dict] = {}

    def _card(cid: str) -> dict:  # ponytail: one RG1 snapshot per DISTINCT card (view load)
        if cid not in card_cache:
            card_cache[cid] = models_card_snapshot(root, cid)
        return card_cache[cid]

    out_roles: list[dict] = []
    for role in sorted(roles_show):
        rdef = roles_show[role] or {}
        chain = [rdef.get("primary"), *(rdef.get("fallbacks") or [])]
        chain = [e for e in chain if isinstance(e, dict) and e.get("card")]
        chat_ctx = role in _FB_CHAT_ROLES
        levels: list[dict] = []
        for i, entry in enumerate(chain):
            cid = str(entry.get("card"))
            snap = _card(cid)
            engine = (snap.get("header") or {}).get("engine")
            executor = entry.get("executor") or engine
            triggers = _fb_executor_triggers(root, executor)
            if chat_ctx:
                triggers = triggers + ["construction failure"]  # SPEC-166 build_engine walk
            meas = ((snap.get("measured") or {}).get("chatTurns")) or {}
            cost = meas.get("costUsd") if meas else None
            latency = meas.get("durationS") if meas else None
            levels.append({
                "position": "primary" if i == 0 else f"fallback-{i}",
                "card": cid, "effort": entry.get("effort") or None,
                "executor": executor, "engine": engine,
                "accounting": (snap.get("header") or {}).get("accounting"),
                "triggers": triggers,
                "circuit": _fb_circuit(root, executor),
                "health": snap.get("health"),  # RG1 card health (non-fabricated) or None
                "cost": ({"median": cost["median"], "count": cost["count"]}
                         if isinstance(cost, dict) and cost.get("count") else None),
                "latency": ({"median": latency["median"], "count": latency["count"]}
                            if isinstance(latency, dict) and latency.get("count") else None),
            })
        out_roles.append({"role": role, "risk": rdef.get("risk"),
                          "description": rdef.get("description"),
                          "chatContext": chat_ctx, "levels": levels})
    return {"roles": out_roles}


# -- GUI-AC3/AC4: audit trail + incident detail (Phase 7 Activity) --------------
# Measure-honesty is LITERAL: every rendered state maps to ONE named real field.
# The hash-chain verifier and the causal-parent id are REUSED read-only from
# scripts/harness.py (T-HASHCHAIN / T-CAUSALPARENT) -- never reimplemented here.
_AUDIT_TAIL = 60  # causal-tree window; the chain is verified over the FULL log


def _events_raw(root: Path) -> tuple[list[dict], int]:
    """Raw (UNREDACTED) event rows + count of unparseable lines. The chain verifier
    must see the stored bytes -- pre-egress redaction would change a signed field's
    value and forge a false `broken`. Display rows get redacted separately below."""
    path = Path(root) / ".harness" / "runs" / "events.jsonl"
    rows: list[dict] = []
    skipped = 0
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return rows, skipped
    for ln in text.splitlines():
        if not ln.strip():
            continue
        try:
            row = json.loads(ln)
        except ValueError:
            skipped += 1
            continue
        if isinstance(row, dict):
            rows.append(row)
        else:
            skipped += 1
    return rows, skipped


def audit_snapshot(root: Path) -> dict:
    """GUI-AC3 audit trail. Chain status is COMPUTED tri-state by the REAL
    `harness.verify_event_chain` (with the durable ledger's C+ seal, mirroring
    repo_health event-chain-integrity): hashed rows + ok -> `intact`; a break ->
    `broken` + where; NO hash-chained (critical) rows in the log -> `unverifiable`
    -- the honest EXPECTED state for legacy rows, never a fabricated integrity badge.
    Events tail carries `parentEventId` (T-CAUSALPARENT) for the client causal tree;
    a parent outside the window is flagged, not synthesized. Calm-degrade, never 500."""
    root = Path(root)
    import harness  # lazy: loads after bind, mirrors repo_health (not circular)
    rows, skipped = _events_raw(root)
    hashed = [r for r in rows if isinstance(r.get("hash"), str)]
    ledger = read_json(root / ".harness" / "state" / "escalations.json", {}) or {}
    seal = ledger.get("chainSeal") if isinstance(ledger.get("chainSeal"), dict) else None
    checked_at = harness.now()
    if not hashed:
        chain = {"status": "unverifiable", "count": 0, "checkedAt": checked_at,
                 "firstBreakAt": None, "firstBreakEvent": None,
                 "reason": "no hash-chained (critical) rows in the log -- "
                           "legacy/non-critical events are not tamper-evident"}
    else:
        res = harness.verify_event_chain(rows, seal=seal)
        if res.get("ok"):
            chain = {"status": "intact", "count": res.get("chainLength", 0),
                     "checkedAt": checked_at, "firstBreakAt": None,
                     "firstBreakEvent": None, "reason": res.get("reason")}
        else:
            bidx = res.get("brokenAt")
            brow = rows[bidx] if isinstance(bidx, int) and 0 <= bidx < len(rows) else {}
            chain = {"status": "broken", "count": res.get("chainLength", 0),
                     "checkedAt": checked_at, "firstBreakAt": bidx,
                     "firstBreakEvent": brow.get("event"), "reason": res.get("reason")}
    tail = rows[-_AUDIT_TAIL:]
    tail_ids = {harness._event_id(r) for r in tail}
    events_out: list[dict] = []
    for r in tail:
        red = ui_events._redact_values(r)
        pid = r.get("parentEventId")
        events_out.append({
            "eventId": harness._event_id(r),
            "event": red.get("event"), "timestamp": red.get("timestamp"),
            "subject": red.get("subject"), "parentEventId": pid,
            "parentInWindow": bool(isinstance(pid, str) and pid in tail_ids),
            "hashed": isinstance(r.get("hash"), str),
        })
    return {"chain": chain, "events": events_out,
            "counts": {"total": len(rows), "hashed": len(hashed),
                       "shown": len(events_out), "skipped": skipped}}


def incident_detail_snapshot(root: Path, escalation_id: str) -> dict:
    """GUI-AC4 incident detail (progressive disclosure) for ONE escalation. Each
    block from a NAMED real source; absent -> None/[] (dim client-side, never
    fabricated). SUMMARY: the escalation record. TIMELINE: events joined by the
    escalation id (+ a NAMED-target subject; never the broad "self") and the causal
    `parentEventId` walk, provenance-labeled. STATE: the executor circuit when the
    record names an executor. SUSPECTS: real joins only -- records rows referencing
    the id + the commit sha the record carries. RESOLUTION: the resolve record.
    Calm-degrade to a not-found shell, never a 500."""
    root = Path(root)
    eid = str(escalation_id or "")
    import harness  # lazy: shared _event_id (id map must match append_event)
    state = read_json(root / ".harness" / "state" / "escalations.json", {}) or {}
    raised = state.get("raised") if isinstance(state.get("raised"), dict) else {}
    resolved_records = state.get("resolvedRecords") if isinstance(state.get("resolvedRecords"), dict) else {}
    rec = raised.get(eid) or resolved_records.get(eid)
    resolved = resolved_records.get(eid)
    empty = {"escalationId": eid, "found": False, "summary": None, "timeline": [],
             "state": None, "suspects": {"records": [], "commit": None}, "resolution": None}
    if not isinstance(rec, dict):
        return empty
    subject = str(rec.get("subject") or "self")
    status = "resolved" if isinstance(resolved, dict) else "pending"
    summary = {"id": rec.get("escalationId") or eid, "subject": subject,
               "reason": (str(rec.get("reason")).split("\n", 1)[0] if rec.get("reason") else None),
               "criticality": rec.get("criticality"), "failureClass": rec.get("failureClass"),
               "source": rec.get("source"), "suggestedProfile": rec.get("suggestedProfile"),
               "raisedAt": rec.get("raisedAt"), "status": status}

    rows, _ = _events_raw(root)
    by_id = {harness._event_id(r): r for r in rows}
    task_id = str(rec.get("taskId") or "")

    def _id_match(r: dict) -> bool:
        if str(r.get("escalationId") or "") == eid:
            return True
        if task_id and str(r.get("taskId") or "") == task_id:
            return True
        # subject join ONLY for a named target (self would be the whole log).
        return bool(subject != "self" and str(r.get("subject") or "") == subject
                    and r.get("escalationId"))

    timeline: dict[str, dict] = {}

    def _add(r: dict, prov: str) -> None:
        rid = harness._event_id(r)
        if rid not in timeline:
            red = ui_events._redact_values(r)
            timeline[rid] = {"eventId": rid, "event": red.get("event"),
                             "timestamp": red.get("timestamp"), "subject": red.get("subject"),
                             "parentEventId": r.get("parentEventId"), "provenance": prov}

    seeds = [r for r in rows if _id_match(r)]
    for r in seeds:
        _add(r, "id-match")
    starts = [r.get("parentEventId") for r in seeds]
    if isinstance(resolved, dict) and resolved.get("parentEventId"):
        starts.append(resolved.get("parentEventId"))
    out_of_window: list[dict] = []
    for pid in starts:
        cur, seen = pid, set()
        while isinstance(cur, str) and cur not in seen:
            seen.add(cur)
            par = by_id.get(cur)
            if par is None:
                if cur not in {x["parentEventId"] for x in out_of_window}:
                    out_of_window.append({"parentEventId": cur, "provenance": "causal",
                                          "outsideWindow": True})
                break
            _add(par, "causal")
            cur = par.get("parentEventId")
    timeline_list = sorted(timeline.values(), key=lambda e: str(e.get("timestamp") or ""))
    timeline_list += out_of_window

    executor = rec.get("executor")
    circuit = _fb_circuit(root, executor) if executor else None

    try:
        hits = records.search(root, eid, limit=8) if eid else []
    except Exception:
        hits = []
    # A suspect is ANOTHER record referencing the id -- the escalation's OWN durable
    # ledger row (source .../escalations.json) is the subject, not a suspect of itself.
    suspect_records = [r for r in hits
                       if not str(r.get("source") or "").endswith("escalations.json")]
    commit = (rec.get("commit") or rec.get("sha")
              or (resolved.get("commit") if isinstance(resolved, dict) else None))

    resolution = None
    if isinstance(resolved, dict):
        resolution = {"resolvedAt": resolved.get("resolvedAt"), "actor": resolved.get("actor"),
                      "parentEventId": resolved.get("parentEventId")}
    return {"escalationId": eid, "found": True, "summary": summary,
            "timeline": timeline_list, "state": circuit,
            "suspects": {"records": suspect_records, "commit": commit},
            "resolution": resolution}


# -- GUI-RG4/RG5: Roles x Resources access matrix + role card + declared/effective -
# Measure-honesty is LITERAL here: every rendered cell state maps to ONE named real
# field (`source`); a cell with no source is None and renders as `no source`
# client-side -- never a fabricated state. The five columns derive from real config;
# the spec's "Production" column has NO harness source, so it is legend-only, never a
# rendered column (typed deviation).
_AM_COLUMNS = (("repo-write", "Repository-write"), ("shell", "Shell"), ("web", "Web"),
               ("mcp", "MCP/External-APIs"), ("secrets", "Secrets"))
_AM_RISK_SET = {"medium", "high", "critical"}
_EVIDENCE_REL = ".harness/prompts/subagent-contract.md"
_EVIDENCE_BASE = ("HARNESS_RESULT", "Universal baseline expectations",
                  "Context discovery evidence")
_EVIDENCE_RISK = "Pre-implementation acceptance contracts"
_EVIDENCE_ALLOWLIST = "Resource allowlist grading (SPEC-143)"


def _am_cell(state: str, source: str, **extra: object) -> dict:
    return {"state": state, "source": source, **extra}


def _am_cells(role: str, agent_name: str | None, tools: set, te: dict,
              room_roles: set) -> dict:
    """Per (role, resource) -> {state, source} from ONE named field, or None (no
    source -> renders `no source`, honest). Sources: agent tool lists
    (.claude/agents/*.md), the SPEC-143 tokenEconomy allowlist, and the SPEC-146
    overseer-room approval. Secrets has no per-role authority declaration in this
    harness, so every secrets cell is None (the living proof of measure-honesty)."""
    src_tools = f"agent tools (.claude/agents/{agent_name}.md)" if agent_name else None
    cells: dict[str, dict | None] = {}
    if not agent_name:
        cells["repo-write"] = cells["shell"] = cells["web"] = None
    else:
        if not ({"Edit", "Write"} & tools):
            cells["repo-write"] = _am_cell("denied", src_tools)
        elif role in room_roles:
            cells["repo-write"] = _am_cell(
                "approval-required", "SPEC-146 overseer room approval (chat_engines.ROOM_ROLES)")
        else:
            cells["repo-write"] = _am_cell("allowed", src_tools)
        cells["shell"] = _am_cell("allowed" if "Bash" in tools else "denied", src_tools)
        cells["web"] = _am_cell(
            "allowed" if ({"WebFetch", "WebSearch"} & tools) else "denied", src_tools)
    allowed_mcp = te.get("allowedMcp")
    if isinstance(allowed_mcp, list) and allowed_mcp:
        cells["mcp"] = _am_cell("scoped", "tokenEconomy.allowedMcp", detail=list(allowed_mcp))
    elif isinstance(allowed_mcp, list):
        cells["mcp"] = _am_cell("denied", "tokenEconomy.allowedMcp (empty allowlist)")
    else:
        cells["mcp"] = None  # no tokenEconomy block -> no source
    cells["secrets"] = None  # no per-role secrets authority field exists in this harness
    return cells


def _am_evidence(prof: dict, te: dict, sections: set) -> dict:
    """The role's evidence contract as a POINTER: the exact subagent-contract.md
    section headers (verbatim, verified present in the live file) the role must
    satisfy -- never a paraphrased summary. Selection is derived from real fields:
    every role owes the base sections; a medium+risk role owes the pre-implementation
    acceptance contract; a role carrying an s2 allowlist owes the resource-grading
    section."""
    want = list(_EVIDENCE_BASE)
    if str(prof.get("risk") or "").lower() in _AM_RISK_SET:
        want.append(_EVIDENCE_RISK)
    if te.get("allowedSkills") is not None or te.get("allowedMcp") is not None:
        want.append(_EVIDENCE_ALLOWLIST)
    cited = [s for s in want if s in sections]  # only cite headers really in the file
    return {"pointer": _EVIDENCE_REL, "sections": cited, "present": bool(sections)}


def _am_hop(hop: object) -> dict | None:
    if not isinstance(hop, dict) or not hop.get("card"):
        return None
    return {"card": hop.get("card"), "executor": hop.get("executor"),
            "effort": hop.get("effort")}


def access_matrix_snapshot(root: Path) -> dict:
    """GUI-RG4/RG5 feed for /api/access-matrix: a Roles x Resources access matrix
    plus, per role, a card (raw spawn + reused RG2 chain strip + s2 allowlists +
    capability supportState + evidence-contract pointer) and the declared-vs-
    effective routing policy (the REAL SPEC-165 resolve_role + circuit gates).

    Read-only; calm-degrades to {roles: [], columns: [...]} -- never a 500."""
    root = Path(root)
    columns = [{"key": k, "label": lbl} for k, lbl in _AM_COLUMNS]
    try:
        from harness_lib import chat_engines, model_routing
        from harness_lib.agent_parity import capability_support_state
        from harness_lib.agent_parity_vendors import collect_claude_agents
        profiles = model_routing._task_profiles(root)
        agents = {a.get("name"): a for a in collect_claude_agents(root) if a.get("name")}
        caps = read_json(root / ".harness" / "capabilities.json", {}) or {}
        routing = model_routing._load_routing(root)
        active = routing.get("activeProfile") or model_routing.CANONICAL
        active_roles = ((routing.get("profiles") or {}).get(active) or {}).get("roles") or {}
        circuits = {c.get("executor"): c for c in ui_runtime._circuits(root)}
        fb_levels = {r["role"]: r.get("levels") or []
                     for r in (fallbacks_snapshot(root).get("roles") or [])}
        sections = _am_evidence_sections(root)
        room_roles = set(chat_engines.ROOM_ROLES)
    except Exception as exc:  # a broken source must never 500 the panel
        return {"roles": [], "columns": columns, "error": f"{type(exc).__name__}"}

    out_roles: list[dict] = []
    for role in sorted(profiles):
        prof = profiles.get(role) or {}
        agent_name = ((prof.get("spawn") or {}).get("claude") or {}).get("agent")
        tools = set((agents.get(agent_name) or {}).get("tools") or [])
        te = prof.get("tokenEconomy") if isinstance(prof.get("tokenEconomy"), dict) else {}

        # the role's vendor = its resolved PRIMARY executor (for supportState legs)
        try:
            res = model_routing.resolve_role(root, role)
        except Exception:
            res = {"profile": model_routing.CANONICAL, "source": "canonical",
                   "primary": None, "fallbacks": []}
        vendor = ((res.get("primary") or {}).get("executor")) or model_routing.DEFAULT_EXECUTOR

        support: list[dict] = []
        skills = te.get("allowedSkills")
        if isinstance(skills, list):
            for s in skills:
                st = capability_support_state(caps, s, vendor)
                if st != "native":
                    support.append({"skill": s, "vendor": vendor, "state": st})

        card = {
            "spawn": (prof.get("spawn") or {}).get("claude"),  # raw, verbatim
            "tools": sorted(tools),
            "allowedSkills": skills,
            "allowedMcp": te.get("allowedMcp"),
            "supportStates": support,
            "evidenceContract": _am_evidence(prof, te, sections),
            "chain": fb_levels.get(role) or [],  # reuse the RG2 chain, no re-derive
            "vendor": vendor,
        }
        out_roles.append({
            "role": role, "risk": prof.get("risk"), "description": prof.get("description"),
            "agent": agent_name, "cells": _am_cells(role, agent_name, tools, te, room_roles),
            "card": card,
            "policy": _am_policy(res, active, active_roles.get(role), circuits),
        })
    return {"roles": out_roles, "columns": columns, "activeProfile": active,
            "playbooks": _am_playbooks(root)}


def _am_playbooks(root: Path) -> dict:
    """SPEC-170 W3: the playbook-registry hierarchy for Registry->Roles — every
    registered role with its extends edge, own playbooks, resolved chain and the
    lockfile's chainHash + per-file sha/updatedAt (Q6 tracking). Read-only over
    the canonical registry + lock; registry absent -> {"roles": []} (honest
    absence, never fabricated)."""
    try:
        from harness_lib import playbook_registry
        reg = playbook_registry.load(root)
        lock = read_json(root / ".harness" / "routing" / "playbook-registry.lock.json", {}) or {}
        lock_roles = lock.get("roles") or {}
        roles_out = []
        for role, entry in sorted((reg.get("roles") or {}).items()):
            chain = playbook_registry.resolve(role, reg)
            files = []
            for rel in chain:
                p = root / rel
                try:
                    stat = p.stat()
                    sha = hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()[:12]
                    upd = dt.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
                except OSError:
                    sha, upd = None, None  # dangling: verify() grades it; render dashes
                files.append({"path": rel, "sha": sha, "updatedAt": upd})
            roles_out.append({
                "role": role,
                "extends": (entry or {}).get("extends"),
                "ownPlaybooks": (entry or {}).get("playbooks") or [],
                "chain": chain,
                "chainHash": (lock_roles.get(role) or {}).get("chainHash"),
                "files": files,
            })
        return {"roles": roles_out, "unmanaged": reg.get("unmanaged") or [],
                "lockGeneratedAt": lock.get("generatedAt")}
    except Exception:  # a broken registry must never 500 the matrix
        return {"roles": []}


def _am_evidence_sections(root: Path) -> set:
    """The exact `## ` headers in subagent-contract.md (verbatim). Empty when the
    file is absent -> the card renders the pointer as `no source`, never a fake."""
    try:
        text = (root / _EVIDENCE_REL).read_text(encoding="utf-8")
    except OSError:
        return set()
    return {ln[3:].strip() for ln in text.splitlines() if ln.startswith("## ")}


def _am_policy(res: dict, active: str, raw_entry: object, circuits: dict) -> dict:
    """RG5 declared-vs-effective: DECLARED = the raw routing entry (verbatim) or the
    inherited task-profile default; EFFECTIVE = the first circuit-usable hop of the
    real resolve_role walk. One divergence row per real reason (inherited /
    temporarily-revoked+lastFailureReason). incident-override (failover) and
    environment restriction stay legend-only unless a real source is present."""
    raw = raw_entry if isinstance(raw_entry, dict) else None
    inherited = res.get("source") == "canonical" or raw is None
    if raw:
        declared = {"primary": _am_hop(raw.get("primary")),
                    "fallbacks": [_am_hop(f) for f in (raw.get("fallbacks") or [])],
                    "source": f"activeProfile:{active}"}
    else:
        declared = {"primary": _am_hop(res.get("primary")), "fallbacks": [],
                    "source": "canonical (task-profile default)", "inherited": True}
    hops = [h for h in [_am_hop(res.get("primary")), *(_am_hop(f) for f in (res.get("fallbacks") or []))]
            if h]

    def _usable(h: dict) -> bool:
        c = circuits.get(h.get("executor"))
        return not (isinstance(c, dict) and c.get("state") == "open")

    effective_primary = next((h for h in hops if _usable(h)), None)
    divergences: list[dict] = []
    if inherited and declared.get("primary"):
        divergences.append({"state": "inherited",
                            "reason": "resolved from the task-profile default "
                                      "(role has no entry in the active profile)"})
    dp = declared.get("primary") or {}
    c = circuits.get(dp.get("executor"))
    if isinstance(c, dict) and c.get("state") == "open":
        divergences.append({
            "state": "temporarily-revoked", "resource": "routing primary",
            "declared": _am_hopstr(dp), "effective": _am_hopstr(effective_primary),
            "reason": f"circuit open on {dp.get('executor')}: "
                      f"{c.get('lastFailureReason') or 'unknown'}",
            "failureCount": c.get("failureCount"),
            "at": c.get("openedAt") or c.get("at"),
        })
    return {"profile": res.get("profile"), "source": res.get("source"),
            "declared": declared, "effectivePrimary": effective_primary,
            "divergences": divergences}


def _am_hopstr(hop: dict | None) -> str | None:
    if not hop:
        return None
    s = f"{hop.get('card')}@{hop.get('executor')}"
    return s + (f" · {hop['effort']}" if hop.get("effort") else "")


class PanelServer(ThreadingHTTPServer):
    """Holds the shared per-process state: root, default chat engine, token, sessions."""

    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr: tuple[str, int], root: Path, engine: str | None, token: str) -> None:
        super().__init__(addr, PanelHandler)
        self.root = Path(root)
        ide_shard.prune(self.root)
        self.engine = engine  # the DEFAULT overseer engine every new session starts with
        self.token = token
        self.sessions = ui_panel.ChatSessions()
        # R24 per-session: SSE generation counter keyed by session id — a connect to
        # session B bumps only B's counter, so session A's stream keeps its cursor.
        self.sse_gen: dict[str, int] = {}
        self.sse_lock = threading.Lock()

    @property
    def bridge(self) -> ui_panel.ChatBridge | None:
        """Back-compat shim: the "main" session's bridge (or None if not yet created).
        The in-process scenario/e2e harness reaches the panel through this; live routes
        use self.sessions directly.
        # ponytail: keeps ~15 existing `server.bridge.*` test refs working unchanged."""
        return self.sessions.get("main")

    def handle_error(self, request: object, client_address: object) -> None:
        # A loopback panel/SSE client disconnecting (tab close, reset, broken
        # pipe) is routine — don't dump the stdlib's traceback for it.
        if isinstance(sys.exc_info()[1], ConnectionError):
            return
        super().handle_error(request, client_address)


class PanelHandler(BaseHTTPRequestHandler):
    server_version = "HarnessPanel/1.0"

    def log_message(self, *_args: object) -> None:  # keep stdout for the banner only
        pass

    # -- helpers ----------------------------------------------------------
    def _authed(self, parsed: object) -> bool:
        want = self.server.token  # type: ignore[attr-defined]
        got = self.headers.get("X-Harness-Token") or ""
        if not got:
            got = (parse_qs(parsed.query).get("token") or [""])[0]  # type: ignore[attr-defined]
        return bool(got) and secrets.compare_digest(got, want)

    def _send_json(self, code: int, payload: object) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionError):
            pass

    def _read_body(self) -> dict[str, object]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0:
                return {}
            data = self.rfile.read(length)
            parsed = json.loads(data.decode("utf-8"))
            return parsed if isinstance(parsed, dict) else {}
        except (ValueError, json.JSONDecodeError):
            return {}

    @property
    def root(self) -> Path:
        return self.server.root  # type: ignore[attr-defined]

    _VENDOR_TYPES = {".wasm": "application/wasm", ".js": "text/javascript; charset=utf-8",
                     ".scm": "text/plain; charset=utf-8", ".json": "application/json; charset=utf-8"}

    _VENDOR_FAMILIES = {"tree-sitter", "codemirror"}  # closed set; SPEC-147 inv 2

    def _send_vendor(self, rel: str) -> None:
        """Serve a provisioned vendor asset (tree-sitter WASM / CodeMirror ESM; auth
        already checked). First path segment must name an allowlisted family;
        path-traversal guarded; missing assets => 404 (run ./setup.sh)."""
        family, _, rest = rel.partition("/")
        if family not in self._VENDOR_FAMILIES:
            return self._send_json(404, {"error": "not found"})
        base = (self.root / "vendor" / family).resolve()
        try:
            target = (base / rest).resolve()
            target.relative_to(base)  # reject any '..' escape
        except (ValueError, OSError):
            return self._send_json(404, {"error": "not found"})
        if target.suffix not in self._VENDOR_TYPES or not target.is_file():
            return self._send_json(404, {"error": "asset not provisioned; run ./setup.sh (or setup.bat)"})
        try:
            data = target.read_bytes()
        except OSError:
            return self._send_json(404, {"error": "not found"})
        self.send_response(200)
        self.send_header("Content-Type", self._VENDOR_TYPES[target.suffix])
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=31536000, immutable")  # pinned by manifest
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionError):
            pass

    _WIKI_TYPES = {".md": "text/markdown; charset=utf-8"}  # wiki serves markdown only

    def _send_wiki(self, rel: str) -> None:
        """Serve a docs/wiki markdown page (auth already checked upstream). Cloned
        from _send_vendor's byte-mechanics with no family segment: path-confined
        under docs/wiki via .resolve() + relative_to(base) (rejects any '..'
        escape), suffix allowlisted (.md only), is_file/OSError => 404. Plus
        _send_dist's literal '..' pre-check. Cache-Control: no-cache -- wiki edits
        should show live, and this is NOT a content-hashed immutable asset."""
        if ".." in rel:  # wiki page paths never contain '..'; reject the traversal alias early
            return self._send_json(404, {"error": "not found"})
        base = (self.root / "docs" / "wiki").resolve()
        try:
            target = (base / rel).resolve()
            target.relative_to(base)  # reject any '..' escape
        except (ValueError, OSError):
            return self._send_json(404, {"error": "not found"})
        if target.suffix not in self._WIKI_TYPES or not target.is_file():
            return self._send_json(404, {"error": "not found"})
        try:
            data = target.read_bytes()
        except OSError:
            return self._send_json(404, {"error": "not found"})
        self.send_response(200)
        self.send_header("Content-Type", self._WIKI_TYPES[target.suffix])
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionError):
            pass

    # -- GUI-F0: the committed React bundle (ui/dist), served like _send_vendor --
    _DIST_TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
                   ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
                   ".map": "application/json; charset=utf-8", ".json": "application/json; charset=utf-8",
                   ".svg": "image/svg+xml", ".ico": "image/x-icon", ".png": "image/png",
                   ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
                   ".webp": "image/webp", ".woff": "font/woff", ".woff2": "font/woff2",
                   ".ttf": "font/ttf", ".otf": "font/otf", ".txt": "text/plain; charset=utf-8"}

    # Vite (base:'./') emits `src|href="./assets/<hashed>"`. The browser fetches those
    # sub-resources with no header, so carry the session token in the URL — same
    # discipline as PAGE's `/vendor/...?token=` (harness_ui_page.py).
    # ponytail: single-bundle F0 has no fonts/code-split, so rewriting the ./assets/
    # refs in index.html covers every request. If GUI-F1+ adds CSS url(font) or
    # dynamic-import chunks, those URLs live inside hashed files we can't rewrite —
    # solve then (e.g. a signed asset prefix), NOT a token cookie (that reopens CSRF
    # on the single write path).
    _DIST_ASSET_REF = re.compile(r'((?:src|href)=")(\./assets/[^"?]+)(")')

    def _send_dist(self, rel: str) -> None:
        """Serve a built React asset from ui/dist (auth already checked upstream).
        Path-confined under ui/dist via .resolve() (rejects any '..' escape);
        extension allowlisted; missing => 404 (falls back to nothing — index.html
        is the only route with a vanilla fallback)."""
        if ".." in rel:  # dist asset paths never contain '..'; reject the /assets/../index.html alias
            return self._send_json(404, {"error": "not found"})
        base = (self.root / "ui" / "dist").resolve()
        try:
            target = (base / rel).resolve()
            target.relative_to(base)  # reject any '..' escape
        except (ValueError, OSError):
            return self._send_json(404, {"error": "not found"})
        if target.suffix not in self._DIST_TYPES or not target.is_file():
            return self._send_json(404, {"error": "not found"})
        try:
            data = target.read_bytes()
        except OSError:
            return self._send_json(404, {"error": "not found"})
        self.send_response(200)
        self.send_header("Content-Type", self._DIST_TYPES[target.suffix])
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=31536000, immutable")  # content-hashed
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionError):
            pass

    def _send_dist_index(self) -> None:
        """Serve ui/dist/index.html with the SAME token/repo/root substitution as
        _send_page, plus a ?token= on each ./assets ref so the browser's un-headered
        sub-resource loads stay authed. No-cache: the token is per-session."""
        try:
            html = (self.root / "ui" / "dist" / "index.html").read_text(encoding="utf-8")
        except OSError:
            return self._send_page()  # unreadable bundle => vanilla, never an error
        token = self.server.token  # type: ignore[attr-defined]
        html = self._DIST_ASSET_REF.sub(
            lambda m: f"{m.group(1)}{m.group(2)}?token={token}{m.group(3)}", html)
        body = (html.replace("__HARNESS_TOKEN__", token)
                    .replace("__HARNESS_REPO__", self.root.name)
                    .replace("__HARNESS_ROOT__", json.dumps(str(self.root)))).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionError):
            pass

    # -- GET --------------------------------------------------------------
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        # Public IBM Plex font binaries are exempt from the session token: the CSS
        # references them via url(./ibm-plex-*.woff2) so the browser fetches them
        # with neither the ?token= rewrite (script/link only) nor the API header —
        # they 403'd and SIGNAL typography silently fell back in real sessions
        # (found by pw_ui_smoke, ui-fonts-403-token-gap). Fonts carry zero repo
        # data; everything else under /assets/ stays token-gated, and the
        # traversal guard in _send_dist still applies.
        _font_exempt = (parsed.path.startswith("/assets/")
                        and parsed.path.rsplit(".", 1)[-1] in ("woff", "woff2"))
        if not _font_exempt and not self._authed(parsed):
            return self._send_json(403, {"error": "forbidden: missing or invalid session token"})
        path = parsed.path
        if path == '/api/artifacts':
            from harness_lib import artifacts
            return self._send_json(200, artifacts.list_artifacts(self.root))
        if path == '/api/artifacts/file':
            from harness_lib import artifacts
            qs = parse_qs(parsed.query)
            target, bad = artifacts.resolve(self.root, (qs.get('path') or [''])[0])
            if target is None:
                return self._send_json(400, {'error': bad})
            if not target.is_file():
                return self._send_json(404, {'error': 'not a file'})
            try:
                with target.open('rb') as artifact_file:
                    data = artifact_file.read(artifacts.MAX_READ + 1)
            except OSError as exc:
                return self._send_json(404, {'error': f'{type(exc).__name__}: {exc}'})
            suffix = target.suffix.lower()
            if suffix in artifacts.IMAGE_EXTENSIONS:
                if len(data) > artifacts.MAX_READ:
                    return self._send_json(413, {'error': 'artifact exceeds the read limit'})
                self.send_response(200)
                self.send_header('Content-Type', self._DIST_TYPES[suffix])
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                try:
                    self.wfile.write(data)
                except (BrokenPipeError, ConnectionError):
                    pass
                return None
            return self._send_json(200, {
                'ok': True,
                'content': data[:artifacts.MAX_READ].decode('utf-8', errors='replace'),
            })
        if path in ("/", "/next"):  # FLIP (owner GO 2026-07-23, screen-parity reached):
            # the React GUI is now the DEFAULT at "/". D025 guard-rail preserved: if the
            # committed dist is absent (never happens in a normal checkout), fall back to
            # the mature vanilla panel — never an error in the user's face. "/next" stays
            # a working alias so old bookmarks/deep-links keep resolving.
            if (self.root / "ui" / "dist" / "index.html").is_file():
                return self._send_dist_index()
            return self._send_page()  # dist missing -> vanilla fallback (D025 guard-rail)
        if path == "/legacy":  # the mature vanilla panel, reachable during the transition
            return self._send_page()  # (retired once the React GUI proves itself in daily use)
        if path.startswith("/assets/"):  # GUI-F0: hashed React bundle assets (ui/dist)
            return self._send_dist(path[1:])
        if path.startswith("/vendor/"):  # local, token-gated static assets (tree-sitter WASM)
            return self._send_vendor(path[len("/vendor/"):])
        if path.startswith("/wiki/"):  # wiki screen: docs/wiki markdown pages (same guard as /vendor/)
            return self._send_wiki(path[len("/wiki/"):])
        if path == "/api/state":
            return self._send_json(200, ui_panel.state_snapshot(self.root))
        if path == "/api/tasks":  # A0 tasks board: derived read-only Kanban (tasks_board)
            return self._send_json(200, tasks_board.tasks_snapshot(self.root))
        if path == "/api/queue":  # B0 live work queue: WFs + stage chips (ui_queue)
            return self._send_json(200, ui_queue.queue_snapshot(self.root))
        if path == "/api/runtime":  # OP-delta pre-req: circuits/holds/locks (facts, redacted)
            return self._send_json(200, ui_runtime.runtime_snapshot(self.root))
        if path == "/api/events":  # api-events-endpoint: redacted event-log tail (WB5/OP3)
            qs = parse_qs(parsed.query)
            return self._send_json(200, ui_events.events_tail(
                self.root, limit=(qs.get("limit") or [None])[0],
                event=(qs.get("event") or [None])[0],
                workflow=(qs.get("workflow") or [None])[0]))
        if path == "/api/commits":  # M5.rec: validated commit timeline (ui_commits)
            qs = parse_qs(parsed.query)
            try:
                limit = int((qs.get("limit") or ["50"])[0])
            except ValueError:
                limit = 50
            return self._send_json(200, ui_commits.commits_snapshot(
                self.root, branch=(qs.get("branch") or [None])[0],
                q=(qs.get("q") or [None])[0], sha=(qs.get("hash") or [None])[0],
                limit=limit))
        if path == "/api/commit":  # M5.rec: capped + secret-redacted git show
            qs = parse_qs(parsed.query)
            return self._send_json(200, ui_commits.commit_detail(
                self.root, (qs.get("sha") or [""])[0]))
        if path == "/api/memory":  # M5.mem: scope×purpose sources, redacted previews
            return self._send_json(200, ui_memory.memory_snapshot(self.root))
        if path == "/api/memory/file":  # M5.mem: ONE registered source, redacted
            qs = parse_qs(parsed.query)
            return self._send_json(200, ui_memory.memory_file(
                self.root, (qs.get("id") or [""])[0]))
        if path == "/api/wiki":  # wiki screen: the docs/wiki subtree of the docs-tree inventory
            return self._send_json(200, {"pages": [r for r in docs_tree.collect(self.root)
                                                   if r["path"].startswith("docs/wiki/")]})
        if path == "/api/specs":  # SPEC-134: read-only SDD inventory, grouped by scope
            return self._send_json(200, ui_specs.specs_snapshot(self.root))
        if path == "/api/specs/file":  # SPEC-134: ONE spec body, closed to the inventory
            qs = parse_qs(parsed.query)
            return self._send_json(200, ui_specs.spec_file(
                self.root, (qs.get("path") or [""])[0]))
        if path == "/api/research":  # SPEC-135: read-only research-round gallery (research list inventory)
            return self._send_json(200, research_snapshot(self.root))
        if path == "/api/research/file":  # SPEC-135: ONE round body, closed to the inventory
            qs = parse_qs(parsed.query)
            return self._send_json(200, research_file(
                self.root, (qs.get("slug") or [""])[0]))
        if path == "/api/research/round":  # GUI-RS1: ONE round's source-lane view, closed to inventory
            qs = parse_qs(parsed.query)  # GUI-RS2: ?claims=1 ADDITIVELY attaches the claim matrix
            return self._send_json(200, research_round(
                self.root, (qs.get("slug") or [""])[0],
                claims=bool((qs.get("claims") or [""])[0])))
        if path == "/api/graph":  # graphs-screen (B3): provider registry + metrics + exploration (read-only)
            return self._send_json(200, graphs_snapshot(self.root))
        if path == "/api/capabilities":  # CAP.2: read-only skills+MCP inventory (mtime-cached in ui_panel)
            return self._send_json(200, ui_panel.capabilities_snapshot(self.root))
        if path == "/api/capabilities/file":  # CAP.2: ONE skill body, CLOSED to the snapshot inventory
            qs = parse_qs(parsed.query)
            return self._send_json(200, ui_panel.capability_file(
                self.root, (qs.get("id") or [""])[0], (qs.get("rel") or [None])[0]))
        if path == "/api/metrics":  # cached by cost-metrics.json mtime (all caching in ui_panel)
            return self._send_json(200, ui_panel.metrics_snapshot(self.root))
        if path == "/api/routing":  # SPEC-115 config view: cards + resolved routing + targets
            return self._send_json(200, ui_panel.routing_snapshot(self.root))
        if path == "/api/models/card":  # GUI-RG1: ONE card's 4-layer view, closed to the card inventory
            qs = parse_qs(parsed.query)
            return self._send_json(200, models_card_snapshot(self.root, (qs.get("id") or [""])[0]))
        if path == "/api/fallbacks":  # GUI-RG2: per-role ordered fallback sequence + trigger/circuit/cost joins
            return self._send_json(200, fallbacks_snapshot(self.root))
        if path == "/api/audit":  # GUI-AC3: hash-chain status (REAL verifier) + causal event tail
            return self._send_json(200, audit_snapshot(self.root))
        if path == "/api/incident":  # GUI-AC4: ONE escalation's incident detail (progressive disclosure)
            qs = parse_qs(parsed.query)
            return self._send_json(200, incident_detail_snapshot(self.root, (qs.get("id") or [""])[0]))
        if path == "/api/access-matrix":  # GUI-RG4/RG5: Roles x Resources matrix + role card + declared-vs-effective policy
            return self._send_json(200, access_matrix_snapshot(self.root))
        if path == "/api/experiments":  # SPEC-116: read-only experiment-lifecycle board
            return self._send_json(200, ui_panel.experiments_snapshot(self.root))
        if path == "/api/experiment-methods":  # method cards for the experiment-paper expand
            return self._send_json(200, ui_panel.experiment_methods(self.root))
        if path == "/api/composer":  # N2: closed vocabularies + derived DAG view (read-only)
            return self._send_json(200, ui_panel.composer_snapshot(self.root))
        if path == "/api/worker":  # SPEC-114 v6 drill-in: on-demand live worker output (read-only)
            qs = parse_qs(parsed.query)
            wf = (qs.get("wf") or [""])[0]
            worker = (qs.get("worker") or [""])[0]
            try:
                lines = max(1, min(1000, int((qs.get("lines") or ["200"])[0])))
            except ValueError:
                lines = 200
            return self._send_json(200, ui_panel.worker_detail(self.root, wf, worker, lines))
        if path == "/api/evidence":  # SPEC-129 v2 (UX-GA.3 phase 2): reviewer bundle drill-in —
            # the SAME collector `workflow evidence` uses (eb-4 parity), read-only,
            # handles-not-bodies; bad ids degrade to the /api/records error shape (eb-5).
            qs = parse_qs(parsed.query)
            wfid = (qs.get("workflow_id") or [""])[0]
            worker = (qs.get("worker_id") or [""])[0] or None
            try:
                return self._send_json(200, evidence_bundle.bundle(self.root, wfid, worker_id=worker))
            except Exception as exc:
                return self._send_json(200, {"error": f"{type(exc).__name__}: {exc}"})
        if path == "/api/records":
            qs = parse_qs(parsed.query)
            q = (qs.get("q") or [""])[0]
            kind = (qs.get("kind") or [""])[0] or None
            try:
                out = (records.search(self.root, q, kind=kind) if q.strip()
                       else records.recent(self.root, kind=kind))
            except Exception as exc:
                return self._send_json(200, {"error": f"{type(exc).__name__}: {exc}"})
            return self._send_json(200, out)
        if path == "/api/chat/sessions":  # SPEC-114 v11: active session list
            return self._send_json(200, self.server.sessions.list())  # type: ignore[attr-defined]
        if path == "/api/ws/file":  # SPEC-147 M2: read-only editor file load (confined)
            from harness_lib import ws_files
            qs = parse_qs(parsed.query)
            return self._send_json(200, ws_files.read_file(
                ide_shard.active_root(self.root), (qs.get("path") or [""])[0]))
        if path == "/api/ws/tree":  # SPEC-147 M3: one confined explorer level (lazy)
            from harness_lib import ws_files
            qs = parse_qs(parsed.query)
            return self._send_json(200, ws_files.list_dir(
                ide_shard.active_root(self.root), (qs.get("path") or [""])[0]))
        if path == "/api/ws/shard":
            return self._send_json(200, ide_shard.status(self.root))
        if path == "/api/ws/integrate":
            return self._send_json(200, ide_integrate.summary(self.root))
        if path == "/api/ws/integrate/file":
            qs = parse_qs(parsed.query)
            return self._send_json(200, integrate_file(
                self.root, (qs.get("path") or [""])[0]))
        if path == "/api/ws/integrate/gate":
            qs = parse_qs(parsed.query)
            return self._send_json(200, integrate_gate(
                self.root, (qs.get("name") or [""])[0]))
        if path == "/api/chat/diff":  # SPEC-147 inv 5: uncapped diff from the session ring
            qs = parse_qs(parsed.query)
            sid = (qs.get("session") or ["main"])[0]
            tid = (qs.get("id") or [""])[0]
            bridge = self.server.sessions.get(sid)  # type: ignore[attr-defined]
            full = bridge.diffs.get(tid) if bridge is not None else None
            if not full:
                return self._send_json(200, {"ok": False})
            return self._send_json(200, {"ok": True, "id": tid, **full})
        if path == "/api/chat/stream":
            return self._stream_chat(parsed)
        if path == "/api/lsp":  # ide-lsp Lane A: RFC6455 upgrade -> pylsp bridge (same
            from harness_lib import lsp_ws  # token, same port; auth already enforced above)
            return lsp_ws.serve_ws(self, ws_root=ide_shard.active_root(self.root))
        return self._send_json(404, {"error": "not found"})

    # -- POST -------------------------------------------------------------
    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if not self._authed(parsed):
            return self._send_json(403, {"error": "forbidden: missing or invalid session token"})
        body = self._read_body()
        path = parsed.path
        if path == "/api/compile":  # N2 K1: read-shaped validate-only compile — writes
            # nothing, NOT an ACTIONS entry, builds no subcommand argv. compile_candidate
            # rejects any profile/taskProfile outside the closed set BEFORE compiling.
            return self._send_json(200, ui_panel.compile_candidate(
                self.root, body.get("profile"), body.get("task"), body.get("branches")))
        if path == "/api/action":
            action = str(body.get("action") or "")
            params = body.get("params") if isinstance(body.get("params"), dict) else {}
            return self._send_json(200, ui_panel.run_action(self.root, action, params))
        if path == "/api/lint":  # SPEC-147 inv 9: read-shaped ruff-as-a-service
            from harness_lib import ws_files
            return self._send_json(200, ws_files.lint_content(
                ide_shard.active_root(self.root), body.get("path"), body.get("content")))
        if path == "/api/format":  # SPEC-147 v3: ruff format (read-shaped; writes nothing)
            from harness_lib import ws_files
            return self._send_json(200, ws_files.format_content(
                ide_shard.active_root(self.root), body.get("path"), body.get("content")))
        if path == "/api/pick-folder":  # R32: server-side native dialog (loopback-local)
            return self._send_json(200, {"path": ui_panel.pick_folder()})
        if path == "/api/chat/send":
            server = self.server  # type: ignore[attr-defined]
            sid = str(body.get("session") or "main")
            bridge = server.sessions.ensure(sid, self.root, engine=server.engine)
            ok = bridge.send(str(body.get("line") or ""))
            return self._send_json(200, {"ok": ok})
        if path == "/api/chat/stop":  # ⏹: stop the CURRENT turn (flag file → engine watcher)
            server = self.server  # type: ignore[attr-defined]
            bridge = server.sessions.get(str(body.get("session") or "main"))
            return self._send_json(200, {"ok": bool(bridge and bridge.stop_turn())})
        if path == "/api/chat/upload":  # attachments: browser file → disk → @mention path
            return self._send_json(200, ui_panel.save_upload(self.root, body))
        if path == "/api/chat/restart":  # restart THIS session in place — no engine
            server = self.server  # type: ignore[attr-defined]   (engine is /config-only now)
            sid = str(body.get("session") or "main")
            server.sessions.restart(sid, self.root)
            return self._send_json(200, {"ok": True})
        if path == "/api/chat/new":  # create a session on the overseer default engine
            server = self.server  # type: ignore[attr-defined]
            sid = server.sessions.new(self.root, engine=server.engine)
            entry = next((s for s in server.sessions.list() if s["id"] == sid), {})
            return self._send_json(200, {"id": sid, "label": entry.get("label", sid)})
        if path == "/api/chat/close":  # stop + remove a session (frees its subprocess)
            server = self.server  # type: ignore[attr-defined]
            ok = server.sessions.close(str(body.get("session") or ""))
            return self._send_json(200, {"ok": ok})
        return self._send_json(404, {"error": "not found"})

    # -- SSE: drain one session's chat bridge until the client disconnects ----
    def _stream_chat(self, parsed: object) -> None:
        # R22: opening the page (this SSE connect) boots the session's REPL, so the
        # banner lines + first `ready` event flow immediately — no manual Restart.
        # start() is idempotent under bridge._lock; sse_lock is a different lock and
        # is released before the stream loop (same pattern as POST /send).
        server = self.server  # type: ignore[attr-defined]
        sid = (parse_qs(parsed.query).get("session") or ["main"])[0] or "main"  # type: ignore[attr-defined]
        bridge = server.sessions.ensure(sid, server.root, engine=server.engine)
        with server.sse_lock:
            # R24 per-session: bump ONLY this session's generation. Opening session B
            # leaves sse_gen["main"] untouched, so session A's loop keeps streaming —
            # per-session single-reader (last tab of THAT session wins), not global.
            my_gen = server.sse_gen.get(sid, 0) + 1
            server.sse_gen[sid] = my_gen
        # SSE is a terminal response — once it ends (client disconnect) do NOT let
        # handle() loop back to read another request on the aborted keep-alive
        # socket (that read raises ConnectionAbortedError and dumps a traceback).
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        last_beat = time.monotonic()
        try:
            # R24 v2 (flake root cause 2026-07-11): delivery is cursor-based and
            # NON-destructive — each connection reads history since its own cursor,
            # so a superseded (zombie) handler can no longer dequeue-and-drop items
            # the way the shared-queue drain did. Replay = cursor 0; the bridge
            # resets cursors past a restart so a new session replays in full.
            cursor = 0
            while True:
                if server.sse_gen.get(sid) != my_gen:
                    return  # a newer tab of THIS session took over; cursors are per-reader
                items, cursor = bridge.read_since(cursor, timeout=0.5)
                for item in items:
                    self.wfile.write(f"data: {json.dumps(item)}\n\n".encode("utf-8"))
                if items:
                    self.wfile.flush()
                if time.monotonic() - last_beat > HEARTBEAT_S:
                    self.wfile.write(b": heartbeat\n\n")  # detects disconnect too
                    self.wfile.flush()
                    last_beat = time.monotonic()
        except (BrokenPipeError, ConnectionError, OSError):
            return  # client went away — stop streaming (R27: no client, no stream)

    def _send_page(self) -> None:
        # __HARNESS_REPO__ = this repo's basename, so the onboarding "este repo" option
        # and header chip can name it without a round-trip (same pattern as the token).
        # __HARNESS_ROOT__ = the full server root path (R33: "este repo" shows a pwd);
        # json.dumps so Windows backslashes stay a valid JS string literal.
        body = (PAGE.replace("__HARNESS_TOKEN__", self.server.token)  # type: ignore[attr-defined]
                    .replace("__HARNESS_REPO__", self.root.name)
                    .replace("__HARNESS_ROOT__", json.dumps(str(self.root)))).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionError):
            pass


def make_server(root: Path, port: int, engine: str | None,
                token: str | None = None) -> tuple[PanelServer, str]:
    """Build the loopback server (port 0 = ephemeral, for tests). Returns (server, token)."""
    token = token or secrets.token_urlsafe(24)
    return PanelServer(("127.0.0.1", port), root, engine, token), token


def serve(root: Path, port: int = 8787, engine: str | None = None,
          open_browser: bool = True, exit_after: float | None = None) -> int:
    # SPEC-147 inv 4 (zero-touch): reconcile vendor families before serving.
    # Satisfied = no network, ~ms; failure logs + degrades, never blocks the panel.
    try:
        from setup_highlight import ensure_vendor
        ensure_vendor(root)
    except Exception as exc:  # noqa: BLE001
        print(f"vendor bootstrap skipped ({exc}); panel will degrade", flush=True)
    server, token = make_server(root, port, engine)
    actual = server.server_address[1]
    atexit.register(server.sessions.stop_all)
    from harness_lib import lsp_ws  # ide-lsp Lane A: kill the single pylsp child at exit
    atexit.register(lsp_ws.shutdown)
    # svc-autostart-owners: declared autoStart:["ui"] services live exactly as
    # long as this panel process — ensured after bind, stopped at exit (plus
    # the status() reap safety net for hard kills).
    from harness_lib import services as services_lib
    started = services_lib.ensure_autostart(root, "ui")
    for row in started:
        print(f"service {row.get('name')}: {row.get('status')}", flush=True)
    atexit.register(services_lib.stop_owned, root)
    url = f"http://127.0.0.1:{actual}/?token={token}"
    print(f"Panel: {url}", flush=True)
    if (root / "ui" / "dist" / "index.html").is_file():  # GUI-F0 React preview (default flips at parity)
        print(f"React preview: http://127.0.0.1:{actual}/next?token={token}", flush=True)
    print("  (loopback only; token required on every route; Ctrl+C to stop)", flush=True)
    if open_browser:  # R25: the token is minted here, so auto-open lives here (ui.bat can't)
        try:
            webbrowser.open(url)
        except Exception:
            pass  # headless / no default browser — the printed URL still works
    if exit_after and exit_after > 0:
        # A hard-killed parent runs no `finally` and no atexit hook, so a panel spawned
        # BY a test outlives the run that started it. Measured 2026-07-24: two servers
        # spawned by pw_ui_smoke on 2026-07-22 were still listening two days later,
        # ~30s CPU each, holding their ephemeral ports. The cleanup below is correct and
        # simply never got the chance to run -- no userspace cleanup does, under SIGKILL.
        # A self-imposed ceiling is the only bound that survives the parent's death, and
        # it is opt-in precisely so the OWNER's panel (ui.bat, no flag) can never be
        # touched by it; a reaper matching on argv could not make that promise.
        # shutdown(), never os._exit: the finally below and the atexit reapers still run,
        # so the autostart services go down with the panel exactly as on a clean stop.
        stop = threading.Timer(exit_after, server.shutdown)
        stop.daemon = True  # never hold the process open waiting for its own deadline
        stop.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.sessions.stop_all()
        server.shutdown()
        server.server_close()
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="SPEC-114 supervision panel (loopback)")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--engine", choices=["manual", "claude", "codex"], default=None,
                    help="Chat-tab engine override; omit to use saved chat prefs (default claude)")
    ap.add_argument("--no-open", action="store_true", help="Do not auto-open the browser")
    ap.add_argument("--exit-after-seconds", type=float, default=None,
                    help="Stop serving after N seconds (for spawned/test panels, so a "
                         "hard-killed parent cannot orphan this process); omit = serve forever")
    args = ap.parse_args(argv)
    return serve(Path(__file__).resolve().parent.parent, args.port, args.engine,
                 open_browser=not args.no_open, exit_after=args.exit_after_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
