#!/usr/bin/env python3
"""Create a clean release ZIP for the Universal Agent Harness.

This script is intentionally dependency-free. It removes runtime/generated
artifacts before zipping so releases do not leak local Python caches, logs,
active workflow packets, Graphify output, or local agent settings.
"""
from __future__ import annotations

import argparse
import shutil
import zipfile
from pathlib import Path

try:
    import release_integrity
except Exception:  # pragma: no cover - packaging must stay dependency-free
    release_integrity = None

try:
    from harness_lib import protected_files, fixture_liveness
except Exception:  # pragma: no cover - packaging must stay dependency-free
    protected_files = None
    fixture_liveness = None

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXCLUDES = {
    '.git',
    '.venv',
    '__pycache__',
    '.mypy_cache',
    '.pytest_cache',
    '.ruff_cache',
    'node_modules',
    'graphify-out',
}
FORBIDDEN_SUFFIXES = {'.pyc', '.pyo', '.log', '.jsonl'}
ALLOWED_JSONL_FILES = {'release/slsa-provenance.intoto.jsonl'}
FORBIDDEN_NAMES = {'.mcp.json', 'settings.local.json'}
FORBIDDEN_ROOT_TEMP_PREFIXES = ('tmp-async',)



def assert_protected_files_current() -> None:
    if protected_files is None:
        return
    errors = protected_files.compare_snapshot(ROOT)
    if errors:
        joined = "; ".join(errors[:10])
        raise SystemExit(f"Refusing to package with protected-file drift: {joined}")


def scrub_fixture_executors() -> list[str]:
    removed: list[str] = []
    path = ROOT / '.harness' / 'routing' / 'executors.json'
    if not path.exists():
        return removed
    try:
        import json
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return removed
    executors = data.get('executors') if isinstance(data, dict) else None
    if not isinstance(executors, dict):
        return removed
    changed = False
    for name in ['fixture-async', 'fixture-async-slow']:
        if name in executors:
            executors.pop(name, None)
            removed.append(f'.harness/routing/executors.json:{name}')
            changed = True
    if changed:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline="\n")
    return removed

def clean() -> list[str]:
    removed: list[str] = []
    if fixture_liveness is not None:
        removed.extend(fixture_liveness.cleanup_transient_market_fixture_files(ROOT))
    removed.extend(scrub_fixture_executors())
    for path in list(ROOT.rglob('__pycache__')):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
            removed.append(str(path.relative_to(ROOT)))
    for path in list(ROOT.rglob('*')):
        if not path.exists() or path.is_dir():
            continue
        rel = path.relative_to(ROOT)
        parts = set(rel.parts)
        if (path.suffix in FORBIDDEN_SUFFIXES and str(rel) not in ALLOWED_JSONL_FILES) or path.name in FORBIDDEN_NAMES or (path.parent == ROOT and path.name.startswith(FORBIDDEN_ROOT_TEMP_PREFIXES) and path.suffix == '.py'):
            path.unlink(missing_ok=True)
            removed.append(str(rel))
        elif rel.match('.harness/workflows/active/WF-*/*'):
            if path.name != '.gitkeep':
                path.unlink(missing_ok=True)
                removed.append(str(rel))
        elif rel.match('.harness/runtime/executor-circuit-*.json') or rel.match('.harness/runs/*'):
            path.unlink(missing_ok=True)
            removed.append(str(rel))
    for path in [ROOT / 'graphify-out', ROOT / '.harness' / 'state-store']:
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
            removed.append(str(path.relative_to(ROOT)))
    active = ROOT / '.harness' / 'workflows' / 'active'
    if active.exists():
        for wf in list(active.glob('WF-*')):
            if wf.exists():
                shutil.rmtree(wf, ignore_errors=True)
                removed.append(str(wf.relative_to(ROOT)))
        (active / '.gitkeep').parent.mkdir(parents=True, exist_ok=True)
        (active / '.gitkeep').touch()
    return removed


def should_include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in DEFAULT_EXCLUDES for part in rel.parts):
        return False
    if (path.suffix in FORBIDDEN_SUFFIXES and str(rel) not in ALLOWED_JSONL_FILES) or path.name in FORBIDDEN_NAMES:
        return False
    if path.parent == ROOT and path.name.startswith(FORBIDDEN_ROOT_TEMP_PREFIXES) and path.suffix == '.py':
        return False
    if rel.match('.harness/workflows/active/WF-*/*'):
        return False
    if rel.match('.harness/runtime/executor-circuit-*.json') or rel.match('.harness/runs/*') or rel.match('.harness/state-store/*'):
        return False
    if release_integrity is not None:
        # ONE predicate, never a second derivation from the raw tuples: re-deriving it
        # here is how the ZIP and the inventory drifted apart (2026-07-24).
        if release_integrity.is_private(rel.as_posix()):
            return False
    return True


def make_zip(output: Path) -> int:
    output = output.resolve()
    if output.exists():
        output.unlink()
    count = 0
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(ROOT.rglob('*')):
            if path == output or not should_include(path):
                continue
            if path.is_file():
                zf.write(path, path.relative_to(ROOT))
                count += 1
    return count


def main() -> int:
    parser = argparse.ArgumentParser(description='Create a clean harness release ZIP')
    parser.add_argument('output', help='Output zip path')
    parser.add_argument('--no-clean', action='store_true', help='Do not delete generated artifacts before packaging')
    args = parser.parse_args()
    if release_integrity is None:
        raise SystemExit('release_integrity unavailable: refusing to package without the private-content excludes')
    removed = [] if args.no_clean else clean()
    assert_protected_files_current()
    if release_integrity is not None:
        release_integrity.generate()
    count = make_zip(Path(args.output))
    print(f'Packaged {count} files into {args.output}')
    if removed:
        print(f'Removed {len(removed)} generated artifact(s) before packaging')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
