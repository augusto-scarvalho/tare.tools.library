# Codex Handoff Compatibility Wrapper

Codex should read `AGENT_HANDOFF.md` and the canonical handoff under `.harness/handoff/`.

Do not store Codex-specific task state here. The core harness must remain executor-agnostic.
