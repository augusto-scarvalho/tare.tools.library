# Universal Agent Harness

A reusable, agent-agnostic harness for running coding agents such as Codex, Claude Code, or future executors against any software project.

The harness provides:

- canonical project/task state under `.harness/`;
- compact handoffs for interrupted or continued work;
- task-profile classification and spawn profiles per agent/model/effort;
- validation gates and coverage policy configurable per project;
- map-reduce / fork-join workflows for tasks larger than one context window;
- compatibility adapters for Codex and Claude Code.

It is not tied to any language, framework, product, architecture, or deployment target: greenfield projects, existing repositories, monorepos, libraries, and infrastructure or documentation projects can all adopt it.

## First adoption steps

1. Edit `.harness/project.json`.
2. Add or adapt tasks in `tasks/`.
3. Configure validation and coverage policy in `.harness/project.json` when the project has executable checks.
4. Run `python scripts/harness.py status`.
5. Run `python scripts/harness.py handoff --task "describe the next task"`.
6. Spawn the chosen executor: `python scripts/harness.py spawn-command --executor generic|codex|claude --task "..."`.

See `docs/PROJECT_ADOPTION_GUIDE.md` for details, `docs/OPERATOR_GUIDE.md` for the practical day-to-day loop, and `docs/HARNESS_ARCHITECTURE.md` for layer diagrams and the supervision model.

## Optional: syntax highlighting

Native, multi-language syntax highlighting for the CLI and the supervision panel is an **opt-in** extra — the core stays zero-dependency and runs identically without it. Run the one-time bootstrap:

```bash
./setup.sh        # macOS/Linux
setup.bat         # Windows
```

It creates the `.venv` (via `uv`) if missing, installs the pinned highlight deps (`requirements-highlight.txt`), and fetches + `sha256`-verifies the tree-sitter WASM grammars into a gitignored `vendor/tree-sitter/` (only the pinned `manifest.json` is committed; the ~21 MB of grammars never enter git). Terminal output colorizes on a real TTY (set `HARNESS_COLOR=always` to force, `NO_COLOR=1` to disable); the panel highlights code on demand (only visible lines). Skip it entirely and everything degrades to plain text.

## Validation

The harness validates itself with language-agnostic gates; adopted projects add real build/lint/test/coverage commands in `.harness/project.json`.

```bash
python scripts/harness-test.py smoke
python scripts/harness-test.py spec-pack
python scripts/harness-test.py product-release --no-project-commands
python scripts/harness-test.py soak --no-project-commands
python scripts/harness-test.py --fixture <name>   # targeted deep fixtures
python scripts/harness-test.py --clean-fixtures
```

Coverage is disabled by default because the template is stack-agnostic; see `testing/COVERAGE_POLICY.md` and `docs/AGENT_TESTING_STRATEGY.md`. The universal quality/security baseline lives in `specs/00-universal/` and applies to every non-trivial task; validate it with `python scripts/harness-test.py spec-pack`. The full verification & validation plan — which gate/fixture proves which capability, plus the latest executed results — is `docs/VV_PLAN.md`.

## Workflows for large tasks

Map-reduce and fork-join packet workflows decompose work that would exceed a single context window. They are read-only by default; parallel source edits require the controlled-write track (approval token, path locks, isolated workspaces, merge plan, rollback). Durable async execution (`workflow start/await/collect`), token budgeting (`workflow token-audit`), tracing (`workflow trace`), and state-store mirroring (`workflow state`) are built in.

```bash
python scripts/harness.py workflow suggest --task "Review the whole repository"
python scripts/harness.py workflow execute --profile repository-review --task "..." --executor claude
```

See `docs/AGENTIC_WORKFLOWS.md`, `docs/WORKFLOW_OPERATIONS_RUNBOOK.md`, `docs/CONTROLLED_PARALLEL_WRITES.md`, and `docs/WORKFLOW_TOKEN_ECONOMICS.md`.

## Structural discovery (Graphify)

Graphify is the mandatory first-pass structural discovery layer for non-trivial repository search. Build the offline code AST graph with `python scripts/harness.py graph-build-code-ast`, then read `graphify-out/GRAPH_REPORT.md` before broad searches. Optional Gemini API enrichment is opt-in, text/image-only, free-tier-only. See `docs/GRAPHIFY_INTEGRATION.md`.

## Releasing

```bash
python scripts/harness-test.py product-release --no-project-commands
python scripts/release_integrity.py generate   # SBOM, checksums, attestation, provenance
python scripts/package-release.py <output.zip>
```

See `docs/RELEASE_INTEGRITY.md`.

## Directory indexes

Directory-level guidance uses semantic file names instead of nested README files: `specs/SPECS.md`, `tasks/TASKS.md`, `schemas/SCHEMAS.md`, `testing/TESTING.md`, `.harness/HARNESS.md`. The harness runtime modules live in `scripts/harness_lib/`.

## Runtime portability

The harness depends only on a project/operator-managed Python 3 interpreter on PATH (or `HARNESS_PYTHON`) — no specific executor, OS, or shell. The template default executor is `generic`; set `activeExecutor` in `.harness/runtime/executor-state.json` (copy the `.example` file) or pass `--executor` explicitly. See `docs/RUNTIME_PORTABILITY.md`.

## Content hygiene

Keep the reusable harness core free of project-specific domain content, local runtime state, generated logs, and dated audit reports (`docs/HARNESS_CONTENT_GUIDE.md`). Open template debt is tracked in `docs/HARNESS_TECHNICAL_DEBT.md`; history lives in the records ledger (`python scripts/harness.py records recent`).
