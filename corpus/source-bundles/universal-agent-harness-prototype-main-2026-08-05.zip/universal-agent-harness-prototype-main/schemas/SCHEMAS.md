# Schemas Directory

This directory stores optional machine-readable contracts used by the harness or the adopted project.

The universal harness includes informational schemas for:

- `schemas/harness-result.schema.json` — expected structure of `HARNESS_RESULT` returned by agents;
- `schemas/validation-policy.schema.json` — expected shape of validation, coverage, and knowledge-graph policy configuration.

Adopted projects may add API schemas, event schemas, data schemas, config schemas, or interface contracts here.

## Usage rules

- Keep schemas stack-agnostic unless the file is explicitly project-specific.
- Validate JSON/YAML syntax with `spec-pack` when schema files exist.
- Treat schemas that define public contracts as review-sensitive changes.
- Link schemas from specs/tasks when they affect acceptance criteria or validation.
- Do not store generated or environment-specific schema dumps unless they are intentionally versioned contracts.

## Knowledge graph policy

`schemas/validation-policy.schema.json` also documents the optional `knowledgeGraph` block used by Graphify. Generated graph outputs remain outside schemas unless a project explicitly promotes them to versioned contracts.

- `workflow.schema.json` — workflow packet shape.
- `worker-result.schema.json` — compact worker output for map-reduce/fork-join.
- `reduce-result.schema.json` — reducer/join synthesis output.
## Workflow schemas

The workflow schemas define the packet manager contract:

- `workflow.schema.json` describes workflow packets, lifecycle state, worker state, split strategy, limits and policy.
- `worker-result.schema.json` describes compact worker output for map-reduce/fork-join workers.
- `reduce-result.schema.json` describes reducer synthesis output and recommended follow-up tasks.

Runtime validation in `scripts/harness.py` enforces the critical subset without requiring external schema libraries. Projects may add stricter JSON Schema validation in their own gates.

## Workflow schema validation notes

Workflow runtime validation uses optional JSON Schema support when the `jsonschema` Python package is available, with manual validation as a fallback. Critical runtime semantics are enforced in code even without the optional dependency: worker id/workflow id matching, terminal status handling, output-size budgets, high/blocker source evidence, Graphify source verification, and reducer status calculation from `done|partial|blocked|failed|missing|invalid` worker states.

## Reviewer result schema

`schemas/reviewer-result.schema.json` defines the optional post-reduce `REVIEWER_RESULT` used by high-risk workflow profiles before finalization.

See `docs/WORKER_RESULT_EXAMPLES.md` for valid worker output examples.

## Controlled write schemas

- `schemas/workflow-locks.schema.json` validates controlled write lock files.
- `schemas/merge-plan.schema.json` validates sequential merge plans for isolated write workers.

## Async-await workflow schemas

The async-await runtime adds durable orchestration contracts:

- `schemas/async-task.schema.json` describes one durable async task/promise record, including command, PID, status, logs, result path, timeout, error, and cancellation metadata.
- `schemas/async-group.schema.json` describes an async group, its await mode, task list, queue/concurrency settings, settlement policy, supervisor PID, counts, and metrics.
- `schemas/await-result.schema.json` describes the persisted result of `workflow await`, including fulfilled/rejected/timeout/cancelled/pending task buckets, reducibility, and async metrics.

These schemas intentionally model orchestration state separately from `worker-result.schema.json`: a task may be orchestration-fulfilled because a valid `WORKER_RESULT` was produced even when the worker's domain status is `partial` or `blocked`.
