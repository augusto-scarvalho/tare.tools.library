# WORKER_RESULT Examples

These examples show compact, valid worker outputs for agentic map-reduce and fork-join packets. Workers should return exactly one JSON object and should avoid long copied file contents.

## `done` with no findings

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-001",
  "shardId": "shard-001",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "done",
  "summary": "Reviewed the assigned scope and found no actionable issues.",
  "itemsAnalyzed": ["specs/00-universal"],
  "findings": [],
  "sourceFilesVerified": ["specs/00-universal/agentic-map-reduce.md"],
  "graphify": {
    "status": "not_applicable",
    "queries": [],
    "reason": "Scope was explicit and small enough for direct source verification."
  },
  "nextStep": null
}
```

## `done` with a medium finding

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-002",
  "shardId": "shard-002",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "done",
  "summary": "Reviewed docs workflow guidance and found one consistency issue.",
  "itemsAnalyzed": ["docs/AGENTIC_WORKFLOWS.md", "docs/WORKFLOW_OPERATIONS_RUNBOOK.md"],
  "findings": [
    {
      "severity": "medium",
      "category": "docs",
      "title": "Runbook does not mention reviewer-result validation",
      "evidence": ["docs/WORKFLOW_OPERATIONS_RUNBOOK.md"],
      "recommendation": "Add reviewer-result validation to the workflow operations runbook."
    }
  ],
  "sourceFilesVerified": ["docs/WORKFLOW_OPERATIONS_RUNBOOK.md"],
  "graphify": {
    "status": "skipped",
    "queries": [],
    "reason": "Task scope was limited to two explicit docs."
  },
  "nextStep": "Update the runbook after reducer review policy is adopted."
}
```

## `partial`

Use `partial` when the worker analyzed part of its scope but could not complete all required verification within its budget.

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-003",
  "shardId": "shard-003",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "partial",
  "summary": "Reviewed the top-level scripts but did not finish all hook files before the scope budget limit.",
  "itemsAnalyzed": ["scripts/harness.py", "scripts/spec_test_gate.py"],
  "findings": [],
  "sourceFilesVerified": ["scripts/harness.py", "scripts/spec_test_gate.py"],
  "graphify": {
    "status": "not_available",
    "queries": [],
    "reason": "No graphify-out/graph.json was available in this workspace."
  },
  "nextStep": "Run a follow-up shard for tools/hooks before treating scripts/tools as fully reviewed."
}
```

## `blocked`

Use `blocked` when the worker cannot continue because an external condition or missing artifact prevents verification.

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-004",
  "shardId": "shard-004",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "blocked",
  "summary": "Could not verify Graphify partitioning because the generated graph artifact is missing.",
  "itemsAnalyzed": [],
  "findings": [],
  "sourceFilesVerified": [],
  "graphify": {
    "status": "not_available",
    "queries": [],
    "reason": "graphify-out/graph.json was not present."
  },
  "nextStep": "Generate Graphify artifacts or rerun this workflow with --split roots."
}
```

## `failed`

Use `failed` when the worker attempted the assignment but encountered an unrecoverable worker-side error. Keep the failure compact and actionable.

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-005",
  "shardId": "shard-005",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "failed",
  "summary": "Worker failed before completing source verification because required files could not be read.",
  "itemsAnalyzed": [],
  "findings": [],
  "sourceFilesVerified": [],
  "graphify": {
    "status": "skipped",
    "queries": [],
    "reason": "Worker failed before discovery."
  },
  "nextStep": "Inspect worker stderr log and retry this worker after fixing the local file access issue."
}
```

## `done` with a QA evidence capsule (`oracleEvidence`)

`oracleEvidence` is optional (SPEC-121). When present it names the oracle that ran, its `exitClass` (`passed|failed|error|timeout|skipped`), a RELATIVE handle to a pre-scrubbed artifact (never an absolute or `..` path), and a re-run command of at most 400 chars — so a reviewer verifies the capsule instead of re-running the oracle.

```json
{
  "workflowId": "WF-20260707-120000",
  "workerId": "worker-006",
  "shardId": "shard-006",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "done",
  "summary": "Ran the scenario oracle for the assigned scope; all checks passed.",
  "itemsAnalyzed": ["scripts/harness_lib/result_contracts.py"],
  "findings": [],
  "sourceFilesVerified": ["scripts/harness_lib/result_contracts.py"],
  "graphify": {
    "status": "not_applicable",
    "queries": [],
    "reason": "Scope was one explicit module."
  },
  "oracleEvidence": {
    "oracle": "testing/scenarios/qe_evidence_capsule.py",
    "exitClass": "passed",
    "artifactPath": ".harness/workflows/active/WF-20260707-120000/workers/worker-006.oracle.log",
    "rerunCmd": "python testing/scenarios/qe_evidence_capsule.py"
  },
  "nextStep": null
}
```

## Evidence rules

- Every `high` or `blocker` finding must include evidence and at least one corresponding path in `sourceFilesVerified`.
- Evidence should be path-oriented, for example `scripts/harness.py` or `testing/QUALITY_GATES.md`.
- Do not paste long source excerpts into evidence; use paths, line numbers when available, command names, test names, and spec IDs.
- If Graphify was used, set `graphify.status` to `used` and verify the graph-derived result in real source/spec/test/config files.
