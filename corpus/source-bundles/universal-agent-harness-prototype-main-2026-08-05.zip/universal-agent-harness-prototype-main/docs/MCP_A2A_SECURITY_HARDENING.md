# MCP / A2A security hardening plan

MCP and A2A tool integrations are treated as adoption-specific security boundaries. The reusable harness can define the policy and red-team expectations, but only an adopting project can approve actual tool servers, egress, secrets, and business actions.

## Required controls before enabling tool servers

- capability allowlist for every tool server;
- explicit human approval for filesystem, network, ticketing, email, calendar, payment, deployment, and destructive operations;
- tool-description review to catch prompt injection, tool poisoning, overbroad capabilities, and hidden exfiltration instructions;
- egress allowlist and payload-size limits;
- audit log of every tool call with redaction;
- versioned manifest or hash for reviewed tool definitions;
- fail-closed behavior when a tool manifest changes unexpectedly.

## Recommended fixtures for adopters

- malicious tool description should be rejected or quarantined;
- unapproved egress host should fail;
- sensitive action without approval token should fail;
- changed tool manifest should require review;
- redaction should remove credentials and bearer tokens from trace exports.

The reusable template already provides adjacent controls through `red-team`, `trace-secret-redaction`, `trace-push-policy`, protected instruction-file snapshots, and controlled-write approval gates.
