# Harness observability and trace contract

## Status

The harness now emits two complementary streams:

- `.harness/runs/events.jsonl` for append-only operational events;
- `.harness/workflows/active/<WF>/trace.jsonl` for workflow-local,
  OpenTelemetry-shaped spans.

Global events without a `workflowId` are mirrored to `.harness/runs/harness-trace.jsonl`.
Release packaging excludes runtime `.jsonl` files, so traces remain local evidence,
not template payload.

## Span contract

Each span is dependency-free JSON with:

```json
{
  "schemaVersion": "1.0",
  "traceId": "32 hex chars",
  "spanId": "16 hex chars",
  "parentSpanId": null,
  "name": "harness.workflow_planned",
  "kind": "internal",
  "startTime": "ISO-8601 timestamp",
  "endTime": "ISO-8601 timestamp",
  "status": "ok|running|done|failed|cancelled|...",
  "attributes": {
    "workflow.id": "WF-...",
    "worker.id": "worker-001",
    "harness.event": "workflow_planned"
  }
}
```

## CLI

```bash
python scripts/harness.py workflow trace WF-...
```

The command returns a summary plus the last spans. This is intentionally JSON so
it can be transformed to OTLP, LangSmith, Phoenix, Datadog, or another collector
by product adopters.

## Product boundary

The template does not require OpenTelemetry SDKs. That keeps offline validation
portable. A product distribution can add exporters on top of this trace contract.


## Export adapters

The trace contract can now be exported without vendor SDKs or network access:

```bash
python scripts/harness.py workflow trace-export WF-... --format otlp-json --output .harness/workflows/active/WF-.../trace.otlp.json
python scripts/harness.py workflow trace-export WF-... --format langsmith-jsonl --output .harness/workflows/active/WF-.../trace.langsmith.jsonl
python scripts/harness.py workflow trace-export WF-... --format phoenix-jsonl --output .harness/workflows/active/WF-.../trace.phoenix.jsonl
```

Supported formats are:

- `otlp-json`: OpenTelemetry Protocol JSON shape for later collector ingestion.
- `langsmith-jsonl`: JSONL run records with trace/run metadata.
- `phoenix-jsonl`: JSONL span records with Phoenix-style context fields.

The template only writes files/stdout. Network exporters remain downstream
adapters so the reusable harness has no vendor lock-in or secrets requirement.


## Network exporter dry-run

The template now includes a safe request planner for network exporters without
sending traffic by default:

```bash
python scripts/harness.py workflow trace-push WF-... --target otlp-http --endpoint http://localhost:4318/v1/traces
python scripts/harness.py workflow trace-push WF-... --target langsmith --endpoint https://api.smith.langchain.com/runs --api-key-env LANGSMITH_API_KEY
python scripts/harness.py workflow trace-push WF-... --target phoenix --endpoint http://localhost:6006/v1/traces --api-key-env PHOENIX_API_KEY
```

The command returns a JSON request plan containing method, endpoint, redacted
headers, body size and body hash. It does **not** read or print secret values.
Actual network send requires both `--send` and `HARNESS_ALLOW_NETWORK_EXPORT=1`;
products should still prefer a collector/sidecar or vendor SDK wrapper for real
production export.

Validation:

```bash
python scripts/harness-test.py --fixture trace-push
```

## Network trace push policy

`workflow trace-push` is dry-run-first. Without `--send`, it builds a request plan only: target, method, endpoint, redacted headers, payload size, payload hash, span count, and endpoint policy result.

Actual network sending requires both:

```bash
HARNESS_ALLOW_NETWORK_EXPORT=1
python scripts/harness.py workflow trace-push WF-... --target otlp-http --endpoint http://127.0.0.1:4318/v1/traces --send
```

The send path is additionally constrained by `.harness/project.json`:

```json
{
  "workflows": {
    "observability": {
      "networkExportPolicy": {
        "allowedHosts": ["localhost", "127.0.0.1", "::1"]
      }
    }
  }
}
```

Template defaults allow only loopback hosts. Product adopters must explicitly add their collector hosts before using `--send` outside local testing. Dry-run planning still works for arbitrary `http(s)` endpoints so request shape can be reviewed before allowlisting.

Validation:

```bash
python scripts/harness-test.py --fixture trace-push
python scripts/harness-test.py --fixture trace-push-send
```

## Trace redaction policy

Trace exports and trace pushes are sanitized before leaving the workflow runtime. The template redacts:

- attribute keys that look sensitive, such as `token`, `apiKey`, `authorization`, `cookie`, `password`, `secret`, `private_key`, and `client_secret`;
- bearer/API-key-like string values, including common `Bearer ...`, `sk-...`, `ghp_...`, `glpat-...`, and `AKIA...` forms;
- URL credentials and sensitive query parameters such as `api_key`, `token`, `secret`, and `password`.

The request plan returned by `workflow trace-push` includes a `redaction.redactedFields` count so operators can see whether redaction happened. Actual `--send` uses the same sanitized payload that produced the dry-run `bodySha256`.

Validation:

```bash
python scripts/harness-test.py --fixture trace-secret-redaction
```



## Fail-closed network policy checks

`workflow trace-push --send` now has four independent gates before network I/O:

1. explicit operator/environment opt-in with `HARNESS_ALLOW_NETWORK_EXPORT=1`;
2. endpoint host allowlisting via `workflows.observability.networkExportPolicy.allowedHosts`;
3. endpoint URL must be secret-free: no embedded credentials and no sensitive query params;
4. payload size must fit within `workflows.observability.networkExportPolicy.maxPayloadBytes`.

Dry-run planning remains available for non-allowlisted or unsafe endpoints so teams can review redacted endpoint policy, payload policy, body size, redaction counts, and payload hash without sending data. Actual send to a blocked endpoint or oversized payload fails before opening a socket.

Validation:

```bash
python scripts/harness-test.py --fixture trace-push-policy
python scripts/harness-test.py --fixture trace-push-send
```

## Exporter implementation guardrails

The trace exporter module is covered by a static duplicate-literal-dict-key check. This protects vendor adapter payloads from silent Python dictionary key overwrites, such as duplicate `context` blocks in JSONL adapters.

Validation:

```bash
python scripts/harness-test.py spec-pack --no-project-commands
```

## Failure patterns (OB.1, SPEC-126)

```bash
python scripts/harness.py failure-patterns [--json]
```

A deterministic repeat-failure rollup. It reads two durable ledgers:

- `.harness/state/escalations.json` — raised **and** resolved escalation
  records (resolved entries are the repeat-failure history);
- `.harness/state/worklog.json` + `worklog-archive.json` — entries whose kind
  or tags mark a failure.

Events cluster by `(failureClass, role, executor)`; missing fields bucket as
`(none)` so a field-less entry can never crash the rollup. Groups sort by
count desc, then last occurrence desc, and each group lists the source
ledgers that contributed.

Discipline (verify-on-demand): pure reads and zero writes — it deliberately
avoids the escalations CLI's read path, which compacts `events.jsonl` into
the ledger on read; no LLM calls; no daemon or polling — the rollup is
recomputed only when someone asks (observation must pay for itself).

Validation:

```bash
python testing/scenarios/fp_failure_patterns.py
```

## Delegation trend by group (OB.2, SPEC-127)

The aggregate `delegation-cost-trend` self-review finding watches the summed
delegation token series — one model or agent type can drift while the mix
keeps the aggregate flat. Self-review therefore also runs the SAME last-5 vs
previous-5 rising-median test per group, over the per-delegation rows
(`model`, `agentType`, `estTokens`, `durationS`) the cost ledger already
records. Findings that can fire:

- `delegation-cost-trend:model:<name>` / `delegation-cost-trend:agent:<name>`
  — est-token medians rising for that model / agent type;
- `delegation-latency-trend:model:<name>` /
  `delegation-latency-trend:agent:<name>` — the same test over `durationS`.

Knobs (`.harness/self-review.json` thresholds, shared with the aggregate
rule): `delegationCostTrendFactor` (default 1.3, the rising-median factor)
and `delegationCostTrendMinSamples` (default 10, per group — sparser groups
stay silent). Deterministic only, evaluated when self-review runs; the LLM
diagnosis card is OB.3, not this.

Validation:

```bash
python testing/scenarios/ob_cost_trend.py
```

## Anomaly feature card (OB.3 deterministic half, SPEC-131)

```bash
python scripts/harness.py anomaly-card WF-... [--json]
```

When the `workflow-cost-outlier` escalation names a workflow, this card gives
the number a shape — deterministically, from data already on disk:

- **Primary input**: the workflow's `cost_metrics` ledger record
  (`.harness/state/cost-metrics.json`) — tokens, cost, `costBasis`, and the
  DW.3 graph-shape fields (`fanOut`/`depth`/`makespanS`). The ledger survives
  WF-dir scrubbing, so the card renders even after `workflow scrub`.
- **Graceful-null enrichment** when `.harness/workflows/active/<WF>/` still
  exists: per-worker estimated tokens from the token-audit report and
  SPEC-129 `evidence_bundle` handles. A scrubbed dir yields nulls, never a
  crash.
- **`factors`**: a FIXED deterministic rule list, each hit a named string with
  its numbers — fan-out above the same-profile ledger median; a single worker
  holding >50% of estimated tokens; duration >3.0x the same-profile median
  (the same factor idiom as the escalation that fired). No scoring model.

Unknown workflow ids exit 0 with a clean not-found line (`--json` returns
`{found: false, error: ...}`). Read-only, verify-on-demand, no daemon.

**The LLM half of OB.3 is DEFERRED** (with UX-GA.4): an opt-in, view-only,
evidence-cited LLM explanation that would sit ON TOP of this card — its seat
is the card's `llmExplanation: null` field. The deterministic card never
calls a model.

Validation:

```bash
python testing/scenarios/ac_anomaly_card.py
```
