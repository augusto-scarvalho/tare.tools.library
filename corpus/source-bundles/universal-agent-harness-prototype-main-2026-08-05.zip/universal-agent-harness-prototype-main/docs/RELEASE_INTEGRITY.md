# Release integrity, SBOM and local attestation

The harness release pipeline includes dependency-free supply-chain evidence so a
consumer can verify what shipped before adopting the template.

## Artifacts

```text
release/harness-sbom.cdx.json
release/checksums.sha256
release/release-attestation.json
release/slsa-provenance.intoto.jsonl
scripts/release_integrity.py
```

- `harness-sbom.cdx.json` is a CycloneDX-shaped source SBOM for the reusable
  harness template files.
- `checksums.sha256` records SHA-256 hashes for release-scoped files.
- `release-attestation.json` links the SBOM/checksum/provenance hashes and documents that
  this is a local unsigned attestation.
- `slsa-provenance.intoto.jsonl` is a SLSA-shaped in-toto statement over the
  release-scoped source files. It is local evidence, not external provenance.

The template intentionally does **not** claim external provenance. Product teams
should wrap these artifacts with Sigstore/cosign, SLSA provenance, or their
organization's signing pipeline when publishing a distribution.

## Commands

```bash
python scripts/release_integrity.py generate
python scripts/release_integrity.py verify
python scripts/harness-test.py --fixture release-integrity
```

`package-release.py` regenerates the release integrity artifacts before creating
the ZIP.

## Release gate

`product-release` fails when these artifacts are missing, malformed, stale or
internally inconsistent. Runtime evidence such as `.jsonl`, `.log`, active
workflow packets and `.harness/state-store/` remains excluded from releases.

## Local signature artifact

`release/release-signature.sha256` is a dependency-free, local tamper-evident digest over:

- `release/harness-sbom.cdx.json`
- `release/checksums.sha256`
- `release/release-attestation.json`
- `release/slsa-provenance.intoto.jsonl`

Verify with:

```bash
python scripts/release_integrity.py verify
```

This is not a substitute for external provenance signing. Production release pipelines should wrap the ZIP and/or integrity files with Sigstore, SLSA provenance, or the organization's signing system.

## SLSA-shaped local provenance

`release/slsa-provenance.intoto.jsonl` uses an in-toto statement shape with `https://slsa.dev/provenance/v1` as predicate type. This gives downstream release pipelines a deterministic file to sign with Sigstore/cosign or an organization-specific signing system.

## External signing handoff

The dependency-free template does not invoke Sigstore, cosign, SLSA hosted provenance, or any external signing service. It now emits a deterministic handoff artifact instead:

```text
release/external-signing-plan.json
```

The file lists the local integrity inputs and command templates that a downstream release pipeline can adapt:

```bash
python scripts/release_integrity.py verify
cosign sign-blob --bundle release/cosign.bundle --output-signature release/cosign.sig <release-zip>
cosign attest-blob --predicate release/slsa-provenance.intoto.jsonl --type slsaprovenance <release-zip>
slsa-verifier verify-artifact --provenance-path release/slsa-provenance.intoto.jsonl <release-zip>
```

`release_integrity.py verify` validates the handoff file and the local attestation records `externalSigningPlanSha256`. The local `release/release-signature.sha256` digest also includes the signing plan hash, so downstream signing inputs are tamper-evident before external signing occurs.


## External signing preflight

The template can now produce a machine-readable readiness report for downstream signing without invoking external tools:

```bash
python scripts/release_integrity.py external-preflight
python scripts/release_integrity.py external-preflight --strict
```

Non-strict mode is intended for local/template validation. It verifies local integrity files, parses `release/external-signing-plan.json`, reports whether optional tools such as `cosign` and `slsa-verifier` are installed, and returns success even when those optional tools are missing. Strict mode is intended for release pipelines that require external signing prerequisites to be present.

The report includes:

- local integrity status;
- external signing tool readiness;
- recommended CI/OIDC environment markers;
- signing plan command count;
- a guarantee that the template itself does not invoke external tools.

Validation:

```bash
python scripts/harness-test.py --fixture release-external-preflight
```
