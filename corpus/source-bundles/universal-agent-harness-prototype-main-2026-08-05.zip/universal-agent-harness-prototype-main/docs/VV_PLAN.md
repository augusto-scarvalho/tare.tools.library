# Verification & Validation Plan

How we know the harness works: what each verification level proves, which fixture/gate is the evidence for each capability, how to reproduce the end-to-end run, and the latest executed results.

## Verification strategy

| Level | What it proves | How to run |
|---|---|---|
| Static/structural gates | Config, schemas, docs, routing, policy, module boundaries, and hygiene are internally consistent (45 `check_*` functions) | `python scripts/harness-test.py spec-pack` |
| Functional fixtures | Each runtime capability behaves correctly in isolation (31 named fixtures, most spawn real subprocesses against temp state) | `python scripts/harness-test.py --fixture <name>` |
| Release gates | The package is distributable: hygiene, portability, CI matrix, generated artifacts | `product-release --no-project-commands`, `soak --no-project-commands` |
| Regression scenarios | The accumulated acceptance scenarios (`testing/scenarios/*.py`: MVP loop, skeptical reviewer, contracts, non-linear reduce, status page, self-review loop, target governance, REPL UX/onboarding) stay green as one aggregated tier (QA.2) | `python scripts/harness-test.py scenarios --no-project-commands` |
| End-to-end dogfood | The full workflow pipeline (plan → spawn → WORKER_RESULT → validate → reduce → finalize) works with a real executor process | procedure below |
| CI matrix | Everything above on ubuntu/windows/macos × Python 3.11–3.13 | `.github/workflows/harness-ci.yml` (requires a remote) |

## Capability → evidence matrix

Executed 2026-07-09 on Windows 11, Python 3.13.14 (venv), harness v0.9.0 tree.

| Capability | Evidence (gate / fixture) | Result |
|---|---|---|
| Core config/schema/docs consistency | `spec-pack` (266 checks) | **pass** |
| Harness sanity + release hygiene | `smoke` | **pass** |
| Workflow wiring/policy aggregate | `workflow` gate | **pass** (after anchor fix) |
| Engineering guardrails (line budgets, module boundaries) | `engineering-guardrails` | **pass** |
| Canonical/market instruction file protection | `protected-files` | **pass** |
| Retired alias hygiene | `deprecation-hygiene` | **pass** |
| Handoff read-budget enforcement | `handoff-budget` | **pass** |
| Workflow ID collision boundaries | `workflow-id-boundary` | **pass** |
| Task-profile classification & planning (8 profiles) | `profile-planning` | **pass** |
| Token budgeting / economics | `token-budget` | **pass** |
| Graphify graph normalization/sharding | `graphify-adapter` | **pass** |
| Dependency-free code AST graph builder | `graphify-code-ast` | **pass** |
| Workflow lifecycle (plan/run/reduce/finalize) | `lifecycle` | **pass** |
| Controlled writes (locks, workspaces, merge, rollback) | `controlled-write` | **pass** |
| Executor output capture/truncation | `execute-output` | **pass** |
| Git-worktree write isolation | `git-worktree` | **pass** |
| Async orchestration (start/await/cancel/recover) | `async-workflow` | **pass** (after Windows pid_alive fix) |
| Repeated planning stability | `workflow-soak` | **pass** |
| Public CLI JSON contract (golden master) | `cli-golden` | **pass** |
| State store contract (file/SQLite) | `state-store` | **pass** (after Windows list_keys fix) |
| Runtime state mirroring/recovery | `state-runtime` | **pass** (after Windows list_keys fix) |
| Artifact mirroring/rehydration | `state-artifacts` | **pass** |
| Trace span contract | `trace-contract` | **pass** |
| Trace export formats (OTLP/LangSmith/Phoenix) | `trace-export` | **pass** |
| Trace push dry-run request shape | `trace-push` | **pass** |
| Trace push loopback send | `trace-push-send` | **pass** |
| Trace network fail-closed policy | `trace-push-policy` | **pass** |
| Trace secret redaction | `trace-secret-redaction` | **pass** |
| SBOM/checksums/attestation/provenance | `release-integrity` | **pass** |
| External signing preflight | `release-external-preflight` | **pass** |
| Timed-out process-tree cleanup | `process-timeout-cleanup` | skip on Windows (CI covers POSIX) |
| Fixture liveness / cleanup policy | `fixture-liveness` | pass with Windows skip of the timeout sub-check |
| Provider canary fail-closed policy | `provider-canary` | **pass** |
| Agency/write boundary red-team | `red-team` | **pass** |
| Bounded stability (soak) | `soak --no-project-commands` | **pass** |
| Full pipeline with a real executor process | E2E dogfood (below) | **pass** (WF executed, reduced, finalized) |
| Packaging produces a clean zip | `package-release.py` + inspection | **pass** (187 files, no venv/git/runtime entries) |

## End-to-end dogfood procedure

Reproducible offline E2E using the same fixture-executor mechanism as the `execute-output` fixture:

1. Back up `.harness/routing/executors.json`.
2. Register a `fixture` executor whose `commandTemplate` runs a small Python script; the harness passes `HARNESS_WORKER_RESULT_PATH`, `HARNESS_WORKFLOW_ID`, and `HARNESS_WORKER_ID` in the environment, and the script writes a valid `WORKER_RESULT` JSON to that path.
3. Run the real CLI pipeline:
   ```bash
   python scripts/harness.py workflow execute --profile repository-review \
       --split explicit --shard README.md --executor fixture \
       --task "V&V dogfood run"
   ```
4. Assert: exit code 0; `reduce/harness-result.json` exists in the workflow dir with `status: done`; top-level `validation` block present.
5. Finalize (`workflow finalize WF-<id>`) and confirm the handoff was regenerated.
6. Restore `executors.json` (always, in a `finally`), then `python scripts/harness-test.py --clean-fixtures`.

## Known platform gaps

- `process-timeout-cleanup` **skips on Windows** (descendant inspection needs `/proc`). The Windows tree-kill path (`taskkill /T` in `harness_lib/processes.py`) was verified manually with a grandchild process; the fixture runs for real on the ubuntu/macos legs of CI.
- The CI matrix (`harness-ci.yml`) has **never executed** — the repo has no remote yet. Pushing to GitHub and getting one green matrix run is the remaining external-verification step.
- `soak`/`product-release` run with `--no-project-commands`: project-specific build/test commands are an adoption concern (PC-002), not template scope.

## Results record

Run-by-run results now live in the records ledger: `python scripts/harness.py records recent` (migrated entries carry tag `migrated:vvplan`).
