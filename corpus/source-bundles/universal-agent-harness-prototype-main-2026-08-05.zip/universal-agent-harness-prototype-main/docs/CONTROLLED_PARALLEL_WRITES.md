# Controlled Parallel Write Workflows

This document describes the optional write-capable extension for the agentic map-reduce/fork-join workflow runtime.

The default harness remains read-only. Write workflows require an explicit approval token, isolated worker workspaces, file locks, a merge plan, and an approval-gated merge step.

## Status

Controlled writes are supported as an explicit, operator-approved workflow track. They are not enabled by default and they do not permit direct writes to the shared working tree from concurrent workers.

The template now supports four lock modes:

- `write`: modify an existing locked file.
- `create`: create a specific future path.
- `delete`: delete a specific existing path.
- `rename`: move an existing path to a specific new path.

## Safety model

Controlled writes follow these invariants:

1. Read-only workflows remain the default.
2. A write workflow must be planned with `--write-allowed` and an approval token.
3. Write workers must be prepared with `workflow prepare-write` before `workflow run`.
4. File ownership is recorded in `.harness/workflows/active/<WF>/locks.json`.
5. Concurrent write workers must use isolated workspaces, not the shared working tree.
6. The harness builds `reduce/merge-plan.json` before applying any worker changes.
7. Merge application requires the same approval token.
8. Worker changes are applied sequentially from the merge plan.
9. Optional validation gates can run after each worker merge and after the final merge.
10. Rollback restores overwritten/deleted/renamed files and removes created files from harness-recorded actions.
11. Write workflows with applied merges require semantic merge review before finalize unless explicitly bypassed after human approval.

## Approval token

The template uses this explicit token:

```bash
I_APPROVE_CONTROLLED_WRITES
```

Projects may change it in `.harness/project.json` under `workflows.controlledWrites.approvalToken`.

## Basic modify-only sequence

```bash
python scripts/harness.py workflow plan \
  --profile repository-review \
  --split explicit \
  --shard src/module-a \
  --task "Implement bounded change in module A" \
  --write-allowed \
  --approval-token I_APPROVE_CONTROLLED_WRITES

python scripts/harness.py workflow prepare-write WF-... \
  --mode temp-copy \
  --approval-token I_APPROVE_CONTROLLED_WRITES

python scripts/harness.py workflow run WF-... \
  --executor claude \
  --concurrency 2

python scripts/harness.py workflow merge-plan WF-... \
  --validation-gate smoke

python scripts/harness.py workflow apply-merge WF-... \
  --approval-token I_APPROVE_CONTROLLED_WRITES \
  --validation-gate smoke \
  --final-gate workflow \
  --rollback-on-final-gate-failure

python scripts/harness.py workflow review-merge WF-... --executor claude
python scripts/harness.py workflow review-merge WF-... --validate-existing
python scripts/harness.py workflow finalize WF-...
```

## Create/delete/rename locks

Use explicit lock specs when a worker needs to create, delete, or rename paths.

```bash
python scripts/harness.py workflow prepare-write WF-... \
  --approval-token I_APPROVE_CONTROLLED_WRITES \
  --create-lock worker-001:src/new-module.ts \
  --delete-lock worker-001:src/old-module.ts \
  --rename-lock worker-001:src/old-name.ts:src/new-name.ts
```

The merge plan records:

- `createdFiles`
- `deletedFiles`
- `renamedFiles`
- per-worker conflicts for unowned creates/deletes/renames

`apply-merge` refuses create targets that already exist and refuses blocked merge plans.

## Isolation modes

### `temp-copy`

Creates `.harness/workflows/active/<WF>/workspaces/<workerId>` as a sparse, lock-scoped workspace. The workspace contains only locked existing paths plus parent directories needed for create/rename targets, and includes `.harness-workspace.json` metadata describing the scope. This keeps the template-default mode isolated without copying the whole repository for every worker.

### `git-worktree`

`prepare-write --mode git-worktree` records per-worker worktree paths and commands. Projects that want template-managed worktree creation can run:

```bash
python scripts/harness.py workflow prepare-worktrees WF-... \
  --approval-token I_APPROVE_CONTROLLED_WRITES
```

Cleanup is explicit:

```bash
python scripts/harness.py workflow cleanup-worktrees WF-... --force
```

Branch policy still belongs to the adopting project.

## Merge plan

`workflow merge-plan` compares locked files in each worker workspace against the main working tree and writes:

```text
.harness/workflows/active/<WF>/reduce/merge-plan.json
.harness/workflows/active/<WF>/reduce/merge-plan.md
```

Only files owned by that worker's locks are eligible for merge. Created, deleted, and renamed files must be covered by matching lock modes.

## Apply and rollback

`workflow apply-merge` applies changes from each workspace into the main working tree in merge-plan order. Before destructive operations, the harness writes action metadata and backups under:

```text
.harness/workflows/active/<WF>/backups/<workerId>/
```

Rollback restores backups and removes files that were created by the merge:

```bash
python scripts/harness.py workflow rollback WF-... --worker-id worker-001
python scripts/harness.py workflow rollback WF-...
```

A failing per-worker validation gate or final gate can rollback automatically:

```bash
python scripts/harness.py workflow apply-merge WF-... \
  --approval-token I_APPROVE_CONTROLLED_WRITES \
  --validation-gate commit \
  --rollback-on-validation-gate-failure
```

```bash
python scripts/harness.py workflow apply-merge WF-... \
  --approval-token I_APPROVE_CONTROLLED_WRITES \
  --final-gate release \
  --rollback-on-final-gate-failure
```

`--rollback-on-final-gate-failure` also rolls back a failed per-worker validation gate for backwards-compatible safety, but new automations should use the explicit `--rollback-on-validation-gate-failure` flag when that is the intended behavior.

## Semantic merge review

Mechanical locks do not prove semantic compatibility. After applying a write workflow, prepare and validate a merge review:

```bash
python scripts/harness.py workflow review-merge WF-... --executor claude
python scripts/harness.py workflow review-merge WF-... --validate-existing
```

When `workflows.controlledWrites.requiresSemanticMergeReview` is true, `workflow finalize` blocks after an applied merge until the semantic merge review is approved, unless `--skip-review` is used after human approval.

## Cleanup

After review, remove write workspaces with:

```bash
python scripts/harness.py workflow cleanup-write WF-... --force
```

## Container isolation

The reusable template does not ship a container-managed write isolation mode. Projects may implement containerized execution as an adoption-specific executor/isolation adapter. The template-supported controlled write modes are `temp-copy` and `git-worktree`.

## What this does not do

The controlled write layer does not remove the need for human review. It also does not bypass project CI, code review, security review, semantic merge review, or final full-gate validation.
