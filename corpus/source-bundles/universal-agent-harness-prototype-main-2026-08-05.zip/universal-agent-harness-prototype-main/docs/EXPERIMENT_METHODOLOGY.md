# Metodologia de experimentos do harness

Protocolo normativo para experimentos: como uma hipótese vira um objeto de
primeira classe, é medida, e é engavetada ou promovida com disciplina — para
não ficarmos presos com features ruins aplicadas no projeto (mandato do dono
2026-07-13). A execução canônica é o verbo `harness.py experiment`; a spec de
lei é `specs/40-features/experiment-lifecycle.md`.

## O ciclo de vida (a máquina de estados)

    proposed → active → (shipped | shelved)

- **proposed** — cartão pré-registrado e completo, ainda sem permissão de rodar.
- **active** — o dono ativou; um `reviewBy` foi carimbado (padrão hoje + 14
  dias); a partir daqui só entram medições (append-only).
- **shipped | shelved** — veredito permanente (tombstone). Não há trimming, não
  há retorno: um experiment settled é história.

Transições só acontecem pelo verbo. Cada uma recusa fora do estado certo
(`record`/`extend`/`verdict` num `proposed` recusam; `activate` num não-proposed
recusa; qualquer verbo num tombstone recusa).

## Cartão sem registro não existe

Os cartões nos extract docs
(`docs/research/weekly-monitor-w28-*-extract.md`) são **rascunhos**. O estado
canônico vive SOMENTE em `.harness/state/experiments.json`, escrito pelo verbo.
Um cartão que não passou por `harness.py experiment add EXP-N …` não existe para
efeito de decisão — não pode ser medido, vencido, nem citado por uma spec de
controle. Isto mata o modo de falha que a fila de intake já matou para pedidos:
o registro evapora quando a conversa segue.

## Disciplina de pré-registro (os seis campos obrigatórios)

`add` recusa um cartão que não traga os seis, e recusa id fora de `EXP-<número>`
ou id duplicado. Pré-comprometer hipótese e critérios ANTES de medir é o ponto:

- **hypothesis** — a afirmação testável ("mudar X move Y").
- **metric** — a variável medida, e como (unidade, fonte).
- **baseline** — o número de partida contra o qual se compara.
- **successCriteria** — o limiar que, atingido, justifica promover (`shipped`).
- **abandonCriteria** — o limiar que, atingido, justifica engavetar (`shelved`).
- **reversalPlan** — como desfazer o probe, escrito antes de começar.

**A ativação é decisão do DONO**, numa triagem conjunta — nunca automatizada. O
overseer propõe o cartão; só o dono transiciona `proposed → active`.

## Lei de fase: active é só probe, controle exige veredito

Um experimento **active** só admite **probes de zero mudança de comportamento** —
instrumentação e medição, nada que altere o controle em produção. Mudar o
comportamento (o "controle") exige um veredito `shipped` E entra por uma spec
NOVA de SPEC-116 que cita o `EXP-id` e os números medidos. Ordem inegociável:
mede-se primeiro, controla-se depois, e o controle é uma spec separada — não um
efeito colateral do probe. É o mesmo idiom observe-first do mpo/ort e da
security-baseline.

## Regras de veredito (e a assimetria, com o porquê)

`verdict` (active-only) exige decisão em `shipped | shelved`:

- **shipped requer ≥1 medição** — "no shipping without data". Promover sem um
  número medido é exatamente a feature ruim aplicada às cegas que a metodologia
  existe para impedir.
- **shelved requer `evidence` E `reopenTrigger`** — engavetar é uma afirmação
  cara: precisa da prova de que a reversão rodou e do gatilho que reabriria a
  questão. A assimetria é deliberada: promover e engavetar têm ônus de prova
  diferentes porque erram para lados diferentes (promover errado aplica lixo;
  engavetar errado só adia).

O veredito grava `verdict, verdictAt, evidence, note, reopenTrigger` e é
permanente. Todo texto livre é redigido (secret_scan) e tem caminho local
raspado para `<local-path>` antes de gravar — o registro é um ledger versionado.

## Protocolo de engavetamento

1. Execute a reversão (o `reversalPlan`) **e verifique** que o controle voltou
   ao baseline — ANTES de bater o veredito.
2. Registre a prova dessa verificação em `--evidence`.
3. `reopenTrigger` é obrigatório: **"não é 'não', é 'quando'"** — nomeie a
   condição objetiva que reabre o experimento.
4. Risque o cartão no extract doc apontando para o tombstone (`EXP-id` +
   `verdictAt`), para que o rascunho não seja relido como pendente.

## Regra de extensão (uma só)

`extend` empurra o `reviewBy` **uma vez**. Um segundo pedido recusa: "already
extended once; decide a verdict or escalate to the owner". Isto é anti
sunk-cost — a segunda prorrogação é uma escalação ao dono, não um verbo.

## Papéis

- **Dono** — ativa (`proposed → active`) e decide o veredito. Único a
  transicionar essas fronteiras.
- **Overseer** — propõe cartões, roda os probes (measure-only) e registra as
  medições com `harness.py experiment record`.
- **Workers** — implementam SOMENTE probes de instrumentação. Um diff de worker
  que muda comportamento citando um experimento exige
  `harness.py experiment show <id>` com status `shipped`; senão, revert.

## Cadência de acompanhamento

Sempre que o `doctor` avisar `experiment-overdue` (um experimento active passou
do `reviewBy`), o overseer decide: registrar mais dados, estender uma vez, ou
bater um veredito. O nag é advisory (rc 0 sempre), mas ignorá-lo é reintroduzir
o zumbi que a metodologia mata.

## Constantes de decisão (defaults do artigo §6.6)

Os limiares de promoção NÃO são inventados por experimento: são defaults
pré-registrados do artigo (§6.6). Um cartão herda estes valores salvo
justificativa pré-registrada em contrário.

| Constante | Default | O que rege |
|---|---|---|
| α | 0.05, Holm-ajustado por família | erro tipo I por família de comparações |
| poder | ≥ 0.80 no menor efeito relevante | detectar o menor efeito que importa |
| δ_Q (qualidade) | 5 pp OU 0.2 SD | efeito mínimo relevante de qualidade |
| δ_C (custo) | 10% de custo | folga de custo tolerada |
| δ_L (latência) | 10% de latência | folga de latência tolerada |
| δ_V (violação) | 0 crítico / 1% não-crítico | tolerância a violações (zero p/ crítico) |
| ECE (calibração) | ≤ 0.05 | erro de calibração esperado máximo |

**Regra de aperto/afrouxamento:** apertar um limiar (exigir mais) é livre e não
precisa de justificativa. Afrouxar (exigir menos) exige justificativa
**pré-registrada** no cartão, ANTES de medir — e **nunca** remove a
tolerância-zero de violação crítica (δ_V crítico = 0 é inegociável).

## Regra lexicográfica de decisão (§9.10-g)

Quando os objetivos conflitam, a decisão é **lexicográfica**, não uma média
ponderada: primeiro segurança/autoridade/privacidade/budget-duro (as restrições
duras); só entre as opções que passam nelas, exige-se qualidade **não-inferior**
ao baseline; e só então maximiza-se a utilidade ajustada a risco. Escalar
recursos (mais budget, mais tempo, modelo maior) **não compra** uma violação
crítica — nenhum ganho de utilidade a jusante reabre uma restrição dura já
violada.

## Graus de evidência 1-4 (App H)

Toda evidência citada por um veredito carrega um **grau** (App H), gravado no
cartão como `evidenceGrade` (opcional e aditivo — cartões antigos sem grau
seguem válidos; não há grau retroativo automático nem inferência por status):

1. **exploratório** — sinal bruto, sem controle formal; levanta hipótese.
2. **atributivo** — mostra associação com o fator, mas o confundidor permanece.
3. **confirmatório** — controle formal (baseline pareado, α/poder do §6.6) sob um
   protocolo pré-registrado.
4. **qualificado-a-promoção** — confirmatório E replicado/robusto o bastante para
   mudar um default persistente.

**Rebaixamento:** um grau não é permanente. Drift do substrato, evidência vencida
(fora da janela de validade do cartão) ou mudança de modelo/executor
**rebaixam** o grau — a evidência que valia para o modelo antigo não vale
automaticamente para o novo.

**Gate de promoção:** só **grau 4** move um default persistente acima do
threshold de risco. Graus 1-3 informam, mas não promovem sozinhos um controle
persistente de alto risco — esse controle continua exigindo o veredito `shipped`
+ a spec SPEC-116 que cita o `EXP-id`.

## Tipagem de fatores (App E-2 / §9.4)

Todo fator num experimento recebe um **tipo**, que decide como ele entra no
desenho:

- **control** — o fator que estamos testando; varia de propósito.
- **noise_context** — varia no mundo real mas não queremos otimizar para ele; o
  desenho o **bloqueia** (mede sob vários níveis) para provar robustez.
- **hard_to_change** — caro de alternar; vira fator de split-plot (whole-plot),
  não re-randomizado a cada rodada.
- **nuisance** — afeta a métrica mas não interessa; controlado/bloqueado para não
  virar confundidor.
- **prohibited** — não pode ser mexido (segurança/autoridade); fixo, fora do
  espaço de busca.

Exemplo (EXP-18, detector de convergência): `T_COSINE` é **control** (o limiar
que o experimento varia); os **5 WFs multi-worker congelados** entram como
**noise blocks** (`noise_context`) — o desenho mede o detector sob todos eles
para que um ganho de recall seja robusto ao WF, não artefato de um único.

## Corpus inicial

Os 9 experimentos semeados (EXP-1..EXP-9) nascem como cartões nos quatro extract
docs da rodada weekly-monitor W28, o corpus de partida deste registro:

- `docs/research/weekly-monitor-w28-memory-extract.md`
- `docs/research/weekly-monitor-w28-code-quality-extract.md`
- `docs/research/weekly-monitor-w28-multiagent-extract.md`
- `docs/research/weekly-monitor-w28-dynamic-workflows-extract.md`

Cada um só passa a existir de fato quando registrado via
`harness.py experiment add EXP-N …` e ativado pelo dono.

> A livraria de desenho (`docs/EXPERIMENT_METHODS.md`) é o catálogo de métodos;
> declare o método escolhido no cartão do experimento (o advisory do `experiment
> add` sugere cards).

## Noise floor (A3)

Nossos detectores são determinísticos, então o ruído não mora neles — mora no
substrato de medição. Antes de promover um delta (mudança de threshold, claim de
ganho <10%), rode o probe de noise floor e compare o delta ao floor da métrica.
**Delta menor que o floor = NÃO é evidência.** Registre no cartão do EXP como
"abaixo do floor" e não promova.

```
./.venv/Scripts/python.exe testing/probes/noise_floor_probe.py
```

O probe (`testing/probes/noise_floor_probe.py`, measure-only, zero-LLM) mede dois
floors a partir de controles pinados e grava `.harness/runs/noise-floor-<ts>.json`:

- **Floor A — jitter de duração.** Corpus: `.harness/runs/gate-perf.jsonl` (timings
  passivos por cenário/attempt). Por cenário com ≥5 amostras: mediana, MAD e spread
  p95-p5 da duração total (snapshot+subprocess+restore). Regra: um delta de duração
  menor que o MAD do cenário é ruído. O probe lista os 10 cenários de maior MAD
  relativo (os que mais enganam).
- **Floor B — spread cross-wave.** Corpus: os WFs multi-worker congelados em
  `.harness/workflows/active` (o controle pinado). Por WF: uniqueRate/convergence
  (chave de dedup de produção) e os 3 scores do detector EXP-18 (jaccard/containment/
  cosine dos pares stage-1). Floor = o spread cross-WF (min-max e desvio) de cada
  métrica. Regra: uma mudança de threshold do EXP-18 só é evidência se mover recall
  além do spread cross-WF correspondente.

Ceiling declarado no próprio probe: corpus de 5-6 WFs de 2 dias, durações dependem
da máquina, e ruído de modelo-no-loop (sampling) está FORA do escopo — o probe
mede só o jitter determinístico do substrato.

## Route churn (C18, pré-requisito da histerese C9)

§3.5 do artigo define route churn como uma rota mudando de novo ANTES de
evidência nova a justificar. Antes de qualquer controle sobre churn (C9), a
métrica precisa existir e ser medida contra um piso — measure-only, sem tocar
o route-loop.

```
./.venv/Scripts/python.exe testing/probes/route_churn_probe.py
```

O probe (`testing/probes/route_churn_probe.py`, measure-only, zero-LLM) lê o
route ledger durável (`route_ledger.read_ledger`, SPEC-144 v8; nunca escreve
nele), agrupa as rows por `demandId` e mede, por demanda, `churnRate` (mudanças
de rota SEM evidência material entre a rota anterior e a nova — proxy Q1: a
row carrega um `outcome`/`riskFlags` novo, refinável se a taxa medida parecer
inflada) e `reversalsPerDemand` (padrão A→B→A). Grava
`.harness/runs/route-churn-<ts>.json` com `{schemaVersion, churnRate,
reversalsPerDemand, byRoute, floorContext}`; `floorContext` reusa o Floor B do
L13 (`noise_floor_probe.metric_floor`, importado — não reimplementado) como
piso de comparação: **um churnRate abaixo do spread cross-WF não é evidência.**
Zeros honestos em ledger vazio (o ledger é transiente, como o corpus do EXP-17);
rows sem `demandId` (o `done` do route-loop e o `done` de backfill, ambos
keyed por entryId/log, não por demandId) contam só em `unkeyedRows`, nunca como
churn — ceiling declarado no próprio probe.

## Perfil de previsibilidade Π-lite (C19)

§3.5 do artigo define Π como o vetor `⟨1−violations, 1−budgetOverruns,
1−replayDivergence, recovery, 1−unknownEffects⟩`, com a regra dura de que uma
média alta NÃO compensa 1 violação crítica — a mesma lógica lexicográfica do
C1 (Q7-2, "Regra lexicográfica de decisão" acima).

```
./.venv/Scripts/python.exe testing/probes/predictability_probe.py
```

O probe (`testing/probes/predictability_probe.py`, measure-only, zero-LLM)
NUNCA colapsa Π num escalar: a saída é o vetor componente-a-componente mais a
flag booleana `criticalViolation` (verdadeira só por uma escalação NÃO
resolvida com `criticality="critical"`, δ_V-crítico=0 do §6.6). Cada
componente sai como um número real medido ou como `{"na": true, "reason": …}`
— nunca fabricado. Corpus: route ledger (`route_ledger.read_ledger`) para
`violations` (rows de triage com `escalate=True`); o records ledger
(`records.collect_records`, hot+archive) para `violations` (escalações não
resolvidas) e `budgetOverruns` (rows `validation` cujo texto de falha cita
"token" — proxy do token-audit); gate-hold (`.harness/runs/gate-hold/`) +
circuit breaker (`.harness/runtime/executor-circuit-*.json`) para `recovery`;
o EXP-17 (`exp17_route_regret_probe.analyze`, importado — não reimplementado)
para `unknownEffects` (a taxa de dead-run já mede "efeito com resultado
desconhecido"). `replayDivergence` é **honestamente `n/a`**: não existe no
repo um mecanismo de replay-e-comparação — `replay_class` (§8.2) só rotula
eventos, nunca detecta divergência. Grava
`.harness/runs/predictability-pi-lite-<ts>.json`; `floorContext` reusa o Floor
B do L13, igual ao route-churn.

## Métricas de recovery (C20)

§5.7 do artigo pede quatro métricas measure-only: `orphanedWork`,
`timeToResume`, `provenanceContinuity`, `recoveryPointError`. As duas
needs-new-state da mesma rodada (`duplicate-effect`, `compensation`) ficam de
fora — exigem effect-id/saga que não existem.

```
./.venv/Scripts/python.exe testing/probes/recovery_probe.py
```

O probe (`testing/probes/recovery_probe.py`, measure-only, zero-LLM) lê o
records ledger (`records.collect_records`, hot+archive) para
`recoveryPointError` — "último-bom" = o último row `gate` com
`status="pass"` (default da pergunta salva Q2). As outras três métricas
precisam de timestamps de crash/resume ou de um stream de replay-class que o
records ledger não carrega estruturalmente; o probe declara o desvio e lê a
instrumentação real que já existe para essa pergunta: o log de eventos
assíncrono por workflow (`.harness/workflows/active/*/async/events.jsonl`) —
cada evento `async_recovery_completed` tem uma lista `recovered` cujo status
`"orphaned"` É literalmente "worker sem transição terminal" (`orphanedWork`),
e a fração de eventos daquele workflow cujo `replayClass` (§8.2) não cai no
default `"approximate"` mede `provenanceContinuity`; e o gate-hold
(`.harness/runs/gate-hold/*-recovered/hold.json`) — o próprio mecanismo de
crash-recovery da gate de scenarios — dá `timeToResume` (mtime do diretório
`-recovered` menos o `created` do manifesto; não existe um campo
`recoveredAt` explícito, então mtime é a proxy declarada). Janela: workflows
já limpos (`workflow scrub`) saem do corpus assíncrono; zeros/`n/a` honestos
em corpus vazio, nunca fabricado. Grava
`.harness/runs/recovery-metrics-<ts>.json`; `floorContext` reusa o Floor B do
L13, igual aos probes anteriores.

## Shadow-challenge de memória governada (GM-5)

R3 (memória governada, cartões GM-1/5) pede, ANTES de qualquer enforcement, um
piso para a metade GM-3 (challenge→expiry, owner-gated, FORA daqui): "quantos
itens um commit típico revalidaria?". Como não existe store de item de memória
governada hoje (recon em 582d734), o probe
(`testing/probes/memory_challenge_shadow_probe.py`, measure-only, zero-LLM,
read-only) NÃO cria store: ele PROJETA as entradas do records ledger (hot +
archive, via `records._load` — leitura pura, nenhum writer tocado) como
proto-itens-escopados — `scopeTag` = os `refs` que parecem path (contêm `/` ou
extensão pontuada; um id/sha é item NÃO-escopado, nunca challenged e não é lixo),
`claim` = title, `itemId` = identidade da entrada. `would_be_challenged(items,
changed_paths)` marca um item como challenged sse seu scopeTag intersecta os
paths de um commit (interseção exata, backslash-normalizado; challenge≠delete —
só MEDE uma re-validação da espécie R3). Sobre os últimos 50 commits (`git log
--name-only`, BOUNDED — teto documentado) reporta a distribuição de
`#challenged`/commit e DUAS frações por commit: over-ALL (denominador = todos os
itens) e over-SCOPED (denominador = itens escopados) — reportar as duas é o sinal
anti-over-expiry (Q3): uma fração over-SCOPED alta indica scope-match grosso
demais pra enforçar. Corpus vazio / histórico fresco → zeros honestos, nunca
crash.

```
./.venv/Scripts/python.exe testing/probes/memory_challenge_shadow_probe.py
```

Teto declarado no próprio probe: `refs` não é um scopeTag perfeito — é um PROXY
sobre o records ledger até um store governado existir (o gatilho pra construir
esse store, GM-3 owner-gated, é esta medição mostrar que o proxy é insuficiente);
o scope-match é interseção exata de path, não containment de diretório
(conservador de propósito). Grava
`.harness/runs/memory-challenge-shadow-<ts>.json`.

## Three-lane test instrument (E-3LANE)

R5 (EXP-20, `docs/research/exp20-three-lane-design.md`) and the matched-budget
control (EXP-15) both need to MEASURE the same thing before either can be
activated: a frozen task set, a stdlib oracle that grades an artifact without
a model in the loop, and a gap table naming which seam supplies each of the
three never-pooled lanes (article Sec.8.4: `normalized-core` /
`native-worker` / `governed-hybrid`). This item builds ONLY that instrument —
the measurement itself (running real lanes against a live model) is a
separate, owner-gated step that neither EXP-20 nor EXP-15 has activated yet,
and this instrument is deliberately NOT coupled to the experiments registry.

```
./.venv/Scripts/python.exe testing/probes/three_lane_probe.py
```

The probe (`testing/probes/three_lane_probe.py`, deterministic, zero-LLM by
construction) is structure-only:

- **Frozen task set** (`TASKS`, pinned by id in `_self_check`): 6
  deterministic stdlib parse/transform/compile tasks with a known expected
  result each — 2 parse (JSON/CSV extraction), 2 transform (numeric sort,
  dedupe+case), 2 compile (define a function/constant, exec-checked).
- **Oracle** (`oracle(task, artifact) -> {"passed": bool, "detail": str}`): a
  per-kind stdlib checker (int-parse compare / exact-string diff /
  compile+exec+semantic check) that never raises — an unparseable or
  malformed artifact is a `passed: False` result, not a crash.
- **Gap table** (`gap_table()`): per metric (`taskQuality`,
  `providerNativeTokens`, `rankingStability`), which seam supplies each of the
  three lanes and its `dataKind` (`real` / `emulated` / `pending-measurement`).
  `providerNativeTokens` is the honest gap the EXP-20 design names (Sec.8.4):
  the `native-worker` lane (codex's native `spawn_agent`) exposes no
  per-subagent token accounting, so its figure is an **EMULATED** proxy
  (parent-process total divided by subagent count) — declared `pooled: False`
  and never averaged with the `normalized-core`/`governed-hybrid` lanes' real
  per-worker `workflow_token_audit` figures. A ranking difference across lanes
  is model x harness interaction evidence, not a measurement artifact to be
  smoothed over.
- **`run_lane(lane, task, executor, *, live=False)`**: an execution-receipt
  stub. Without `--live` (the default, and the only mode this item builds) it
  returns a receipt with `spawned: False` and `artifact: None` — no model is
  ever called on this path. `live=True` raises `NotImplementedError`: real
  lane execution is the owner-gated measurement EXP-20/EXP-15 activate later,
  not something this instrument spawns itself; `main()` refuses `--live` the
  same way, before doing anything else (rc 2, no artifact written).

Ceiling declared in the probe itself: 6 tasks is a starting corpus, not a
statistically powered task class (that sizing is EXP-20's job once/if
activated); `rankingStability`'s seam exists structurally (Kendall tau over
per-scenario oracle scores) but has no data until a lane actually runs
(`dataKind: "pending-measurement"`), deliberately distinct from
`providerNativeTokens`' `native-worker` gap, which stays `emulated` even once
live (codex never exposes per-subagent tokens, no matter when it runs). The
compile-oracle's `exec()` runs only on the developer-authored fixtures
`_self_check()` exercises — fine for that trust boundary; any future `--live`
wiring that executes real model-produced source needs process isolation/
timeout hardening first, which is flagged, not built, here. Self-check only —
`main()` writes one `.harness/runs/three-lane-<ts>.json` artifact recording
that the structure and oracle validated on fixtures, never a real lane
measurement.
