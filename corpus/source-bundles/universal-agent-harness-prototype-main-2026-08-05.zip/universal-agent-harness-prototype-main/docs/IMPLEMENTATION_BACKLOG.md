# Implementation Backlog — planning context (the task tables have retired)

> **The backlog is `.harness/state/tasks.json`, not this file.** The task tables were
> removed on 2026-07-27 (`backlog-json-canonical`): they had become a SECOND writer
> surface next to the store the board actually reads, and the two drifted for ten days
> without anything turning red — 16 rows registered here and invisible everywhere, 84
> rows archived here and still on the board, 15 closures the store never learned, and
> 77 dep-tagged rows carrying no dependencies at all.
>
> - **read** — `harness.py tasks list [--lane L] [--category C] [--topo]`, one row with
>   its full prose via `harness.py tasks show <id>`, or the GUI backlog screen;
> - **write** — `harness.py tasks add "<title>" --body -` (prose on STDIN), then
>   `harness.py tasks dep <id> <depends-on|blocks|relates-to|duplicates> <otherId>` or
>   `harness.py tasks dep <id> no-deps`; `tasks move|close|note|plan|delete` for the rest.
> - **do NOT re-add a task table here.** `sp_store_parity` fails the gate if one appears:
>   the drift above started because the reader was frozen and the writer was not.
>
> Every row's prose was carried into the store verbatim (`body`, uncapped) before the
> tables went; git history holds the tables, and `docs/backlog-archive.md` is untouched.
> What survives below is genuine planning CONTEXT — rationale, roadmap narrative, the
> numbered owner decisions, the GUI phase matrix (a pointer into
> `docs/GUI_IMPLEMENTATION_PLAN.md`, never task rows), and the auto-generated
> self-review inbox, which is pre-backlog triage rather than tasks.

Completed milestones (M1–M4, M2W, M2H, MF, SE, HT, QA, CHAT) are recorded in the records
ledger — query them with `python scripts/harness.py records recent --kind milestone`. This
file now tracks only forward-looking work: criticality rationale, the remaining milestone
(M5), triage-stage ideation, and the deferred queue.

Each planned milestone still lands as an **MVP with a concrete validation scenario** under
`specs/40-features/` with its proportional gate green; when it starts it graduates to
`tasks/<milestone-slug>/`.

## GUI / front-end track (owner 2026-07-19) — detailed plan in `docs/GUI_IMPLEMENTATION_PLAN.md`

Front-end NOVO em **React/Vite/TS** (owner 2026-07-19: stack moderna liberada) consumindo o
backend `/api/*` que JÁ existe (`harness.py ui` → `harness_ui.py`, GUI-writes-no-state).
**Invariante real = zero-friction:** `ui.bat` serve um bundle PRÉ-BUILDADO e commitado (`ui/dist/`)
offline — sem npm/env/download no clique do usuário (não "stdlib-only", que foi inferência errada
do scanner). Alinha à visão "operating system for agentic engineering" (ref.
`harness_web_gui_dark_references.md`). **Cada item tem card de implementador** (fonte de dado
real + componente a tocar + tokens + aceite) no plano detalhado. Ordem por fase:

| Fase | Itens (ver plano) | Tam | Fonte/estado |
|---|---|---|---|
| **0 Fundação** | **GUI-F0 stack+pipeline `ui.bat`→dist** · F1 tokens · F2 tipografia · F3 densidade · F4 status-system · F5 primitivos | M,S,S,S,M,L | F0 = novo `ui/` Vite; tokens da paleta da ref |
| **1 Shell** | GUI-SH1 top-nav 7 domínios · SH2 mapa view→domínio · SH3 command-palette · SH4 inbox · SH5 env/budget/health · SH6 layout-3-painéis | M,M,M,M,S,M | reestrutura as ~15 views atuais |
| **1 X-cutting** | GUI-X1 progressive-disclosure · X3 deep-links · X4 inspector · X5 action-semantics · X6 antipadrões | M,M,M,M,S | padrões, não telas |
| **2 Workbench** | GUI-WB1 faixa-agente · ~~WB2+WB3~~ ✅ (f23a532 WB-β) · ~~WB4 approval-card~~ ✅ (7a13e21: dock completo, opções do servidor, gaps de backend declarados) · WB5 event-timeline | S..M | `/api/chat/*`, `/api/commit`, planCard |
| **3 Operations** | GUI-OP1 queue · OP2 worker-table+inspector · OP3 workflow-Temporal-grade · OP4 resources/locks · OP5 incidents | M,M,L,M,M | `/api/queue`, `workflow events`, `services` |
| **4 Experiments** | ~~GUI-XP1 runs~~ ✅ (b7c970f) · ~~XP2 compare~~ ✅ (7a90f20: CompareView, honestidade noise-floor) · XP3 regressão-drill · XP4 promotion | S,M,L,M | `experiment list/show --json` |
| **5 Research ⚠️** | ~~GUI-RS1 source-lanes · RS2 claim-evidence-matrix · RS3 consenso · RS4 run-form~~ — backend+painel-LEGADO shipped 2026-07-22 (`plan-gui-rs1.md`: "Surface: the LEGACY panel", desvio de D025); **nativização React PENDENTE** — `ui/src/shell/domainMap.ts` sem nenhuma section Research native. Pins legados rs1/rs2/rs3 ficam verdes intactos; `gui-research-screen`/`research-run-form` NÃO fecham até o port React (foram struck contra a surface errada). | M,M,M,M | remediation loop 2026-07-22 (Onda 2) |
| **6 Registry ⚠️** | ~~GUI-RG1..RG6~~ — backend+painel-LEGADO shipped 2026-07-22 (mesmo desvio de surface); **nativização React PENDENTE** — Registry com zero sections native no domainMap. `config-keys-gui`/`graphs-screen-gui` idem (struck contra o legado). | L,M,M,M,M,M | remediation loop 2026-07-22 (Onda 3) |
| **7 Activity ⚠️** | AC1 (7a13e21) · AC2 (7a90f20) — REAIS em `ui/src/domains/activity/`. ~~AC3 audit-hash-chain · AC4 incident-Sentry~~ — backend+painel-LEGADO shipped 2026-07-22 (ac34 6/6 pina o legado); **nativização React PENDENTE** — domainMap sem `audit`/`incidents` native. | M,S,M,M | remediation loop 2026-07-22 (Onda 4); claim anterior "TODAS as 8 fases completas" era FALSO para a GUI React |

O bookend de entrada do D037 continua valendo — cada slice do build-loop entra como task
(`harness.py tasks add`), agora no store em vez de numa tabela aqui.

Gaps de backend descobertos (pré-req, não UI): `workflow list --json`, compare run-a-run de
experimentos, verbo único de policies — §12 do plano.

## Criticality rationale (why this order)

1. **M1 first because it compounds:** legible failures make every subsequent item cheaper to
   build and debug — including the backlog itself. Proven in-repo: a partially mute error cost a
   full exploration cycle (F4 evidence).
2. **M2 before any GUI:** the CLI-first strategy (§8) is a dependency order, not a preference —
   every GUI button must call an existing subcommand.
3. **M3 is harness quality:** evaluation trust gates how much autonomy anything else can be given.
4. **M4/M5 (GUI) last:** rendering over a proven CLI is cheap; rendering over a moving one is rework.

## M5 — Interactive panel

Criticality: lower — highest build cost, and only valuable once M1–M4 hold.

_(all shipped — see backlog-archive.md)_

**MVP validation:** from the browser alone: approve one escalation and one controlled-write
merge (with the deliberate confirm step), watch a gate re-run, see the queue grouped by
`failureClass`. Feature-parity check: nothing the panel does is impossible from the terminal.

## Panel/UX & optimization roadmap (2026-07-12 — 8 parallel refinements)

Owner request: a wave of chat-UX, new panel screens, PyO3 optimization, and a full docs
revision + Wiki. Refined in parallel (Fable planners), each into a detailed, seam-grounded
roadmap under `docs/roadmap/`. 41 buildable items below, each linking its roadmap doc.

**Cross-cutting foundations (build/extract once, reuse everywhere):**
- **Panel-screen scaffold** — every new screen repeats one pattern: a stdlib collector in
  `harness_lib/` → a token-gated `GET /api/*` (`harness_ui.py`) → a `PAGE` section + nav
  button (`harness_ui_page.py`) → **CLI verb first (parity)** → mutations only via the
  `ui_panel.run_action` allowlist (GUI writes no canonical state). Extract from the first
  screen; later screens reuse it.
- **Harness-vs-target subject selector** — every screen must separate harness scope from the
  worked-repo scope; the SPEC-110 plumbing already exists (`targets.py`, `activeTarget`).
  Build the selector once.
- **Reuse the shipped highlighter + `/vendor` route** (this session) for the records/memory
  diff+code viewer and to serve the Wiki's fragmented markdown.

**Suggested build waves** (P1/small/no-dep collectors first — they unblock the GUIs):
- **Wave 0 (foundations):** `perf-metrics-rung`, `docs-tree-printer`, `docs-audit-refs`,
  `spec-index`, `research-index`, `tasks-board-read`, `queue-view-live`, `chat-tool-chips`,
  `config-keys-cli`, `CAP.1`, `graph-provider-abstraction`, `M5.rec`/`M5.mem`.
- **Wave 1 (GUIs on the collectors):** `gui-specs-screen`, `gui-research-screen`, `CAP.2`,
  `config-keys-gui`, `graphs-screen-gui`, `wiki-screen`, `chat-plan-hud`,
  `queue-cancel-worker`, `M5.sum`.
- **Wave 2 (interactive/advanced):** `research-run-form`, `research-checkpoints`,
  `chat-gate-tracker`, `queue-reorder`, `CAP.4/5`, `wiki-spec-guard`,
  `perf-hotspot-watch-rule`, `codex-stream-parity`, `pyo3-accel-prototype` (parked).

**Open decisions for the owner (cross-cluster — flagged, not assumed):**
1. ✅ **DECIDED 2026-07-13 (owner): YES** — the browser may START agent work / research waves
   (real token spend from a click). Unblocks `queue-start-action` + `research-run-form`.
   Owner also wants, later, a **task scheduler** (jobs / node-based flow execution) — recorded
   in the Deferred table; design `queue-start-action` so the spawn path is reusable by it.
2. ✅ **DECIDED 2026-07-13 (owner): YES, but NOT to `.env`** — key writes via CLI+GUI approved with
   the storage rescoped: primary backend = OS-native vault via the `keyring` lib (Windows
   Credential Manager / macOS Keychain / Linux Secret Service), read cascade
   `process env → keyring → .env` (headless/CI degrades to today's behavior; nothing breaks).
   `.env` demoted to dev fallback; a migration verb imports it into the vault. CLI `keys set NAME`
   reads the value from **stdin, never argv**; GUI write = allowlisted action calling that same
   verb (confirm dialog, masked echo, records entry with key NAME + timestamp, never the value).
   `keys list` gains a `backend` column + `lastRotated` metadata (doctor warns on stale keys).
3. ✅ **DECIDED 2026-07-13 (owner): `tasks.json` canonical** — `.harness/state/tasks.json` is the
   operational truth (lanes/status/priority/wfid), written ONLY by the `tasks` CLI verb; the
   backlog markdown stays as the human prose document, its tables FREEZE after `tasks import`
   (history, not state); in-execution lanes stay derived-per-poll, never stored. **Rider (owner
   directive, ties TE.5):** any agent-facing rendering of the store (`tasks list`, packet
   context) MUST reuse the shipped TE.5 tabular/compact path (`HARNESS_AGENT_OUTPUT=compact`
   TSV for fixed-property lists, ~44% of pretty-JSON chars) — never feed raw pretty JSON rows
   to a model.
4. **SPEC-105 ghost** fix vs the SPEC-116 legacy freeze (docs).
5. ✅ **DECIDED 2026-07-13 (owner): PERMIT** — allow the TodoWrite tool in headless chat spawns
   (plan-annotation only, no project-disk writes); unblocks the `chat-plan-hud` real-time
   plan-step HUD.

### Chat overlays — `docs/roadmap/chat-overlays.md`

_(all shipped — see backlog-archive.md)_

### Tasks board + work queue — `docs/roadmap/screens-tasks-queue.md`

### Specs inspector + research — `docs/roadmap/screens-specs-research.md`

### Skills + MCP panels — `docs/roadmap/screens-capabilities.md`

### Memory snapshot + records/changelogs — `docs/roadmap/screens-memory-records.md`

### Configs/keys + graphs — `docs/roadmap/screens-config-graphs.md`

### PyO3 optimization — `docs/roadmap/pyo3-optimization.md`

### Docs revision + Wiki — `docs/roadmap/docs-wiki.md`

## Security & isolation roadmap (2026-07-12 — complement, 3 parallel refinements)

Owner request: (a) formal enforcement/tests for the security/OWASP universal directives
(harness AND targets), and (b) an audit that files/diffs/escalations/data are not LEAKING
across the projects the harness operates on, or between the harness and those projects.
Refined in parallel (Fable), each into a seam-grounded roadmap under `docs/roadmap/`.
This round **enforces** the harness-vs-target boundary the prior round designed. 15 items.

**The cross-cutting foundation — a `subject` dimension.** Both isolation roadmaps converge
on ONE missing primitive: a structured `subject` (`"self"` | target name) stamped at the
producers and used to scope every view. Build it once; it is the dependency of
`records-subject-dimension`, `subject-tagged-events`, and `esc-subject-scope`. The
enforcement machinery (a deterministic `isolation-audit` gate + the `security-baseline`
gate) extends the same gate runner (`spec_test_gate.py` + `gate_generic` for targets).

**Most urgent (near-bugs, do first):**
- **`target-gate-env-filter` (P0)** — `gate_generic.run_target_commands` runs a target's
  build/test with the FULL `os.environ` (`gate_generic.py:177`): any target Makefile can read
  every API key + other targets' secrets. The workflow path is already deny-by-default
  (`harness.py:1825-1835`); the gate path must match. A real secret-exfil hole.
- **`requiresSecurityReview` hardcoded `False`** (`spec_test_gate.py:1732`) — no gate result
  can ever demand security review; fixed inside `security-baseline-mvp`.

**Suggested order:** `target-gate-env-filter` → `subject` primitive (`records-subject-dimension`,
`esc-subject-scope`) → the two gates (`isolation-audit-gate`, `security-baseline-mvp`) →
scoped views + per-target fixes → dual-subject/target extensions → the open architectural item.

**Open decisions for the owner:**
1. ✅ **DECIDED 2026-07-13 (owner): ROUTE** — a security-baseline hit escalates to the
   `security-triage` specialist (analyze + audit), NOT a hard-fail. Mandatory companion: the
   **known-false-positive exemption registry** (`{pattern, reason, reviewedAt}`) so a known FP
   never re-spends triage tokens/time — this selects the already-refined `security-diff-routing`
   row as the implementation. Future (owner note): the single triage step may grow into a full
   security-verification **pipeline** triggered by the alarm; design the routing hook as a named
   entry point, not an inline call, so the pipeline can replace the single agent later.
2. **`target-worker-world` (L/open)** — confining target workers to run OUTSIDE the harness
   tree (cwd today = harness ROOT, `harness.py:1848`) is an architectural change; do it, or
   rely on prompt-level read confinement + the audit gate?
3. False-positive tolerance for the security AST sink scan (snapshot-baseline mitigates).

### Security / OWASP enforcement — `docs/roadmap/security-owasp-enforcement.md`

_(all shipped — see backlog-archive.md)_

### Cross-project data isolation — `docs/roadmap/cross-project-isolation-data.md`

### Escalation / human / LLM isolation — `docs/roadmap/cross-project-isolation-escalation.md`

## Ops hygiene & bootstrap roadmap (2026-07-12 — complement, 4 parallel refinements)

Owner request: (a) bootstrap operated-project + harness dependencies that must stay running
(e.g. the ponytail MCP server); (b) investigate the black terminal windows spawning on
Windows; (c) investigate the `augus` absolute paths in commits + the git↔OneDrive trouble;
(d) an English-default terminology pass. Refined/investigated in parallel (Fable), each into
a seam-grounded roadmap under `docs/roadmap/`. 13 items.

**🔴 Confirmed do-now near-bugs (root-caused this round):**
- **Black terminal windows** — the async supervisor is spawned `DETACHED_PROCESS`
  (`async_runtime.py:761`) → a console-less parent → every child pops a window; **zero**
  `CREATE_NO_WINDOW` exists anywhere. The single highest-value fix is that one spawn +
  worker-spawn kwargs. (`win-hidden-spawn-helper`.)
- **Absolute-path leak keeps recurring** — the `local-absolute-paths` gate regex
  (`spec_test_gate.py:844`) matches a SINGLE backslash, so JSON's doubled `C:\\Users\\` (and
  `C:/Users/`, `/c/Users/`) evade it. Two live leaks: `.harness/handoff/handoff.json:197`
  and `.harness/targets/PrintIntel/target.json:3`; source is `harness.py:295`
  (`shutil.which("graphify")`). (`path-hygiene-scrub-and-gate`.)

**Shared foundation:** a **Windows-hidden spawn helper** in `processes.py` (`CREATE_NO_WINDOW`
+ hidden `STARTUPINFO`, only when stdio is redirected so interactive `!`/login flows keep a
console) is needed by BOTH `win-hidden-spawn-helper` AND `svc-registry-mvp` (the service
bootstrap must not spawn visible consoles). Build it once.

**Cross-round links:** `en-docs` folds into `docs-wiki` (one docs pass, not two, flipping its
wiki-folder names to English before they exist); `svc-mcp-wiring` connects to the prior
round's Skills/MCP panel (`CAP.*`); the CRLF finding (`.gitattributes eol=lf` vs system
`core.autocrlf=true`, 9 files re-touched) explains the release-artifact diff churn.

**Open decisions for the owner:**
1. **MCP transport** — stdio MCP servers can't be shared across CLI sessions; the ponytail
   case needs a socket/HTTP transport, else the honest scope is "configure, not bootstrap".
2. ✅ **Repo out of OneDrive — DONE 2026-07-13 (owner):** relocated to
   `C:\projects\universal-agent-harness-prototype`; doctor confirms no OneDrive path, no
   `.git` reparse point, repo-local `core.autocrlf=false` (WARN cleared).
3. **Legacy-frozen specs** — translating `supervision-m5` etc. may exit the SPEC-116 freeze;
   default is to leave frozen bodies as-is.

### Dependency / service bootstrap — `docs/roadmap/dependency-bootstrap.md`

### Black terminal windows (Windows) — `docs/roadmap/black-terminal-windows.md`

_(all shipped — see backlog-archive.md)_

### Path hygiene + git/OneDrive — `docs/roadmap/git-onedrive-path-hygiene.md`

_(all shipped — see backlog-archive.md)_

### English-default terminology — `docs/roadmap/terminology-en-default.md`

## CE — Communication efficiency roadmap (research round 2026-07-12; full round + verdict table in `docs/research/agent-communication-protocols.md`)

Double-Diamond round on efficient agent/tool communication (owner's July-2026 study, 61 refs).
Thesis the round confirmed against our own runtime: **protocols don't save tokens — architecture
does.** Divergence (5 ideators, 23 concepts) → 5 candidates → critique (4 lenses:
validity/architecture/cost/security). Deterministic-first held: every survivor is a
gate/ledger/read-time extension of an existing seam — no new daemon, broker, LLM-in-the-loop,
or bleeding-edge latent comm. Each row maps to a named gap (G1–G6), a **verified** integration
seam, and the one §13 metric it moves. Criticality: medium — net-cost-positive rule applies
(an item ships only with a baseline proving the gain). Unanimous build order: CE.1 → CE.2 →
CE.3/CE.4 → CE.8.

## DW — Dynamic workflows roadmap (research round 2026-07-12; full round + verdict table in `docs/research/dynamic-workflows.md`)

Double-Diamond round on dynamic workflows (owner's July-2026 study). Thesis confirmed against our
runtime: the field moves from hand-written static workflows to routable/replannable Agentic
Computation Graphs, but **"more agents = better" is false** — single-agent is the HARD baseline;
the winning shape is a **hybrid restricted orchestrator** (deterministic durable core runs a typed
graph; the LLM only fills explicitly-dynamic slots inside policies/budgets/gates). Divergence (5
ideators, 25 concepts) → 6 candidates → critique (4 lenses). Deterministic-first held: every
survivor extends an existing plan-time/settle-time/finalize-time seam — no daemon, no new state
family, no LLM in a control loop. The critique's governing correction: **measurement before
control** — the graph metrics (DW.3) and the router `--explain` verdict (DW.4) must exist and be
trusted BEFORE any auto-fork/auto-split flips on, because all pro-adaptation evidence is preprint-
grade and none is measured on this harness yet. Criticality: medium — net-cost-positive rule
applies. Build order: DW.1 → DW.2 → DW.3 → DW.4 → DW.5.

## CQ — Code quality roadmap (research round 2026-07-12; full round + verdict table in `docs/research/code-quality-agents.md`)

Double-Diamond round on the quality of agent-written code (owner's July-2026 study). Thesis
confirmed against our runtime: code quality is a control-and-assurance-SYSTEM problem, not a
model-capability one — and the harness's own weakest link is that the only per-change functional
oracle is a scenario self-check WRITTEN BY THE SAME implementer. Divergence (5 ideators, 25
concepts) → 6 candidates → critique (4 lenses). Governing corrections from critique: **fail-
closed** (unknown diffs → medium tier), **handles-not-bodies** (the collect boundary WITHHOLDS
secret-shaped results at workflow_reduce.py:97-105, so QA evidence is a handle to a pre-scrubbed
artifact, never an inline snippet), **honest naming** (≤3 mutants is not a "mutation score";
replaying your own test is REPRODUCTION, not independence). Criticality: medium — net-cost-
positive. Build order: CQ.1 → CQ.2 → CQ.3 → CQ.4 → CQ.5.

CQ.4 + CQ.5 both execute author-declared commands → build ONE allowlisted isolated-worktree
oracle runner first; both land on it. Cross-cutting: define the `exitClass` enum ONCE in
`result_contracts` (CQ.2/CQ.4/CQ.5 share it) or the three drift.

## W29 — Evidence-gated assurance (research round 2026-07-21; full round in `docs/research/w29-evidence-gated-assurance-round.md`)

Dual-vendor round (NVIDIA 4/5 + Sonnet 3) over the W29 monitor (Proof-or-Stop, Beyond Test
Presence, E3 — arXiv refs verified). All items observe-first; enforcement is a future owner
decision with measurement. Experiments: EXP-31 (false-DONE probe), EXP-32 (flakiness
repetition), EXP-33 (ladder A/B). Build order N1→N8.

## SEC — Code security roadmap (research round 2026-07-12; full round + verdict table in `docs/research/code-security-agents.md`)

Double-Diamond round on the security of agent-written code (owner's July-2026 study), de-duped
against the CQ round + landed work. Thesis: "the agent proposes; deterministic controls
authorize/verify/admit"; prompting is NOT a security boundary; limiting authority beats
classifying every malicious input. Divergence (5 ideators, 25 concepts) → 6 candidates →
critique (4 lenses). Two source-verified holes drove the spine; the sharpest lesson (reinforcing
the study): the items with real evidence are the ones that CONTAIN/MEASURE (egress gate,
regression ratchet), while the authority-limiting ideal (complete mediation) is honestly
downgraded to observe-first because the harness has **48 un-mediated `subprocess.*` sites across
18 files**. Criticality: medium — net-cost-positive. Build order: SEC.1 → SEC.2 → SEC.3 → SEC.4.

### SECREV-2026-07-21 — parecer /security-review (sandbox SPEC-151 + T-HASHCHAIN) — AGUARDANDO RATIFICAÇÃO DO OWNER (D014)

Parecer read-only completo no transcript da lane (1 HIGH, 4 MED, 2 LOW, 1 INFO + lista de superfícies sólidas). Nenhum fix implementado sem ratificação. Rows propostas:

**PARK:** SEC6 CaMeL-style capability interpreter, OS-level network sandbox, network signature/
Scorecard/SBOM. Note: SEC.2 and CQ.1 both consume the unconsumed `security['new']` diff — build
CQ.1 (routing) and SEC.2 (ratchet) as two consumers of one signal.

## RF — Owner refinement requests (2026-07-12, AFK loop; refined seams, not yet built)

Two owner-requested capabilities, refined into buildable rows for the loop to pick up. Both are
deterministic-first and additive. Criticality: medium.

Both ship the standard spec (SPEC-116) + scenario + doc. RF.1 phase-1 is observe-only (no
routing change); RF.2 defaults to dry-run (no deletion without `--apply`) — neither is
app/host-destroying. NOTE (slice discipline): RF.1 is explicitly two-phase — phase 1 (runner +
table) does NOT close RF.1; phase 2 (routing feedback, owner-gated) stays open.

## UX-GA — Generative-AI supervision UX roadmap (research round 2026-07-13, ALT PROVIDER gemini→codex; full round in `docs/research/ux-ui-generative.md`)

Double-Diamond round on gen-AI UX/UI, run on the alternative provider pipeline (divergence =
gemini-2.5-flash-lite, critique = codex gpt-5.6). Governing correction from the codex critique
(source-verified): the harness ALREADY has the pieces (N3 attention/blast-radius ranking, flat
worker cards, the composer) — EXTEND them deterministically; do NOT add a second dashboard, a new
state store, or a render-loop LLM; the only LLM use is one optional, read-only, evidence-GATED
explain action. De-duped vs the Panel/UX roadmap. Criticality: medium (M5-adjacent).

**CUT (codex critique):** a second dashboard, a new supervision state store, any render-loop / polling LLM,
and re-implementations of the N3 attention / worker cards / composer (already built).

## OB — Generative-AI observability roadmap (research round 2026-07-13, ALT PROVIDER gemini→codex; full round in `docs/research/observability-generative.md`)

Double-Diamond round on gen-AI observability of the harness's own operation, alt provider
(gemini divergence → codex critique). Codex critique (source-verified): the cost ledger / CE.2
economy meter / DW.3 graph metrics / cost-outlier review / trace-export / escalation ledger are
SIGNAL SOURCES; the existing `delegation-cost-trend` already covers a narrow OB1 slice. Keep four
bounded verify-on-demand DETERMINISTIC views; the only LLM use is an opt-in, evidence-cited,
redacted explanation over a deterministic feature card — no daemon, no network, no render-loop.
De-duped vs cost_metrics/CE.2/DW.3/self-review/control-liveness. Criticality: medium. Build
order: OB.1 → OB.2 → OB.3 → OB.4.

_(all shipped — see backlog-archive.md)_

**CUT (codex critique):** generic dashboards, any resident daemon, network calls, render-loop LLM,
raw-summary re-dumps, and duplicating the existing `delegation-cost-trend`. LLM output (OB.3 only)
is opt-in + evidence-cited + redacted + a view.

## TE — Token economy (research round 2026-07-11; sources + gains in `docs/WORKFLOW_TOKEN_ECONOMICS.md` §TE ideation)

Criticality: medium — each item ships only with a measurement proving net gain
(net-cost-positive rule). TE.1–TE.3 (quiet gates, delegation-cost findings,
layered verification contract) shipped in the TE round itself.

_(all shipped — see backlog-archive.md)_

## WF — Workflow efficiency roadmap (research round 2026-07-20; full round in `docs/research/loop-workflow-efficiency-round.md` + evidence `docs/research/loop-workflow-efficiency-evidence.md`)

Owner 2026-07-20: the loop/single-demand workflow got too SEQUENTIAL (a 10-20min task now takes
20min-1h+). Diagnosis (firsthand + external-validated): #1 RE-GATE CHURN (every tiny fix forces a full
7-15min re-gate), #2 the gate is the constraint (ToC drum), #3 cold serial spawns. 9 concepts from a
5-ideator NVIDIA divergence wave + a parallel Sonnet external-evidence gather (Bazel/Nx/Turborepo,
Google TAP/Ekstazi/pytest-testmon, pytest-xdist, Little's Law/ToC, LLMCompiler). BUILD ORDER (each earns
its cost against MEASURED gate time): observability → cache+TIA (kill #1) → parallel (compress #2) →
pipelining (throughput) → speculative (measured bet). All ship SPEC-116 + scenario + doc; none weaken the
gate/reckon/ledger guarantees.

## MF2 — Self-review inbox triage (2026-07-20 audit session)

Triage of the 3 auto-generated inbox findings (block below refreshes itself on the next
self-review run; these are their groomed homes). The `workflow-cost-outlier` finding was
INSPECTED, not deferred: ledger record `WF-20260712-004425-895025` (fork-join,
profile research-divergence, 5 workers) shows estTokens 22,878 vs **observedTokens
1,796,816** — a 78× estimator under-estimate, $9.62 costBasis observed. The blowout is
an estimation gap, not a plan gap; operationally the ideation rounds already moved to
NVIDIA free-tier ideators (2026-07-20 round cost ~0).

**owner-decision (bookend self-exemption policy) — DECIDED 2026-07-20 = (a), recorded as D037:**
every feature gets a backlog row at entry (SPEC-155 groom applies) and closes in lockstep at ship
(SPEC-154), owner-directed/build-loop work INCLUDED — no exemptions. The commissioned batch below
dogfoods it (rows created at entry before any code).

## Ideation input (not scheduled — triage material)

`docs/SELF_EVOLUTION_IDEATION.md` (2026-07-09): external survey (self-evolving agents,
MAPE-K/autonomic computing, adaptive automata, AIOps/safety) crossed against SPEC-109, with
nine triage-ready candidates (I1–I9: MAPE-K naming, rules-that-propose-rules, blast-radius
tiers, config variant evaluation, skill retrieval, loop KPI, replay-verified actions,
LLM signal interpreter, evolution-process audit). Companion record:
`docs/SELF_EVOLUTION_REPORT.md`.

**Re-triage 2026-07-11 (§5, double diamond, fresh 2026 sources)** — five actionable
outcomes, **all shipped 2026-07-11**. ~~I3-adj (safe-action rate circuit breaker, S)~~,
~~I11 (zombie-scan over friction/worklog/records, S)~~, ~~I10 (one-shot MLAS 5×5 coverage
mapping, S/docs — §6)~~, ~~I2-adj (rule-proposal provenance vs OEP poisoning, S)~~ and
~~I9-adj (evolution-memory anomaly/spam audit, the broader half of the I9 cluster, S–M)~~
done. The rules landed in `self_review.py` + the extracted `self_review_rules.py`
(MF split at the 900-line budget): `safe-action-rate-breaker`,
`evolving-store-zombie-scan`, `rule-proposal/*` provenance + acceptance-path refusal, and
`evolving-store-anomaly/*` (rate/single-writer/orphan) — all with se_self_review coverage
(56/56) and spec R26/R27 registration. Named residual (§6 Cognitive×Propose, still ◐):
write-time validation of store content — auditable post-persistence now, not at the door.
I4/I8 stay trigger-gated (I8's bar HARDENED by the 2026 judge-bias corpus: adoption now
requires A/B against the deterministic dedup on a hand-labeled sample). I1/I5/I6/I7 held
as-is with fresh confirming sources.

## Deferred (needs a demand signal first — do not schedule)

Recorded, not scheduled (the loop already watches them): P1 via the provider-sweep-age rule
(~2 weeks), GEMINI key rotation (user-side), py-run.sh × .env decision, ledger growth trigger,
~~chat_operator.py fragmentation~~ — **done 2026-07-10** (split into chat_engines.py 349 +
chat_setup.py 308 + chat_operator.py 701, all under the 900 budget; escalation resolved),
~~async_runtime.py 1,009 > 900~~ — **done 2026-07-10** (fragmented into async_state.py 239 —
the pure state/persistence + await-policy + circuit-breaker domain, bound via its own
`bind(env)` mirroring async_runtime.bind — and async_runtime.py 813 which re-exports it; both
under the 900 budget. Same round split scripts/harness_ui.py 1,319 → harness_ui_page.py 1,062
(the PAGE front-end string, moved verbatim) + harness_ui.py 262 server/routes/serve/main).

---
Milestone history: `python scripts/harness.py records recent --kind milestone` (search the
full ledger with `records search <terms>`). Planning-only file since the SPEC-112 migration.

<!-- self-review-inbox:start -->
## Self-review inbox (auto-generated — triage, then resolve the escalation)

| finding | observed | proposed action | ref |
|---|---|---|---|
| `delegation-cost-trend:agent:reviewer` | median of last 5 144000 vs previous 5 102000 | this agent's delegation stream is drifting while the aggregate can look flat — review its briefs / context packaging before the trend compounds (OB.2) | — |
| `harness-lines-burndown` | 3234 lines | run the next extraction round (MF.1 round 2: workflow lifecycle + CLI parser table) | MF.1 |
| `self-lib-file-budget` | scripts/harness_lib/chat_operator.py 1625 lines (+11 more over budget) | fragment the module (MF discipline: extract a cohesive domain, bind() or pure module) | — |

<!-- self-review-inbox:end -->
