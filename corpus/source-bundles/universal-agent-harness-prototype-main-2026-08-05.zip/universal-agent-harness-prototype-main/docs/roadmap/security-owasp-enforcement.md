# Roadmap — Security/OWASP directives: from prose to deterministic enforcement

## Goal + why

Request (quote): "Temos algumas diretrizes gerais em forma de spec, principalmente sobre SEGURANÇA DE SOFTWARE e OWASP, que parecem NÃO ter checagem formal da nossa parte nem testes. São importantes não só para o harness como também para os projetos que ele vai operar e aplicar como DIRETRIZES GLOBAIS."

Adversarial framing applied throughout: a directive that is not a deterministic check (or a forced review trigger, or a documented exemption) does not hold. Today the harness *checks that the string "OWASP ASVS 5.0.0" appears in a doc* (`scripts/harness_lib/baseline_catalog.py:154-162`, `engineering-guardrails:reference-anchor-index`) — that is prose asserting prose, not enforcement.

## Current-state audit

Enforcement classes: **DET** = deterministic check exists; **PARTIAL** = deterministic but covers only a slice of the directive's scope; **REVIEW** = a review trigger exists but is evadable; **PROSE** = nothing executes.

### Cross-cutting adversarial findings (verified)

| # | Finding | Evidence |
|---|---|---|
| F1 | `requiresSecurityReview` is **hardcoded `False`** in quality-state after every gate run. No gate result can ever demand a security review. | `scripts/spec_test_gate.py:1732` |
| F2 | OWASP anchors are enforced as **string presence** in `specs/MANIFEST.yaml` + baseline docs only. | `scripts/harness_lib/baseline_catalog.py:154-162`; anchor list at `scripts/harness_lib/engineering_guardrails.py:54-65` |
| F3 | Security risk routing scores **task text + file-path globs only** (`scripts/harness.py:144-165`, riskTerms at `.harness/project.json:113-133`). A diff introducing `eval()`/`shell=True` under a bland task description routes nowhere. Diff *content* is never inspected. | `scripts/harness.py:158-165` |
| F4 | `secret_scan` runs only at the **workflow collect/reduce boundary** (`scripts/harness.py:1590`, `scripts/harness_lib/workflow_reduce.py:97,338`, `scripts/harness_lib/log_rotation.py:65`). The repo **tree** and commits are never scanned — "never commit real secrets" has no check. `hygiene-lite` catches a tracked `.env` by **filename** only (`scripts/harness_lib/gate_generic.py:126`). | cited inline |
| F5 | The per-target gate (`gate_generic.run_target_gate`, `scripts/harness_lib/gate_generic.py:217-252`) has exactly **one** security check: `check_protected_instructions` (line 138). No secret scan, no dangerous-sink scan, nothing OWASP-shaped runs against governed targets. | `scripts/harness_lib/gate_generic.py:224-231` |

### Directive → enforcement table

`specs/00-universal/secure-engineering.md`:

| Directive (line) | OWASP map | Today | Evidence |
|---|---|---|---|
| Untrusted input validated/encoded (L13) | A03 Injection | **PROSE** | no check anywhere |
| Authz fail-closed at resource level (L14) | A01 Broken Access Control | **PARTIAL** | only the harness's own worker write boundary: red-team fixture `scripts/spec_test_gate.py:1256-1316` + `tools/hooks/workflow_write_guard.py`; nothing generic, nothing for targets |
| Auth/session/token changes require explicit review (L15) | A07 Auth Failures | **REVIEW (evadable)** | riskTerms routing, F3 — blind to diff content |
| No custom crypto/token formats (L16) | A02 Cryptographic Failures | **PROSE** | — |
| Don't weaken security controls to pass tests (L17) | — | **PROSE** | — |
| No secrets/stack internals in logs/errors/output (L18) | A09 | **PARTIAL** | `secret_scan.py` at collect/reduce + `trace-secret-redaction` fixture (`scripts/spec_test_gate.py:904`); not the tree, not targets (F4) |
| No new network/shell/eval/deserialization without scope (L19) | A08/A05, LLM excessive agency | **PROSE** | no sink detector exists |
| Least privilege (L20) | A01/A05 | **PARTIAL** | write guard for workflow workers only |
| Safe-by-default config (L21) | A05 Misconfiguration | **PROSE** | — |
| Allow-lists over block-lists (L22) | — | **PROSE** (but practiced: write guard is allow-list) | — |
| Control-plane file protection (L60) | supply chain | **DET — the model to copy** | `tools/hooks/protect_canonical_files.py`, `protected-files` fixture `scripts/spec_test_gate.py:1028-1047`, per-target `gate_generic.py:138-167` |

`specs/00-universal/api-and-interface-security.md`:

| Directive (line) | OWASP map | Today |
|---|---|---|
| Input/output contract validation (L13) | ASVS V5 | **PROSE** |
| Object-level authorization (L14) | API1 BOLA | **PROSE** |
| Mass assignment / over-exposure (L15) | API3 | **PROSE** |
| Bounded pagination/payload/recursion (L16) | API4 | **PROSE** for targets (harness's own token budgets exist in `engineering_guardrails.py` but are harness-internal) |
| No internal errors via public interfaces (L17) | A09 | **PROSE** |
| Rate limiting/idempotency where plausible (L20) | API4 | **PROSE** |
| Tool/plugin/model calls are security boundaries (L21) | LLM Top 10 | **PARTIAL** — red-team fixture covers harness workers only |

`specs/00-universal/dependency-and-supply-chain.md`:

| Directive (line) | Today |
|---|---|
| Preserve lockfiles; no mass-updates (L15-16) | **PROSE** — no gate detects lockfile churn |
| No unknown installers/post-install hooks (L17) | **PARTIAL** — protected-file snapshot around installers covers instruction files only (L57) |
| New runtime dep needs justification (L19) | **PROSE** — nothing detects a new import/dep appearing |
| Pin/constrain versions (L20) | **PROSE** |
| Installer snapshot protocol (L57) | **DET** — `protect_canonical_files.py snapshot/check` |

`specs/00-universal/secrets-and-configuration.md`:

| Directive (line) | Today |
|---|---|
| Never commit real secrets (L13) | **GAP — the worst one.** Scanner exists (`secret_scan.py:22-31`, 8 anchored patterns) but is never pointed at the tree/commits (F4) |
| No secrets in logs/HARNESS_RESULT (L15) | **DET** at collect/reduce + log rotation |
| Don't weaken .gitignore/secret scanning (L19) | **PROSE** |

`specs/00-universal/data-protection-and-privacy.md`: L13-L21 (minimization, tenant boundaries, no real personal data in fixtures, no sensitive data in handoffs) — **all PROSE/REVIEW**; only the riskTerms text-match can trigger review (F3). Handoff secret leakage specifically is covered by secret_scan at reduce (PARTIAL).

`specs/00-universal/ai-agent-safety.md`: agents must not self-upgrade (L14) — structural (routing owns profiles); destructive/broad-write commands need policy (L15) — **PARTIAL** (write guard + red-team fixture); no secrets in handoff/context (L22) — **PARTIAL** (secret_scan at reduce, not at handoff-file write).

`specs/00-universal/canonical-file-protection.md`: **DET end-to-end** (snapshot, hook, fixture, per-target). This spec is the existence proof that the repo already knows how to turn a directive into enforcement — the roadmap below replicates its pattern.

## Phased plan

Pattern to replicate (proven): stdlib module returning gate-shaped `{"name","status","detail"}` rows (`engineering_guardrails.py:111-121`), wired into `spec_test_gate.py` main() (`:1631-1694`) for the harness AND into `gate_generic.run_target_gate` (`gate_generic.py:217-231`) for targets, with a fixture + scenario.

### Phase 1 — MVP: `security-baseline` deterministic checks (highest value/effort)

New module `scripts/harness_lib/security_baseline.py` (stdlib only), `evaluate(root: Path, config: dict) -> list[dict]`, subject-root parameterized like `gate_generic.check_syntax`. Checks:

1. **`security-baseline:tree-secrets`** — reuse `secret_scan._PATTERNS` (import, don't duplicate) over `git ls-files` text files (bounded like `MAX_SCAN_FILES=400`, `gate_generic.py:29`; respect `EXCLUDE_PARTS`, `targets.py:40`). Redaction contract preserved (first-4+len). Placeholder allowlist for `.example` files. Closes secrets-and-configuration.md:13.
2. **`security-baseline:python-sinks`** — `ast`-walk (same approach as `engineering_guardrails.largest_functions`, `:85-97`) for the deterministic sink set: `eval`/`exec` calls, `subprocess.*(..., shell=True)`, `pickle.load(s)`, `yaml.load` without `SafeLoader`, `os.system`, `requests(..., verify=False)`, `hashlib.md5/sha1` in names containing token/password/sign. **Snapshot-baseline semantics** exactly like `check_protected_instructions` (`gate_generic.py:155-167`): first run records existing sinks to `testing/security-baseline.json` (harness) / `state_dir(name)/security-baseline.snapshot.json` (targets); a *new* sink fails until reviewed. This is what makes secure-engineering.md:19 ("no new shell/eval/deserialization without explicit scope") a real check instead of prose — new = drift = fail.
3. **`security-baseline:config-hygiene`** — tracked files matching secret-bearing names/extensions (`.env`, `*.pem`, `id_rsa*`, `*.p12`, `*.key` with PEM header) — generalizes `hygiene-lite`'s filename check (`gate_generic.py:126`) to both subjects.
4. **Fix F1**: `requiresSecurityReview` in quality-state derives from security-baseline failures instead of literal `False` (`spec_test_gate.py:1732`; same field exists in reduce results, `workflow_reduce.py:338`).

Wiring: `check_security_baseline()` added to the non-fast branch of `main()` (`spec_test_gate.py:1643-1652`); fixture name registered in `WORKFLOW_FIXTURE_FUNCTIONS` and in the CI required list (`spec_test_gate.py:904`).

### Phase 2 — Dual-subject + review triggers with teeth

1. `gate_generic.run_target_gate` gains `results.extend(security_baseline.evaluate(target_root, entry))` next to `check_protected_instructions` (`gate_generic.py:228`). Per-target snapshot lives in `targets_lib.state_dir(name)` (`targets.py:124`), same as `protected-files.snapshot.json`. Non-Python targets get checks 1+3 only (documented ceiling; sink scan is Python-AST in MVP).
2. **Diff-aware routing (fix F3)**: when Phase-1 sink scan runs in a pre-commit/gate context, a *new* sink or a riskTerms hit in changed-file **content** (not just task text) forces the `security` profile / `security-triage` workflow suggestion (`.harness/workflows/workflow-profiles.json:209`, `harness.py:189-195` already lists "security triage" as a workflow term). This gives secure-engineering.md:15 ("auth changes require explicit review") an enforcement path that does not depend on the task author's honesty.
3. **Exemption registry — no silent prose**: `testing/security-baseline.json` allowlist entries must carry `{path, rule, reason, reviewedAt}`; an entry missing `reason` fails the gate. Exemption is explicit and diff-reviewable, mirroring `specConformance.legacy` (`spec_test_gate.py:792`).

### Phase 3 — Directive→check conformance map (kills the prose class structurally)

Mirror the SPEC-116 Gherkin mechanism (`spec_conformance.py:90-126`): each security universal spec gets stable invariant IDs; a mapping file (extend `testing/security-baseline.json`) declares for every ID one of `{check: <gate-check-name> | trigger: <riskTerm/profile> | exemption: <reason>}`. A new check `security-baseline:directive-map` fails when a security-spec invariant has no mapping — so a future prose-only directive **cannot be merged silently**. Scope Phase 3 to the 6 security specs; do not generalize to all universal specs yet.

### Phase 4 — SDD spec + scenario (validation)

- Door NEW per SPEC-116: `specs/templates/intake-refinement.md` → `specs/40-features/security-baseline.md` (+ `.intake.md`), required sections per `spec_conformance.REQUIRED_SECTIONS` (`spec_conformance.py:24-31`), Gherkin `Scenario:[sb:*]` ids.
- `testing/scenarios/sb_security_baseline.py` (naming convention: existing `sc_spec_conformance.py`, `ht_targets.py`): plants a fake anchored secret in a temp tree → tree-secrets fails; adds `eval()` beyond snapshot → python-sinks fails; exemption without reason → fails; clean tree → passes; runs against a temp "target" via the same `evaluate(root)` to prove dual-subject.
- Gate runs: `python scripts/spec_test_gate.py spec-pack`, `... scenarios`, `... spec-pack --target <name>`.

## Dual-subject application (summary)

One module, two call sites — the pattern already proven by protected-files:

| Subject | Call site | Snapshot/state |
|---|---|---|
| Harness itself | `spec_test_gate.py` main() check list | `testing/security-baseline.json` |
| Governed target | `gate_generic.run_target_gate` (`gate_generic.py:217`) | `.harness/targets/<name>/security-baseline.snapshot.json` via `targets.state_dir` (`targets.py:124`) |

The universal specs stay the single source of directives; the module is the single source of enforcement; `target.json` `validation.<gate>.commands` (`gate_generic.py:170-189`) remains the place for a target's *own* SAST/dep-audit tools when it has them (spec's "project scans when configured", secure-engineering.md:36).

## Risks / open decisions

- **False positives** are the failure mode that kills adoption. Mitigations already in-house: anchored patterns only (`secret_scan.py:10-12` ponytail note), snapshot-baseline (fail only on *new* sinks), explicit allowlist. Do NOT add an entropy detector.
- **Not a SAST replacement** — explicit non-goal. The sink list is deliberately small and deterministic; A01/A03/API1-level semantic checks stay REVIEW-tier (security-triage workflow, cheap models per the LLM-cost memory) or target-owned tools. Pretending a regex covers BOLA would be the same prose-theater as F2.
- **Language ceiling**: sink scan is Python-AST in MVP. Regex-tier for JS/TS later only if a governed target needs it (ponytail: named ceiling).
- **Perf on big targets**: bounded caps (existing `MAX_SCAN_FILES` idiom); OneDrive/Windows I/O — keep single-pass reads.
- **Open decision**: should `requiresSecurityReview=true` *block* anything, or only route? Proposal: route + surface in quality-state first (observable, reversible), block at `release` gate in a later increment.
- **Open decision**: does Phase-3 directive-ID annotation live inside the spec files (edit 6 protected-adjacent specs) or in the mapping file only (no spec edits)? Recommend mapping-file-only to avoid touching universal specs.

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| security-baseline-mvp | security-baseline gate: tree secret scan, Python sink snapshot scan, config hygiene, requiresSecurityReview wiring (harness subject) | M | P1 | — | docs/roadmap/security-owasp-enforcement.md |
| security-baseline-targets | dual-subject: run security_baseline in gate_generic per target + per-target snapshot | S | P1 | security-baseline-mvp | docs/roadmap/security-owasp-enforcement.md |
| security-diff-routing | diff-content risk routing: new sinks / riskTerms in changed content force security profile / security-triage | S | P2 | security-baseline-mvp | docs/roadmap/security-owasp-enforcement.md |
| security-directive-map | directive→check conformance map for the 6 security universal specs (no silent prose check) | S | P2 | security-baseline-mvp | docs/roadmap/security-owasp-enforcement.md |
| security-baseline-sdd | SPEC-116 door NEW: intake + specs/40-features/security-baseline.md + sb_security_baseline.py scenario | S | P1 | security-baseline-mvp | docs/roadmap/security-owasp-enforcement.md |
