# Roadmap — Config/Keys screen + Graphs screen (planning only)

Status: refined plan, nothing implemented. Both requests are **door NEW** under
SPEC-116 (`specs/templates/intake-refinement.md` → `specs/40-features/<name>.md`
with Gherkin scenarios mapped to named checks; conformance enforced by
`scripts/harness_lib/spec_conformance.py` via the spec-pack gate).

Shared architecture constraints (verified):

- GUI is one self-contained page `scripts/harness_ui_page.py` (`PAGE`), nav pills
  at `scripts/harness_ui_page.py:318-320` (`Painel / ⚙ Config / ◇ Compose`);
  routes in `scripts/harness_ui.py:137-217` (GET snapshots, POST
  `/api/action` → `ui_panel.run_action` at `scripts/harness_ui.py:191-194`).
- All GUI mutation goes through the allowlist `ACTIONS`
  (`scripts/harness_lib/ui_panel.py:675-736`) and `run_action`
  (`scripts/harness_lib/ui_panel.py:739-802`): browser confirm for mutating
  actions (:791), human-only backstop via `classify_command` (:785). GUI writes
  no canonical state directly — every button is an existing CLI subcommand.
- CLI-first parity: every screen capability lands as a `scripts/harness.py`
  subcommand first (backlog rationale, `docs/IMPLEMENTATION_BACKLOG.md:17-18`).
- Harness-vs-target (SPEC-110): subjects are root-parameterized —
  `discover_paths(subject_root, subject_out)` at
  `scripts/harness_lib/discovery.py:66-70`; per-target artifacts under
  `graphify-out/targets/<name>/` (`scripts/harness_lib/targets.py:120-125`);
  `graph-build-code-ast --target` at `scripts/harness.py:2479-2483`. Both
  screens need a subject selector (harness | registered target).
- GUI validation: Playwright layer `testing/scenarios/ui_e2e.py` (+ in-process
  `testing/scenarios/m5_ui_panel.py`); extend after every GUI change; run on the
  cheap `ui-validation` routing profile (`docs/IMPLEMENTATION_BACKLOG.md:48`).

---

## Screen A — Configs & Keys

> "tela de configs e keys: configurações gerais que NÃO quebrem o harness e o
> usuário pode editar. Aqui também as SECRETS das APIs. Precisamos validar a
> feature SEM EXPOR keys de produção do .env."

### Seams

| Seam | Where |
|---|---|
| Editable config surface | `.harness/project.json` (whole file; no per-key editor exists today) |
| Existing config-view pattern to extend | `routing_snapshot` `scripts/harness_lib/ui_panel.py:259-278` feeds the SPEC-115 `#viewConfig` section (`scripts/harness_ui_page.py:357`) |
| Ambient key loading | `load_ambient_keys` `scripts/harness_lib/common.py` — real env wins, keys come from the OS vault (SPEC-169 v2 removed the `.env` tier), `HARNESS_NO_VAULT=1` gives a key-absent test path |
| Key consumption | `_discover_provider_gates` `scripts/harness_lib/discovery.py:27-55`: `GEMINI_API_KEY`/`GOOGLE_API_KEY` (:36), `NVIDIA_API_KEY` (:47); per-target `requiresEnv` + deny-by-default `spawn_env` `scripts/harness_lib/targets.py:198-200` |
| Redaction | `scripts/harness_lib/secret_scan.py:22-36` — anchored patterns + `redact()` = first-4-chars+len, value never echoed |
| Template of known keys | `.env.example` (repo root) |

### SAFE editable subset (proposed allowlist — JSON pointer → validator)

Editable (bounded, harness keeps running with any allowed value):

- `intakeTriage.minPromptChars|maxHits` (int ranges), `intakeTriage.silentProfiles` (subset of the closed profile set) — `.harness/project.json:961-965`
- `knowledgeGraph.llmAssisted.enabled` (bool, :397), `knowledgeGraph.apiAssistedProviders.nvidia.enabled` (bool, :449), `knowledgeGraph.discoveryOrder` (permutation of the known list, :389-395), provider model lists (arrays of strings)
- `graphRefresh.codeGlobs|docGlobs|exclude` (:502-508)
- `workflows.limits.*` and `workflows.budgets.tokenBudget.*` (bounded ints, :522-528, :620-631)

NEVER editable from GUI (harness-breaking or trust-boundary):
`schemaVersion`, `protectedFiles.*` (:966+), `universalSpecs.required` (:295),
`workflows.schemas` (:529), `specConformance` (:1006), `directoryGuides`,
`runtime`, `stateStore` paths, `knowledgeGraph.outputDir|graphPath|reportPath`,
and every `validation.<gate>.commands` array (arbitrary-command surface —
stays CLI/editor-only).

### Secret-safety design

1. **Presence + masked only.** A `keys_snapshot(root)` reports, per known key
   (union of provider `requiresEnv` from `.harness/project.json:409/453` and
   every target's `requiresEnv`): `{name, present, source: env|.env|absent,
   masked}` where `masked = secret_scan.redact(value)` (first-4+len). The raw
   value never enters any snapshot, action output, or log.
2. **Masked values cannot re-trip the scanner**: `redact()` output is 4 chars +
   a length note, shorter than every anchored pattern's minimum — so
   `secret_scan.scan(snapshot) == []` is itself the leak test.
3. **Validation WITHOUT prod keys** (scenario runs with `HARNESS_NO_VAULT=1`,
   the fixture path built into `inject_vault_keys`,
   `scripts/harness_lib/keys_vault.py`): export fake pattern-shaped keys
   (`sk-FAKE…`, `nvapi-FAKE…` — same trick as `secret_scan._demo()` :66) and
   assert (a) snapshot shows present+masked, (b) `secret_scan.scan` over the
   full JSON payload of every route returns `[]`, (c) provider gates in
   `discover` flip to available (`discovery.py:27-55`) without any network call.
4. **Key WRITE is deferred** (open decision): `.env` is operator-managed and
   agent-protected. If added later it is `harness.py keys set NAME` reading the
   value from stdin (never argv — process lists leak), and the GUI action
   response echoes only the redacted form. MVP = presence view only.

### Phased plan

- **A0 (SDD)** — intake refinement → `specs/40-features/screen-config-keys.md`
  (Gherkin: safe-edit accepted / forbidden-key refused / masked-keys-no-leak).
- **A1 (CLI MVP)** — new `scripts/harness_lib/config_edit.py`: `EDITABLE`
  registry (pointer → validator) + `config list|get|set` subcommands in
  `scripts/harness.py`; `keys` subcommand printing the presence+masked table.
  Save path: validate → `write_json` → re-`load_project()` smoke. Scenario
  `testing/scenarios/cfg_config_keys.py` (fake keys, forbidden-pointer refusal,
  round-trip of one editable key).
- **A2 (GUI)** — extend the existing `⚙ Config` view (`harness_ui_page.py:357`)
  with two panels: "Geral" (form generated from `EDITABLE`, server-side
  re-validation) and "Keys" (presence+masked read-only). Feed: extend
  `routing_snapshot` (or a sibling `/api/config`) in `ui_panel.py`; one new
  allowlisted action `config-set {mutating: True}` in `ACTIONS`
  (`ui_panel.py:675`). Extend `ui_e2e.py`: edit a safe key, assert refusal of a
  forbidden pointer, assert no raw fake key text anywhere in the DOM.
- **A3 (increments)** — `.env.example` diff ("known keys you have not set"),
  per-target `requiresEnv` rows, optional `keys set` (decision above).

### Risks / open decisions

- `project.json` is also rewritten by `models`/`routing` commands — keep the
  single-writer rule (all writes via CLI subprocess); no GUI-side merge.
- Enabling `llmAssisted.enabled` from GUI changes network posture — the flag is
  already opt-in-only policy; the form must label it as a network opt-in.
- Decide: GUI `.env` write allowed at all, or forever presence-only.

---

## Screen B — Graphs (management, exploration, metrics; provider-decoupled)

> "nossos grafos — tela de gerenciamento, exploração e MÉTRICAS de atualização e
> consumo … DESACOPLAR isso e a nossa busca do graphify, fazendo dele apenas UM
> PROVEDOR disponível."

### Seams — where discovery couples to graphify today

| Coupling | Where |
|---|---|
| `discover` routes code straight to the builder | `scripts/harness_lib/discovery.py:90` calls `graphify_code_ast.build_graphify_code_ast` |
| Freshness gate calls the builder directly | `scripts/harness_lib/gate_checks_policy.py:60-76` (harness), `scripts/harness_lib/gate_generic.py:193-214` (per target), `targets.py:174-176` (`graphStale`) |
| Builder-specific CLI | `graph-build-code-ast` `scripts/harness.py:2476-2500`; `graph-status` :2473 / `graphify_status()` :245-275 |
| Artifact readers (already shape-based, NOT builder-coupled) | `doc_find` reads `docs-enrichment.json` + `modules.json` (`discovery.py:149-193`); symbols/report are files under `graphify-out/` |
| Normalizer that already accepts multiple graph shapes | `normalize_graphify_graph` `scripts/harness_lib/graphify_adapter.py:76-106`; workflow partitioning `group_graphify_paths` :109-174 |
| Search guardrail hook | `tools/hooks/graphify_search_guard.py` (PreToolUse before Glob/Grep) |

Key insight: the **artifact contract is already the interface**. Everything
downstream (doc-find, symbols, workflow partitioning, the freshness gate, the
panel) consumes files in `graphify-out/` in shapes `graphify_adapter` already
normalizes. Only four call sites invoke the builder function directly.

### Provider-abstraction design (ponytail-minimal)

- **Interface**: a provider = `{name, build(root, out_dir) -> stats,
  status(root, out_dir) -> dict}` producing the artifact set in the subject's
  out dir — `graph.json` (nodes/edges/communities, any shape the adapter
  normalizes) required; `symbols.json`, `modules.json`, `GRAPH_REPORT.md`
  optional (features degrade calmly when absent, same rule `doc_find` already
  applies at `discovery.py:159-167`).
- **Registry**: new `scripts/harness_lib/graph_providers.py` with two entries:
  built-in `graphify-code-ast` (wraps `graphify_code_ast.build_graphify_code_ast`)
  and `external-command` (a configured argv run via `run_process_tree_bounded`
  that must emit `graph.json`; validated by `normalize_graphify_graph` on
  completion — `normalizationStatus != "unsupported"`). No plugin loading, no
  entry points; providers are declared in config, reviewed in-repo.
- **Selection**: `knowledgeGraph.provider` (default `"graphify-code-ast"`) in
  `.harness/project.json`; per-target override key in `target.json` (merged by
  `load_targets`, `targets.py:43-62`). CLI: `graph providers` (list + which is
  active + availability), `graph provider set <name>` (validated).
- **Fallback**: if the selected provider fails or emits an unusable graph, fall
  back to `graphify-code-ast` and report `{provider, fellBackTo, reason}` in
  build stats — deterministic-first, never silent. The text/image API chain
  keeps its own existing gate/fallback order (`discovery.py:27-64`) — untouched.
- **Rewire (the whole diff)**: replace the direct builder call at 4 sites —
  `discovery.py:90`, `gate_checks_policy.py:71`, `gate_generic.py` (~:205),
  `harness.py:2485` — with `graph_providers.active(subject).build(...)`.
  `graph-build-code-ast` stays as an alias for the built-in provider.

### Metrics design

- **Structure**: nodes/edges/parse errors/files from `graph.json.stats`
  (written at `graphify_code_ast.py:169`).
- **Freshness**: reuse the exact gate rule (graph mtime vs newest tracked `.py`,
  `gate_checks_policy.py:60-70`; per-target `targets.py:174-176`) — one shared
  helper so screen and gate can never disagree.
- **Build stamps**: `stats` today has no `generatedAt`/`durationMs` — add both
  at build time (S change inside the provider wrapper); file mtime is the MVP
  fallback.
- **Consumption**: cheap-API token spend per enriched file already recorded
  (`input_tokens`/`output_tokens`, `discovery.py:128-135`) plus cache-hit rows
  in `discover-report.json` (:113-114, :145-146) — aggregate, don't re-collect.
  Query counts (doc-find/symbols) are NOT tracked today; increment: one
  `append_event("doc_find_query", …)` (`scripts/harness.py:2468-2471`) and a
  counter derived from the event log — no polling, no daemon.

### Phased plan

- **B0 (SDD)** — intake refinement → `specs/40-features/screen-graphs-providers.md`
  (Gherkin: provider-select round-trip / fallback-on-broken-provider /
  freshness-metric-matches-gate / exploration-hit).
- **B1 (provider abstraction, CLI-first — the crux)** —
  `harness_lib/graph_providers.py` + config keys + rewire the 4 call sites +
  `graph providers` / `graph provider set` subcommands. Scenario
  `testing/scenarios/gp_graph_providers.py`: register a fake external provider
  (a tiny script emitting a minimal nodes/edges graph.json), select it, assert
  `discover`/gate consume its artifacts, break it, assert deterministic
  fallback with a legible reason. No network.
- **B2 (metrics CLI)** — extend `graph-status` per subject: stats + freshness +
  artifact sizes/mtimes + provider gates + token/cache aggregates + active
  provider. `--target <n>` parity.
- **B3 (GUI screen)** — new nav pill `⛁ Grafos` (pattern:
  `harness_ui_page.py:318-320` + a `#viewGraphs` section); GET `/api/graph`
  snapshot in `ui_panel.py` (degrade-to-empty pattern of `state_snapshot`
  :281-313) with a subject selector (harness | each target). Panels: metric
  tiles, freshness badge (+ last gate result), provider selector; actions
  (ACTIONS additions, all subprocess-backed): `graph-rebuild` (mutating),
  `graph-provider-set` (mutating). Exploration: search box querying
  `symbols.json` + `doc_find` in-process (read-only GET, no action), god-nodes
  list reusing the degree logic of `graphify_adapter.py:161-173`, link to
  `graph.html` when present. Extend `ui_e2e.py`.
- **B4 (increments)** — doc-find query counters via events, embedded graph
  rendering, cross-subject comparison row.

### Risks / open decisions

- External provider = arbitrary command execution → providers configurable only
  via tracked config (code review), never creatable from the GUI; GUI only
  selects among registered names.
- Big-target rebuild may exceed panel `ACTION_TIMEOUT` → rebuild action shows
  the CLI command as fallback (same pattern as heavy gates).
- `graphify_search_guard.py` hook wording says "Graphify" — after B1 it should
  say "the active graph provider" (docs-only follow-up).
- Naming: config keys stay under `knowledgeGraph.*` (compat) vs a new
  `graph.*` block — decide at B1 spec time; leaning compat.

---

## Proposed central-backlog rows (`docs/IMPLEMENTATION_BACKLOG.md` format)

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| `config-keys-cli` | Editable-config registry (`config list/get/set`) + `keys` presence+masked CLI | M | high | — | docs/roadmap/screens-config-graphs.md §A1 |
| `config-keys-gui` | Panel Config: safe general settings form + masked keys view (action `config-set`) | M | medium | config-keys-cli | §A2 |
| `graph-provider-abstraction` | Provider registry: graphify-code-ast = one provider; select/fallback; rewire 4 call sites | M | high | — | §B1 |
| `graphs-metrics-cli` | `graph-status` metrics: freshness, build stamps, token/cache aggregates, per target | S | medium | graph-provider-abstraction | §B2 |
| `graphs-screen-gui` | Panel Grafos: metrics tiles, exploration (symbols/doc-find), provider select, rebuild | L | medium | graph-provider-abstraction, graphs-metrics-cli | §B3 |
