# Black terminal windows on Windows — root cause + fix roadmap

## Goal / why

User report (quote): "Enquanto o harness está rodando — na GUI, CLI ou via comandos pelo
Claude/Codex — vejo telas de terminal PRETAS spawnando de vez em quando no meu computador.
Isso tem me atrapalhado. Investigue."

Goal: no harness subprocess ever pops a visible console window on Windows, without breaking
POSIX (stdlib-only core) or process-tree cleanup semantics.

## Root-cause diagnosis (verified 2026-07-12)

Windows rule: a console-subsystem child **inherits the parent's console** (no new window).
If the parent has **no console**, `CreateProcess` allocates a **new visible console** unless
the spawn passes `CREATE_NO_WINDOW` (0x08000000) or `DETACHED_PROCESS`. Redirecting
stdout/stderr to files/pipes does NOT suppress the window.

A repo-wide grep for `CREATE_NO_WINDOW|STARTUPINFO` finds **zero** console-hiding flags.
The only creationflags used anywhere are `CREATE_NEW_PROCESS_GROUP` (0x200, isolation),
`DETACHED_PROCESS` (0x8) and `CREATE_SUSPENDED` (0x4, job-assign race) — none hide windows
of grandchildren.

### The primary mechanism: the deliberately console-less supervisor subtree

`scripts/harness_lib/async_runtime.py:761` launches the workflow async-supervisor with
`CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS` (Popen at `:767`). `DETACHED_PROCESS` means the
supervisor process has **no console at all**. From that point on, **every** subprocess the
supervisor (or its harness.py children) spawns without `CREATE_NO_WINDOW` allocates a fresh
visible black window:

| Spawn site (verified) | Call | Why it pops |
|---|---|---|
| `scripts/harness_lib/async_runtime.py:382,396` | `asyncio.create_subprocess_exec`, only `CREATE_NEW_PROCESS_GROUP` on nt | each **worker** spawned from the console-less supervisor gets a new visible console for its whole run (claude.cmd → cmd.exe → node included) |
| `scripts/harness_lib/processes.py:171-175` (`process_group_kwargs`) → `run_process_tree_bounded` Popen at `:274` | `CREATE_NEW_PROCESS_GROUP` only | every bounded validation/fixture command run from a console-less parent pops |
| `scripts/harness_lib/processes.py:72` | `subprocess.run(["taskkill", ...])`, no flags | cleanup/kill passes flash a window |
| `scripts/harness_lib/targets.py:145` | `git status --porcelain`, no flags | status polls flash a window intermittently — matches "de vez em quando" |
| `scripts/harness_lib/records.py:170,290` | `git log`, no flags | record reads flash |
| `scripts/harness.py:82` (`git()` helper) | `subprocess.run(["git", ...])`, no flags | every git call inside a console-less harness.py process |

Short-lived children (git, taskkill) = the intermittent black **flashes**; long-lived workers
= persistent black windows during workflow rounds. This subtree alone explains the symptom in
CLI, GUI and Claude/Codex-driven runs, because `workflow start` always detaches the supervisor.

### Secondary console-less parents (same mechanism, other entry points)

- **GUI panel actions**: `scripts/harness_lib/ui_panel.py:795` (action runner → `python
  scripts/harness.py ...`), `:876` (ChatBridge Popen → `harness.py chat`), `:252`
  (`pick_folder` Tk subprocess). If the panel server runs without a console (pythonw,
  detached launch, spawned in background by an agent), each pops a window.
- **Chat engine**: `scripts/harness_lib/chat_engines.py:184` (claude.CMD Popen — the comment
  at `:179` already notes claude.CMD goes through cmd.exe), `:109`, `:323` (codex run).
- **Intake triage (SPEC-117, fires on every request)**: `scripts/harness_lib/intake_triage.py:70,91`
  — two `harness.py classify`/`doc-find` subprocesses per intake.
- **Hooks**: `tools/hooks/refresh_graphs_post_commit.py:53,60,90,108` (git + `harness.py
  discover` after every commit), `tools/hooks/validate_before_stop.py:31`,
  `tools/hooks/protect_canonical_files.py:42` — pop when the invoking git/agent client is
  console-less (IDE git, background agent Bash).
- **Gate runner**: `scripts/spec_test_gate.py:112-128` (its own bounded Popen,
  `CREATE_NEW_PROCESS_GROUP` only at `:122`), plus `run_bounded_command(..., shell=True)`
  from `scripts/harness_lib/gate_generic.py:180` (explicit cmd.exe).
- Minor: `scripts/harness_lib/gate_fixtures_workflow.py:351-354` (fixture sleeper),
  `scripts/setup_highlight.py:43` (uv pip), `scripts/harness_lib/chat_hud.py:76`,
  `scripts/harness_lib/chat_operator.py:174`, `scripts/harness_lib/self_review.py:452`,
  `scripts/harness_lib/gate_checks_policy.py:242`, `scripts/harness_lib/gate_generic.py:119`,
  `scripts/harness_lib/workflow_writes.py:490,494,519,528`.

### Hypothesis verdicts

- (b) worker spawns without console-hiding flags — **confirmed** (async_runtime.py:382,396).
- (c) git/graphify from console-less processes — **confirmed for git** (see table); the
  detached supervisor (async_runtime.py:761) is what makes parents console-less.
- (a) `graphify.CMD` — **refuted as a spawn source**: `shutil.which("graphify")` at
  `scripts/harness.py:295` only *probes* PATH for status reporting
  (`externalGraphifyTool`); no harness code executes it. Graph builds are in-process
  (`graphify_code_ast.build_graphify_code_ast`, `scripts/harness.py:929`). `.CMD` shims DO
  get executed for executors (claude.cmd via `_resolve_argv0`, `scripts/harness.py:355-363`,
  and chat_engines.py:184), but `CREATE_NO_WINDOW` hides cmd.exe's console too — no special
  casing needed beyond the shared helper.
- `scripts/harness_lib/discovery.py` — **no subprocess use at all** (HTTP-only provider
  chain); not an offender.

## Fix design (SDD: enters via the SPEC-116 NEW door as a small platform spec)

One shared seam, routed through by every call site. `processes.py` is already the canonical
process helper module and already owns `process_group_kwargs()` — extend it, don't add a new
module.

### Phase 0 — MVP: hidden-spawn helper + kill the supervisor-subtree popups

Files: `scripts/harness_lib/processes.py`, `scripts/harness_lib/async_runtime.py`.

1. In `processes.py`: add `CREATE_NO_WINDOW = 0x08000000` and inject it on `os.name == "nt"`:
   - `process_group_kwargs()` (processes.py:171) returns
     `{"creationflags": CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW}` — this alone fixes
     `run_process_tree_bounded` and every caller of the kwargs helper. `CREATE_NO_WINDOW`
     gives the child a *hidden* console, so process-group semantics and `taskkill /T`
     cleanup are unchanged.
   - New thin wrapper `run_quiet(cmd, **kwargs)` = `subprocess.run` that ORs
     `CREATE_NO_WINDOW` into `creationflags` on nt **only when stdio is redirected**
     (capture/PIPE/DEVNULL/file). When stdio is inherited (human-facing `!` escape,
     interactive login flows), it passes no flag so output/console behavior is untouched.
     No-op on POSIX.
2. `processes.py:72`: route the `taskkill` call through the hidden flags.
3. `async_runtime.py:380-384` (worker spawn kwargs): use `process_group_kwargs()` instead of
   the inline copy — workers stop popping consoles.
4. `async_runtime.py:761` (supervisor): replace `DETACHED_PROCESS` with `CREATE_NO_WINDOW`
   (the two flags are mutually exclusive — both control console allocation). The supervisor
   keeps its own (hidden) console + new process group; detachment-from-parent-lifetime is
   provided by the process group + no inherited console handles, and stdio already goes to
   supervisor log files (async_runtime.py:764-767). **This is the single highest-value line.**

MVP outcome: the whole detached-supervisor subtree — the confirmed intermittent offender —
spawns hidden.

### Phase 1 — sweep the remaining direct call sites through the helper

Mechanical replacement of `subprocess.run(...)` → `processes.run_quiet(...)` (or
`process_group_kwargs()` for Popen sites) in:
`scripts/harness.py:82`; `scripts/harness_lib/{targets.py:145, records.py:170+290,
chat_hud.py:76, chat_operator.py:174, self_review.py:452, gate_checks_policy.py:242,
gate_generic.py:119, workflow_writes.py:490-528, intake_triage.py:70+91,
ui_panel.py:252+795+876, chat_engines.py:109+184+323}`; `scripts/spec_test_gate.py:122`
(OR `CREATE_NO_WINDOW` into its bounded runner); `scripts/setup_highlight.py:43`;
`tools/hooks/{refresh_graphs_post_commit.py, validate_before_stop.py,
protect_canonical_files.py}` (hooks may not import harness_lib cheaply — an inline
3-line flags constant is acceptable there; keep it identical to the helper's).
`gate_fixtures_workflow.py:351` (fixture sleeper) included for silence during gate runs.

Note: `protect_canonical_files.py:42` runs the wrapped command with *inherited* stdio on
purpose (it's a passthrough wrapper) — `run_quiet`'s inherited-stdio bypass handles it.

### Phase 2 — deterministic guard: forbid raw subprocess outside the helper

- New gate fixture (spec_test_gate family): grep `scripts/ tools/` for
  `subprocess.run(|subprocess.Popen(|create_subprocess_exec(|os.system(` and fail on any hit
  outside an allowlist (`processes.py` itself, `run_posix_spawn_bounded`'s POSIX-only path,
  documented exceptions with a `# raw-spawn-ok:` marker + reason).
- Wire into the existing gate like other policy fixtures (pattern: `gate_checks_policy.py`).

## Cross-platform notes

- POSIX untouched: helper branches on `os.name == "nt"`; `start_new_session=True` paths and
  `run_posix_spawn_bounded` (processes.py:314) unchanged. No new dependencies (stdlib-only).
- `CREATE_NO_WINDOW` vs `DETACHED_PROCESS`: mutually exclusive; NO_WINDOW is strictly better
  here because the child still has a (hidden) console, so console-API-using CLIs (cmd.exe
  shims, node) behave normally.

## Validation

- Deterministic: the Phase 2 gate fixture (no raw spawn outside the helper) + a unit
  self-check in `processes.py` asserting `run_quiet` injects `CREATE_NO_WINDOW` on nt when
  stdio is redirected and does NOT when inherited (assert on kwargs, no real spawn needed —
  runs identically on POSIX by monkeypatching `os.name` check indirection or asserting the
  kwargs-builder function directly).
- Windows manual verify (one-time note for the operator): run `workflow start` on a 2-worker
  workflow + open the GUI panel + trigger a chat turn + make a commit (post-commit hook);
  observe zero console flashes over the run. Existing `ui_e2e` Playwright layer can host the
  panel part.

## Risks / open decisions

1. **Interactive children that legitimately need a console**: the chat REPL `!` escape
   (`chat_engines.py:100-115`, human path) and vendor login flows must keep visible output.
   Mitigation: `run_quiet` only hides when stdio is fully redirected. Decision needed: is
   inherited-stdio detection sufficient, or do we want an explicit `visible=True` kwarg?
2. **Supervisor detachment semantics**: swapping `DETACHED_PROCESS` → `CREATE_NO_WINDOW`
   changes the supervisor from "no console" to "own hidden console". If the parent CLI's
   console closes, the supervisor must survive — verify on Windows that closing the launching
   terminal does not kill the hidden-console supervisor (expected: it doesn't, different
   console = no CTRL_CLOSE propagation; confirm manually once).
3. **Ctrl-Break delivery**: harness cleanup uses `taskkill /T /F` on nt
   (processes.py:65-74), not console ctrl events, so hidden consoles don't regress cancel.
4. **Hook duplication**: tools/hooks getting an inline flags constant duplicates 3 lines;
   acceptable, but the Phase 2 gate must allowlist-or-verify them.

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| win-hidden-spawn-helper | Hidden-console spawn helper in processes.py + route supervisor/worker/git/taskkill spawn sites (Phase 0+1) | M | high | — | docs/roadmap/black-terminal-windows.md |
| no-raw-subprocess-gate | Deterministic gate fixture forbidding raw subprocess calls outside processes.py helper | S | medium | win-hidden-spawn-helper | docs/roadmap/black-terminal-windows.md |
