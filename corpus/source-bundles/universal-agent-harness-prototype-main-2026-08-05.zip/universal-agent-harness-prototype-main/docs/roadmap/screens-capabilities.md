# Roadmap — Capability control panels (skills + MCPs)

Planning only (2026-07-12). Two control-panel requests refined against verified seams.
No implementation here; every citation checked in source.

Shared context for both panels — the machinery already exists and is reused, not rebuilt:

- **SPEC-113 canonical manifest**: `.harness/capabilities.json` is the declared single
  source of truth for hooks, MCP servers and skills every agent CLI must expose
  (`.harness/capabilities.json:3`). Skills already carry a `scope` field
  (`ponytail` → `"scope": "user"` at `:83`; `research` → `"scope": "repo"` at `:89`);
  `"mcpServers": {}` at `:79` (empty today).
- **Parity engine**: `scripts/harness_lib/agent_parity.py` already collects everything the
  panels need: user-scope Claude skills (`_claude_user_skills`, `:95`), repo skill presence
  (`_skill_status`, `:220`), codex `[mcp_servers]` (`collect_codex`, `:150-161`), repo MCP
  manifest `tools/agent-sync/mcp.manifest.json` (`REPO_MCP_REL`, `:38`; `_repo_mcp_servers`,
  `:301`), and the drift matrix (`audit`, `:237`). CLI home: `python scripts/harness.py agents`
  (`scripts/harness.py:3078`).
- **SPEC-110 target registry**: per governed target, `target.json` already declares
  `"mcp": {"servers": {}}`, `"skills": []`, `"plugins": []`
  (`scripts/harness_lib/targets.py:33-35`), rendered on demand to
  `graphify-out/targets/<name>/adapter/{mcp-config.json,spawn-env.json}`
  (`sync_adapter`, `targets.py:203-223`) with deny-by-default env (`spawn_env`, `:198-200`).
- **Worker session diet**: spawned Claude workers run with `--strict-mcp-config
  --setting-sources project,local` (`.harness/routing/executors.json:54-57`), i.e. user-scope
  skills/MCP are already stripped from workers — the access-control primitive the policy builds on.
- **GUI shell**: nav has three views — Painel / Config / Compose
  (`scripts/harness_ui_page.py:318-320`; `viewConfig` section at `:357`); routes live in
  `scripts/harness_ui.py:146-213`; snapshots in `scripts/harness_lib/ui_panel.py`
  (`routing_snapshot`, `:259`); writes only via the allowlisted `/api/action`
  (`harness_ui.py:191`, `run_action` at `ui_panel.py:739`).
- **Roles/workflows**: spawn profiles = `.claude/agents/*.md` (8 files, frontmatter
  name/model/effort only — no skill/MCP declaration today, e.g. `.claude/agents/scanner.md:1-6`);
  workflow roles = `workerRole`/`taskProfile` in branch entries of
  `.harness/workflows/workflow-profiles.json` (e.g. `:351-375`). Skill↔role links exist only
  implicitly in prompt text (e.g. `.claude/skills/research/SKILL.md:14` points at
  `.harness/prompts/research-playbook.md`).

---

## The crux: harness-vs-target separation policy (applies to both panels)

**Three scopes, all already latent in the repo — the policy names them and makes them enforceable:**

| Scope | Canonical declaration | Physical location | Who may load it |
|---|---|---|---|
| `harness` | `.harness/capabilities.json` `skills[]` (scope `repo`) / `mcpServers{}` | `.claude/skills/<name>/` in this repo; codex adapters `codex/prompts/*` | harness-repo sessions + spawned workers on harness work |
| `target/<name>` | `.harness/targets/<name>/target.json` `skills`/`plugins`/`mcp.servers` | generated adapter `graphify-out/targets/<name>/adapter/` (gitignored, regenerable) | only workers spawned for that target |
| `user` | `.harness/capabilities.json` `skills[]` (scope `user`) — presence-tracked, not owned | `~/.claude/{plugins,skills}` | interactive operator sessions only; dieted out of workers (`executors.json:54-57`) |

Policy rules (to be codified in the SDD spec):

1. **Declaration lives only in `.harness/`.** `capabilities.json` for harness scope,
   `targets/<name>/target.json` for target scope. Adapters (`.claude/`, `.codex/`,
   `graphify-out/.../adapter/`) are rendered, never canonical — this is already the SPEC-113
   contract (`capabilities.json:3`) and the SPEC-110 contract (`targets.py:203-208`).
2. **Discovery ≠ grant.** The inspectors additionally *scan* target repos for
   `.claude/skills/*/SKILL.md` and `.mcp.json` (none of this is scanned today). Anything found
   but not declared in that target's `target.json` renders with status `undeclared` — visible,
   never loaded, never auto-granted.
3. **Namespacing is computed, not physical.** Display/stable IDs: `harness:research`,
   `target/<tname>:<skill>`, `user:ponytail`. No file moves; the prefix is derived from which
   canonical file declares the item.
4. **Access control stays deny-by-default.** A worker on target X gets exactly
   `adapter/mcp-config.json` for X (`targets.py:211-212`) and only X's `requiresEnv` keys
   (`:198-200`). Harness-scope `mcpServers` (when non-empty) apply only to harness-repo work.
   Cross-scope loading is a policy violation the audit reports.
5. **Viewers are read-only; mutation is an allowlisted action.** Enable/disable edits the
   canonical JSON via a new subcommand routed through the existing `/api/action` allowlist
   pattern (`ui_panel.py:739`), same as `targets add` (`ui_panel.py:247`).
6. **Drift detection reuses `agents audit`.** Statuses (`present`/`missing`/`drift`) come from
   `agent_parity.audit` (`agent_parity.py:237-287`) — the panel renders them, it does not
   re-derive them.

---

## Panel A — Skills control panel

**Goal (user request):** "painel de controle de skills: skills instaladas, visualizador de
prompt e scripts/código das skills, papéis/workflows que fazem uso / têm acesso à essa skill.
Precisamos de POLÍTICA de separação de skills do HARNESS vs skills LOCAIS do repositório
trabalhado."

**Value:** today the only skill inventory is `capabilities.json:80-93` (2 entries) plus an
unenumerated user profile; nothing shows what a skill *does* or *who uses it* without opening
files by hand. One screen answers install/scope/content/consumers.

### Current reality (verified)

- Repo skills: exactly one — `.claude/skills/research/SKILL.md` (glob-verified; dir may carry
  scripts, none today). User skills: enumerated by `_claude_user_skills`
  (`agent_parity.py:95-115`, globs `plugins/**/skills/*/SKILL.md` + `skills/*/SKILL.md`).
- Codex parity adapters: `codex/prompts/ponytail.md`, `codex/prompts/research.md`
  (declared at `capabilities.json:85,91`).
- Target skills: `target.json` `skills[]` is passed through into `spawn-env.json`
  (`targets.py:219`) but nothing scans a target repo for its own `.claude/skills/`.
- Role↔skill links: none are declared anywhere; only prose references in prompts.

### Design

**Backend** — new small module `scripts/harness_lib/capabilities_view.py` (ui_panel.py is
1000+ lines; token-economy directive says fragment monoliths):

- `skills_snapshot(root)` → per skill: `{id, scope, name, path, vendors, status,
  hasScripts, referencedBy}`. Reuses `agent_parity.load_manifest/collect_claude/_skill_status`
  and `targets_lib.load_targets()`; adds the target-repo scan (rule 2).
- `referencedBy`: deterministic name-grep over `.claude/agents/*.md`, `.harness/prompts/*.md`,
  `codex/prompts/*.md`, and `workflow-profiles.json` branch titles/roles — returns
  `[{kind: agent|prompt|workflow, ref}]`. Stdlib, no LLM, no polling.
- `skill_file(root, id, rel)` → SKILL.md text or a script under the skill dir. **Path
  allowlist**: resolve only inside registered skill roots (prevents arbitrary file read via
  the viewer — this is a trust-boundary check, not optional).

**CLI (parity first, per M5 rule "every GUI button calls an existing subcommand",
`docs/IMPLEMENTATION_BACKLOG.md:17-18`):**

- `python scripts/harness.py agents skills [--json]` — table: id, scope, status, referencedBy count.
- `python scripts/harness.py agents skills show <id> [--file <rel>]` — prints SKILL.md / script.

**GUI:** extend the Config view (`harness_ui_page.py:357`) with a "Skills" card grid grouped
by scope (harness / target/<name> / user), fed by new GET `/api/capabilities`
(one cached endpoint for both panels, mtime-cached like `/api/metrics`, `harness_ui.py:148`).
Click → modal (reuse the existing `#confirmDlg` modal machinery, `harness_ui_page.py:1006-1010`)
showing SKILL.md rendered + script file list + referencedBy chips. `undeclared` and `missing`
badges from the audit statuses.

### Phases

- **A1 (MVP):** `capabilities_view.skills_snapshot` + `agents skills` CLI + Config-view card
  grid + SKILL.md viewer modal. Harness+user scopes only. Files: new
  `scripts/harness_lib/capabilities_view.py`; touch `scripts/harness.py` (subcommand),
  `scripts/harness_ui.py` (route), `scripts/harness_ui_page.py` (section), `ui_panel.py`
  (snapshot passthrough only).
- **A2:** target-scope discovery — scan each governed target for `.claude/skills/*/SKILL.md`,
  merge with its `target.json.skills`, render `declared`/`undeclared`. Files:
  `capabilities_view.py`, `targets.py` (read-only helper).
- **A3:** allowlisted mutation — `agents skills enable|disable <id>` editing
  `capabilities.json` / `target.json` `required` flags; GUI button POSTs `/api/action`.

## Panel B — MCP control panel

**Goal (user request):** "painel de controle de mcps: mcps configurados, visualizador de
schemas / métodos / endpoints disponíveis, papéis/workflows que fazem uso / têm acesso a esse
mcp. Precisamos de POLÍTICA de separação de mcps do HARNESS vs mcps LOCAIS do repositório
trabalhado."

**Value:** MCP intent is scattered over four files that are all empty today
(`capabilities.json:79`, `.codex/config.toml:15` `[mcp_servers]`,
`tools/agent-sync/mcp.manifest.json:4` `"tools": []`, per-target `target.json` `mcp.servers`)
— so the panel's first job is to make the *scopes and grant paths* legible before any server
exists, and to be the obvious place one lands when the first server is added.

### Current reality (verified)

- No repo `.mcp.json` exists (glob-verified). All four declaration points are empty.
- The grant path for targets already works end-to-end: `target.json` `mcp.servers` →
  `sync_adapter` → `adapter/mcp-config.json` (`targets.py:211-212`).
- Workers: `--strict-mcp-config` (`executors.json:54`) means only an explicitly passed MCP
  config loads — the enforcement hook for scope separation already exists.
- `agents audit` already cross-checks manifest vs codex vs repo-manifest MCP sets
  (`agent_parity.py:278-287`).

### Design

**Backend** (same module): `mcp_snapshot(root)` → per server: `{id, scope, command/args/env
(secret-masked), declaredIn, renderedTo, status, accessibleBy}`. Sources: the four declaration
points + per-target adapters. `accessibleBy` is derived, not guessed: harness-scope servers →
sessions using `.claude`/`.codex` adapters; target-scope → workers spawned for that target
(via `sync_adapter`); plus the executors.json diet flags shown as the enforcement evidence.

**Schema/method viewer — deterministic-first, no daemons** (observation-pays-for-itself rule):

- MVP shows *configuration* (command, args, env keys masked, transport), not live tools.
- Increment: allowlisted on-demand action `agents mcp introspect <id>` — launches the server
  once, issues `tools/list` (and `resources/list`), writes
  `graphify-out/mcp/<id>.tools.json`, exits. The panel renders the cached file with its
  timestamp; stale is visible, never auto-refreshed. No polling, no resident processes.

**CLI:** `agents mcp [--json]`, `agents mcp show <id>`, `agents mcp introspect <id>`
(the only non-read subcommand; allowlisted).

**GUI:** second card grid in the same Config section, same `/api/capabilities` feed, grouped
by scope with an explicit empty-state that renders the policy table (so the panel teaches the
grant path even with zero servers). Introspection results render as a method/schema table in
the modal.

### Phases

- **B1 (MVP):** `mcp_snapshot` merged into `/api/capabilities` + `agents mcp` CLI + GUI grid
  with policy-aware empty state. Files: same four as A1.
- **B2:** `agents mcp introspect` action + cached tools/schema viewer. Files:
  `capabilities_view.py`, `harness.py`, action allowlist in `ui_panel.py:739` region.
- **B3:** target `.mcp.json` discovery + `undeclared` badge; enable/disable allowlisted
  (mirrors A3).

---

## CLI+GUI parity summary

| Capability | CLI | GUI |
|---|---|---|
| List skills/MCPs by scope | `agents skills` / `agents mcp` | Config-view card grids via GET `/api/capabilities` |
| View prompt/scripts/schema | `agents skills show` / `agents mcp show` | read-only modal |
| Who uses it | `referencedBy` in both outputs | chips on card |
| Introspect MCP tools | `agents mcp introspect <id>` | allowlisted `/api/action` button |
| Enable/disable | `agents skills|mcp enable/disable` | allowlisted `/api/action` button |

## Validation (SDD two-door: this is NEW behavior → door NEW)

- Intake via `specs/templates/intake-refinement.md` → spec
  `specs/40-features/capability-panels.md` with Gherkin `Scenario:[id]` blocks mapping to
  named checks (spec-conformance gate, `scripts/harness_lib/spec_conformance.py` per
  `docs/IMPLEMENTATION_BACKLOG.md:32`).
- New scenario `testing/scenarios/cap_capability_panels.py`: snapshot shape; scope
  classification (fixture target with declared + undeclared skill/mcp); path-allowlist refusal
  on a viewer escape attempt; introspection cache write; CLI/GUI payload equivalence.
- Extend `testing/scenarios/ui_e2e.py` (Playwright layer — mandatory after any GUI change,
  per standing memory): cards render, modal opens, empty-state shows policy table.

## Risks / open decisions

1. **Empty-state MCP panel** — all MCP config is empty today; mitigated by the policy-teaching
   empty state, but confirm the user wants the panel before a first real server exists.
2. **Viewer file read is a trust boundary** — the skill/script viewer must resolve strictly
   inside registered skill roots; test the escape case explicitly.
3. **`referencedBy` is textual** — name-grep can false-positive ("research" is a common word);
   decision: match only exact skill-invocation forms (`Skill tool`, `/name`, path references)
   and accept misses over noise.
4. **Introspection secrets** — server env in `target.json.mcp.servers` may hold secrets;
   snapshot masks values, shows key names only (same posture as `spawn-env.json`).
5. **Where mutation lands** — A3/B3 write to canonical `.harness/` files from a GUI action;
   needs the same confirm-token ceremony as other controlled writes (M5.2,
   `docs/IMPLEMENTATION_BACKLOG.md:29`). Deferred until viewers prove useful.
6. **Open decision:** separate nav view vs Config-view sections. Proposal: Config sections
   (cheapest, matches SPEC-115 routing/targets placement at `ui_panel.py:259-278`); promote to
   its own view only if the section outgrows one screen.

## Proposed central-backlog rows (for `docs/IMPLEMENTATION_BACKLOG.md`)

| slug | title | size | priority | deps | doc |
|---|---|---|---|---|---|
| CAP.1 | `capabilities_view` snapshot + `agents skills`/`agents mcp` CLI (scopes, statuses, referencedBy) | M | high | — | docs/roadmap/screens-capabilities.md |
| CAP.2 | GUI Config sections + read-only viewers (`/api/capabilities`, SKILL.md/script modal, MCP config modal, policy empty-state) | M | high | CAP.1 | docs/roadmap/screens-capabilities.md |
| CAP.3 | Separation-policy enforcement: target-repo skill/`.mcp.json` discovery, `undeclared` badges, SDD spec `capability-panels.md` + `cap_capability_panels.py` | M | medium | CAP.1 | docs/roadmap/screens-capabilities.md |
| CAP.4 | `agents mcp introspect` allowlisted action + cached tools/schema viewer | S | low | CAP.2 | docs/roadmap/screens-capabilities.md |
| CAP.5 | Allowlisted enable/disable for skills/MCPs (CLI + GUI confirm ceremony) | S | low | CAP.3 | docs/roadmap/screens-capabilities.md |
