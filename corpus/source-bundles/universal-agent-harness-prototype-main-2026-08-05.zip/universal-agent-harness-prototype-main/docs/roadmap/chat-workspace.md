# Roadmap — chat workspace (file tree + diff viewer + editor)

Owner request (2026-07-17, verbatim intent): the chat screen's freed side
columns (see the chat-workspace declutter, SPEC-133 v4) will become an
IDE-like workspace around the conversation:

- **Left column**: a project structure viewer — folders and files, expandable,
  like VS Code's explorer. Read-only navigation at minimum; opening a file
  feeds the right-column editor.
- **Right column**: two interchangeable surfaces (tabbed or toggled):
  1. a **full diff viewer** (working tree / per-turn / per-commit diffs,
     colorized, reusing `colorizeDiff` + the turn-diff event);
  2. a **code editor** — a real editing surface with syntax highlight (the
     vendored tree-sitter HL already covers viewing; editing needs an
     editable surface on top) and a **linter** pass.

Constraints to respect when this gets built:

- CSP is self-contained (no CDN Monaco/CodeMirror — vendoring would follow the
  tree-sitter precedent: pinned assets under `vendor/`, token-gated route).
- Writes must route through an allowlisted server path with the same
  confirm/token discipline as `/api/action` (an editor that writes files is a
  WRITE surface — the panel's trust boundary must widen deliberately, likely
  path-scoped like the ui-overseer room's `Edit(<glob>)` grants).
- The linter should be the project's existing one (ruff/flake8 via a server
  endpoint), not a JS reimplementation.
- The declutter deliberately left the side space EMPTY (the chat is
  full-width); this doc is the claim on that space.

Not started. When picked up: SPEC-116 intake → its own spec (this is a
write-capable feature, not a QoL amendment).
