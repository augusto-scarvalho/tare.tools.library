# Roadmap: chat overlay/HUD surface (tool chips · plan HUD · gate tracker)

Status: PLANNED (refined 2026-07-12, planning only — nothing here is implemented).
Cluster: three requests designed as ONE overlay surface shared by GUI panel and CLI REPL.

## Unifying design decision

All three features ride the **existing per-turn event pipe**, extended with a small
shared vocabulary instead of three ad-hoc mechanisms:

- Producer (single source): `stream_json.parse_chat_stream()` walks every claude NDJSON
  event live (`scripts/harness_lib/stream_json.py:137-179`) and already fires
  `on_tool({name,arg})` per `tool_use` block (`stream_json.py:167-169`). All new
  overlay data (full tool input digest, tool results, TodoWrite plans) is extracted HERE.
- Transport: the `\x1e`-prefixed JSON emit in `chat_operator.run_chat`
  (`scripts/harness_lib/chat_operator.py:389-394`) → ChatBridge → cursor-based SSE
  (`scripts/harness_ui.py:250-258`). New event kinds: `tool` (extended), `tool-result`,
  `plan`, `gate`. Same-repo producer+consumer, so no protocol versioning needed.
- Consumers: GUI `handleEvt` (`scripts/harness_ui_page.py:1124-1143`); CLI
  `chat_hud.Hud` (`scripts/harness_lib/chat_hud.py:214-409`) plus plain `say()` fallback.
- Invariants respected: stdlib-only (JSON parsing already there), GUI stays
  self-contained (emoji icons, no `/vendor/` assets needed), GUI writes no canonical
  state (overlay is render-only; gate data is read from existing state files),
  deterministic-first (gate status re-read from quality-state on demand, no polling).

Harness vs target-repo scope: the overlay renders BOTH but the data paths never mix —
harness gates come from `.harness/state/quality-state.json`
(`scripts/spec_test_gate.py:45`), target gates from
`targets_lib.state_dir(name)/quality-state.json` written by
`gate_generic.run_target_gate` (`scripts/harness_lib/gate_generic.py:217-238`).
`ui_panel._gates` already collects both separately (`scripts/harness_lib/ui_panel.py:120-134`).

---

## Request 1 — tool-call highlighter (summary chip + expand-to-inspect)

> "tool highlighter nos chats, algo resuma a tool e mostre um ícone legal ao lado,
> dando a opção do usuário inspecionar expandindo a mensagem na GUI (se possível,
> fazer no CLI também)"

### Current seams (verified)

- `stream_json.tool_descriptor` reduces a `tool_use` block to `{name, arg}` with a
  primary-arg precedence file_path/path/command/pattern/url (`stream_json.py:123-134`).
  Full input and all output are DROPPED today.
- `ClaudeEngine.send` streams per-turn NDJSON through `parse_chat_stream(proc.stdout,
  on_tool=on_tool)` (`scripts/harness_lib/chat_engines.py:211`); `on_activity` is
  getattr-guarded, claude-only (`chat_engines.py:178`).
- GUI renders one plain line `🔧 name arg` in `handleEvt` case `"tool"`
  (`harness_ui_page.py:1134-1138`) via `append()` (`harness_ui_page.py:532-542`).
- Tool RESULTS exist in the stream as `user` events with `tool_result` blocks — the
  worker drawer's `fmtStreamLine` already recognizes that shape
  (`harness_ui_page.py:680-682`) but `parse_chat_stream` ignores it.
- CLI: in a plain TTY (no panel), mid-turn tool calls are INVISIBLE — the emit lambda
  is a no-op unless `HARNESS_CHAT_EVENTS=1` (`chat_operator.py:389-390`).
- ANSI gating pattern to reuse: `highlight.color_enabled` (HARNESS_COLOR → NO_COLOR →
  isatty, `scripts/harness_lib/highlight.py:11-12`).

### Phased plan

**MVP — GUI chip + expand on input (M, mostly front):**
1. `stream_json.py`: extend `tool_descriptor` with `id` (tool_use id) and
   `input_digest` (compact JSON of the input dict, capped ~2 KB) — keep `{name, arg}`
   untouched for existing callers; extend `_self_check`.
2. `chat_operator.py:394`: forward the new fields in the `tool` event.
3. `harness_ui_page.py` `handleEvt "tool"` (1134): render a chip instead of a plain
   line — icon by tool-name map (emoji only, CSP-safe: 📖 Read, ✏️ Edit/Write,
   🖥️ Bash, 🔎 Grep/Glob, 🌐 WebFetch/WebSearch, 📋 TodoWrite, 🔧 default) +
   one-line arg digest. Use a native `<details><summary>` for expand-to-inspect
   (no JS state machine); expanded body shows the pretty-printed `input_digest`.
   New CSS class in `PAGE`; keep the model-attribution prefix.

**Increment 2 — tool output in the inspector (S):**
4. `parse_chat_stream`: also walk `user`/`tool_result` blocks, fire
   `on_tool_result({id, digest})` (capped ~2 KB); wire a second emit event
   `tool-result` in `chat_operator.py`. GUI: match by id, fill the expanded panel's
   output section (data kept client-side per chip; SSE replay rebuilds it — the
   bridge already replays history on reconnect, `harness_ui.py:244-250`).

**Increment 3 — CLI parity (S/M):**
5. Wire `on_tool` to ALSO print in the terminal: a collapsed dim line
   `🔧 Read README.md` via `say` (HUD-safe scroll-region print, `chat_hud.py:284-303`;
   plain `print` fallback). ASCII fallback per `chat_hud._glyphs` pattern
   (`chat_hud.py:40-48`); color gated by `highlight.color_enabled`.
6. Expand-to-inspect in a line-based REPL is a command, not a keybind: `/tool [n]`
   lists the last turn's tool calls / prints call n's full input+output from an
   in-memory per-turn buffer (no state file). Register in `HELP_TEXT`
   (`chat_operator.py:55-66`) and the `/`-dispatch chain (`chat_operator.py:562`).

**Increment 4 — codex parity (M, shared with Request 2):** convert `CodexEngine.send`
from buffered `subprocess.run` (`chat_engines.py:323`) to line-streamed `Popen`
mirroring `ClaudeEngine.send` (`chat_engines.py:184-215`), mapping `item.started/
completed` `command_execution`/`file_change`/`mcp_tool_call` items onto the same
`tool` event.

### Validation

- SDD two-door: NEW behavior → `specs/templates/intake-refinement.md` →
  `specs/40-features/chat-overlays.md` (one spec for the whole surface; verified dir:
  `specs/40-features/`). Gherkin `Scenario:[chat-overlays-tool-chip]` etc. resolving
  to real `check()` names; `feature-spec-conformance` gate enforces.
- Deterministic: extend `stream_json._self_check` (canned NDJSON with tool_use +
  tool_result → descriptors fired with digest/id) and `chat_operator.__main__`
  (emit shape). GUI: Playwright ui_e2e case — feed a canned `tool` event, assert chip
  renders and `<details>` expands (per the standing playwright-ui-e2e-layer practice).

### Risks / open decisions

- Digest cap size (2 KB proposed) — big Bash outputs truncate; honest `[truncated]`
  marker, reuse `truncate_text` from `common.py`.
- Emoji icons on legacy Windows consoles: CLI must use the `_glyphs()` encode-probe
  fallback; GUI is fine.
- Event volume: one extra `tool-result` per call is bounded by the turn; no polling.

---

## Request 2 — real-time plan-step HUD

> "Na tela de chat, atualizar em tempo real em qual etapa de um plano estamos (se
> houver plano rastreável como no codex e claude). Card minimizável flutuando em cima
> da barra de digitação, como no Codex GUI. No CLI, bloco de texto fixo preso no fundo
> do chat, atualizado como overlay/HUD enquanto ativo, e vira histórico quando completo."

### The trackable-plan mechanism (verified)

- **claude**: headless `-p --output-format stream-json` emits `TodoWrite` `tool_use`
  blocks whose `input.todos` is the live plan (`[{content, status, activeForm}]`).
  These flow through the exact loop `parse_chat_stream` already walks
  (`stream_json.py:163-169`) — the hook is: when `block.name == "TodoWrite"`, fire
  `on_plan(todos)` instead of/in addition to `on_tool`.
- **codex**: `codex exec --json` emits `item.*` events; the current parser consumes
  only `agent_message`/`error` (`chat_engines.py:349-354`). Codex's plan tool surfaces
  as a `todo_list` item type — same fold point. BUT the codex turn is buffered
  (`subprocess.run`, `chat_engines.py:323`), so codex plans are post-turn until
  Increment 4 of Request 1 lands streaming.
- CAUTION (open decision): `ClaudeEngine._argv` allowlists only Bash harness patterns
  (`chat_engines.py:151`, `:169-173`). TodoWrite is normally permission-free in
  headless claude, but this must be CONFIRMED live; if denied, add `"TodoWrite"` to
  the allowed list at `chat_engines.py:169`.

### Current seams for rendering

- CLI: `chat_hud.Hud` already owns a bottom-pinned, scroll-region (DECSTBM) HUD
  redrawn in place — `_redraw` composes `separator / telemetry / agent rows / status /
  input` with `hud_h = 4 + len(agent_rows)` (`chat_hud.py:380-409`). The plan block is
  literally MORE ROWS in this list. "Vira histórico" = print the final plan via
  `hud.say()` (scrolls above the region, `chat_hud.py:284-303`).
- GUI: input bar `#chatin` (`harness_ui_page.py:344`); transcript with pinned busy
  line (`harness_ui_page.py:526-529`); chat column layout in `PAGE` CSS. The card is
  a new absolutely-positioned element above the input row.
- Turn lifecycle events already exist: `turn-start`/`turn-end`/`ready`
  (`chat_operator.py:592, 603, 610, 436`).

### Phased plan

**MVP — claude plans, both surfaces (M):**
1. `stream_json.parse_chat_stream`: add `on_plan` callback fired per TodoWrite block
   with the raw todos list (normalized to `[{text, status}]`, statuses
   pending/in_progress/completed).
2. `chat_engines.ClaudeEngine.send`: thread `on_plan = getattr(self, "on_plan", None)`
   (same getattr pattern as `on_activity`, `chat_engines.py:178`).
3. `chat_operator.run_chat`: `emit({"event":"plan", "steps":[...]})` + hand the steps
   to the HUD (`hud.set_plan(steps)`).
4. `chat_hud.py`: `set_plan()` + plan rows in `_redraw` — one row per step, capped
   (e.g. 6: done-count summary + current step + next steps), glyphs `✔ ▸ ○` with
   ASCII fallback via `_glyphs`. On `end_turn` with a finished plan (or `set_plan(None)`):
   print the final checklist once via `say()` → scrollback history, drop the rows.
5. `harness_ui_page.py`: floating minimizable card anchored above `#chatin` —
   header `Plano (2/5)` + minimize toggle (CSS-only collapse to the header strip),
   step list with the in-progress step highlighted. `handleEvt` case `"plan"`
   updates it; on `turn-end` (`harness_ui_page.py:1139`) with all steps completed,
   `append()` the checklist into the transcript as history and hide the card.
   SSE replay rebuilds the card state naturally (last `plan` event wins).

**Increment 2 — codex plans (M):** after CodexEngine streams (Request 1 / Increment 4),
map `todo_list` items to the same `on_plan`/`plan` event. Until then, fold the final
`todo_list` from the buffered `_parse` (`chat_engines.py:334-369`) so codex at least
shows the plan as history post-turn.

**Increment 3 — stale-plan hygiene (S):** clear the card/rows on `ready` after N
turns without a TodoWrite update; never persist plans anywhere (render-only).

### CLI+GUI parity

Same event, two renderers: bottom scroll-region rows (CLI) ≡ floating card (GUI);
`say()` history line ≡ transcript `append()` history. Non-TTY / `HARNESS_CHAT_NO_HUD=1`
CLI degrades to printing step-transition lines only.

### Harness vs target

The plan is the OVERSEER's plan (engine-side), scope-free by nature; the per-turn
target tag (`chat_operator.py:587-589`) already tells the model which repo it plans
against. No target-side data path.

### Validation

- Spec scenario `Scenario:[chat-overlays-plan-hud]` in `specs/40-features/chat-overlays.md`.
- Deterministic checks: `stream_json._self_check` canned TodoWrite sequence →
  `on_plan` firings in order; `chat_hud._self_check` pure-formatter test for plan rows
  (same style as `format_worker_rows` tests, `chat_hud.py:463-468`); Playwright ui_e2e:
  canned `plan` events → card renders, minimizes, becomes history on turn-end.

### Risks / open decisions

- TodoWrite may not fire in short turns — HUD simply never appears (fail-quiet).
- HUD height: plan rows + agent rows can exceed small terminals — cap plan rows and
  respect `MIN_HEIGHT` (`chat_hud.py:36`); the HUD is already fail-open by design.
- Claude may rewrite the whole todo list mid-turn (it does) — last event wins, no diffing.
- Codex `todo_list` item shape must be confirmed live before Increment 2.

---

## Request 3 — test/gate visualization (harness vs target-repo gates)

> "Nas fases de testes, mostrar os gates por quais a feature precisará passar, quais
> já passou, e quando terminal vira histórico. CLI e GUI. Representar gates do harness
> e gates locais do repo trabalhado de forma DIFERENTE. Pode ser integrado ao
> overlay/HUD/card do plano atual, indentado na etapa que roda os testes."

### Current seams (verified)

- Harness gate ladder: `GATES = ["smoke", "spec-pack", "commit", "feature", ...]`
  (`scripts/spec_test_gate.py:47`); per-run results appended to
  `.harness/runs/validation-results.jsonl` (`spec_test_gate.py:46`) and last-run
  summary in `.harness/state/quality-state.json` (`spec_test_gate.py:45`).
- Target gates: `spec_test_gate.py --target <name>` routes to
  `gate_generic.run_target_gate` (`spec_test_gate.py:1604-1615`), which composes the
  target's own `validation.<gate>.commands` from `target.json`
  (`gate_generic.py:170`, profile default `scripts/harness_lib/targets.py:27-38`) and
  persists per-target quality-state (`gate_generic.py:238`,
  `targets.py:25 STATE_BASE`).
- The panel ALREADY separates the two: `ui_panel._gates` returns
  `{order, last, target:{name, last}}` (`ui_panel.py:120-134`) and `renderGates` draws
  harness tier chips + a distinct `target <name>: …` line
  (`harness_ui_page.py:822-843`) — but only in the right-column Gates section,
  disconnected from the chat.
- Detection hook: when the overseer runs a gate, it is a Bash `tool_use` whose
  `command` (already the chip arg via `tool_descriptor` precedence,
  `stream_json.py:129`) matches `spec_test_gate.py`/`harness.py test`; `--target` in
  the command ⇒ target scope.

### Phased plan

**MVP — gate rows under the running test step (M):**
1. `chat_operator.py`: in the `on_tool` path, pattern-match the command
   (`spec_test_gate|harness\.py .*test` + optional `--target (\S+)`) → emit
   `{"event":"gate", "scope":"harness"|"target", "target":name?, "gate":g,
   "status":"running"}`. Deterministic regex, no LLM.
2. On the matching `tool-result` (Request 1 Increment 2) or `turn-end`: re-read the
   authoritative status from `quality-state.json` / per-target quality-state (one
   read, verify-on-demand — the exact sources `ui_panel._gates` uses) and emit the
   settled `gate` event with pass/fail + counts.
3. GUI: render gate rows INDENTED under the plan card's current in-progress step
   (or, with no active plan, as a standalone strip in the same card slot).
   Visual distinction reuses the established language: harness gates = `gtier`
   chips; target gates = `target <name>` mono prefix + distinct border/color
   (extends the `renderGates` precedent at `harness_ui_page.py:835-841`).
   Terminal→history together with the plan card (or immediately on settle when
   plan-less).
4. CLI: same rows indented in the HUD plan block (`↳ gate feature ✓ harness` /
   `↳ gate commit ✗ target:my-app`), capped; history via the same `say()` flush.

**Increment 2 — "gates the feature still needs" (S):** the ladder ahead is static
knowledge: show remaining tiers from `GATES` order beyond the last-passed gate
(harness side), and the target's configured `validation` keys (target side). Data
already assembled by `_gates` (`ui_panel.py:120-134`); reuse, don't re-derive.

**Increment 3 — richer per-check drill-in (S, GUI only):** clicking a settled gate
row opens the last run's check list from `validation-results.jsonl` (read-only route
addition in `ui_panel.py` snapshot collectors; still no canonical writes).

### CLI+GUI parity

Same `gate` events; GUI card sub-rows ≡ CLI HUD sub-rows; both flush to history with
the plan. Distinction encoding is identical (prefix + color class), only the medium
differs.

### Harness vs target

Structural, not cosmetic: scope is carried IN the event (`scope`/`target` fields) and
sourced from two different state files that never merge (`spec_test_gate.py:45` vs
`gate_generic.py:238`). The UI may never infer scope from text.

### Validation

- Spec scenario `Scenario:[chat-overlays-gate-tracker]` in the same feature spec.
- Deterministic: unit check for the command→gate-event classifier (pure function,
  goes next to `classify_command` self-checks, `chat_operator.py:624-633`); canned
  quality-state fixture → settled event shape; Playwright ui_e2e: canned `gate`
  events indent under the plan step and style harness≠target differently.

### Risks / open decisions

- Overseer may run gates via `!` human escape or manual mode — those paths bypass
  `on_tool`; MVP covers the agent path, human runs can emit the same event from
  `run_harness_command` later (open).
- Workers (not the chat overseer) also run gates — out of scope here; the workers
  panel/drawer already covers them (`chat_hud.read_workers`, worker drawer).
- Gate command regex drift if CLI syntax changes — keep the classifier next to
  `classify_command` so the same self-check file guards both.

---

## Sequencing & shared backlog rows

Build order: R1 MVP (event vocabulary + chips) → R2 (plan HUD reuses the pipe and the
turn lifecycle) → R3 (indents into R2's card; needs R1's tool/tool-result events).
Codex streaming (R1-Inc4) unblocks full codex parity for all three.

| slug | title | size | priority | deps | doc |
|---|---|---|---|---|---|
| chat-tool-chips | Tool-call chips + expand-to-inspect (GUI `<details>`, CLI `/tool`) | M | P1 | — | docs/roadmap/chat-overlays.md |
| chat-plan-hud | Real-time plan-step HUD (GUI floating card / CLI bottom block → history) | M | P1 | chat-tool-chips | docs/roadmap/chat-overlays.md |
| chat-gate-tracker | Gate sub-tracker under the test step, harness ≠ target styling | S | P2 | chat-plan-hud | docs/roadmap/chat-overlays.md |
| codex-stream-parity | CodexEngine Popen streaming (tool/plan events mid-turn) | M | P2 | chat-tool-chips | docs/roadmap/chat-overlays.md |

SDD: one intake (`specs/templates/intake-refinement.md`) → one feature spec
`specs/40-features/chat-overlays.md` carrying the three `Scenario:[id]` blocks named
above; `feature-spec-conformance` enforces scenario↔check resolution.
