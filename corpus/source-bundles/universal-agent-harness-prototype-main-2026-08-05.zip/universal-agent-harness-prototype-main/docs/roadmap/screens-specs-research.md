# Roadmap — GUI screens: Specs + Research

Planning-only refinement (2026-07-12). No behavior changed. Both screens follow the
panel's existing pattern: a read-only snapshot builder in `harness_lib`, a token-gated
`/api/*` route in `scripts/harness_ui.py`, a PAGE section + nav button in
`scripts/harness_ui_page.py`, and any write routed exclusively through the
`run_action` allowlist (`scripts/harness_lib/ui_panel.py:675-736`, guards `:739-802`).

Shared seams (verified):

- Nav/views: buttons `scripts/harness_ui_page.py:318-320`, `switchView`
  `scripts/harness_ui_page.py:1240-1253`, sections `:357` (`viewConfig`) / `:373`
  (`viewCompose`). New screens = one more button + section each.
- Routes: `do_GET` dispatch `scripts/harness_ui.py:137-177`; path-traversal-guarded
  static serving pattern to copy for raw-file endpoints: `_send_vendor`
  `scripts/harness_ui.py:111-134`.
- Records API already exists (`scripts/harness_ui.py:163-172`) — research rounds and
  decisions are searchable through it today.
- Harness-vs-target: registry `scripts/harness_lib/targets.py:43-62` (`load_targets`),
  roots `:91-94`, generated state bases `:23-25`. `doc-find` already takes `--target`
  (`scripts/harness.py:3051`) — the precedent for subject-scoped CLI verbs.
- File budgets: `ui_panel.py` is 1363 lines, `harness_ui_page.py` 1829 — new snapshot
  logic goes in NEW `harness_lib` modules, not into `ui_panel.py` (token-economy
  directive: fragment monoliths).

---

## Screen A — Specs

### Goal + value

> "tela de specs: especificações do projeto organizadas por escopo. Leitor/inspetor de
> specs. Se uma spec linka pra outra, já deve ter opção de clicar e ir pra visualização
> da spec indicada. Destaque especial na separação de specs GLOBAIS (funcionam tanto no
> harness quanto no repo trabalhado — diretrizes globais), specs LOCAIS DO HARNESS,
> specs LOCAIS DO REPO trabalhado."

Value: the specs tree is the SDD source of truth (SPEC-116 two-door flow) but is only
readable via editor/grep today. A scoped, cross-linked inspector makes "which rule
governs this?" a click instead of a search, and makes the global/harness/target
boundary (SPEC-110) legible to the operator.

### Seams (verified)

- Tree semantics: `specs/SPECS.md:8-15` — `00-universal/` is the mandatory baseline
  ("Always inherit `specs/00-universal/`" `specs/SPECS.md:19`) = the GLOBAL scope;
  `10-project/ … 90-operations/` = harness-local scope. 17 files in `00-universal`,
  21 in `40-features` today.
- Spec identity: H1 pattern `# SPEC-### — Title` (e.g.
  `specs/40-features/research-skill.md:1`); 149 `SPEC-###` occurrences across 23 spec
  files (the cross-reference graph is real and dense —
  `supervision-m5-interactive-panel.md` alone has 27).
- Cross-reference forms found in the tree (all three must linkify):
  1. bare `SPEC-###` mentions (needs an id→file index from H1s);
  2. bare path tokens like `specs/00-universal/structural-discovery.md`
     (`specs/40-features/research-skill.md:169`);
  3. real markdown links `[..](..)` — mostly external URLs
     (`specs/00-universal/sdd-bdd-flow.md:90-95`) → open in new tab.
- Section/conformance model: `REQUIRED_SECTIONS`
  `scripts/harness_lib/spec_conformance.py:24-31`; per-spec check dicts from
  `check_feature_specs` `:90-126` (skips `*.intake.md` `:100-101`, legacy exemptions
  `:104-105`) — reusable as conformance badges.
- Target scope: a registered target's own `specs/` tree under `target_root(entry)`
  (`scripts/harness_lib/targets.py:91-94`). Note: targets may have NO specs tree —
  the screen must degrade calmly ("target has no specs/").

### Phased plan

**S0 — spec index (CLI-first, S).** New `scripts/harness_lib/spec_index.py` (stdlib):
scan `specs/**/*.md` of the harness root + each enabled target's `specs/` tree; per
file emit `{path, scope, specId (H1), title, headings, outgoingRefs}` where
`outgoingRefs` = the three link forms above resolved to `{kind: spec|path|external,
target}`. Scope classes: `global` (= `specs/00-universal/`), `harness`
(other harness `specs/` dirs incl. `templates/`), `target:<name>`. New CLI verbs
`specs list [--target X] [--scope ...]` and `specs show <SPEC-id|path>` (prints body +
resolved refs + reverse refs) in `scripts/harness.py` — parity comes first, GUI reads
the same index.

**S1 — routes (S).** In `scripts/harness_ui.py` `do_GET`: `GET /api/specs` → index
snapshot; `GET /api/spec?path=<rel>` → raw markdown, allowlisted to the harness
`specs/` root and registered targets' `specs/` roots with the `_send_vendor`-style
resolve+`relative_to` traversal guard (`scripts/harness_ui.py:114-119`).

**S2 — GUI section (M).** `viewSpecs` in `harness_ui_page.py`: left rail grouped by
the three scopes (GLOBAL badge visually distinct; per-scope counts; target picker when
targets are registered); right pane = inspector: minimal self-contained markdown
renderer (escape-first, whitelist: headings/lists/tables/fenced code/links — strict
CSP, no CDN), linkifying `SPEC-###` + `specs/...md` tokens to in-app navigation.
Breadcrumb/back = a client-side history stack (same lazy pattern as the REPL history
array `harness_ui_page.py:1092`).

**S3 — increments.** (a) "Referenced by" backlink panel (invert `outgoingRefs`);
(b) conformance badges per feature spec from `check_feature_specs` results;
(c) search box backed by `doc-find`; (d) mini cross-ref graph reusing the composer's
inline SVG DAG approach (`harness_ui_page.py:1657-1719`). All optional; ship S0-S2
first.

### CLI + GUI parity

`specs list/show` (S0) is the canonical surface; `/api/specs`/`/api/spec` render the
same `spec_index` output. No GUI-only capability; no write path at all (screen is
read-only — zero `ACTIONS` entries needed).

### Harness vs target separation

Scope is structural, not a filter: `global` and `harness` come from the harness tree;
`target:<name>` from each registered target root. The GLOBAL group is pinned first and
shown under BOTH subjects (it governs both — `specs/SPECS.md:19`). `specs list
--target X` mirrors `doc-find --target` (`scripts/harness.py:3051`).

### Validation (SDD)

Door NEW (SPEC-116): `specs/templates/intake-refinement.md` →
`specs/40-features/gui-specs-screen.md` with template sections
(`spec_conformance.py:24-31`) and Gherkin `Scenario:[ui:specs-*]` ids mapped to
`check()` calls in a `testing/scenarios/` file referenced from Validation
(enforced by `check_feature_specs`). Deterministic checks: index parses all current
spec files; SPEC-id resolution round-trips; traversal attempts on `/api/spec` refuse.
Browser layer: extend `testing/scenarios/ui_e2e.py` (navigate a cross-link, breadcrumb
back) per the Playwright ui_e2e memory rule.

### Risks / open decisions

- Markdown rendering in-page: keep the renderer whitelist-only (escape first, then
  re-emit known constructs) — a permissive renderer inside a token-authenticated panel
  is an XSS foot-gun even on loopback.
- `SPEC-###` ids live only in H1 prose — if two files claim the same id the index must
  surface the collision, not pick silently.
- Target spec taxonomy is unowned: nothing guarantees a target uses this repo's
  folder convention. MVP: treat any `<target>/specs/**/*.md` flatly under
  `target:<name>`; do not infer global/local inside a target.
- `MANIFEST.yaml` (required-baseline membership) as a badge — deferred until someone
  asks (YAGNI).

---

## Screen B — Research

### Goal + value

> "tela de researchs: visualizar todas as pesquisas já feitas, material elaborado,
> fontes, resultados, backlog resultante, experimentos, resultados de experimentos.
> HUGE PLUS: rodar pesquisas por aqui, com um form de informações práticas que guiam a
> pesquisa. Interativo durante a pesquisa quando roda via agentes na GUI/CLI: deliberar
> se já temos fontes suficientes, contribuir com algum achado, ou guiar o resultado
> (DISCLAIMER: esses dois podem influenciar muito a decisão da pesquisa — deixar o
> usuário ciente). Separar pesquisas do harness das do repo."

Value: three real rounds already exist (`docs/research/memory-context-management.md`,
`deep-research-pipelines.md`, `agent-gui-cli-features.md`) and their outputs seeded
SPEC amendments and whole task plans — but the material is only reachable by opening
markdown files. A gallery + run-surface turns the Double Diamond machine into an
operable product instead of a chat ritual.

### Seams (verified)

- Round doc = the canonical artifact: one file per round, fixed phase order
  (`docs/research/RESEARCH.md:9-13`); real round headings Phase 0-5 confirmed in
  `docs/research/memory-context-management.md:1-106`.
- Method contract: `.harness/prompts/research-playbook.md` — phase→command→artifact
  map `:50-57`; evidence-entry format (claim|source|type|year|method|limitations|
  confidence|maturity) `:83-87`; `[web]/[repo]/[judgment]` provenance prefix `:89-93`;
  Phase 2 **human gate** `:95-102`; portfolio buckets + experiment template
  `:145-148`; traceability matrix `Evidência→…→Status` `:156-158`; 60% budget gate
  `:119-121`.
- Wave machinery: profiles `research-divergence` / `research-critique`
  (`.harness/workflows/workflow-profiles.json:344,:413`; shape pinned by SPEC-119
  rules 3-4, `specs/40-features/research-skill.md:31-36`). Wave artifacts:
  `.harness/workflows/active/<WF>/` with `reduce/reducer.result.json`,
  `seed-context.md` (rule 19 `:190-197`), `context-digest.md` (rule 16 `:161-169`);
  concept cards ride in findings (`research-playbook.md:125-128`).
- GUI can already CREATE (not start) a research workflow: `composer-create` →
  `workflow plan --branch-json` (`ui_panel.py:732-735`; CLI seam SPEC-119 v7
  `specs/40-features/research-skill.md:319-328`), gated by an in-process compile
  (`ui_panel.py:773-778`) with budget + secret-scan (rules 28-30).
- Escalations already flow to the panel and are resolvable from it
  (`ui_panel.py:94` `_escalations`; action `resolve-escalation` `:676-677`) — the
  lazy checkpoint transport.
- Deliverables: decisions in `.harness/context/DECISIONS.md`, tasks via
  `workflow promote` (`research-playbook.md:149-152`); records API for search
  (`harness_ui.py:163-172`).
- Verification pattern for derived views: digest header carries `mtime+sha256` and a
  NON-AUTHORITATIVE note (`scripts/harness_lib/context_digest.py`, SPEC-119 rule 16)
  — the screen's parsed views must carry the same "derived, verify in the doc" stance.

### Phased plan

**R0 — research index (CLI-first, M).** New `scripts/harness_lib/research_index.py`
(stdlib, deterministic): parse each `docs/research/*.md` into
`{slug, question, budget, phaseProgress (which Phase-N headings exist), evidenceRows
(parsed Phase-1 table), briefs, waves (WF-ids found in the doc), portfolio buckets,
experiments, traceability rows}`, plus live workflows whose profile starts with
`research-` (from `.harness/workflows/active/`). Parsing is best-effort per section
with a `parseErrors` field — never crash on a hand-written round doc. CLI:
`research list` / `research show <slug>` (rendering the index), keeping parity first.

**R1 — gallery + detail GUI (M).** `GET /api/research` + `viewResearch`:
- Gallery: one card per round — question, phase progress bar (0-5), evidence count by
  confidence class, #waves, portfolio bucket counts, subject chip (harness/target).
- Detail: evidence matrix as a sortable/filterable table (confidence + maturity chips,
  provenance `[web]/[repo]/[judgment]` color-coded as trust boundaries); brief cards;
  wave timeline divergence→critique with per-wave reduce status and top findings read
  from `reduce/reducer.result.json` when the WF dir still exists (degrade to the doc's
  own Phase 3/4 summary when scrubbed); portfolio buckets as columns; experiment
  ledger cards (hipótese/baseline/métricas/critérios + result when present);
  traceability matrix rendered verbatim. Every parsed view links back to the source
  section of the round doc (non-authoritative derived view, digest stance).

**R2 — "run research" form (M).**
- Form fields: question, success criteria, seed material/sources, subject
  (harness | target:<name>), declared budget/wave, #waves (default 1+1 per playbook
  `:178-179`), executor (claude/codex/openai-compat).
- MVP wiring, honest about who orchestrates: (a) new CLI verb `research scaffold
  <slug> --question … --criteria … --budget … [--target X]` writes the Phase-0
  skeleton of `docs/research/<slug>.md` (SPEC-119 rule 9 — no new directories); the
  form calls it via a new allowlisted mutating `ACTIONS` entry (confirm dialog, same
  ladder as `ui_panel.py:790-792`). (b) The form then opens a chat session pre-filled
  with the research-skill activation line + the scaffolded slug — the orchestrator IS
  the chat agent (playbook `:3-7`); the GUI does not re-implement phase logic.
  (c) Wave creation stays on the existing `composer-create` path (create-only,
  compile-gated); starting waves remains CLI/chat until a `workflow-start` action is
  deliberately allowlisted — an explicit open decision, not an accident.

**R3 — interactive checkpoints (M).**
- Transport = the existing escalation loop (no new daemon, no polling): the
  orchestrator (playbook Phase 2 gate `:95-102`; 60% budget gate `:119-121`) raises an
  escalation typed `research-gate` with the round slug + a compact payload (evidence
  counts by confidence class vs success criteria). The panel renders it as a
  deliberation card: **"Fontes suficientes?"** → options continue-discovery /
  proceed-to-briefs; resolve via the existing `resolve-escalation` action.
- Operator contribution: new CLI verb `research note <slug> --kind
  finding|steer|enough-sources|experiment-result --text …` appending to a dedicated
  `## Operator contributions` section of the round doc, each entry stamped
  `[operator]` + timestamp; exposed as an allowlisted mutating action. Provenance
  gains a fourth class `[operator]` alongside `[web]/[repo]/[judgment]`
  (playbook `:89-93`) so the influence is auditable downstream.
- **Disclaimer (verbatim requirement):** the contribution form and the steer card
  display, before submit: "Contribuir um achado ou guiar o resultado pode influenciar
  fortemente a decisão da pesquisa — sua entrada será registrada como proveniência
  [operator] e pesará na convergência." The same line is stamped into the doc entry.

**R4 — increments (owner-requested contribution, see next section).** Source de-dup +
cross-round source index; budget burn-down; genealogy DAG; export.

### Contributed ideas — information organization + features

Organization (the detail page as five stacked lenses, each collapsible):

1. **Evidence matrix as the screen's spine.** Sortable by confidence/maturity/year;
   provenance color = trust boundary; clicking a claim highlights every downstream
   brief/idea/decision that cites it (reverse walk of the Phase-5 traceability matrix
   `research-playbook.md:156-158`) — "what does this claim actually hold up?" in one
   click.
2. **Ranked source cards with de-dup.** Canonicalize URLs (strip fragments/UTM, host
   lowercase) into a cross-round source index: each card shows type/year/confidence,
   "seen in N rounds" badge, and a staleness hint against the playbook's 24-36-month
   bleeding-edge window (`:77-79`). Prevents re-fetching the same source next round —
   Phase 0 says search records first (`:68-70`); this makes that instinct visible.
3. **Divergence→critique flow viz.** Ideas as nodes (ideator branch → concept card →
   critique verdict → operation `mantida|…|rejeitada` `:139-141`), genealogy edges
   from recombination waves (`:119-120`); render with the composer's existing inline
   SVG DAG technique (`harness_ui_page.py:1657-1719`). Shows WHERE an idea died and
   which critic killed it.
4. **Experiment ledger.** Portfolio `experimentos` entries as
   hypothesis/baseline/metrics/decision-criteria cards (`:147-148`) with a
   result slot filled by `research note --kind experiment-result` — experiments stop
   evaporating after Phase 5.
5. **Budget burn-down.** Declared per-wave budget (Phase 0) vs `token-audit` actuals
   per WF, with the 60% gate line drawn — observation pays for itself and the gate
   stops being folklore.

Features beyond the ask: confidence-class filter chips on the gallery ("show me only
rounds with ≥N forte claims"); "decision provenance" footer on each round card
(decisions appended to DECISIONS.md, tasks promoted — pulled from records); export =
the round doc itself is the portable artifact (link/download raw markdown + the
evidence matrix as JSON — no bespoke exporter).

### CLI + GUI parity

Every screen capability has a CLI twin: `research list/show` (R0), `research scaffold`
(R2), `research note` (R3), escalation resolve (exists). The GUI adds rendering, never
capability. All writes go through `run_action` allowlisted subcommands — the panel
still writes no canonical state directly.

### Harness vs target separation

Subject declared at scaffold time (`--target X`, mirroring `doc-find --target`
`scripts/harness.py:3051`) and recorded in the round doc's Phase 0 block. Gallery
groups by subject; a target round's Phase-1 repo evidence points at the target root.
Open decision: target round docs live in the harness (`docs/research/` with a subject
field) vs per-target subdirs — recommendation: keep ONE flat `docs/research/` with a
subject line (SPEC-119 rule 9 forbids new top-level dirs; a subject field is the
smaller change and keeps `records`/`doc-find` working unchanged).

### Validation (SDD)

Door NEW ×1 spec (`specs/40-features/gui-research-screen.md`) after an
intake-refinement; the CLI verbs land as an amendment to SPEC-119 (research surface)
or inside the new spec — decide at intake. Gherkin `Scenario:[ui:research-*]` ids →
`check()`s (spec-pack gate, `spec_conformance.py:90-126`). Deterministic checks:
index parses the 3 real round docs without error; scaffold round-trips; `research
note` appends only to its section; escalation-card payload shape. `ui_e2e.py`
extension: open gallery → detail → submit a note (disclaimer visible asserted).

### Risks / open decisions

- **Round docs are hand-written prose** — the parser will meet nonconforming docs.
  Best-effort per-section parse + visible `parseErrors`, never a crash; the doc stays
  authoritative (digest stance).
- **Operator-influence bias is real**: `[operator]` provenance + the stamped
  disclaimer keeps the influence auditable, but the critique wave should be told to
  treat `[operator]` like `untrusted-derived` seed content (SPEC-119 rule 20) — needs
  one line in the playbook when implemented.
- **Starting waves from the GUI** is deliberately excluded from MVP (create-only
  boundary, `ui_panel.py:725-735`); allowlisting `workflow start` is a separate
  security decision (it spawns agents).
- **Scrubbed WFs**: reduce artifacts are gitignored/scrubable; the detail view must
  degrade to the round doc's own summaries (already the plan).
- Cross-round source index adds a small derived state file — keep it regenerable
  under `graphify-out/` or compute in-memory per request; no new canonical state.

---

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| spec-index | `spec_index.py` + `specs list/show` CLI (scoped index, ref resolution) | S | P1 | — | docs/roadmap/screens-specs-research.md |
| gui-specs-screen | Specs screen: 3-scope grouping + cross-linked inspector + breadcrumb | M | P2 | spec-index | docs/roadmap/screens-specs-research.md |
| research-index | `research_index.py` + `research list/show` CLI (round parsing, WF join) | M | P1 | — | docs/roadmap/screens-specs-research.md |
| ~~gui-research-screen~~ ✅ | ~~Research gallery + detail — SHIPPED 2026-07-22 (fase 5 completa: RS1 source-lanes + RS2 claim-evidence matrix + RS3 consenso calibrado + RS4 run-form; viewResearch legado, measure-honesty, rs1/rs2/rs3/rf 4/4 cada)~~ | M | P2 | research-index | docs/roadmap/screens-specs-research.md |
| research-run-form | `research scaffold` verb + run form + chat handoff | M | P3 | research-index | docs/roadmap/screens-specs-research.md |
| research-checkpoints | Escalation-based gates + `research note` with [operator] provenance + disclaimer | M | P3 | research-run-form | docs/roadmap/screens-specs-research.md |
