# Roadmap — Total docs revision + Wiki screen + structure-printer

Status: planning only (2026-07-12). Nothing here is implemented.

## Goal (owner request, verbatim)

> "Revisão COMPLETA da documentação atual. Depois de revisada, adicionar nova tela 'Wiki' com
> manuais de TODAS as features e configurações do harness, do usuário LEIGO ao TÉCNICO. Wiki
> organizada por SEÇÕES e TÓPICOS, tudo bonitinho. Adicionar SPEC LOCAL pro harness documentar
> (se pertinente) features novas na wiki, usando o padrão de documentação/organização existente.
> Arquivos fonte da wiki devem ser FRAGMENTADOS, não monolito embutido em código python. Docs
> fáceis de navegar, inclusive um IMPRESSOR de estrutura de pastas e nomes de docs/SPECs (em vez
> de greps aleatórios). Revisão TOTAL, sem deixar passar nada, sem referências quebradas pra trás."

Value: agents stop paying token cost for random greps over 90+ markdown files; humans (leigo →
técnico) get one navigable surface; new features can no longer ship undocumented.

## 1. Inventory (audited 2026-07-12; lines / last commit / scope / verdict)

Scope legend: **H** = harness-scope, **T** = target/template-scope (stub filled after adoption),
**M** = mixed.

### docs/ (32 files + 4 research)

| File | Title | Ln | Last | Scope | Verdict |
|---|---|---|---|---|---|
| docs/AGENTIC_WORKFLOWS.md | Agentic Workflows | 104 | 07-08 | H | current (gate-checked for runtime consistency, `scripts/spec_test_gate.py:650`) |
| docs/AGENT_COMPATIBILITY.md | Agent Compatibility | 20 | 07-08 | H | stub — fold into wiki topic |
| docs/AGENT_TESTING_STRATEGY.md | Agent Testing Strategy | 43 | 07-08 | H | current (release-manifest required) |
| docs/ARCHITECTURE.md | Project Architecture | 18 | 07-08 | **T** | template stub — name collides with HARNESS_ARCHITECTURE.md; needs explicit scope banner |
| docs/CONTROLLED_PARALLEL_WRITES.md | Controlled Parallel Write Workflows | 190 | 07-08 | H | current |
| docs/FLOW_COMPOSER.md | Flow composer (Compose screen) | 97 | 07-12 | H | current — model for per-screen manuals |
| docs/GRAPHIFY_INTEGRATION.md | Graphify Integration | 123 | 07-09 | H | current (required file, `spec_test_gate.py:383`) |
| docs/HARNESS_ARCHITECTURE.md | Harness Architecture | 286 | 07-09 | H | current; wiki "técnico" backbone |
| docs/HARNESS_BENCHMARKING.md | Harness benchmarking plan | 27 | 07-08 | H | stub — freshness check |
| docs/HARNESS_CONTENT_GUIDE.md | Harness Content Guide | 47 | 07-08 | H | current — the doc-conventions law; wiki must obey it |
| docs/HARNESS_IMPROVEMENT_IDEAS.md | Improvement Ideas | 320 | 07-09 | H | living ideation ledger — tension with records-ledger direction (SPEC-112); triage in Phase 3 |
| docs/HARNESS_OBSERVABILITY.md | Observability + trace contract | 175 | 07-08 | H | current (release-manifest required) |
| docs/HARNESS_TECHNICAL_DEBT.md | Technical Debt Register | 37 | 07-10 | H | current |
| docs/IMPLEMENTATION_BACKLOG.md | Implementation Backlog | 119 | 07-12 | H | current — central backlog; rows below land here |
| docs/MCP_A2A_SECURITY_HARDENING.md | MCP/A2A hardening plan | 23 | 07-08 | H | stub plan — freshness check |
| docs/MILESTONE_REPORT_2026-07-11.md | Milestone report 2026-07-11 | 54 | 07-11 | H | point-in-time report — candidate for records-ledger migration (SPEC-112 precedent) |
| docs/OPERATOR_GUIDE.md | Operator Guide | 220 | 07-10 | H | current — wiki "operador" backbone |
| docs/PANEL_CHAT.md | Chat tab | 61 | 07-12 | H | current — per-screen manual model |
| docs/PROJECT_ADOPTION_GUIDE.md | Project Adoption Guide | 84 | 07-08 | **T** | current |
| docs/PROVIDER_CANARIES.md | Provider canary policy | 28 | 07-08 | H | current |
| docs/RELEASE_INTEGRITY.md | Release integrity/SBOM | 109 | 07-08 | H | current |
| docs/RUNTIME_PORTABILITY.md | Runtime Portability Policy | 39 | 07-08 | H | current (gate-enforced, `spec_test_gate.py:712`) |
| docs/SELF_EVOLUTION_IDEATION.md | Self-Evolution survey (living) | 252 | 07-11 | H | ideation ledger — Phase 3 triage |
| docs/SELF_EVOLUTION_REPORT.md | SE milestone report | 136 | 07-09 | H | point-in-time report — ledger-migration candidate |
| docs/STATE_STORE_CONTRACT.md | StateStore contract | 110 | 07-08 | H | current (release-manifest required) |
| docs/SUPERVISION_UI_IDEATION.md | Supervision UI ideation | 196 | 07-09 | H | ideation ledger (referenced by memory) — keep, label |
| docs/THREAT_MODEL.md | Harness threat model | 60 | 07-08 | H | current (release-manifest required) |
| docs/VV_PLAN.md | V&V Plan | 84 | 07-10 | H | current |
| docs/WORKER_RESULT_EXAMPLES.md | WORKER_RESULT Examples | 139 | 07-08 | H | current |
| docs/WORKFLOW_OPERATIONS_RUNBOOK.md | Workflow Operations Runbook | 250 | 07-08 | H | current (gate-checked, `spec_test_gate.py:650`) |
| docs/WORKFLOW_TOKEN_ECONOMICS.md | Workflow Token Economics | 119 | 07-11 | H | current |
| docs/research/RESEARCH.md (+3 rounds) | Research rounds index | 13/164/285/150 | 07-11..12 | H | current — pattern owned by SPEC-119 |

### specs/ (39 files)

| Group | Files | Verdict |
|---|---|---|
| specs/SPECS.md, SPEC_TEMPLATE.md, templates/intake-refinement.md | index + SPEC-116 templates | current |
| specs/00-universal/ (18) | baseline + patterns + sdd-bdd-flow.md + structural-discovery.md + canonical-file-protection.md | current; scope **T-reusable** |
| specs/10..30, 90 (5 index stubs) | PROJECT/ARCHITECTURE/STACK/OPERATIONS | template stubs (**T**) |
| specs/40-features/ (20) | SPEC-101..120 + intakes + FEATURES.md | current; **monoliths**: supervision-m5-interactive-panel.md **1175 ln**, repl-ux-onboarding.md 421, research-skill.md 411 — specs stay whole (SPEC-116 conformance owns their shape), wiki summarizes instead of fragmenting them |

### Root + .harness instruction files (13)

| File | Ln | Verdict |
|---|---|---|
| AGENTS.md 135, CLAUDE.md 24, AGENT_HANDOFF.md 5, CODEX_HANDOFF.md 5, AGENT_IMPLEMENTATION_ROADMAP.md 5, CODEX_IMPLEMENTATION_ROADMAP.md 5 | — | **protected** (`.harness/protected-files.json`) — revision may only propose reviewed amendments, never rewrites |
| README.md 88, EXPORT_MANIFEST.md 372 | — | current; README gets a Wiki pointer in Phase 5 |
| .harness/HARNESS.md 21, .harness/prompts/{harness-operator,subagent-contract,implementer-packet,research-playbook}.md | — | protected contracts — read-only for this effort |

## 2. Broken / stale reference list

Markdown `[..](..)` links: **0 broken** — already guarded by `check_markdown_links`
(`scripts/spec_test_gate.py:749-781`, scans root/docs/specs/tasks/testing/schemas/.harness).
The remaining holes are refs that guard does NOT see:

| # | Ref | Where | Problem |
|---|---|---|---|
| B1 | `SPEC-105` | `specs/40-features/supervision-m4-readonly-gui.md:7,45,104` | SPEC-105 never created; the interactive panel shipped as **SPEC-114**. Stale forward-pointer. Fix = amend to "SPEC-114 (planned as SPEC-105)". Note: amending pulls the file out of the `specConformance.legacy` freeze (`.harness/project.json`) — the fix must either be paired with template retrofit or the legacy list must state that ref-only edits keep the freeze (owner decision, see Risks). |
| B2 | SPEC numbering gaps 105–106 | corpus-wide | No spec defines 105/106; nothing documents the gap, so agents grep for them. docs-tree output should mark ID gaps. |
| B3 | `docs/CHANGELOG.md` (4×) | `specs/40-features/records-ledger.md:3,27,40,69` | File deliberately deleted by SPEC-112 itself. Historical, not broken — but a naive link check would flag it; tag the mentions "(deleted by this spec)". |
| B4 | `.harness/runtime/executor-state.json` | `README.md:84` | File exists only as `executor-state.example.json` until the operator copies it. Intentional; wiki "Configurações" topic must explain the copy step so the ref stops looking broken. |
| B5 | Backtick path refs with placeholders (`<name>`, globs) — 14 more hits (e.g. `AGENTS.md:124`, `docs/HARNESS_ARCHITECTURE.md:255`, `.harness/prompts/research-playbook.md:52`) | various | Not broken (placeholders), but any future backtick-path check must be placeholder-aware or it will false-positive. |

## 3. Seams (verified)

- GUI page: `scripts/harness_ui_page.py` (1829 ln, single `PAGE` string; nav buttons
  `navPanel/navConfig/navCompose` at lines 318-320, `switchView` wiring at 1245-1253).
- Routes: `scripts/harness_ui.py` (327 ln) — GET dispatch at 137-178; **`_send_vendor`
  at 111-135 is the precedent** for token-gated, traversal-guarded static file serving.
- Snapshots: `scripts/harness_lib/ui_panel.py` (`state_snapshot:281`, `routing_snapshot:259`,
  `composer_snapshot:494`) — pattern for a `wiki_snapshot`.
- Docs discovery: `scripts/harness_lib/discovery.py` (`doc_find`, wired at
  `scripts/harness.py:1779,2329,3051` incl. `--target` for SPEC-110 repos).
- Link guard: `scripts/spec_test_gate.py:749` (`check_markdown_links`); conformance gate:
  `scripts/harness_lib/spec_conformance.py` + `spec_test_gate.py:791`
  (`check_feature_spec_conformance`); target-side variant `scripts/harness_lib/gate_generic.py:83`.
- Conventions: `docs/HARNESS_CONTENT_GUIDE.md`; roots from `.harness/project.json`
  (`docsRoots=["docs"]`, `specRoots=["specs"]`).
- E2E: Playwright ui_e2e layer exists — every GUI change extends it (project memory).

## 4. Phased plan

### Phase 0 — Audit (this document) — done
Deliverables: inventory §1, broken-ref list §2, seams §3.

### Phase 1 — Fix stale refs + scope banners (S)
- Amend `specs/40-features/supervision-m4-readonly-gui.md` (B1) and
  `specs/40-features/records-ledger.md` (B3 tags); resolve the legacy-freeze question first.
- Add a one-line scope banner ("Escopo: harness" / "Escopo: projeto adotado (template)") to the
  two-scope collisions: `docs/ARCHITECTURE.md` vs `docs/HARNESS_ARCHITECTURE.md`,
  `docs/PROJECT_ADOPTION_GUIDE.md`, spec index stubs 10/20/30/90.
- No protected file is rewritten; AGENTS.md/CLAUDE.md untouched.

### Phase 2 — Structure-printer `harness.py docs-tree` (S)
- New function `docs_tree(root, scope=None, target=None)` in
  `scripts/harness_lib/discovery.py` (beside `doc_find` — no new module): walk `docsRoots` +
  `specRoots` from `.harness/project.json` plus the fixed root/`.harness/prompts/` instruction
  list; emit stable-sorted tree of `path — first `# ` heading — scope(H/T) — lines`; mark
  SPEC-ID gaps (B2). Deterministic, zero LLM, zero network.
- CLI: `python scripts/harness.py docs-tree [--json] [--scope harness|target] [--target <n>]`,
  registered next to `doc-find` (`scripts/harness.py:3051` pattern). Honors
  `HARNESS_AGENT_OUTPUT=compact` (TE.5).
- Retire the "random grep" path: `AGENTS.md` discovery guidance gains one line pointing to
  `docs-tree` (reviewed amendment — protected file, no overwrite).
- Acceptance: `testing/scenarios/dt_docs_tree.py` (title extraction, determinism = two runs
  byte-identical, gap marking, `--json` schema).

### Phase 3 — Consolidate + freshness pass (M)
- Ledger triage: decide per living doc (HARNESS_IMPROVEMENT_IDEAS, SELF_EVOLUTION_IDEATION,
  SUPERVISION_UI_IDEATION) — keep-and-label vs migrate closed items to the records ledger
  (`harness.py records`, SPEC-112 precedent). Point-in-time reports
  (MILESTONE_REPORT_2026-07-11, SELF_EVOLUTION_REPORT) → ledger-migration candidates.
- Freshness check of the four stubs (AGENT_COMPATIBILITY, HARNESS_BENCHMARKING,
  MCP_A2A_SECURITY_HARDENING, PROVIDER_CANARIES): update or fold into wiki topics.
- Spec monoliths stay whole (conformance owns their format); wiki pages summarize + link.

### Phase 4 — Wiki sources: fragmented `docs/wiki/` (L)
- Layout (folders = SEÇÕES, files = TÓPICOS; numeric prefixes give deterministic order):
  ```
  docs/wiki/
    00-comece-aqui/      10-o-que-e-o-harness.md   20-instalacao-setup.md  30-primeiro-workflow.md
    10-telas-do-painel/  10-painel.md 20-chat.md 30-config-routing.md 40-compose.md 50-wiki.md
    20-cli/              10-comandos-essenciais.md 20-workflows.md 30-records.md 40-doc-find-docs-tree.md
    30-configuracao/     10-project-json.md 20-executor-runtime.md 30-model-routing.md 40-gates.md
    40-features/         um tópico por SPEC shipped (101..120) — resumo leigo + link pro spec técnico
    50-seguranca-operacao/ 10-threat-model.md 20-protected-files.md 30-release.md
    90-projetos-adotados/  escopo target: adoption, targets, governance (SPEC-110)
  ```
- Each topic: title, `Nível: leigo|operador|técnico` line, body ordered leigo→técnico, "Fontes"
  footer linking canonical doc/spec (wiki NEVER duplicates normative text — it summarizes and
  links, per `docs/HARNESS_CONTENT_GUIDE.md` anti-duplication rules).
- Existing per-screen manuals (`docs/FLOW_COMPOSER.md`, `docs/PANEL_CHAT.md`) move under
  `docs/wiki/10-telas-do-painel/` with redirects-by-link from old paths kept for one release
  (markdown-links gate keeps everything honest).
- No manifest file: section/topic order derives from the folder tree (docs-tree function reused).

### Phase 5 — Wiki GUI screen (M)
- Routes in `scripts/harness_ui.py`: `GET /api/wiki` → tree+titles JSON (calls the Phase-2
  `docs_tree` restricted to `docs/wiki/`), `GET /api/wiki/page?p=<rel>` → raw markdown, cloned
  from `_send_vendor` (lines 111-135): resolve under `docs/wiki/`, `relative_to` traversal
  guard, `.md`-only, token-gated like every route. Files served from disk — **not** embedded in
  `PAGE`.
- `scripts/harness_ui_page.py`: fourth nav button `navWiki` (beside lines 318-320), sidebar tree
  + topic pane; minimal embedded markdown renderer (headings/lists/links/tables/code — ~60-line
  JS, CSP-safe, no CDN; code blocks reuse the existing tree-sitter `/vendor/` highlight assets
  where already loaded). Search v1 = client-side filter over titles+headings from `/api/wiki`;
  full-text stays on `doc-find`/records (no new index).
- Snapshot helper `wiki_snapshot(root)` in `scripts/harness_lib/ui_panel.py` only if caching is
  needed; otherwise route calls `discovery.docs_tree` directly (ponytail: skip the layer).
- Extend Playwright ui_e2e: open Wiki tab, click a topic, assert render + traversal-guard 404.

### Phase 6 — Local spec + guards (M)
- Door NEW per SPEC-116: fill `specs/templates/intake-refinement.md` →
  `specs/40-features/docs-wiki.md` (next free ID: **SPEC-121**) with Gherkin
  `Scenario:[id]` mapped to named checks in `testing/scenarios/dw_docs_wiki.py`.
- The spec's lasting rule: **every new/amended `specs/40-features/*.md` (non-legacy) must name
  its wiki topic** (a `Wiki:` line or a page under `docs/wiki/40-features/`); enforced by a new
  deterministic `wiki-conformance` check inside `scripts/harness_lib/spec_conformance.py`
  (same gate slot as `feature-spec-conformance`, `spec_test_gate.py:791`).
- Broken-ref guard extension in `scripts/spec_test_gate.py`: (a) `SPEC-###` textual refs must
  resolve to a spec heading (whitelist: SPEC-000 template, documented gaps 105/106); (b)
  placeholder-aware backtick-path check (skip refs containing `<`, `*`, `{`). Keeps "sem
  referências quebradas pra trás" true forever, not just once.

## 5. CLI ↔ GUI parity

`docs-tree` CLI and the Wiki sidebar consume the **same** `discovery.docs_tree()` function; the
GUI adds zero capability the terminal lacks (M2 rule: every GUI element is a rendered
subcommand). `docs-tree --json` output = `/api/wiki` payload (wiki-scoped subset).

## 6. Harness-scope vs target-scope

- Every docs-tree row carries scope H/T (derived from the Phase-1 banners + fixed lists).
- `docs-tree --target <name>` mirrors `doc-find --target` (SPEC-110,
  `scripts/harness.py:3051`) for adopted repos' own docsRoots.
- Wiki section `90-projetos-adotados/` isolates target-scope manuals; template stubs
  (docs/ARCHITECTURE.md, specs/10..90 indexes) are labelled, never merged into harness topics.

## 7. Validation

- `markdown-links` (existing) — covers docs/wiki automatically (scans `docs/`).
- New: spec-ref resolution + placeholder-aware path check (Phase 6) in the spec-pack gate.
- New: `wiki-conformance` beside `feature-spec-conformance`.
- `testing/scenarios/dt_docs_tree.py`, `testing/scenarios/dw_docs_wiki.py` (SDD Gherkin-mapped).
- Playwright ui_e2e Wiki flow. All checks deterministic — no LLM (net-cost-positive rule).

## 8. Risks / open decisions

1. **Legacy-freeze vs B1 fix**: amending supervision-m4 exits the SPEC-116 legacy exemption.
   Decide: ref-only amendments keep the freeze (needs a one-line rule in
   `.harness/project.json` `specConformance` description) vs full template retrofit.
2. **Markdown renderer in PAGE**: minimal hand renderer (~60 ln) vs vendoring a md lib under
   `vendor/` (setup.sh provisioning like tree-sitter). Plan assumes minimal renderer; upgrade
   path documented if tables/footnotes outgrow it.
3. **Ledger migration appetite** (Phase 3): how much of the ideation docs moves to records —
   owner call; token-economy directive pushes toward migration, memory-of-record pushes back.
4. **Language**: wiki topics in PT-BR (owner voice) with EN canonical docs linked — confirm.
5. Page count for `40-features/` (20 specs) is the bulk of Phase 4 (L size driver); can ship
   sections incrementally (comece-aqui + telas first).

## 9. Proposed central-backlog rows (docs/IMPLEMENTATION_BACKLOG.md)

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| ~~docs-audit-refs~~ ✅ | ~~Phase 1: stale-ref fixes + scope banners~~ — SHIPPED loop AFK 2026-07-23 (5 fixes: SPEC-105→114, CHANGELOG deleted-by-SPEC-112 tags, 4 scope banners; spec-pack pass, markdown-links 0-broken). B4/B5 (placeholder refs) deferidos. Desbloqueia docs-consolidation. | S | P1 | — | docs/roadmap/docs-wiki.md §4.1 |
| docs-tree-printer | `harness.py docs-tree` deterministic structure-printer | S | P1 | — | §4.2 |
| docs-consolidation | Phase 3: ledger triage + stub freshness | M | P2 | docs-audit-refs | §4.3 |
| wiki-sources | Fragmented `docs/wiki/` (seções/tópicos, leigo→técnico) | L | P2 | docs-audit-refs | §4.4 |
| wiki-screen | Panel Wiki view served from files (routes + nav + e2e) | M | P2 | docs-tree-printer, wiki-sources | §4.5 |
| wiki-spec-guard | SPEC-121 + wiki-conformance + ref-resolution guard | M | P3 | wiki-screen | §4.6 |
