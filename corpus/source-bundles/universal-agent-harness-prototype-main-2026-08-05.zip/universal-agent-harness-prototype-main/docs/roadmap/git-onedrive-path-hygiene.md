# Git / OneDrive path hygiene — investigation + fix roadmap

Status: PLANNED (investigation done 2026-07-12, read-only). Owner decision pending on Phase 3.

## Goal + why

Operator report (quoted): "Percebi que em alguns commits tinham o path com o meu nome 'augus', achei estranho — isso não é legal. Também tenho percebido que há alguma 'ENCRENCA' entre o git e pastas syncadas com o OneDrive. Dá uma investigada."

Two problems, one root area: machine-identifying absolute paths committed to the repo despite an existing hygiene gate, and the repo (including `.git/`) living inside an actively-synced OneDrive folder.

## Part A findings — absolute-path leak

### Exact leaks in HEAD (tracked files)

1. `.harness/handoff/handoff.json:197` — `"externalGraphifyTool": "C:\\Users\\augus\\bin\\graphify.CMD"`. Entered at commit `c78bbce`, survived the closeout regeneration in `107f93b`.
2. `.harness/targets/PrintIntel/target.json:3` — `"path": "C:\\Users\\augus\\OneDrive\\Documentos\\projetos\\PrintIntel"`. Entered at `c78bbce`. This field is inherently machine-local (external target registration) yet the file is git-tracked.
3. `tasks/harness-self-improvement/PLAN.md:98` — personal email `augustosc4rvalho@gmail.com` in prose. Lower severity (git author email is already public in every commit), listed for completeness.

History check: `git log -S 'augus'` → only `c78bbce`, `107f93b`, `425b993`. The `release/` artifacts (SBOM, provenance, attestation, checksums, EXPORT_MANIFEST) are clean in HEAD and history.

### Source generators

- The initial hypothesis (release generator) is FALSE: `scripts/release_integrity.py` emits repo-relative posix paths by design (`path.relative_to(ROOT).as_posix()` at lines 44, 66, 289). No leak there.
- Real source #1: `scripts/harness.py:295` — `"externalGraphifyTool": shutil.which("graphify") or None` returns the machine's absolute PATH hit. That `graph-status` output was pasted into the agent-authored `handoff.json` at closeout. Generator emits an absolute home path; the handoff process propagated it into a tracked file.
- Real source #2: target registration writes the target's absolute path into `.harness/targets/<name>/target.json`, and that file is tracked.

### Why `release-hygiene:local-absolute-paths` missed it

The check (`scripts/spec_test_gate.py:829-896`) DOES scan these files (rglob over ROOT, skipping only `.git/` and `.venv/`, lines 850-853). The miss is the pattern at line 844:

```python
re.compile(r"[A-Za-z]:\\(?:Users|workspace|tmp)\\")
```

It matches exactly ONE backslash after the drive colon. JSON files store Windows paths escaped — the raw text is `C:\\Users\\augus` (two backslashes) — which the regex does not match. Verified empirically: the compiled pattern returns no match against the current contents of both leaked files. Also uncovered: forward-slash form `C:/Users/...` and git-bash form `/c/Users/...` (both evade; only `/mnt/data`, `/opt/pyvenv`, `/home/oai` have unix patterns, lines 841-843).

## Part B findings — git vs OneDrive

1. **`.git/` is synced by OneDrive.** `(Get-Item .git -Force).Attributes` → `ReadOnly, Hidden, Directory, Archive, ReparsePoint`. The ReparsePoint on `.git` is the OneDrive Files-On-Demand marker: every index write, lockfile, and packfile repack is uploaded and can be raced (index.lock contention, placeholder-hydration stalls, conflict-copy risk inside `.git/objects`). This is the highest-risk class.
2. **Delete-locks are a confirmed, recurring symptom.** `scripts/harness_lib/common.py:30-45` — `rmtree_robust` exists specifically for "transient Windows handles (OneDrive/AV)" with a 3-attempt retry loop, promoted after a real failure (SPEC-109 note in the docstring). `.harness/state/worklog.json` (SPEC-108 H3 entry, ~line 398) records "OneDrive-rmtree defects" found by `workflow scrub`.
3. **CRLF re-touch churn.** `.gitattributes:1` sets `* text=auto eol=lf`, yet `git ls-files --eol` shows 9 tracked files with `w/crlf` vs `i/lf` — including the canonical instruction files `AGENTS.md`, `CLAUDE.md`, `.harness/prompts/{harness-operator,implementer-packet,subagent-contract}.md`, plus `scripts/harness_ui_page.py`, `testing/engineering-guardrails.json`, `testing/scenarios/m4_status_html.py`, `vendor/tree-sitter/manifest.json`. Something rewrites them with CRLF post-checkout (Windows editors / PS `Out-File` / protected-file restores). System gitconfig sets `core.autocrlf=true` (`C:/Program Files/Git/etc/gitconfig`), which fights the attr policy and amplifies re-hash + OneDrive re-upload churn.
4. **Conflict copies:** none currently tracked or in the working tree (`git ls-files | grep -iE 'conflicted copy|DESKTOP-'` → empty), but nothing in `.gitignore` protects against them either — first sync hiccup pollutes the tree.

## Phased plan

### Phase 1 — MVP: scrub + tighten gate + conflict-copy gitignore (size S)

- Scrub `handoff.json:197`: replace with a boolean-ish portable value, e.g. `"externalGraphifyTool": "graphify.CMD (on PATH)"` or just `true/null`; fix the generator seam at `scripts/harness.py:295` to emit `Path(which).name` (or a bool) so `graph-status` output can never re-leak a home path into pasted state.
- Scrub `target.json:3`: decide the seam — either untrack `.harness/targets/*/target.json` (gitignore; the path is machine-local by nature) or split the machine path into an untracked sibling (`target.local.json`). Least-invasive: gitignore + keep a tracked `target.meta.json` without `path` only if something needs it; today only the path field leaks, so plain gitignore is enough.
- Tighten `scripts/spec_test_gate.py:844` to fail closed on all spellings:
  `re.compile(r"(?i)(?:[A-Za-z]:(?:\\\\?|/)|/(?:c|mnt/c)/)(?:Users|workspace|tmp)(?:\\\\?|/)")` — covers `C:\Users\`, JSON-escaped `C:\\Users\\`, `C:/Users/`, `/c/Users/`. Keep the existing unix patterns.
- `.gitignore` += OneDrive conflict-copy patterns: `*conflicted copy*` and `*-DESKTOP-*.*` (validate the machine-name suffix against this PC's hostname before landing).
- PLAN.md:98 email: owner call; propose leaving it (already public via commit metadata) and noting the decision here.
- SPEC-116: this is an amendment to the existing release-hygiene coverage (COVERED door — versioned emenda on the release-hygiene spec section), not a new gate.

### Phase 2 — OneDrive health-check (size S)

- Add a deterministic check (no daemon, runs inside the existing gate or `graph-status`/workflow-doctor seam — `testing/scenarios/wd_workflow_doctor.py` shows the doctor pattern): WARN when (a) `ROOT` path contains `OneDrive` AND (b) `.git` carries `FILE_ATTRIBUTE_REPARSE_POINT` (`os.lstat('.git').st_file_attributes`). Warning text points at Phase 3 options. Warn-only, not fail — the condition is an environment fact, not a repo defect.
- Optional: same check flags `core.autocrlf=true` overriding the repo's `eol=lf` attr and suggests repo-local `core.autocrlf=false` + one-time `git add --renormalize .` review.

### Phase 3 — structural (owner decision, size M)

- Option A (strongest): relocate the repo out of OneDrive (e.g. `C:\dev\...`), keep OneDrive for docs/exports only.
- Option B: keep the worktree in OneDrive but move `.git` out (`git init --separate-git-dir C:\dev\git\uahp.git` migration; worktree keeps a `gitdir:` pointer file). OneDrive cannot exclude arbitrary subfolders natively, so this is the only reliable ".git out of sync" mechanism.
- Option C: status quo + Phases 1-2 mitigations. Risk of `.git` corruption remains nonzero.

## Validation

- Extended `local-absolute-paths` gate must FAIL on current HEAD before the scrub (proves detection) and PASS after (proves the fix) — capture both in the scenario.
- One scenario fixture: plant a JSON-escaped `C:\\Users\\x\\...` and a `C:/Users/x/...` in temp tracked-shape files, assert the gate reports them; assert conflict-copy names are ignored by `git check-ignore`.
- Phase 2: health-check scenario asserts WARN fires under a simulated OneDrive path/reparse condition and stays silent otherwise.

## Risks / open decisions

- Rewriting git history to purge `c78bbce`/`107f93b` blobs is NOT recommended (main branch, shared hashes); scrub forward. If the repo ever goes public, revisit with `git filter-repo` — owner call.
- Untracking `target.json` changes target-governance expectations (`specs/40-features/harness-target-governance.md`) — verify the gate that reads targets tolerates gitignored files.
- `*-DESKTOP-*` gitignore pattern could shadow a legitimate filename; scope it to this machine's actual hostname suffix if too broad.
- Relocate vs separate-git-dir vs status quo: owner decision (Phase 3).

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| path-hygiene-scrub-and-gate | Scrub committed home paths; tighten local-absolute-paths regex; gitignore conflict copies | S | high | — | docs/roadmap/git-onedrive-path-hygiene.md |
| onedrive-repo-health-check | Doctor-style WARN when repo/.git is OneDrive-synced + autocrlf/eol audit | S | medium | path-hygiene-scrub-and-gate | docs/roadmap/git-onedrive-path-hygiene.md |
| repo-out-of-onedrive-decision | Owner decision: relocate repo or separate-git-dir out of OneDrive | M | owner-decision | onedrive-repo-health-check | docs/roadmap/git-onedrive-path-hygiene.md |
