# Cross-project isolation — escalation / human-in-the-loop / LLM-routing channel

Status: roadmap (planning only). Scope: the INTERACTION channel — escalations, human decision surfaces, LLM routing/attribution. The DATA channels (files/diffs/memory/records/telemetry/graphs) are a separate roadmap.

## Goal and why

Request (escalation portion, quoted):

> "auditar se PEDIDOS DE ESCALAR PRA HUMANO/USUÁRIO/LLM não estão vazando de um projeto pra outro que o harness está operando, e também do harness para os projetos, ou desses projetos para dentro do harness. Cada um deve ter seu MUNDO e VISÃO."

The harness governs multiple target repos (SPEC-110, `scripts/harness_lib/targets.py`). When it asks a human to decide, or routes work to an LLM, that ask must belong to exactly one subject (the harness itself, or one named target) and be visible/actionable only under that subject's "world and view".

## Audit — enforcement vs gap (all file:line verified read-only, 2026-07-12)

### What is already scoped (enforcement exists)

| Seam | Evidence | Verdict |
|---|---|---|
| LLM model routing per subject | `scripts/harness_lib/model_routing.py:375-401` — precedence `perTarget > activeProfile > canonical`; `target_assign`/`target_clear` at :491-504 | ENFORCED. A target's work resolves its own model profile. |
| Worker spawn env | `scripts/harness.py:1811-1822` `worker_target_env`: deny-by-default (`targets.spawn_env`, `targets.py:198-200`) + `HARNESS_TARGET_NAME/ROOT`; least-privilege filter `build_worker_spawn_env` :1825-1835 | ENFORCED. No other target's env keys can reach a worker. |
| Worker packet prompt confinement | `scripts/harness.py:1143-1147` `target_line` names ONE target root, "analyze THERE... never in the harness repo"; one workflow carries one `workflow["target"]` (`harness.py:1813-1814`) | ENFORCED for target↔target: two targets never share a packet. Required reads are harness governance docs (`context_digest.py:37-44`) — intentional contract, not another project's task context. |
| Chat session target | `chat_operator.py:329-366` — flag > saved pref > picker, fail-closed `targets_lib.resolve`; mid-session switch rebuilds the engine for `perTarget` bindings (:315-318, SPEC-114 R37) | ENFORCED for routing. NOT enforced for the escalation view (below). |
| Per-target self-review config + ratchets | `targets.py:226-235` layered config; `self_review.py:336-369` per-target ratchet | ENFORCED (actions scoped by subject). |

### Confirmed bleeds / gaps

G1. **The escalation ledger is one pooled, subject-blind queue.** `.harness/state/escalations.json` is a single global path (`escalations_lib.py:108`); the record schema — `escalationId, taskId, suggestedProfile, reason, failureClass, raisedAt, source, criticality` (`escalations_lib.py:62-68, 75-82`) — has NO `target`/subject field. Per-target state dirs exist (`targets.py:124-125` `state_dir`) but escalations never use them. Harness-self findings, target findings, and target-workflow escalations all land in the same `raised` dict.

G2. **A target's self-review finding is absorbed into the harness queue with attribution only as a string convention.** Target findings get ids `target/<tname>/file-budget` etc. (`self_review_rules.py:322-346`), then `run_self_review` emits `self_review_finding` with no target field (`self_review.py:530-537`) — the subject survives only if a human parses the id prefix. Custom rules already support `"target": "<name>"|"self"|"*"` scoping at EVALUATION time (`self_review_rules.py:366-372`), but the scope is dropped at ESCALATION time.

G3. **Target-workflow escalations are unattributed.** `list_escalations` folds `WF-*/reduce/harness-result.json` with `requiresEscalation` into the queue (`escalations_lib.py:113-126`) without reading the workflow's `target` field — even though `workflow.json` carries it (`harness.py:1813-1814`). An escalation ABOUT target A is indistinguishable from a harness-self escalation unless the reason text happens to mention it.

G4. **The human view mixes all subjects and resolve is unscoped — a human can resolve another project's escalation without knowing it.** Panel snapshot `_escalations` reads the global ledger, row schema `{id, reason, criticality, raisedAt, suggestedProfile}` — no subject (`ui_panel.py:94-108`); `renderEsc` renders one mixed list with a Resolve button per card (`harness_ui_page.py:794-801`); attention strips inherit the mix (`ui_panel.py:164-178`); `run_action["resolve-escalation"]` passes the id straight to the CLI (`ui_panel.py:676-677`); `escalations --resolve` validates only pending-ness, never subject (`harness.py:2381-2392`). Adversarial read: a human triaging target A sees target B's `high` finding first (tier sort, `ui_panel.py:106-107`), acts on B's context while thinking in A's.

G5. **Chat's human-attention nag ignores the session target.** `_pending_critical` counts ALL high/critical raised records globally (`chat_operator.py:288-296`) and the warning fires regardless of `/repo` target (`chat_operator.py:398`). A human who opened chat to work on target A is pulled toward harness/target-B escalations; `!escalations` shows the pooled queue.

G6. **Finalizing a TARGET workflow rewrites the harness-global next-session prompt.** `workflow_finalize` unconditionally calls `update_context_from_workflow` + `generate_handoff` (`workflow_lifecycle.py:87-90`); `generate_handoff` has no target/subject parameter at all (`handoff.py:285-311`) and stamps `project` = harness project (`handoff.py:313`). Target A's task text becomes the handoff/next-prompt the NEXT session (possibly about the harness or target B) is primed with — target→harness interaction bleed, and transitively target→target via the shared handoff.

Direction coverage: target→harness = G2, G3, G6. harness→target = G4/G5 (harness escalations pollute a target-focused human session; packet required-reads are governance-by-design, accepted). target→target = G4 (mixed queue), G6 (shared handoff), G1 (root cause).

## Design

### D1. Subject field on every escalation record (root cause fix — one shared seam)

Add one structured field, `subject`: `"self"` or the target name. Single global ledger file stays (SPEC-109 durability, git history, `ledger-anomaly` monotonic check at `self_review.py:495-500` all keep working) — scoping is a FIELD + mandatory filters, not a file split. Splitting into `state_dir(name)/escalations.json` per target is deferred: it multiplies the compaction path (`compact_supervision_events`) and the resolved-monotonicity check for no MVP gain.

Producers stamp it:
- `self_review.py:533-537` — `subject = tname` when the finding id matches `target/<tname>/...` (derive once where the finding is created in `self_review_rules.py:318-346`, carried as `f["subject"]`, default `"self"`; custom rules pass their existing `target` scope from `self_review_rules.py:366`).
- `escalations_lib.py:60-68` (`harness_result_validated`) and `:117-126` (workflow fold) — `subject = workflow/harness-result target` (read `data.get("target")`; ensure `workflow_harness_result` copies `workflow["target"]` into the result payload — verify seam at `workflow_reduce.py` during implementation).
- `escalations_lib.py:74-83` (`self_review_finding` event) — pass through `evt.get("subject", "self")`.
- Legacy records without the field read as `subject: "self"` (backward compatible, no migration).

### D2. Scoped view + scoped resolve (the human's "world and view")

- `list_escalations(subject: str | None = None)` filters `pending` (and adds `bySubject` counts) — `escalations_lib.py:101-132`. CLI: `escalations --target <name|self>` (parser at `harness.py:3047`); default stays "all" but the output gains a `bySubject` breakdown so the mix is at least VISIBLE.
- Resolve gets a guard: `escalations --resolve <id> [--target <name|self>]` — when `--target` is given, refuse if the record's subject differs (legible refusal naming the actual subject). The panel and chat ALWAYS pass their active subject (fail-closed surfaces); the bare CLI keeps unscoped resolve for the operator.
- Panel: `_escalations` row gains `subject` (`ui_panel.py:102-105`); `renderEsc` renders a subject badge per card and a filter chip row (all / self / per-target) (`harness_ui_page.py:794-801`); `run_action["resolve-escalation"]` forwards the card's subject as `--target` (`ui_panel.py:676-677`). Attention strips label the subject (`ui_panel.py:175-178`).
- Chat: `_pending_critical(root, subject)` counts only the session's subject (session target name, else `"self"`) — `chat_operator.py:288-296` + call site `:398`; `!escalations` inside a `/repo <name>` session defaults to that subject's filter.

### D3. Routing/handoff confinement (G6)

- `generate_handoff` accepts `subject` (`handoff.py:285-311`); target-scoped handoffs write under `targets_lib.state_dir(name)/` (dir already exists per SPEC-110, `targets.py:124-125`) instead of the harness-global handoff; payload gains `"subject"`.
- `workflow_finalize` routes on `workflow.get("target")` (`workflow_lifecycle.py:87-90`): target workflow → target handoff + target context head; only subject-less (harness-self) workflows regenerate the global handoff/CONTEXT.
- Routing itself needs no change (perTarget already enforced, `model_routing.py:375-401`); add the subject to the escalation record so "which model/profile was in effect" is attributable per subject in `routing_show --target` (already exists, `model_routing.py:409-420`).

### D4. Deterministic isolation test (dual-subject)

Extend the ui_panel self-check pattern (`ui_panel.py:1060-1122` already builds a temp ledger and asserts rendering): temp root, ledger with `{subject: "self"}`, `{subject: "tA"}`, `{subject: "tB"}` records; assert (a) `list_escalations(subject="tA")` returns ONLY tA's, (b) panel snapshot filtered to tA never contains tB's id/reason string, (c) `--resolve` of tA's id with `--target tB` REFUSES, (d) `_pending_critical(root, "tA")` ignores tB's critical, (e) legacy record (no field) surfaces only under `self`. Pure stdlib, temp-dir, no LLM — gate-check shaped.

## Phased plan

**Phase 1 — MVP: subject tag + scoped list/resolve + deterministic test.**
Files: `scripts/harness_lib/escalations_lib.py` (schema + filter), `scripts/harness_lib/self_review.py:530-537` + `self_review_rules.py:318-346` (stamp), `scripts/harness.py:2381-2392,3047` (CLI `--target` + guarded resolve), one test (dual-subject, D4) wired as a gate fixture. SDD: intake via `specs/templates/intake-refinement.md` → `specs/40-features/escalation-subject-scope.md` with `Scenario:` ids mapped to the checks.

**Phase 2 — human view scoping.** `ui_panel.py:94-108,164-178,676-677` (subject in rows/strips + scoped resolve action), `harness_ui_page.py:794-801` (badge + filter chips), `chat_operator.py:288-296,398` (session-subject nag + `!escalations` default filter). Extend the existing panel self-check (`ui_panel.py:1060+`) and the Playwright ui_e2e layer for the filter chips.

**Phase 3 — handoff/context confinement (G6).** `handoff.py:285-311` (subject param + per-subject output path), `workflow_lifecycle.py:87-90` (route on `workflow["target"]`), verify `workflow_harness_result` carries `target`. Riskiest phase — touches the session-bootstrap prompt; needs its own intake.

## Validation

- Scenario (Gherkin, feature spec `escalation-subject-scope.md`): `Scenario:[esc-scope-1]` Given escalations raised by target tA and tB and the harness, When a human views the queue scoped to tA, Then only tA's escalations render and resolving a tB id under tA scope is refused with a legible error. `Scenario:[esc-scope-2]` Given a chat session with `/repo tA`, When tB has a pending critical, Then the session nag counts 0.
- Deterministic check per D4 runs in the gate (dual-subject fixture, stdlib-only, no LLM per the cheap-models rule).
- Conformance: SPEC-116 gate maps each `Scenario:[id]` to the fixture assertions.

## Risks / open decisions

- **Subject derivation from id-prefix (G2) is a convention, not a contract** — Phase 1 makes it structural, but until `workflow_harness_result` provably carries `target`, G3 stamping may need the workflow.json lookup as fallback (extra read in `list_escalations`). Verify during implementation.
- **Unscoped bare-CLI resolve stays legal** — deliberate operator escape hatch; the panel/chat surfaces are the fail-closed ones. Open decision: should the gate warn when an unscoped resolve touches a target-subject record?
- **Handoff split (Phase 3) changes session bootstrap** — a target session must learn to read the target handoff; needs coordination with chat `/repo` and any session-start docs. Kept out of MVP.
- **Legacy-record default `"self"`** could mis-attribute an old target-workflow escalation to the harness; acceptable (history is small, resolved ids are frozen).
- Per-target ledger FILES deferred (see D1) — revisit only if the global file becomes a contention/size problem.

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| esc-subject-scope | Escalation records carry + enforce a subject (self/target); scoped list/resolve + dual-subject deterministic test | M | high | — | docs/roadmap/cross-project-isolation-escalation.md |
| esc-scoped-hitl-view | Panel/chat escalation surfaces filter by subject; scoped resolve action; subject badges + session-subject nag | M | high | esc-subject-scope | docs/roadmap/cross-project-isolation-escalation.md |
| handoff-subject-confinement | Per-subject handoff/context on workflow finalize (target workflow stops rewriting the harness next-session prompt) | M | medium | esc-subject-scope | docs/roadmap/cross-project-isolation-escalation.md |
