# Roadmap: Memory Snapshot screen + Records & Changelogs screen

Status: planning only (no implementation). Source: user request 2026-07-12.
SDD door: NEW behavior — both screens must enter via `specs/templates/intake-refinement.md`
and land as `specs/40-features/<name>.md` with Gherkin→named-check mapping
(SPEC-116 law, `specs/00-universal/sdd-bdd-flow.md`; conformance gate in
`scripts/harness_lib/spec_conformance.py`).

Shared architecture constraints (verified):

- GUI is one self-contained page `scripts/harness_ui_page.py` (`PAGE`), served by
  `scripts/harness_ui.py:266-281` (`_send_page`); routes are flat `if path ==`
  branches in `do_GET` (`scripts/harness_ui.py:137-177`) / `do_POST` (:180-217).
  Strict loopback+token (`_authed`, :75-80). New screens = new nav pill + hidden
  `<section>` (pattern: `viewConfig` at `scripts/harness_ui_page.py:357`,
  `viewCompose` at :373).
- All snapshot collectors live in `scripts/harness_lib/ui_panel.py`; per-source
  never-crash degrade (`state_snapshot`, ui_panel.py:281-313) and the mtime/stat
  cache `_cached` (ui_panel.py:60-81). New collectors follow both patterns.
- Mutating power only via the `ACTIONS` allowlist → `run_action`
  (ui_panel.py:675, :739) → allowlisted `harness.py` subcommands. CLI+GUI parity:
  every panel capability must exist as a subcommand first.
- Native highlighter to REUSE: CLI-side `scripts/harness_lib/highlight.py`
  (detect_language / diff detection `_looks_diff`, used by
  `_detect_panel_language`, ui_panel.py:336-361); panel-side `colorizeDiff`
  (harness_ui_page.py:993) for diff-shaped text and on-demand tree-sitter
  `HL.highlightBlock` (harness_ui_page.py:951, WASM served from `/vendor/`,
  harness_ui.py:111-134). The worker drill-in already does exactly this pairing
  (harness_ui_page.py:706-709). No new highlight code.
- GUI writes no canonical state. Anything a screen persists goes to the derived
  layer `.harness/state-store/` (gitignored; precedent: `records.db`,
  `scripts/harness_lib/records.py:41`).

---

## Screen A — Memory snapshot

Goal (quote): "tela de snapshot de memórias: memórias e ledgers que os agentes
têm acesso, organizados por ESCOPO e FINALIDADE, com conteúdo atual sendo
exibido em tempo real."

Value: today the memory surface is scattered — the panel shows only the ledger
tail + head (`state_snapshot` keys `ledger`/`ledgerHead`, ui_panel.py:288-289)
and a search dialog (`recDlg`, harness_ui_page.py:441-449). Nobody can see, in
one place, *what an agent will actually find in its context* and where each
piece lives.

### Scope × purpose matrix (the screen's data model)

| Scope | Source (verified) | Purpose |
|---|---|---|
| USER (machine, outside repo) | `~/.claude/projects/<project-slug>/memory/MEMORY.md` + `memory/*.md` (Claude Code auto-memory; per-machine, NOT repo state) | preferences / lessons |
| HARNESS | `.harness/state/worklog.json` + `worklog-archive.json` (records.py:39-40) | decisions / milestones / changes |
| HARNESS | `.harness/context/CONTEXT.md` ledger head between markers (records.py:49-51, `render_head` :436) | always-in-context head |
| HARNESS | `.harness/state/escalations.json` (records.py:43) | escalations |
| HARNESS | `.harness/state/cost-metrics.json` + `.harness/state/token-calibration.json` (records.py:44; token_calibration.py:22) | cost |
| HARNESS | `.harness/state/self-review.json` (records.py:45) | self-review findings |
| HARNESS | `.harness/state/quality-state.json` (records.py:46) | validation memory |
| HARNESS (derived) | `.harness/state-store/records.db` FTS index (records.py:41) | retrieval index (show staleness only) |
| TARGET (per repo) | `.harness/state/targets/<name>/*` (targets.py:25 `STATE_BASE`, `state_dir` :124) + `.harness/targets/<name>/target.json` | target validation / profile |

Harness-vs-target separation is already physical (SPEC-110): target ledgers
live under the harness in `STATE_BASE`, never in the target repo — the screen
just groups by these path roots. The `_gates` collector already reads a
target's quality-state this way (ui_panel.py:127-135).

### Phased plan

**MVP (M-A1): source map + live previews**
- New collector `memory_snapshot(root)` in `ui_panel.py`: for each source above
  return `{scope, purpose, path(rel), exists, mtime, size, preview}` where
  preview = first/last ~10 lines (handles only — the records.py `_compact`
  philosophy, records.py:368-372). Wrap each source in the per-source degrade
  idiom; cache per file with `_cached`.
- Route `GET /api/memory` in harness_ui.py `do_GET` (next to `/api/records`,
  :163). Poll on the panel's existing ~3s tick (that IS the "tempo real" —
  no daemon; the mtime cache makes an unchanged tick one stat, ui_panel.py:60-66).
- PAGE: nav pill + `viewMemory` section — a card grid grouped scope→purpose;
  card click opens a full-content dialog.
- Full content on demand: `GET /api/memory/file?id=<source-id>` returning the
  whole text of ONE registered source (closed id set — no free paths, same
  discipline as `_safe_log`, ui_panel.py:321-330). Rendered with
  `HL.highlightBlock` (markdown/json grammars are vendored).
- Redaction at the trust boundary: pipe every preview/full body through
  `scripts/harness_lib/secret_scan.py` (same seam harness.py:1589-1590 uses)
  before it leaves the server. Non-negotiable: MEMORY.md has already carried a
  leaked `GEMINI_API_KEY` once (memory note, PrintIntel incident).
- CLI parity: `python scripts/harness.py records sources` (new action on the
  existing `records` subparser, harness.py:3056) printing the same scope×purpose
  table. Read-only → no ACTIONS entry needed.

**Increment M-A2: user-scope auto-memory**
- Resolver for the Claude Code project-memory dir (home + project-path slug;
  degrade to "not present on this machine" — it is user/machine scope, so
  absence is normal on CI). Read-only, redacted, clearly badged "user scope,
  not repo state".

**Increment M-A3: target-scope cards**
- One card group per registered target (`load_targets`, targets.py:43) showing
  `state_dir(name)` files + last gate. Reuses `inspect()` fields (targets.py:155)
  where cheap.

**Increment M-A4 (optional, only if asked): change pulses**
- Highlight cards whose mtime changed since the previous tick (pure client-side
  compare). Skipped from MVP: YAGNI until someone watches the screen live.

### Validation
- Scenario `testing/scenarios/mem_snapshot_panel.py`: seed temp state files →
  assert `/api/memory` groups them by scope/purpose, degrades on a corrupt
  JSON, and NEVER returns a string matching the secret_scan patterns
  (fixture precedent: `gate_fixtures_trace.check_trace_secret_redaction_fixture`,
  gate_fixtures_trace.py:142).
- Playwright `testing/ui/test_panel_e2e.py` + `testing/scenarios/ui_e2e.py`
  (auto-skip layer): open panel → click Memory pill → cards render → open one
  full-content dialog. (Standing rule: extend ui_e2e after every GUI change.)
- SDD: `specs/40-features/panel-memory-snapshot.md` via intake-refinement, with
  `Scenario:[mem-snapshot-*]` ids mapped to the named checks above.

### Risks / open decisions
- **Secrets in memory dumps (top risk):** redact server-side via secret_scan on
  every byte leaving `/api/memory*`; never rely on the client. Decide: redact
  (first-4+length, the harness.py:1589 convention) vs suppress the line.
- **User-memory path resolution** is Claude-specific and machine-specific;
  needs a documented resolver + calm degrade, and must stay read-only.
- **OneDrive transient locks** on `.harness/state/*` reads (known gotcha) —
  collectors already degrade, keep it that way.
- No LLM anywhere on this screen — pure deterministic reads.

---

## Screen B — Records & changelogs

Goal (quote): "tela de registros e changelogs: painel com changelogs
organizados por commit, filtros por branch, hash, etc, visualizador do que foi
feito (CÓDIGO), e um resumo geral da rodada feito SOB DEMANDA (usar LLM barata
aqui)."

Value: the ledger already ingests commits (`collect_records` runs
`git log -n 300 --format=%H%x1f%aI%x1f%s%x1f%b%x1e`, records.py:289-302, rows
kind=`commit`; worklog rows kind=`change`) but the panel only exposes flat
search (`/api/records`, harness_ui.py:163-172). There is no timeline, no
filters, and no way to SEE the code of a commit.

### Phased plan

**MVP (M-B1): commit timeline + filters**
- New collector `commits_snapshot(root, branch, author, grep, path, limit)` in
  ui_panel.py: thin `git log` wrapper (subprocess pattern of
  `records.head_commit`, records.py:167-180; `git -C` degrade pattern of
  `targets.git_status`, targets.py:141-152). Returns handles: sha, date,
  subject, author, branch-decoration, stat counts. Branch list via
  `git branch --format=%(refname:short)`.
- Route `GET /api/commits?branch=&q=&hash=&limit=`; args validated against a
  regex (the `_WORKER_ID_RE` discipline, ui_panel.py:318) — never interpolate
  raw user input into argv positions that could be flags (`--` separator).
- PAGE: nav pill + `viewRecords` section — filter bar (branch select, hash/text
  input) + commit table. Merges the existing worklog `change`/ledger rows into
  the same timeline by date (data already in `/api/records` kind filter).
- CLI parity: exists already — `git log` itself + `records recent --kind commit`
  (harness.py:3056). Document the equivalence in the spec; no new subcommand
  for the read path.

**Increment M-B2: per-commit code/diff viewer (REUSE the highlighter)**
- Route `GET /api/commit?sha=`: `git show --stat --patch <sha>` (sha regex
  `[0-9a-f]{7,40}` validated first), body size-capped (~200 KB, mirroring
  `_MAX_HIGHLIGHT_BYTES`, highlight.py:48), secret_scan-redacted.
- Render: the diff body goes through `colorizeDiff` (harness_ui_page.py:993)
  exactly as the worker drill-in does for diff-shaped stdout
  (harness_ui_page.py:706); a per-file "view at this commit" (`git show
  <sha>:<path>`) uses `HL.highlightBlock` + `_detect_panel_language`
  (ui_panel.py:336-361). Zero new highlight code.
- Cross-link: a ledger row whose `refs` carries a sha opens the same dialog.

**Increment M-B3: on-demand round summary (cheap LLM, cached)**
- CLI first: `python scripts/harness.py records summarize <from-sha>..<to-sha>`
  (new action on the `records` subparser). Behavior:
  1. Build a BOUNDED prompt: subjects + `--stat` + ledger rows in the range —
     never full diffs (token economy; also shrinks the secret surface).
     secret_scan the prompt before spawn (the workflow_lifecycle precedent,
     workflow_lifecycle.py:20).
  2. Spawn headless cheap model — sonnet or haiku card
     (`.harness/routing/model-cards.json:37,48`), low effort, via the existing
     headless-claude seam (`chat_engines.py:126-156`; pass `--permission-mode`
     explicitly — this machine defaults headless sessions to plan mode).
     NEVER Fable/Opus (standing policy).
  3. Cache result at `.harness/state-store/summaries/<from>-<to>.json`
     (derived layer, gitignored — GUI writes no canonical state); cache hit =
     no spawn. Record spend via the existing `delegation` ledger entry
     (harness.py:3054) so the cost screen sees it.
- GUI: "Resumo da rodada" button on the timeline selection → ACTIONS entry
  `records-summarize` (mutating: it spends money → browser confirm, the
  run_action trust boundary, ui_panel.py:739). Cached summaries render
  instantly without confirm (read via `/api/commits` detail or a
  `/api/round-summary?range=` read route that ONLY reads cache).

**Increment M-B4: target-repo timeline**
- `?target=<name>` on `/api/commits`, resolved via `targets.resolve`
  (targets.py:65) and `git -C <target_root>`; summaries cache under
  `.harness/state-store/summaries/targets/<name>/`. Keeps the harness/target
  funnel separation of SPEC-110.

### Validation
- Scenario `testing/scenarios/rec_changelog_panel.py`: temp git repo with 3
  commits → `/api/commits` filters by branch/hash; `/api/commit` rejects a bad
  sha, caps size, redacts a seeded secret; `records summarize` with a stubbed
  engine writes the cache and a second call is a cache hit (no spawn).
  LLM-backed check, if any, runs on haiku low (standing rule) — but the
  deterministic stub path is the gate; the live call is not gated.
- Playwright ui_e2e: timeline renders, diff dialog shows colorized `+/-` lines,
  summary button shows the confirm dialog.
- SDD: `specs/40-features/panel-records-changelogs.md` via intake-refinement;
  Gherkin `Scenario:[rec-changelog-*]` mapped to the named checks.

### Risks / open decisions
- **Cheap-LLM cost:** bounded prompt (subjects+stat only), cache-first, explicit
  confirm, ledger-recorded. Open: cache invalidation when the range's tip moves
  (key by exact sha pair → naturally immutable; decided: key on shas, not
  branch names).
- **Secrets:** diffs and commit bodies can contain keys — secret_scan BOTH the
  panel-bound payloads and the LLM-bound prompt.
- **Argv injection via filters:** regex-validate + `--` before any pathspec.
- **PAGE bulk:** harness_ui_page.py is 1829 lines; two new sections may cross
  the MF line-budget — plan a second MF split (page per view) as a follow-up,
  not a blocker.
- **Plan-mode default machine:** any headless spawn must pass
  `--permission-mode` explicitly or the summary call hangs in plan mode.

---

## Proposed central-backlog rows (`docs/IMPLEMENTATION_BACKLOG.md` M5 table format)

| ID | Item | Source | Layer | Size |
|---|---|---|---|---|
| M5.mem | `panel-memory-snapshot`: scope×purpose memory map (`/api/memory` + Memory view), secret_scan-redacted previews + on-demand full view; CLI `records sources`. Deps: none. Doc: `docs/roadmap/screens-memory-records.md` §A | user request 2026-07-12 | cli+gui | M |
| M5.rec | `panel-records-changelogs`: commit timeline + branch/hash filters (`/api/commits`) + diff/code viewer reusing colorizeDiff/HL. Deps: none. Doc: §B M-B1/B2 | user request 2026-07-12 | cli+gui | M |
| M5.sum | `records-round-summary`: `records summarize <range>` on sonnet/haiku low, sha-keyed cache in `.harness/state-store/summaries/`, ACTIONS confirm + delegation ledger entry. Deps: M5.rec. Doc: §B M-B3 | user request 2026-07-12 | cli+gui+routing | S |
| M5.tgt | target-scope extensions for both screens (`?target=`, target memory cards). Deps: M5.mem, M5.rec | user request 2026-07-12 | cli+gui | S |
