# PyO3 Optimization Roadmap — measure first, flag deterministically, rewrite last

Status: planning only (no behavior changed). Owner: SDD NEW door (SPEC-116) when Phase 1 starts.

## Goal and value

Request (verbatim): *"Plano de ação para otimizar partes do harness com PyO3. Otimização dos
módulos e do processamento mais pesado da aplicação. A parte determinística e os testes podem
ficar pesados com o tempo e isso pode ajudar. Seria bom ter MÉTRICAS dos processos para fazer
TRACKING daquilo que pode ser otimizado com o tempo — seja algum módulo, teste, fluxo, ou
reescrita em PyO3. De preferência fazer isso DETERMINISTICAMENTE e só escalar usando o
ferramental de AUTO-MELHORIA que já temos."*

Translation into harness invariants: the deliverable is **not** "rewrite modules in Rust". It is
a deterministic perf-metrics rung (mirror of the M1 `stdoutBytes` rung), a pure watch rule that
flags recurring hot spots through the existing SPEC-109 funnel, and a PyO3 ramp that only fires
when the data says a candidate clears strict criteria. Observation must pay for itself
(net-cost-positive memory directive); the core stays stdlib-only and portable; any native module
follows the highlighter's optional-dep + pure-fallback pattern.

## Ground truth: what is timed today (verified)

| What | Where | Timed? |
|---|---|---|
| Individual gate checks | `scripts/spec_test_gate.py:85` (`result()` → `{name,status,detail}`) | **No** — no duration field exists |
| Isolated workflow fixtures | `scripts/spec_test_gate.py:1456,1474-1478` | Yes, but only as prose inside the `detail` string (`elapsed=…s`) — not machine-readable |
| Scenario treasury tier (~27 scenarios, one fresh interpreter each, `timeout=900`) | `scripts/spec_test_gate.py:1665-1674` | **No** — only the last stdout line is kept |
| Gate run log | `scripts/spec_test_gate.py:1704-1714` → `.harness/runs/validation-results.jsonl` | Counts only, no wall time per run or per check |
| Workflows | `scripts/harness_lib/cost_metrics.py:108-158` (`record_workflow`: `durationS` from roundHistory, `cpuS`, `maxStdoutBytes`) | Yes — the precedent to mirror |
| Chat turns / delegations | `cost_metrics.py:73-105` | Yes (engine-reported / caller-supplied) |
| The observer itself | `cost_metrics.py:331` (`summarizeMs`), `self_review.py:550` (`durationS`), threshold `selfReviewMaxDurationS: 30` at `self_review.py:68` | Yes — R27 "observation measures itself" precedent |

Conclusion: the gate/test path — exactly the surface the request worries about growing heavy —
is the one surface with **zero structured timing**. Phase 1 closes that gap and nothing else.

## Seams studied (hot-path inventory)

| Seam | File:line | Nature | PyO3 fit (a priori) |
|---|---|---|---|
| Gate check pipeline + fixtures | `scripts/spec_test_gate.py:1631-1694` | subprocess spawn + file I/O dominated | **Poor** — interpreter startup and I/O, not Python bytecode; PyO3 cannot help |
| Scenario treasury (~27 × fresh `sys.executable`) | `scripts/spec_test_gate.py:1665-1674` | subprocess spawn dominated | **Poor** — the deterministic fix is timing + skip/parallelize, never a rewrite |
| Graphify AST build | `scripts/harness_lib/graphify_code_ast.py:96` (`build_graphify_code_ast`); `ast.parse` per file at `:116`, `ast.walk` symbol pass at `:143-145` | pure deterministic CPU (parse + walk), stable I/O contract (files in → `graph.json`/`symbols.json` out) | **Best structural fit** — but backlog already records it at ~1s/108 files (`docs/IMPLEMENTATION_BACKLOG.md`, deferred row "Stop `cleanup_test_artifacts` deleting `graphify-out/`… every gate run rebuilds, ~1s"); the cheaper rungs are stop-deleting + mtime-incremental rebuild. Scales with adopting-project size (`max_files=1000`), so it may cross a threshold on large targets |
| Records ledger index | `scripts/harness_lib/records.py:321-327` (FTS5 insert), `:73-92` (`_superseded_indices`, documented O(n²) over ≤300 hot entries, `HOT_MAX` at `:48`) | SQLite's C core already does the heavy lifting | **Poor today** — bounded window; watch for archive growth only |
| Token economics / audit | `scripts/harness_lib/token_economics.py:54-59` (chars-divisor arithmetic), `scripts/harness_lib/workflow_token_audit.py:20` (`audit_workflow`) | trivial arithmetic over small dicts | **Non-candidate** |
| Syntax highlighting | `scripts/harness_lib/highlight.py:55-64` | already native (tree-sitter, PyO3-backed language pack) | **Done** — this is the packaging precedent, not a candidate |

Honest reading: nothing measured or documented today justifies a PyO3 rewrite. The heavy-growth
surfaces (gate, scenarios) are spawn/I-O bound where Rust buys nothing. That is precisely why the
roadmap is measurement-first: Phase 3 stays parked until Phase 2 produces a data-backed trigger —
the same "masking-before-measurement inverts the cost equation" logic as the M1 stdout rung
(`self_review_rules.py:94-104`).

## Phase 1 — PERF-METRICS rung (deterministic, low-overhead)

Mirror of `record_workflow` + the M1 rung. All timing via `time.monotonic()` wraps — stdlib,
deterministic to collect, negligible overhead (the observed quantity is wall time; the ledger
record itself is the deterministic artifact rules evaluate).

1. **Structured per-check durations in the gate.** Extend `result()`
   (`scripts/spec_test_gate.py:85`) with an optional `durationMs` field, and wrap the coarse
   sections of `main()` (`:1631-1694`), each isolated fixture (reuse the existing
   `started`/`elapsed` at `:1456,1474` — promote it from the detail string to the field), and
   each scenario in the treasury loop (`:1665-1674`). Rows in
   `.harness/runs/validation-results.jsonl` (`:1704-1714`) gain timing for free.
2. **One new ledger kind.** `cost_metrics.record_gate(root, *, gate, status, total_s, checks)`
   next to `record_workflow` (`cost_metrics.py:108`): stores `{kind:"gate", gate, status,
   durationS, checks, slowest:[{name, durationS}]×5}` — top-5 only, so the record stays small.
   Called once at the end of `spec_test_gate.main()`, never-crash like every other writer
   (`_append`, `cost_metrics.py:56-70`).
3. **Module self-timing where the seam already exists.** `build_graphify_code_ast` adds
   `durationS` to `graph["stats"]` (`graphify_code_ast.py:169`) and its return dict; the records
   index rebuild adds the same to its stats — mirroring `summarizeMs`
   (`cost_metrics.py:331`). No new files, no polling, no daemon.
4. **`summarize()` exposure.** A `gates` section in `summarize()` (`cost_metrics.py:228`):
   `durationS` stats (`_stats` at `:179`), `bySlowest` grouping, and a chronological `series`
   per recurring slow check — the exact shape the delegation trend rule already consumes
   (`series` precedent at `cost_metrics.py:302`).
5. **Pays for itself, provably.** The `observability` section (`cost_metrics.py:325-332`)
   already self-measures; `record_gate` adds one JSON append per gate run (~1 write against a
   ledger capped at `MAX_RECORDS=500`, `cost_metrics.py:35`). Budget: perf capture must stay
   under ~1% of gate wall; `summarizeMs` is the existing sentinel.

Allocation tracking (`tracemalloc`): **skipped** — wall time is the pain named in the request;
add allocation sampling only if a flagged hotspot turns out memory-bound.

## Phase 2 — CANDIDATE-IDENTIFICATION loop (pure rule, watch-only)

Mirror of `stdout-oversize-recurring` end to end:

1. **Collect.** `collect_metrics` (`self_review.py:124`) reads the last ~100 ledger records the
   same way the M1 rung does (`self_review.py:234-240`) and derives
   `gatePerf: {runs, medianS, slowestRecurring: [{name, medianS, count}]}` — checks/scenarios/
   modules appearing in the top-5 `slowest` of ≥K recent gate records.
2. **Rule.** One pure rule in `evaluate()` (`self_review_rules.py:76`):
   `perf-hotspot-recurring`, severity **info** (watch), firing when a named seam recurs ≥
   `perfHotspotMinCount` (default 5) times with median ≥ `perfHotspotMinS` (default 5s).
   Thresholds live in `DEFAULT_CONFIG["thresholds"]` (`self_review.py:46-77`) so tuning is a
   config change, not code — same knob pattern as `stdoutOversizeMinCount`.
   Proposed action text: "cheapest rung first: cache / skip-unchanged / algorithmic; PyO3 only
   via the Phase 3 checklist" — the rule surfaces, it never rewrites.
3. **Escalation via existing plumbing.** Watch findings reach the backlog inbox through
   `update_inbox` (`self_review.py:419`); a trend variant (median growing ≥
   `perfHotspotTrendFactor`, mirroring `delegationCostTrendFactor` at `self_review.py:60-61`)
   graduates to `high` and enters the supervision funnel as `self-review/perf-hotspot-recurring`
   (`run_self_review` routing at `self_review.py:524-538`). Humans triage; nothing auto-executes.

## Phase 3 — PyO3 ramp (parked until Phase 2 fires)

**Admission checklist — every box, no exceptions:**
- [ ] Flagged by `perf-hotspot-recurring` over ≥20 real gate records (not synthetic).
- [ ] Pure deterministic CPU-bound Python (profiling shows bytecode, not subprocess/I-O, dominates).
- [ ] Stable interface + golden outputs available for byte-identical A/B replay.
- [ ] Cheaper rungs exhausted and documented (cache, incremental, algorithmic, skip-unchanged).
- [ ] Net-positive after counting build + maintenance + supply-chain cost
      (`specs/00-universal/dependency-and-supply-chain.md` invariants apply).

**Packaging (mirror the highlighter exactly):**
- Separate maturin/PyO3 crate outside the core, e.g. `tools/native/harness-accel/` publishing a
  `harness_accel` wheel; **never** imported unconditionally by `scripts/harness_lib/`.
- Import guard identical to `highlight._engine()` (`highlight.py:55-64`): `try: import
  harness_accel` → module handle, else `None` → the pure-Python implementation, which remains
  the **canonical** one (the Rust path must match it byte-for-byte, verified by a golden fixture).
- Deps declared in a pinned `requirements-accel.txt` mirroring `requirements-highlight.txt`
  (prebuilt wheels, no compiler for adopters); provisioning via a `scripts/setup_accel.py`
  sibling of `scripts/setup_highlight.py`, wired into `setup.sh` as opt-in.
- CI never needs a Rust toolchain: gates run the pure fallback; an optional, separate job builds
  and A/B-tests the wheel.

**Ramp per candidate:** measure (Phase 1 data) → flag (Phase 2 rule) → prototype ONE function →
A/B: golden byte-identity + timing recorded into the ledger as a normal gate record → adopt only
if the measured win exceeds the maintenance cost; otherwise document and park.

## Candidate shortlist (justification per seam)

1. **`graphify_code_ast.build_graphify_code_ast`** (`graphify_code_ast.py:96,116,143-145`) —
   the only plausible eventual candidate. Pure CPU (parse + walk), stable file-in/JSON-out
   contract, rebuilt every gate run (~1s at 108 files per the backlog deferred row), and the one
   seam whose cost scales with adopting-project size (`max_files=1000`). Cheaper rungs queued
   first: stop deleting `graphify-out/` in gate cleanup (already a deferred backlog row with a
   ~2s trigger) and mtime-keyed incremental re-parse. PyO3 (e.g. tree-sitter or `syn`-style
   parsing in Rust) only if a large target repo pushes the measured build past the rule threshold
   after those land.
2. **`records._superseded_indices` + index rebuild** (`records.py:73-92,321-327`) — documented
   O(n²) but bounded to ≤300 hot entries (`HOT_MAX`, `records.py:48`); SQLite already does FTS in
   C. Watch-only: becomes interesting solely if archive-scale indexing enters the hot path.
3. **Scenario treasury tier** (`spec_test_gate.py:1665-1674`) — the real growth curve the request
   fears (~27 interpreters today, +1 per feature), but spawn-dominated: **explicit PyO3
   non-candidate**. Its Phase 2 finding routes to deterministic fixes (per-scenario timing,
   parallel execution, skip-unchanged) — listing it here prevents a future misdirected rewrite.
4. **`workflow_token_audit.audit_workflow` / `token_economics`** (`workflow_token_audit.py:20`,
   `token_economics.py:54-59`) — arithmetic over small dicts; non-candidate; included so the
   shortlist is falsifiable by the same metrics that admit candidate 1.

## Validation plan

- **Perf-metrics scenario** (`testing/scenarios/` — treasury pattern, `spec_test_gate.py:1665`):
  seed a temp root, run `record_gate` + `summarize`, assert the `gates` section, `slowest` top-5
  bound, series ordering, and never-crash on a corrupt ledger — mirroring
  `cost_metrics._self_check` (`cost_metrics.py:336-397`).
- **Rule test**: extend `testing/scenarios/se_self_review.py` with synthetic `gatePerf` metrics
  asserting `perf-hotspot-recurring` fires watch-only and stays silent below threshold — exact
  mirror of the M1 assertions at `se_self_review.py:53-62`.
- **SDD**: new behavior → NEW door (SPEC-116); one feature spec under `specs/40-features/`
  (perf-metrics rung + rule), conformance gate green. Phase 3, if ever unparked, gets its own
  spec (native accel + fallback contract + golden byte-identity fixture).
- **Phase 3 golden fixture**: same inputs through pure and native paths must be byte-identical;
  runs only when `harness_accel` is importable (auto-skip otherwise, like the `ui_e2e` pattern).

## Risks and open decisions

- **Observation overhead**: bounded by design (monotonic wraps + one ledger append/run) and
  self-measured (`summarizeMs` sentinel). Abort criterion: perf capture >1% of gate wall.
- **Ledger crowding**: `MAX_RECORDS=500` is shared across kinds (`cost_metrics.py:35`); gate
  records at several runs/day could evict chat/workflow history. Open decision: per-kind trim vs
  a modest cap raise — decide in the Phase 1 spec.
- **Wall-time nondeterminism**: durations vary run-to-run; the *pipeline* stays deterministic
  (fixed thresholds over medians/counts, like every existing cost rule). Tests use synthetic
  metrics, never live timings.
- **Rust toolchain in CI**: avoided — pure fallback is canonical; wheels are prebuilt and
  optional (highlighter precedent). Adopters without Rust lose nothing.
- **Portability**: hard invariant — core stays stdlib-only; any `import harness_accel` outside a
  guarded probe is a gate-detectable regression (candidate check for `check_static_integrity`).
- **Premature rewrite pressure**: the phased gate is the control; Phase 3 admission requires the
  Phase 2 finding plus exhausted cheaper rungs, in writing.
- **Windows/OneDrive**: ledger writes already retry transient locks (`cost_metrics.py:56-70`);
  no new write paths are introduced.

## Proposed central-backlog rows (`docs/IMPLEMENTATION_BACKLOG.md`)

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| `perf-metrics-rung` | Gate/module wall-time ledger: `durationMs` on gate results + `record_gate` kind + `summarize().gates` | S | P1 | — | docs/roadmap/pyo3-optimization.md |
| `perf-hotspot-watch-rule` | `gatePerf` in `collect_metrics` + pure `perf-hotspot-recurring` watch rule (thresholded, inbox-routed) | S | P2 | perf-metrics-rung | docs/roadmap/pyo3-optimization.md |
| `pyo3-accel-prototype` | Optional `harness_accel` PyO3 crate for the first data-confirmed hotspot (likely graphify AST); golden A/B; pure fallback canonical | M | P3 — **parked until `perf-hotspot-recurring` fires on real data** | perf-hotspot-watch-rule | docs/roadmap/pyo3-optimization.md |
