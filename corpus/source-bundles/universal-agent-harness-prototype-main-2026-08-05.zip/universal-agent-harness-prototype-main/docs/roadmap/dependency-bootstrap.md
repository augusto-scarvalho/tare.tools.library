# Dependency bootstrap: start/stop long-lived services the harness (or a target) needs

## Goal

> "Se o projeto que estivermos operando tiver alguma dependência que precise de
> start — tipo servidor MCP, servidor de visualização ou algo do tipo —
> precisamos que o harness faça esse BOOTSTRAP pra gente. Caso o harness também
> tenha, também precisamos fazer isso. Um caso de exemplo é o MCP server do
> ponytail que precisa ficar ativo pra funcionar."

The harness must be able to *declare* a service ("this target needs its MCP
server running", "the harness chat needs the ponytail MCP alive"), *start* it
idempotently when something needs it, *health-check* it, and *stop it with no
orphan process*. Today nothing does this.

## Current-state audit (verified 2026-07-12)

**No MCP server is ever started by the harness.** What exists is configuration
plumbing that dead-ends:

- `.harness/capabilities.json:79` — `"mcpServers": {}` (empty). `agent_parity.py:434-437`
  even carries a self-aware TODO: *"capabilities.json declares mcpServers; wire
  them into ..."* — the render path for non-empty maps was never built.
- `scripts/harness_lib/targets.py:33` — `DEFAULT_PROFILE` has `"mcp": {"servers": {}}`;
  `sync_adapter` (`targets.py:203-223`) writes
  `graphify-out/targets/<name>/adapter/mcp-config.json` from `target.json`. But a
  repo-wide grep for `mcp-config` shows **no consumer**: no spawn path ever passes
  `--mcp-config <file>` to a CLI. The generated adapter file is write-only today.
- `.harness/routing/executors.json:54` — the claude worker template carries
  `--strict-mcp-config --setting-sources project,local` with **no `--mcp-config`
  file**, so workers run with zero MCP servers by design (session diet,
  `.harness/context/DECISIONS.md:36-40`). The registered target (`.harness/targets/PrintIntel/target.json`)
  declares no `mcp.servers` either.
- Chat: `scripts/harness_lib/chat_engines.py:142-166` (`ClaudeEngine._argv`) builds
  one `claude -p --resume` per turn (`Popen` at `chat_engines.py:184-189`) with no
  MCP flags. Any MCP server a session did use would be a **stdio child spawned by
  the vendor CLI itself, per session, and dying with it** — never a persistent,
  shared server. A ponytail-style MCP that "precisa ficar ativo" has no home.

**What the harness does start (precedents to reuse, not reinvent):**

| Precedent | Seam | Lifecycle |
|---|---|---|
| Panel server | `scripts/harness_ui.py:291-312` (`serve_forever`; `atexit.register(server.sessions.stop_all)` at :295) | foreground, dies with process — the documented "no resident daemon" invariant (`docs/PANEL_CHAT.md:25`) |
| Detached async supervisor | `scripts/harness_lib/async_runtime.py:756-777` — `DETACHED_PROCESS` on nt (:761), stdout/stderr to log files, **pidfile** via `workflow_async_supervisor_pid_path` (`async_state.py:61`), pid recorded in the lock json (:777) | detached but bounded: settles with the workflow; recover paths check `pid_alive` |
| Worker spawn | `async_runtime.py:380-397` (process-group isolation) + `worker_target_env` (`scripts/harness.py:1811-1822`, injects `HARNESS_TARGET_*` + deny-by-default env) | per-task, reaped |
| Chat bridges | `scripts/harness_lib/ui_panel.py:966-1044` (`ChatSessions.stop_all`) | session registry with explicit stop-all |
| Kill/health primitives | `scripts/harness_lib/processes.py:60-88` (`signal_process_tree`, `taskkill /T /F` on nt), :91-135 (`pid_alive`, zombie/handle-aware), :171-175 (`process_group_kwargs`) | ready to reuse as-is |
| Provisioning precedent | `scripts/setup_highlight.py:1-12` — idempotent, verify-then-fetch, degrade-if-missing | model for "declare → ensure" semantics |

**The gap.** There is no *lifecycle manager for a dependency that must be
RUNNING*: no declarative registry of services, no idempotent `start`, no ready
probe, no owner-scoped stop, and the one MCP artifact that exists
(`adapter/mcp-config.json`) is never fed to any executor.

## Design

### Service registry (declarative, two scopes, one schema)

- **Harness-scope**: new tracked file `.harness/services.json`.
- **Target-scope**: new optional `"services"` key in
  `.harness/targets/<name>/target.json` (merged via the existing
  `DEFAULT_PROFILE` mechanism, `targets.py:27-38` / `load_targets` :43-62).

Entry schema (identical in both scopes):

```json
{
  "ponytail-mcp": {
    "command": ["<exe>", "..."],
    "cwd": null,
    "env": {},
    "ready": {"type": "tcp", "port": 8931, "timeoutSeconds": 15},
    "stopGraceSeconds": 5,
    "autoStart": ["workflow", "chat", "ui"],
    "mcp": {"transport": "http", "url": "http://127.0.0.1:8931/mcp"}
  }
}
```

- `ready.type`: `tcp` (stdlib `socket.create_connection`) or `http` (stdlib
  `urllib.request`, expect < 500). No `log-line` probe in MVP.
- `autoStart`: which harness entry points ensure it (empty = manual only).
- `mcp` (optional): when present, the service is an MCP server and its
  url/transport is what `sync_adapter` should emit into `mcp-config.json`
  (a persistent socket/HTTP MCP is *shareable*; a stdio MCP is not — the vendor
  CLI owns stdio children, see Risks).

### Lifecycle manager: `scripts/harness_lib/services.py` (~200 ln, stdlib-only)

State file per service (the supervisor-pidfile pattern, `async_runtime.py:771,777`):
`.harness/state/services/<name>.json` (harness scope) and
`.harness/state/targets/<t>/services/<name>.json` (reuses `state_dir`,
`targets.py:124-125`) — `{pid, startedAt, command, ownerPid, scope, logPath}`.

- `ensure(name)` — **idempotent start**: if state file exists and
  `pid_alive(pid)` (`processes.py:91`) → return `{"status": "already-running"}`;
  stale pidfile → treat as dead, restart. Spawn with
  `process_group_kwargs()` + on nt additionally `CREATE_NO_WINDOW` (0x08000000)
  — the repo currently never sets it (grep: only `CREATE_NEW_PROCESS_GROUP` /
  `DETACHED_PROCESS`), which is exactly the sibling black-console-window
  concern; services must never flash a console. stdout/stderr to
  `.harness/state/services/logs/<name>.log` via the pre-opened-handle pattern
  (`async_runtime.py:764-770`). Then block on the ready probe up to
  `timeoutSeconds`; on probe failure: stop the tree and fail legibly
  (cause/fix, house error style `targets.py:68-73`).
- `stop(name)` — `signal_process_tree(pid, SIGTERM)` (`processes.py:60`), wait
  `stopGraceSeconds`, escalate to kill, verify `pid_alive` is false, delete the
  state file. **No orphans**: taskkill `/T` covers grandchildren on Windows.
- `status()` — list every state file, live-check each pid, and **reap**: dead
  pid → remove state; live pid whose `ownerPid` is dead → stop it (orphan
  recovery at the next harness invocation — no polling, no monitor daemon).
- CLI: `harness.py services [list|start|stop|status] <name> [--target <t>]`
  (router pattern of `cmd_targets`, `harness.py:2351-2364`; `("services","list")`
  and `("services","status")` join `READ_ONLY_PREFIXES`, `chat_engines.py:42-52`).

### Start-on-demand and ownership (reconciling "no resident daemon")

Services are **not** harness daemons. Every start records an *owner* (the
foreground harness process that needed it) and services are stopped when the
owner finishes; leaks are reaped at the next invocation via `status()`. The
invariant "every session dies with the panel process (no resident daemon)"
(`docs/PANEL_CHAT.md:25`) is preserved: the harness itself never stays
resident; a *declared dependency* may outlive one command only while its owner
(workflow supervisor, panel) is alive. Health is checked at use points only —
no polling loop (memory: observation must pay for itself).

Wiring (phase 2):

- **workflow with a target** → in the start path next to `worker_target_env`
  (`harness.py:1811`) / async launch (`async_runtime.py:744-778`): ensure that
  target's `autoStart:["workflow"]` services before spawning workers; stop them
  in settle/collect (same place the supervisor pidfile is cleared).
- **panel/chat** (`harness_ui.serve`, :291) → ensure harness-scope
  `autoStart:["ui"|"chat"]` services after bind; register stop next to the
  existing `atexit.register(server.sessions.stop_all)` (:295).
- **Harness-vs-target separation**: a target's services start only when a
  workflow/chat is *operating that target* (the `workflow.get("target")` check
  already gating `worker_target_env`, `harness.py:1813-1815`); harness-scope
  services are global to harness entry points. Env for target services uses
  `targets_lib.spawn_env` (deny-by-default, `targets.py:198-200`).

### MCP consumption (closing the write-only adapter gap)

- `sync_adapter` (`targets.py:203`) additionally folds `services.*.mcp` entries
  into the generated `mcp-config.json` as url-type servers.
- Worker spawn for a target workflow passes
  `--mcp-config graphify-out/targets/<name>/adapter/mcp-config.json` (the flag
  `--strict-mcp-config` at `executors.json:54` was designed for exactly this and
  currently starves workers of MCP). Template gains an optional `{mcpConfig}`
  slot rendered by `workflow_spawn_command_for_prompt` (`harness.py:1702-1726`).
- **Ponytail example threaded through**: declare `ponytail-mcp` in
  `.harness/services.json` with `autoStart:["chat","ui"]` and an `mcp.url`;
  chat/panel ensure it at startup; `ClaudeEngine._argv` (`chat_engines.py:142`)
  gains `--mcp-config` pointing at a small generated harness-scope
  `mcp-config.json`; the server stays alive across per-turn `claude -p --resume`
  spawns — which per-session stdio MCP can never do.

## Phased plan

**P0 — MVP: declare + start/stop one service, health-check, orphan-free** (size M)
- New: `scripts/harness_lib/services.py`, `.harness/services.json` (seed:
  ponytail-mcp entry, may be a placeholder command), `services` CLI in
  `scripts/harness.py`, optional `services` key honored in `target.json`
  (`targets.py` DEFAULT_PROFILE + `inspect` shows declared services).
- Reuse only: `processes.py` (`pid_alive`, `signal_process_tree`,
  `process_group_kwargs`), log-handle pattern, pidfile pattern.
- Scenario `testing/scenarios/sv_services.py` (naming convention of
  `ht_targets.py` etc.): fake service = `[sys.executable, "-c", "<stdlib
  http.server on ephemeral port>"]` (fixture precedent:
  `gate_fixtures_trace.py:243`); assert start → probe ok → double-start is a
  no-op (same pid) → stop → `pid_alive` false for pid *and* a spawned child
  (orphan check precedent: sleeper tree in `gate_fixtures_workflow.py:351`).

**P1 — auto-start/stop wiring (owners)** (size S, deps P0)
- Workflow-with-target start/settle hooks (`async_runtime.py`,
  `harness.py` collect path); panel/chat startup + atexit (`harness_ui.py:293-311`).
- Owner-pid reaping in `services status`.

**P2 — MCP integration** (size S, deps P0)
- `sync_adapter` emits service-backed url servers; `{mcpConfig}` template slot;
  chat `--mcp-config`; live ponytail validation. Single retry-on-unhealthy at
  use point (no restart loops).

## Cross-platform notes

- Windows: `CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP` for service spawns
  (never a visible console — the sibling black-terminal-windows complaint);
  `taskkill /T /F` semantics already handled in `processes.py:65-74` (no
  graceful term on detached trees — `stopGraceSeconds` is best-effort there).
- POSIX: `start_new_session=True` + `killpg` (already in `processes.py:75-79`).
- OneDrive path: state/log files under `.harness/state/` see sync-lock retries
  (memory: rmtree retries) — writes go through the existing `write_json` seam.
- No `psutil`; stdlib-only holds (`pid_alive` is already ctypes/procfs dual).

## Validation (SDD two-door: NEW behavior)

- Intake via `specs/templates/intake-refinement.md` →
  `specs/40-features/service-bootstrap.md` with Gherkin, each
  `Scenario:[svc-*]` mapped to checks in `sv_services.py`:
  - `Scenario:[svc-idempotent]` double `ensure` returns the same pid.
  - `Scenario:[svc-ready-timeout]` probe that never opens → legible failure,
    tree killed, no state file left.
  - `Scenario:[svc-orphan-free]` stop kills the whole tree (child pid checked).
  - `Scenario:[svc-owner-reap]` state file with dead ownerPid → `status` stops+reaps.
- Deterministic-first: all four run with the fake stdlib service; no LLM.

## Risks / open decisions

1. **stdio MCP cannot be shared.** Vendor CLIs own stdio MCP children; a
   persistent shared server requires socket/HTTP (SSE/streamable-http)
   transport. Decision needed: does the ponytail server expose a socket mode?
   If stdio-only, the honest scope is "configure, don't bootstrap" for it.
2. **Persistent daemon vs on-demand.** Chosen: owner-scoped on-demand +
   reap-on-next-invocation. A service the user wants alive *across* harness
   invocations (true daemon) is explicitly out of scope until a real need
   shows; revisit against `docs/PANEL_CHAT.md:25`.
3. **Hard-kill leaks.** If the owner is `taskkill`ed, services survive until the
   next `services status`/entry-point run. Accepted (no watchdog daemon).
4. **Port conflicts / fixed ports** in declarations; MVP fails legibly on a
   busy port rather than auto-picking (auto-port + env injection is a P2+ idea).
5. **Session diet regression**: adding `--mcp-config` to workers re-inflates
   context; measure against `DECISIONS.md:36-40` before defaulting it on
   (target workflows only, opt-in via declared servers).

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc |
|---|---|---|---|---|---|
| ~~svc-registry-mvp~~ ✅ | ~~Service registry + lifecycle CLI (declare, idempotent start, ready probe, orphan-free stop)~~ — SHIPPED (verificado loop AFK 2026-07-23: services.py + CLI services list/start/stop/status + sv_services.py 5/5). Desbloqueia svc-mcp-wiring + svc-autostart-owners. | M | high | — | docs/roadmap/dependency-bootstrap.md |
| svc-autostart-owners | Owner-scoped auto start/stop: workflow(target) + panel/chat(harness) + reaping | S | medium | svc-registry-mvp | docs/roadmap/dependency-bootstrap.md |
| svc-mcp-wiring | Consume generated mcp-config.json in worker/chat spawns; ponytail persistent MCP end-to-end | S | medium | svc-registry-mvp | docs/roadmap/dependency-bootstrap.md |
