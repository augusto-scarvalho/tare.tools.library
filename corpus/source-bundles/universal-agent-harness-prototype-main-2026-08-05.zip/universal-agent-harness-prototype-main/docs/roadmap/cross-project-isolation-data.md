# Roadmap: cross-project DATA isolation (harness ↔ targets ↔ targets)

Status: proposed (planning only — no behavior changed)
Scope: DATA channels only. The escalation/human/LLM-routing channel is owned by a separate roadmap and is explicitly excluded here.

## Goal + why

> "auditar se ARQUIVOS, DIFFS, [dados] etc não estão vazando de um projeto pra outro que o harness está operando, e também do harness para os projetos, ou até desses projetos para dentro do harness. Cada um deve ter seu MUNDO e VISÃO."

The harness governs multiple target repos (SPEC-110). Adversarial assumption: data WANTS to leak across subject boundaries unless a deterministic mechanism confines it. Today several stores are pooled (tagged at best, untagged at worst) and one env seam hands a target's build commands the whole machine environment.

Every claim below was verified in source at the cited file:line on 2026-07-12.

## Channel × direction audit

Directions: H→T (harness→target), T→H (target→harness), T→T (target→target).

### (a) FILES / paths

| Dir | Current enforcement | Gap |
|---|---|---|
| H→T | Target repos stay clean by design: all generated state lives harness-side (`scripts/harness_lib/targets.py:4-6`, `out_dir`/`state_dir` `targets.py:120-125`); adapters regenerated under `graphify-out/targets/<name>/adapter/` (`targets.py:203-223`); target gate state under `state_dir(name)/quality-state.json` (`scripts/harness_lib/gate_generic.py:238`). | Nothing ASSERTS cleanliness post-run. No check that a harness flow left zero new files inside a target tree. |
| T→H | Target source is read via `source_files` with `EXCLUDE_PARTS` (`targets.py:128-138`); graph output confined to `out_dir(name)` (`scripts/harness.py:2480-2482`). | Worker results carrying target file excerpts land in pooled `.harness/workflows/active/WF-*` and pooled ledgers (see c/e). |
| T→T | Per-target dirs are name-keyed (`targets.py:23-25`). | **Worker cwd is the HARNESS root, not the target**: `cwd = (ROOT / workspace) if workspace else ROOT` (`scripts/harness.py:1848`, `scripts/harness_lib/async_runtime.py:371-372`). A worker "on" target A runs inside the harness tree with only env coordinates (`HARNESS_TARGET_ROOT`, `harness.py:1811-1822`) pointing at A — it can freely read target B's tree, every `.harness/targets/*/target.json` (all registered repo paths), and all pooled state. Read confinement is prompt-level only. |

Also: full-copy temp workspaces copy the harness tree including `.harness/state/*` (pooled worklog, cost ledger, escalations) and `.harness/targets/` — the ignore set (`scripts/harness_lib/controlled_writes.py:47-54`) blocks `runs`, `workflows/active`, `graphify-out`, `.jsonl` files, but NOT `.harness/state` JSON or the target registry. A sandboxed worker still receives every subject's coordinates and ledgers in its copy (`controlled_writes.py:199-201`).

### (b) DIFFS / controlled writes

| Dir | Current enforcement | Gap |
|---|---|---|
| H→T | **Deterministic refusal**: controlled writes on targets raise HT-T5b at plan time — "locks/backups/merge machinery is harness-root-relative" (`scripts/harness.py:1421-1427`). | The refusal is honest but the capability hole remains: there is no confined write path to a target at all. Meanwhile a read-only target worker PROCESS is not OS-confined; "Write allowed: `False`" is a prompt line (`controlled_writes.py:247`), so a misbehaving worker can still write into the target (or any) tree undetected. |
| T→H | Locks + sparse workspaces + approval token confine harness-repo writes (`controlled_writes.py:128-177`, `180-242`); merge is supervisor-gated (`controlled_writes.py:262`). | None found for the sanctioned path; the unsanctioned path (direct writes bypassing the workflow) is caught only for protected files, not per-subject. |
| T→T | n/a (no target writes exist). | All lock/expansion plumbing hardwires `root=ROOT` (`harness.py:1283`, `1305`, `1318`) — any future target-write feature inherits harness-root confinement, i.e. zero confinement on the target side. Design constraint to fix before HT-T5b is lifted. |

### (c) MEMORY / RECORDS / CONTEXT

| Dir | Current enforcement | Gap |
|---|---|---|
| T→H | `records.py` is root-parameterized (`scripts/harness_lib/records.py:121`); per-target quality-state and protected-file snapshots are subject-scoped (`gate_generic.py:238`, `gate_generic.py:155`). | **The worklog is a single pooled store with NO subject dimension**: `add_entry(root, kind, title, ...)` has no target field (`records.py:121-136`) and every caller passes ROOT (`harness.py:2416`, `2427-2428`). Target-work milestones land in the harness worklog uncredited. |
| H→T | Nothing harness-side is written into target repos (see a). Worker packets inject harness docs (`scripts/harness_lib/context_digest.py:37-44`) — intended contract context, acceptable. | — |
| T→T | — | `CONTEXT.md` ledger head renders the pooled worklog into EVERY session's always-in-context head (`records.py:436-455`); `records.search` feeds intake triage across all subjects (`scripts/harness_lib/intake_triage.py:86`). Subject A's records are in subject B's "view". User auto-memory is Claude-scope, out of harness control — no leak mechanism found, but the worklog head reaches every chat regardless of active target. |

### (d) TELEMETRY

| Dir | Current enforcement | Gap |
|---|---|---|
| T→H | Records carry a `target` field for chat turns, delegations, workflows (`scripts/harness_lib/cost_metrics.py:75`, `93`, `150`); `byTarget`/`byStack`/`targetShare` views (`cost_metrics.py:266-322`). Pooled-but-tagged is acceptable for spend. | — |
| T→T | — | **Calibration cross-drift**: `cpt_samples` pools ALL chat turns regardless of target (`cost_metrics.py:237-243`) and the learned override is one GLOBAL file `.harness/state/token-calibration.json` with no target dimension (`scripts/harness_lib/token_calibration.py:22`, `25-47`). One verbose target's reply style recalibrates every subject's workflow budgets. |
| H→T | **Env leak at the gate seam**: `run_target_commands` executes the target's build/test commands with `{**os.environ, **spawn_env}` (`gate_generic.py:177`) — full harness environment (all API keys, other targets' `requiresEnv` values) visible to any target's build scripts. Contrast the workflow path, which is deny-by-default (`build_worker_spawn_env`, `harness.py:1825-1835`; `spawn_env` `targets.py:198-200`). A malicious target `package.json`/`Makefile` exfiltrates the machine env today. | |

### (e) LOGS / TRACES

| Dir | Current enforcement | Gap |
|---|---|---|
| all | Rotation into `runs/archive/` with manifests + secret quarantine (`scripts/harness_lib/log_rotation.py:3-18`); collect-boundary secret redaction (`scripts/harness_lib/secret_scan.py:22-36`). | `events.jsonl` (`harness.py:57`, `127-133`), `harness-trace.jsonl` (`harness.py:134-139`), `validation-results.jsonl` (`scripts/spec_test_gate.py:45-46`) are single pooled files mixing subjects. Target attribution exists only incidentally (check-name prefix `target:<name>` — `gate_generic.py:221`; workflow payloads). `append_event` has no subject parameter, so harness-work and target-work events are indistinguishable unless the payload happens to carry one. Archive segments inherit the mixing. |

### (f) GRAPHS / discovery

| Dir | Current enforcement | Gap |
|---|---|---|
| T→H / T→T | Per-subject graph dirs: `graphify-out/targets/<name>/` (`harness.py:2480-2482`); gate rebuilds per subject (`gate_generic.py:192-214`); `discover`/`doc-find --target` set `subject_root`/`subject_out` (`harness.py:2320-2341`). | Scoping is OPT-IN PER CALL, not bound to worker identity. A worker spawned for target A (env `HARNESS_TARGET_NAME=A`) can run `doc-find` unscoped (harness corpus) or `--target B`; nothing cross-checks the flag against the caller's subject. With cwd=ROOT, all `graphify-out/targets/*` are also directly readable. |

## Isolation invariant (per channel, per direction)

**A subject's WORLD is what it can touch; its VISION is what it can see. Both must be derivable from its name alone.**

1. **Files** — H→T: after any harness flow over target T, T's tree gains no file not written by T's own gate commands. T→H: content derived from T lives only under `graphify-out/targets/T/`, `.harness/state/targets/T/`, or records/events tagged `subject=T`. T→T: no artifact under A's dirs contains B's root path or name (and vice versa).
2. **Diffs** — writes are either (i) harness-repo, lock-confined, or (ii) refused (HT-T5b). Invariant: git status of every REGISTERED target is byte-identical before/after a harness-side flow that did not run that target's own commands.
3. **Records** — every worklog/records row is attributable: `subject ∈ {harness, <target-name>}`. The CONTEXT.md head shows harness-subject rows plus at most a per-subject section; subject A's rows never render into a session working on B.
4. **Telemetry** — spend rows carry `target` (already true); LEARNED values (charsPerToken) are keyed per subject — samples from A never move B's (or the harness's) effective budget inputs.
5. **Logs** — every event/validation row is subject-attributable (field, not name-prefix convention); rotation preserves the attribution.
6. **Graphs/discovery** — a discovery call made under `HARNESS_TARGET_NAME=A` resolves only `subject_out(A)` + A's root; unscoped calls are harness-subject only.
7. **Env** — a process working for subject T sees exactly: OS base allowlist + T's `requiresEnv` + HARNESS_* coordinates. Never another subject's keys. (Workflow path already conforms; gate path does not.)

## Phased plan

### Phase 0 — MVP: `isolation-audit` gate (catches TODAY's leaks)

Dual-subject deterministic fixture, stdlib-only, added to the gate fixture family (pattern: `scripts/harness_lib/gate_fixtures_*.py`; registration in `scripts/spec_test_gate.py` — the target-gate fixture at `spec_test_gate.py:1612` is the template to follow).

Mechanics: create two throwaway git repos A and B (each with one sentinel file carrying a unique token, e.g. `ISOTOKEN_A`), register both via `targets_lib.register` (`targets.py:97-117`), then run cheap real flows (target gate on A via `run_target_gate` `gate_generic.py:217`; `doc-find --target A`; graph build). Assertions:

- **files/diffs**: `git -C <B> status --porcelain` empty and B's tree file-list unchanged after all A-flows (and vice versa); no new untracked files in A beyond its own command outputs.
- **cross-bleed scan**: string-scan `graphify-out/targets/A/**` and `.harness/state/targets/A/**` for `ISOTOKEN_B` / B's absolute root — zero hits (and symmetric).
- **records credit**: a worklog entry added during A-work is attributable to A (xfail/warn until Phase 1 adds the field — the gate documents the leak deterministically from day one).
- **telemetry**: cost record for the A-flow carries `target: "A"`; token-calibration file untouched by A's samples alone (xfail until Phase 2).
- **env**: spawn a `python -c "import os,json;print(json.dumps(sorted(os.environ)))"` as an A gate command with a canary var exported (e.g. `ISOCANARY_B=x`) — assert the canary is NOT visible (xfail until Phase 3 — this is today's confirmed leak at `gate_generic.py:177`).
- Cleanup: unregister/delete profiles + tmp repos (OneDrive rmtree retry pattern already used in fixtures).

SDD: new behavior → `specs/templates/intake-refinement.md` → `specs/40-features/cross-project-isolation-data.md` with `Scenario:[iso-01]`(dual-subject no-bleed) … mapped to the fixture checks; `feature-spec-conformance` gate covers it.

Files: `scripts/harness_lib/gate_fixtures_isolation.py` (new), `scripts/spec_test_gate.py` (register), `specs/40-features/cross-project-isolation-data.md` (new).

### Phase 1 — records subject dimension (channel c)

- Add optional `subject: str = "harness"` to `records.add_entry` (`records.py:121`) and store it on the entry; thread `--target` through the records CLI (`harness.py:2416-2428`) and any workflow-finalize writers.
- `render_head` (`records.py:436`) filters to harness-subject rows (per-subject heads deferred until a real per-target chat session exists — YAGNI).
- `search`/`recent` accept a subject filter; `intake_triage` passes the active target when one is set.
- Flip the Phase-0 records assertion from xfail to hard.

Files: `scripts/harness_lib/records.py`, `scripts/harness.py`, `scripts/harness_lib/intake_triage.py`.

### Phase 2 — per-subject token calibration (channel d, drift)

- Key the override per subject: write to `state_dir(name)/token-calibration.json` for targets, keep the existing path for the harness subject (`token_calibration.py:22` gains a `subject` root resolution — smallest diff: an optional `rel` or a resolver that maps subject→file).
- `summarize` groups `cpt_samples` by record `target` (`cost_metrics.py:237-243`) and reports per-subject observed CPT; the recalibration writer (self-review) writes only the matching subject's file; budget sizing reads the workflow's subject.
- Flip the Phase-0 calibration assertion.

Files: `scripts/harness_lib/token_calibration.py`, `scripts/harness_lib/cost_metrics.py`, the self-review recalibration rule, workflow budget sizing call-site.

### Phase 3 — env + workspace hygiene (channels d-env, a-workspace)

- `run_target_commands`: replace `{**os.environ, **spawn_env}` (`gate_generic.py:177`) with the same least-privilege composition the worker path uses (`build_worker_spawn_env` / `filter_spawn_env`, `harness.py:1825-1835`): OS base + target `requiresEnv` only. Escape hatch mirrors `workerEnvFilter`.
- `workflow_runtime_ignore` (`controlled_writes.py:47-54`): add `.harness/state` and `.harness/targets` (dir-scoped, like the existing `runs` special-case) so full-copy workspaces stop shipping pooled ledgers + the target registry to every worker.
- Flip the Phase-0 env canary assertion.

Files: `scripts/harness_lib/gate_generic.py`, `scripts/harness_lib/controlled_writes.py`.

### Phase 4 — subject-attributed events/logs (channel e)

- `append_event` (`harness.py:127-133`) gains an optional `subject` (default harness; workflow paths pass `workflow.get("target")`); `run_target_gate` results and `validation-results.jsonl` rows carry `subject` as a field, not just the `target:` name prefix.
- No per-subject files yet (pooled-but-attributed is enough for the invariant; splitting files is cost without a consumer — revisit if a per-target panel view needs it).

Files: `scripts/harness.py`, `scripts/harness_lib/gate_generic.py`, `scripts/spec_test_gate.py` (row shape).

### Phase 5 (deferred, open) — target-worker world (channels a/b, T→T reads)

Worker cwd = target root for target workflows + a confined target-write path (HT-T5b successor: locks parameterized by `workflow["targetRoot"]`, which `workflow_token_audit` already threads at `harness.py:1699`). True READ confinement of an agent process needs OS sandboxing the harness deliberately does not own today — keep the deterministic artifact-level audit (Phase 0) as the detection layer and treat process-level read isolation as an explicit accepted risk until an executor-level sandbox exists.

## Validation

- **Gate**: `isolation-audit` checks inside the standard gate run (Phase 0 fixture); dual-subject, deterministic, stdlib, no LLM.
- **Scenario**: `Scenario:[iso-01]` dual-subject no-bleed; `[iso-02]` target tree byte-clean after harness flow; `[iso-03]` env canary invisible to target commands; `[iso-04]` records/telemetry attribution — each mapped to a fixture check per SPEC-116.
- **SDD spec**: `specs/40-features/cross-project-isolation-data.md` via the intake template; `feature-spec-conformance` enforces the mapping.
- Per-module self-checks stay the proof for records/calibration changes (existing `__main__` pattern).

## Risks / open decisions

1. **Env filter on target commands may break real targets** whose builds legitimately need PATH-adjacent vars — the OS base allowlist must be generous (PATH, HOME, TEMP, SystemRoot…); reuse the worker filter's base, don't invent a second list.
2. **Worklog subject default**: retrofitting old entries is not worth it — treat missing `subject` as `harness` (matches reality: target flows barely write records today).
3. **Per-subject calibration cold start**: a new target has no samples; reader falls back to the harness seed (3.1) — same fallback shape `read_override` already has.
4. **Read confinement is not fully deterministic** (Phase 5): the audit gate detects artifact-level bleed, not live reads by a worker process. Named, accepted, revisit with sandboxed executors.
5. **OneDrive**: dual-subject fixture creates/deletes tmp git repos — reuse the existing rmtree-retry pattern or place them under the system temp dir, not the OneDrive tree.

## Proposed central-backlog rows

| slug | title | size | priority | deps | doc |
|---|---|---|---|---|---|
| isolation-audit-gate | Dual-subject isolation-audit gate + SDD spec (detects today's cross-project bleed) | M | high | — | docs/roadmap/cross-project-isolation-data.md |
| target-gate-env-filter | Least-privilege env for target gate commands (closes full-os.environ leak) | S | high | isolation-audit-gate | same |
| records-subject-dimension | Subject field on worklog/records + head/search filtering | S | high | isolation-audit-gate | same |
| per-target-token-calibration | Per-subject charsPerToken override + grouped CPT samples | S | medium | isolation-audit-gate | same |
| workspace-state-exclusion | Exclude .harness/state + .harness/targets from worker workspace copies | S | medium | — | same |
| subject-tagged-events | subject field on events/validation rows | S | low | records-subject-dimension | same |
| target-worker-world | Worker cwd = target root + confined target writes (HT-T5b successor) | L | low (open) | all above | same |
