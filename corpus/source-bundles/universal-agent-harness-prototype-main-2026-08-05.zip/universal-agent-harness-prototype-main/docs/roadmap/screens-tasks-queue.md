# Roadmap — Tasks screen + Current Work Queue screen (planning only)

Cluster: two interdependent panel screens; the tasks board feeds the work queue.
Demand signal note: the backlog itself already holds "Kanban view — trigger: M5 panel
proving insufficient at-a-glance" (`docs/IMPLEMENTATION_BACKLOG.md:83`). This user
request IS that trigger firing.

Governing invariants (verified): GUI writes no canonical state — all mutation via
`ui_panel.run_action` + the closed `ACTIONS` allowlist (`scripts/harness_lib/ui_panel.py:675-802`);
stdlib-only; CLI-first parity (`docs/IMPLEMENTATION_BACKLOG.md:17-18`); SDD two-door
(`specs/templates/intake-refinement.md` → `specs/40-features/<name>.md` + Gherkin →
`feature-spec-conformance` gate, `docs/IMPLEMENTATION_BACKLOG.md:32`).

---

## Screen A — Tasks board (backlog/roadmap Kanban)

### Goal + value

> "tela de tasks: visão de backlog/roadmap + raias tipo Kanban - com status do que está
> rolando, visões por categoria de tasks (bug, ideação/experimento, feature nova, etc.).
> Precisamos separar backlog/roadmap/tasks do HARNESS dos do REPOSITÓRIO trabalhado.
> Daqui podemos enviar tasks abertas/fechadas para a FILA DE TRABALHO do harness."

Value: today the backlog is one markdown file + scattered signals; nothing shows it as
a board, and "send this to an agent" is a manual chat/CLI ritual.

### How a "task" is modeled today (seams)

| Source | Seam | What it gives the board |
|---|---|---|
| Task docs | `tasks/TASKS.md:1-30` (only TEMPLATE + README exist; `tasks/generated/` = `workflow promote` drafts, `tasks/TASKS.md:30`) | task shape: goal/acceptance/profile; profile vocab `scan|cheap|docs|plan|implementation|debug|review|security` (`tasks/TASK_TEMPLATE.md:17`) |
| Single backlog | `docs/IMPLEMENTATION_BACKLOG.md` — M5 table `:26-33`, TE table `:44-48`, Deferred table `:74-94`, self-review inbox between markers `:110-119` | the real roadmap rows: `{ID, Item, Source, Layer, Size}`; strikethrough `~~…~~ ✅` = done |
| Records ledger | `scripts/harness_lib/records.py:37` (`LOG_KINDS = milestone/change/decision/release/note`), `search:381`, `recent:416` | done-lane history + doc links |
| Escalations | `.harness/state/escalations.json` read by `ui_panel._escalations` (`scripts/harness_lib/ui_panel.py:94-108`) | open "needs human" items (bug-ish lane) |
| In-progress | active workflows: `chat_hud.read_workers` (`scripts/harness_lib/chat_hud.py:84-124`), WF `phase` (`scripts/harness.py:1455`, `scripts/harness_lib/async_runtime.py:749`) | "o que está rolando" column, derived — never stored on the board |

There is NO canonical machine-readable task store today. Decision below.

### Category taxonomy (derivation first, field second)

MVP derives category from source + row metadata, no new data:
- **bug**: self-review inbox findings (`docs/IMPLEMENTATION_BACKLOG.md:110-119`), open escalations, records `kind=change` with fix-shaped titles.
- **feature**: M5/TE/SPEC rows (Layer column `cli|gui|process|routing`), `specs/40-features/*` without a done milestone.
- **ideação/experimento**: "Ideation input" section rows (`docs/IMPLEMENTATION_BACKLOG.md:50-72`), Deferred rows (they wait on a demand signal).
- **chore/infra**: burndown findings (line budgets), records `kind=note`.

Increment 2 (canonical store) adds an explicit `category` field; derivation stays the
fallback so old rows never need migration.

### Kanban lanes + status derivation

Lanes: `ideia → backlog → pronta (ready) → na fila → em execução → em revisão → feita`.
- `em execução / em revisão`: DERIVED every poll from active WFs (worker `status` +
  `taskProfile`; review lane = running worker with profile `review`), same no-stored-index
  rule as `attention_strips` (`scripts/harness_lib/ui_panel.py:141-207`).
- `feita`: strikethrough backlog rows + records milestones.
- `backlog/pronta/na fila`: from the canonical store once it exists; MVP shows every
  parsed row in `backlog` and skips manual lane moves.

### Canonical store decision (increment 2)

One JSON file `.harness/state/tasks.json` (list of `{id, title, category, lane, size,
priority, source, docPath, target, wfid?}`), written ONLY by a new `tasks` CLI subcommand
(same single-write-path rule as targets `register`, `scripts/harness_lib/targets.py:97-117`).
An `import` verb parses the three backlog tables + self-review inbox into rows (idempotent,
keyed by ID/slug). The markdown file stays the human document; `tasks.json` is the board
state. NB `.harness/state/` git-tracking caveat: `docs/IMPLEMENTATION_BACKLOG.md:94`.

### HARNESS vs TARGET separation

- Harness board: the sources above, rooted at the harness repo.
- Target board: per governed target (SPEC-110), selected by the same `activeTarget`
  already fed to the panel (`ui_panel.routing_snapshot`, `scripts/harness_lib/ui_panel.py:270`;
  targets list `:228-239`). Sources: harness-held target findings (self-review inbox rows
  already carry `target/PrintIntel/...`, `docs/IMPLEMENTATION_BACKLOG.md:117`) + per-target
  state dir (`targets.state_dir`, `scripts/harness_lib/targets.py:124-125`) + read-only scan
  of the target repo's own `tasks/`/backlog markdown via `targets.target_root`
  (`scripts/harness_lib/targets.py:91-94`) when present.
- GUI: one board, a `harness | <target>` scope toggle; rows carry `target` so mixed views
  stay unambiguous. Tasks store keeps target rows under `.harness/state/targets/<name>/tasks.json`
  (mirrors quality-state placement, `scripts/harness_lib/ui_panel.py:128-135`).

### "Send to work queue" action

Real seam already shipped: `composer-create` → `workflow plan --profile … --branch-json …
--task …` with the compile-must-be-valid pre-check (`scripts/harness_lib/ui_panel.py:732-735,
773-778`; `cmd_workflow_plan`, `scripts/harness.py:2502`). Sending a task =
1. CLI: `tasks enqueue <id> [--profile P]` — builds the `--task` text from the row
   (title + docPath), runs `workflow plan`, writes `wfid` back into the row.
2. GUI: new allowlisted action `tasks-enqueue` (mutating → browser confirm → the
   `classify_command` HITL backstop, `scripts/harness_lib/ui_panel.py:786-791`).
Create-only, like composer-create: enqueue materializes a `planned` WF, it does NOT spawn
agents. STARTING from the browser is a separate decision (see risks).

### Phased plan

| Phase | Content | Files touched |
|---|---|---|
| A0 MVP (read-only board) | collector `tasks_snapshot(root)` in `ui_panel.py` (parse backlog tables + inbox + escalations + derive in-progress from the workers already in `state_snapshot`); route `GET /api/tasks` (`scripts/harness_ui.py:137-177`); nav button + `viewTasks` section in PAGE (`scripts/harness_ui_page.py:318-320`); CLI `tasks list [--category] [--target]` | `scripts/harness_lib/ui_panel.py` (or new `ui_tasks.py` if the 1364-line file nears the 900 budget — it is already over; prefer new module), `scripts/harness_ui.py`, `scripts/harness_ui_page.py`, `scripts/harness.py` |
| A1 Canonical store + lanes | `tasks import/add/set/move/close` CLI over `tasks.json`; manual lane moves in GUI via allowlisted `tasks-move` | `scripts/harness.py`, new `scripts/harness_lib/tasks_store.py`, `ui_panel.ACTIONS` |
| A2 Enqueue | `tasks enqueue` CLI + `tasks-enqueue` action + board→queue link (row shows its `wfid`) | same + `scripts/harness_ui_page.py` |
| A3 Target boards | target scan + per-target store + scope toggle | `scripts/harness_lib/tasks_store.py`, PAGE |

### CLI + GUI parity

Every GUI verb = an existing subcommand: `tasks list/import/add/move/enqueue` land in
`harness.py` FIRST (M2 rule, `docs/IMPLEMENTATION_BACKLOG.md:17-18`); the panel only
calls them through `run_action`.

### Validation

- Door NEW: `specs/templates/intake-refinement.md` → `specs/40-features/panel-tasks-board.md`
  with Gherkin `Scenario:[tb-…]` ids → named checks (conformance gate,
  `docs/IMPLEMENTATION_BACKLOG.md:32`).
- Deterministic scenario `testing/scenarios/tb_tasks_board.py`: import parses the real
  backlog tables; enqueue creates a planned WF and links `wfid`; unknown task id refused.
- GUI: extend the Playwright `ui_e2e` layer (board renders, lane counts, enqueue confirm).

### Risks / open decisions

1. Markdown-table parsing is brittle (row 94 is multi-line prose). Mitigation: parse only
   `|`-leading lines, tolerate failures per-row (never-crash collector idiom,
   `scripts/harness_lib/ui_panel.py:281-298`).
2. Two sources of truth (markdown vs tasks.json). Decision needed: after A1, do new rows
   live only in tasks.json (markdown becomes generated/frozen)? Recommend: markdown stays
   for prose sections; tables freeze after import.
3. Enqueue-from-closed-task ("abertas/fechadas" in the quote): re-opening a done row
   should clone into a new task id, not mutate history.
4. `ui_panel.py` is 1364 lines — new collectors go in a new `harness_lib` module.

### Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| tasks-board-read | A0 read-only tasks Kanban (collector + /api/tasks + view + `tasks list`) | M | high | — | docs/roadmap/screens-tasks-queue.md |
| tasks-store-cli | A1 `tasks.json` store + `tasks import/add/move/close` + lane moves | M | med | tasks-board-read | docs/roadmap/screens-tasks-queue.md |
| tasks-enqueue | A2 `tasks enqueue` CLI + allowlisted GUI action → planned WF link | S | med | tasks-store-cli | docs/roadmap/screens-tasks-queue.md |
| tasks-target-board | A3 per-target board (SPEC-110 scope toggle) | M | low | tasks-store-cli | docs/roadmap/screens-tasks-queue.md |

---

## Screen B — Current work queue (live)

### Goal + value

> "fila de trabalho atual: tasks que o harness está trabalhando, em tempo real, em que
> parte do processo de trabalho está (pesquisa, refinamento, debugging, codificando,
> revisando, etc). Aqui podemos cancelar tasks em andamento ou enfileiradas, ou
> reorganizar prioridade."

Value: today live work is a small "Agents" strip on the Painel (`scripts/harness_ui_page.py:352`,
`renderAgents` `:633-651`) + CLI `workflow watch/tail`; no queue-level view, no browser
reprioritization.

### Seams (all verified)

- Live rows: `/api/state` already ships `workers` with `status/taskProfile/lastOutputAt/
  elapsed` every ~3s poll (`ui_panel.state_snapshot`, `scripts/harness_lib/ui_panel.py:292-293`;
  `chat_hud.read_workers`, `scripts/harness_lib/chat_hud.py:84-124`).
- Queue mechanics: async tasks `AT-NNN` created in WORKER-LIST ORDER at round start
  (`scripts/harness_lib/async_runtime.py:697-699`), supervisor runs them at
  `concurrency` (`:731`, `:758`); worker statuses `pending|queued|running|done|…`
  (`scripts/harness.py:2068`); WF phases `planned → running_workers → awaiting_reduce/
  reducing → finalized` (`scripts/harness.py:1455`, `async_runtime.py:749`,
  `workflow_reduce.py:137,254`, `workflow_lifecycle.py:91`).
- Status JSON: `workflow_async_status` (`scripts/harness_lib/async_runtime.py:892-908`) +
  `workflow list` (`scripts/harness.py:3136`) + `workflow doctor` (`:3151`).
- Cancel: CLI `workflow cancel <wf> [--worker-id]` (`scripts/harness.py:3148`;
  implementation kills PIDs with grace, `async_runtime.py:843-890`). Panel action
  `workflow-cancel` EXISTS but is whole-WF only (`scripts/harness_lib/ui_panel.py:710-711`)
  behind the recovery gate (`:599-624`).
- Drill-in: `GET /api/worker` live tail (`scripts/harness_ui.py:154-162`,
  `ui_panel.worker_detail:364-419`).
- Reprioritize: NO seam exists — no priority field anywhere (only worker-list order).
  New CLI verb required.

### "Which part of the process" derivation

Two real fields, zero new state:
1. Worker `taskProfile` → stage label: `scan→pesquisa`, `plan→refinamento`,
   `implementation→codificando`, `debug→debugging`, `review/security→revisando`,
   `docs→documentando` (vocab: `tasks/TASK_TEMPLATE.md:17`).
2. WF `phase` → group header (`planned / running_workers / reducing / finalized`), with
   `reducing` shown as "consolidando".
Pure front-end mapping over data the snapshot already carries; the only backend addition
is including each WF's `phase`+`workflowId` in the queue payload.

### Cancel + reprioritize (allowlisted, single write path)

- Cancel queued OR running worker: extend the existing `workflow-cancel` builder to pass
  `--worker-id` when given (param validated by `_recovery_reason`'s `_WORKER_ID_RE` gate,
  `scripts/harness_lib/ui_panel.py:612-624`) — CLI already supports it.
- Cancel whole WF / discard planned WF: already shipped (`workflow-cancel`,
  `workflow-discard` + `_discard_reason` not-running guard, `:657-668,723-724`).
- Reprioritize (new): CLI `workflow reorder <wf> <workerId> --position N` — reorders ONLY
  workers still `pending|queued` before their async task exists (order → AT creation order,
  `async_runtime.py:697`); refuse when the round already started (tasks written). Then an
  allowlisted `workflow-reorder` action (mutating + recovery gate). Cross-WF priority =
  Screen A's ready-queue order in `tasks.json` (`priority` field) — the supervisor never
  runs cross-WF today, so no scheduler change is claimed.

### Phased plan

| Phase | Content | Files touched |
|---|---|---|
| B0 MVP (view) | `queue_snapshot(root)`: active WFs (id, phase, task title, counts via `workflow_async_status_counts`, `async_runtime.py:166`) + per-worker stage rows; `GET /api/queue`; new `viewQueue` PAGE section polling it (~3s, same as Painel); stage chips from taskProfile; drill-in reuses `/api/worker`. CLI: `workflow list` already prints this — optionally a `queue` alias | new `scripts/harness_lib/ui_queue.py` (file budget), `scripts/harness_ui.py`, `scripts/harness_ui_page.py`, `scripts/harness.py` (alias only) |
| B1 Cancel granularity | `--worker-id` param on the `workflow-cancel` action + per-row cancel buttons (queued rows too) | `scripts/harness_lib/ui_panel.py` (ACTIONS), PAGE |
| B2 Reorder | `workflow reorder` CLI verb + `workflow-reorder` action + drag/buttons in the queue view | `scripts/harness.py`, `scripts/harness_lib/async_runtime.py` or `workflow_lifecycle.py`, `ui_panel.py`, PAGE |
| B3 Start-from-panel (decision-gated) | allowlisted `workflow-start` (planned WF only, recovery-gated, confirm) closing the A2→B loop: enqueue → start → watch | `ui_panel.py`, PAGE |

### CLI + GUI parity

`workflow list/async-status/cancel/tail` already cover B0/B1 from the terminal;
`workflow reorder` lands as CLI first; B3's start = existing `workflow execute/start`
(`scripts/harness.py:2196,2694`).

### HARNESS vs TARGET separation

Workflows are harness-rooted (`.harness/workflows/active/`), but each WF's task text /
tasks-store row carries `target`; the queue view groups by scope chip using the same
`activeTarget` feed (`scripts/harness_lib/ui_panel.py:270`). No second queue exists —
one runtime, labeled scopes.

### Validation

- Door NEW: `specs/40-features/panel-work-queue.md` (Gherkin `Scenario:[wq-…]` → checks).
- Deterministic scenarios: `wq_queue_view.py` — snapshot lists a fixture WF with correct
  stage labels; `reorder` refuses a running round; worker-level cancel marks only that
  worker `cancelled` (assert via `workflow_async_status`). Reuse the fixture WFs the
  existing wf_* scenarios build.
- Playwright `ui_e2e`: queue renders, cancel confirm dialog, reorder persists after poll.
- Gates: spec-pack (conformance) + scenarios; no new gate.

### Risks / open decisions

1. **Browser may START agents?** B3 spends real tokens from a click — needs an explicit
   owner decision (today creation is deliberately create-only, `ui_panel.py:728-735`).
2. Reorder-vs-race: the supervisor reads tasks at round start; reorder must hold the same
   guard scrub uses (`_wf_running`, `ui_panel.py:642-654`) and refuse mid-round.
3. Real-time = 3s poll, not push — consistent with "panels categorize, never stream"
   (`docs/IMPLEMENTATION_BACKLOG.md:30`); resist SSE for the queue.
4. Stage labels are heuristic (profile ≠ actual activity); honest labeling ("perfil"),
   refine only if operators misread it.

### Proposed central-backlog rows

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| queue-view-live | B0 live work-queue view (queue_snapshot + /api/queue + stage chips) | M | high | — | docs/roadmap/screens-tasks-queue.md |
| queue-cancel-worker | B1 worker-level cancel from the panel (`--worker-id` on workflow-cancel) | S | high | queue-view-live | docs/roadmap/screens-tasks-queue.md |
| queue-reorder | B2 `workflow reorder` CLI + allowlisted reorder in the queue view | M | med | queue-view-live | docs/roadmap/screens-tasks-queue.md |
| queue-start-action | B3 decision-gated `workflow-start` action (enqueue→start→watch loop) | S | low | tasks-enqueue, queue-view-live | docs/roadmap/screens-tasks-queue.md |

---

## Build order across the cluster

`queue-view-live` → `tasks-board-read` (independent, can parallelize) → `queue-cancel-worker`
→ `tasks-store-cli` → `tasks-enqueue` → `queue-reorder` → decision on `queue-start-action`
→ `tasks-target-board`. Each phase is one bounded implementer task with its own spec
scenario; nothing depends on an unshipped abstraction.
