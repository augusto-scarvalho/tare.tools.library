# Roadmap — Terminology: English default across screens, CLI, docs

Status: planning only (2026-07-12). Nothing here is implemented.

## Goal (owner request, verbatim)

> "Revisão completa de TERMINOLOGIA, TELAS e DOCUMENTAÇÃO para pararmos de misturar termos em
> inglês e português pelo projeto. DEFAULT É INGLÊS. Ajustar cuidadosamente JUNTO com o backlog
> de documentação."

Why: the GUI ships Portuguese strings while CLI/docs are mostly English; agents and tests pin
mixed-language substrings; every new screen re-decides language ad hoc. One default (English)
plus one deterministic guard ends the drift. The docs half rides the already-planned total docs
revision (`docs/roadmap/docs-wiki.md`) so the corpus is rewritten once, not twice.

## 1. Inventory of Portuguese by surface (audited 2026-07-12)

Method: pt-diacritic scan (`[ãõáéíóúâêôç]`) + curated word grep for diacritic-free pt
("Confirmar", "Salvar", "falha ao", ...). Counts are occurrences, not unique strings.

### 1a. GUI PAGE — `scripts/harness_ui_page.py` (1829 ln, single `PAGE` string) — PRIMARY surface

**~60 diacritic occurrences on ~55 lines + ~15 diacritic-free pt strings ≈ 75-90 pt user-facing
strings.** Everything inside `PAGE` ships to the browser (HTML labels, JS-built text, titles,
embedded CSS/JS comments). Representative (verified):

| Line | String | Kind |
|---|---|---|
| 704 | `sem saída ainda` | empty-state |
| 492 | `procurar pasta…` | button (test-pinned, see 1e) |
| 474, 480, 1018-1019 | `Confirmar` / `Entrada` / `Resultado` | modal title/buttons |
| 508 | `começar` | onboarding CTA |
| 351, 779 | `Atenção` / `quadro calmo` | section + empty-state |
| 1163, 1180 | `+ Nova sessão` / session-bar labels | session bar |
| 388, 464 | `Criar workflow` / `Descartar` (+ pt tooltips) | action buttons |
| 347 | `!comando roda um comando do harness local (não vai pra LLM)` | input hint (test-pinned) |
| 755, 757, 1780-1781 | cancel/discard/create confirm bodies | modal copy |
| 488-489, 496, 505 | onboarding dialog copy (`repositório de trabalho`, `perfil de roteamento`) | dialog |
| 1363-1366, 1478, 1484, 1490, 1513, 1518, 1581, 1583, 1596, 1603 | validation/error strings (`id é obrigatório`, `JSON inválido`, `falha ao trocar perfil`, ...) | errors |
| 582-583, 650, 833, 1067-1068, 1074, 1284, 1319, 1390-1395, 1419, 1453, 1458, 1631, 1648, 1724, 1792, 1797 | chips, tiles, badges, routing labels (`sessão $`, `output há Ns`, `delegações`, `primário`, `(padrão)`, `restaurar canônico`, `✓ criado`, ...) | dynamic text |
| 53-55, 649 | pt comments inside `PAGE` (ship to browser) | comments |

### 1b. CLI + `scripts/harness_lib/*` — NEARLY CLEAN

`scripts/harness.py` (3218 ln): **0** pt-diacritic hits. CLI stdout (chat_operator, common):
none found. Remaining pt shipped strings — **9 lines in 3 files** (all surface via GUI/API/state):

- `scripts/harness_lib/ui_panel.py:197` — `"detail": f"sem saída há {int(age)}s"` (attention card)
- `scripts/harness_lib/ui_panel.py:667` — `"workflow em execução — cancele antes de descartar"` (refusal)
- `scripts/harness_lib/ui_panel.py:1004` — `label or f"sessão {self._seq}"` (default session label)
- `scripts/harness_lib/model_routing.py:50` — `OVERSEER_DESC = "modelo padrão do harness (chat/GUI)"`
- `scripts/harness_lib/model_routing.py:80,84,88,92` — catalog `note` fields (pt provenance notes)
- `scripts/harness_lib/self_review_rules.py:362` — `"[sem proveniência — não aprovar] this rule..."` (mixed pt/en, written into proposedAction state)

### 1c. docs/ — 168 diacritic occurrences / 20 files

Heaviest: `docs/SELF_EVOLUTION_IDEATION.md` (49), `docs/research/agent-gui-cli-features.md` (23),
`docs/research/deep-research-pipelines.md` (23), `docs/roadmap/docs-wiki.md` (13),
`docs/roadmap/screens-*.md` (~31 across 5 files), `docs/roadmap/chat-overlays.md` (9),
`docs/WORKFLOW_TOKEN_ECONOMICS.md` (6). Mostly section labels, owner-request quotes, and
pt-voiced ideation notes.

### 1d. specs/ — 185 diacritic occurrences / 14 files

Heaviest: `specs/40-features/supervision-m5-interactive-panel.md` (86),
`specs/40-features/research-skill.md` (41), `specs/40-features/flow-composer.md` (11),
`specs/00-universal/sdd-bdd-flow.md` (9). Much of this is verbatim owner-request quotes and
Gherkin/UX copy mirroring the pt GUI strings (which 2a will flip).

### 1e. Test assertions that PIN pt strings (must move in lockstep with the string)

| Assertion | Pins |
|---|---|
| `testing/scenarios/m5_ui_panel.py:312` | `"procurar pasta" in harness_ui.PAGE` |
| `testing/scenarios/m5_ui_panel.py:1051-1052` | `"!comando" in harness_ui.PAGE` (×2) |
| `testing/ui/test_panel_e2e.py:392` | `"criado" in created_txt` (composer-create verdict, PAGE:1792) |
| `testing/scenarios/se_self_review.py:279` | `"sem proveniência" in ...proposedAction` (self_review_rules.py:362) |

Everything else in `testing/` asserts element IDs or English text (verified: `workflow retry` /
`workflow scrub` at `testing/ui/test_panel_e2e.py:452,462`; `valid|invalid` at 372). Only 3
pt-diacritic hits exist in testing and 2 are comments (`test_panel_e2e.py:315`,
`m5_ui_panel.py:279`). `testing/scenarios/ux_repl_onboarding.py` and
`testing/scenarios/ui_e2e.py`: no pt assertions found.

### 1f. Commit messages + protected files

- Commit messages: already English (last 25 verified via `git log`). Convention: keep English.
- Protected files: `AGENTS.md`, `CLAUDE.md`, `README.md`, `.harness/prompts/{harness-operator,
  implementer-packet,subagent-contract}.md` — **0** pt hits. Exception:
  `.harness/prompts/research-playbook.md` — **21** pt-diacritic lines, and it is protected →
  amendment-only via the protected-file flow, never a blind rewrite.
- Scenario `check()` detail strings: English (spot-checked m5/e2e above); pt only in comments.

## 2. Policy (English default)

1. **Shipped user-facing text is English.** Everything in `PAGE`
   (`scripts/harness_ui_page.py`), all CLI stdout, all API/state strings surfaced in the GUI
   (`ui_panel.py` details/refusals/labels, `model_routing.py` descriptions/notes,
   `self_review_rules.py` proposal text). No exceptions — i18n is explicitly out of scope
   (no locale layer; one language, one string).
2. **Identifiers, files, folders, CLI flags, check names: English.** Includes the planned
   `docs/wiki/` folder names (see §5 — rename before they exist).
3. **Docs and specs: English default.** Two exemptions: (a) verbatim owner-request quotes in
   "Goal" sections stay untouched (provenance > polish); (b) legacy-frozen spec bodies are
   amended only via the SPEC-116 COVERED door, never bulk-rewritten (same legacy-freeze risk as
   docs-wiki B1).
4. **Code comments: English for new/modified code.** Existing pt comments are converted
   opportunistically (lowest priority, Phase 4) — except comments inside `PAGE`, which ship to
   the browser and are treated as user-facing (Phase 1).
5. **Commit messages: English** (already the convention; write it down in the content guide).
6. The policy line lands in `docs/HARNESS_CONTENT_GUIDE.md` (currently has no language rule —
   verified) as the single normative home.

## 3. Phased plan (each phase pairs string change ↔ test-assertion update)

### Phase 1 — GUI PAGE strings + pinned assertions (M) — highest visibility
- Translate all pt strings in `scripts/harness_ui_page.py` (§1a lines), including tooltips,
  confirm-modal bodies, error strings, and the pt comments inside `PAGE` (they ship).
- Same commit, lockstep: `testing/scenarios/m5_ui_panel.py:312` (`procurar pasta` → new EN
  label), `m5_ui_panel.py:1051-1052` (`!comando` → `!command` — note the hint text AND the
  assertion), `testing/ui/test_panel_e2e.py:392` (`criado` → `created`, matching PAGE:1792).
- Keep element IDs, `data-*` attributes, route paths, and check names untouched — only display
  text changes, so all ID-based selectors in `test_panel_e2e.py` keep passing.
- Terminology table (pt → EN) fixed here and reused by every later phase: sessão→session,
  saída→output, quadro→board, papel→role, perfil de roteamento→routing profile,
  Descartar→Discard, Confirmar→Confirm, começar→start, padrão→default, etc. The table lives in
  this doc (appendix section added during Phase 1), not a new file.
- Validate: `m5_ui_panel` + `mr_model_routing` scenarios, Playwright ui_e2e layer
  (`testing/ui/test_panel_e2e.py`) — the GUI-change-means-e2e rule applies.

### Phase 2 — harness_lib shipped strings + pinned assertion (S)
- `ui_panel.py:197,667,1004`; `model_routing.py:50,80,84,88,92`; `self_review_rules.py:362`.
- Lockstep: `testing/scenarios/se_self_review.py:279` (`sem proveniência` → EN marker). Note
  `self_review_rules.py:362` text is persisted into rule-proposal state — old records keep the
  pt marker; the assertion must target newly generated proposals (it does — it generates one).
- `model_routing.py` catalog `note` fields render in the Config screen (PAGE:1319 uses
  `m.note`), so they are user-facing, not comments.

### Phase 3 — docs/specs: fold into the docs-wiki pass (no separate pass)
- This phase is NOT a standalone effort. It becomes an explicit acceptance criterion of
  `docs/roadmap/docs-wiki.md` Phases 3-4 (consolidation + wiki sources): every doc touched by
  that revision is normalized to English in the same edit. §5 below lists the concrete
  docs-wiki deltas.
- Owner-quote exemption (§2.3a) applies; legacy-frozen specs only via COVERED-door amendments.
- `.harness/prompts/research-playbook.md` (21 pt lines, protected): reviewed amendment through
  the protected-file flow (`python tools/hooks/protect_canonical_files.py check` +
  `protected-files` fixture), scheduled with the docs pass.

### Phase 4 — code comments (S, lowest priority, opportunistic)
- Non-PAGE pt comments (`testing/ui/test_panel_e2e.py:315`, `testing/scenarios/m5_ui_panel.py:279`,
  scattered elsewhere): convert when the surrounding code is next touched. No dedicated sweep,
  no guard coverage (§4) — not worth a gate.

## 4. Regression guard (deterministic, SDD Door NEW)

New check `check_en_default_strings` in `scripts/spec_test_gate.py`, registered beside
`check_markdown_links` (line 749) and `check_feature_spec_conformance` (line 791) — same
pattern, zero LLM, zero network.

Design (low-false-positive by construction):

- **Rule A — PAGE, whole-file:** the pt-diacritic class `[ãõáéíóúâêôçà]` must not appear
  anywhere in `scripts/harness_ui_page.py`. The whole file ships to the browser, so no
  string-vs-comment parsing is needed. Legit non-ASCII glyphs already in PAGE (✕ ⎇ 📁 ❯ · —)
  are outside the class → zero false positives.
- **Rule B — python string literals:** for `scripts/harness.py` + `scripts/harness_lib/*.py`,
  walk string tokens via stdlib `tokenize` and flag the pt-diacritic class inside STRING tokens
  only. Comments exempt (Phase-4 scope stays out of the gate; keeps FP at zero).
- **Rule C — curated diacritic-free word-list:** short, word-boundary, case-sensitive list of
  pt words that actually appeared in shipped strings ("Confirmar", "Cancelar", "Salvar",
  "Aplicar", "Descartar", "falha ao", "procurar pasta"). Applied to the Rule A/B scopes only.
  An entry is added only when it has once shipped — no speculative dictionary.
- **Allowlist:** inline `ALLOW` set in the check, empty at ship (ponytail: no config file until
  a real exemption exists).
- **Blocking, not advisory:** the check lands in the SAME commit as Phase 1+2 conversions, so
  it is green from its first run and there is no advisory window to forget about. Docs/specs
  are NOT guarded (owner quotes + pt-BR research material make any docs language gate FP-heavy;
  docs correctness is owned by the docs-wiki pass and review).
- **SDD (SPEC-116 Door NEW):** intake → `specs/40-features/terminology-en-default.md`
  (**SPEC-122** — 121 is reserved by docs-wiki, 120 is the current max, verified) with Gherkin
  scenarios mapped to a named scenario file `testing/scenarios/tg_en_default.py`
  (PAGE-clean / lib-strings-clean / word-list hit is flagged / allowlist honored).
- **CLI+GUI parity:** the check is a gate check, surfaced like every other in the gate ladder
  (GUI gates section reads the same gate state; no GUI-only capability added).

## 5. Coordination with docs-wiki (one revision, not two)

Concrete deltas to `docs/roadmap/docs-wiki.md` (amend that doc when this roadmap is accepted):

1. **Resolve its open decision #4** (line 224: "wiki topics in PT-BR (owner voice) — confirm")
   → **English**, per this request. Wiki topics are written EN from birth.
2. **Rename planned wiki structure to English before it exists** (docs-wiki Phase 4, lines
   146-155 — still unimplemented): `00-comece-aqui/`→`00-getting-started/`,
   `10-telas-do-painel/`→`10-panel-screens/`, `30-configuracao/`→`30-configuration/`,
   `50-seguranca-operacao/`→`50-security-operations/`, `90-projetos-adotados/`→
   `90-adopted-projects/`; topic filenames likewise; `Nível: leigo|operador|técnico` →
   `Level: beginner|operator|technical`.
3. **Scope banners** (docs-wiki Phase 1, lines 116-118): "Escopo: harness" → "Scope: harness".
4. **Sequencing:** docs-wiki Phase 1 (stale refs) is independent; this roadmap's Phase 3 merges
   into docs-wiki Phases 3-4 as an acceptance criterion ("touched docs leave English") so no
   file is revised twice. GUI/lib string phases (1-2 here) don't wait on docs-wiki at all.
5. `docs/HARNESS_CONTENT_GUIDE.md` gains the §2 policy in the same edit that docs-wiki already
   treats it as "the doc-conventions law" (docs-wiki line 36).

## 6. Validation

- Gate: `check_en_default_strings` green (Rules A-C) from the landing commit.
- Scenarios updated in lockstep and green: `m5_ui_panel` (312, 1051-1052), `se_self_review`
  (279), `mr_model_routing` (PAGE-reading check at 203), new `tg_en_default.py`.
- Playwright ui_e2e full run after Phase 1 (`testing/ui/test_panel_e2e.py`, incl. the
  `criado`→`created` assertion at 392) — GUI change rule from project memory.
- Protected-file fixture after the research-playbook amendment
  (`python tools/hooks/protect_canonical_files.py check`).

## 7. Risks / open decisions

1. **Comment-language scope** — proposed: English required for new/modified comments (policy),
   old comments converted opportunistically, NOT gate-enforced. Owner may want a sweep instead;
   that changes Phase 4 from S-opportunistic to M-dedicated.
2. **Commit-message language** — already English in practice; proposed: write it into the
   content guide, no hook. A commit-msg hook is available later if drift appears.
3. **Guard blocking vs advisory** — proposed blocking (lands with the conversion, §4). If
   Phase 1 is split across commits, a temporary allowlist entry per remaining file is the
   escape hatch — not an advisory mode.
4. **Owner-quote exemption breadth** — verbatim pt quotes in Goal sections stay. Decide whether
   pt-voiced ideation ledgers (`SELF_EVOLUTION_IDEATION.md`, 49 hits) are translated during
   docs-wiki Phase 3 triage or grandfathered until migrated to records (docs-wiki decision #3
   interacts: items migrated to the records ledger get translated on migration).
5. **Persisted pt state** — old rule-proposal records carry the pt provenance marker
   (`self_review_rules.py:362`); any tooling matching that marker must match both old pt and
   new EN forms, or only ever inspect new proposals (current scenario does the latter).
6. **Legacy spec freeze** — translating shipped spec bodies (e.g. supervision-m5, 86 hits) may
   exit the SPEC-116 legacy exemption; same open question as docs-wiki B1. Default: don't
   translate frozen spec bodies; new amendments are English.

## 8. Proposed central-backlog rows (docs/IMPLEMENTATION_BACKLOG.md)

| slug | title | size | priority | deps | doc-link |
|---|---|---|---|---|---|
| en-gui-strings | Phase 1: PAGE strings → English + lockstep test assertions | M | P1 | — | docs/roadmap/terminology-en-default.md §3.1 |
| en-lib-strings | Phase 2: harness_lib shipped strings → English (+ se_self_review pin) | S | P1 | en-gui-strings | §3.2 |
| en-default-guard | SPEC-122: `check_en_default_strings` gate check + `tg_en_default.py` | S | P1 | en-gui-strings, en-lib-strings | §4 |
| en-docs-fold | English-default acceptance criterion folded into docs-wiki Phases 3-4 (+ research-playbook amendment) | S | P2 | docs-consolidation (docs-wiki row) | §5 |
| en-comments | Opportunistic pt-comment conversion (policy only, no sweep) | S | P3 | — | §3.4 |
