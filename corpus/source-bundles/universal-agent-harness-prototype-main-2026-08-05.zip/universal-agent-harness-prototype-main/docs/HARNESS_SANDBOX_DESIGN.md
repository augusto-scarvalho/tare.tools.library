# Harness-owned sandbox — architecture (design-first, pre-spec)

Status: **ADOPTED → SPEC-148** (`specs/40-features/harness-sandbox.md`, door-NEW
intake `harness-sandbox.intake.md`; P1 shipped 2026-07-18 — `sandbox_spawn`
chokepoint + nt fs backend). This doc stays as the architecture rationale.
Source of requirement: the reference-architecture article (§5.9 runtime plane
lists "leased scheduler and **sandbox**" as a MANDATORY component; §7.4
defense-in-depth layer 5 = "filesystem, process, and network sandboxing"; §7.5
requires sandbox against a compromised worker/model and a malicious adapter/tool).
Owner framing (2026-07-18): a harness-owned sandbox is a **requirement** for
multi-vendor + open models working together.

## 1. Why the harness must own a sandbox (not delegate to vendors)

Experimentally established this session (8 live codex execs, recon of all spawn
surfaces):

| Worker class | Native vendor sandbox | Our hooks enforce? | Today's containment |
|---|---|---|---|
| claude (Agent/exec) | permission-mode + allowedTools (deny honored) | **yes** | tools ceiling (S2) + allowedTools globs |
| codex exec | `sandbox_mode` read-only/workspace-write (RELIABLE — proven) | **no** — deny ignored under bypassPermissions | S3 native sandbox by writeAllowed |
| open models (http family: local-llama / nvidia / gemini, `tools/openai_worker.py`) | **NONE** | **no** (no hook runtime) | **NOTHING** — plain OS-user process |

The open-model row is the load-bearing gap: those workers run with the full OS
user's filesystem, process, and network access, zero confinement. Vendor-native
sandboxes are heterogeneous (codex has one, claude has permission-mode, open
models have none), so containment cannot be delegated. Only a harness-owned layer,
applied at spawn regardless of vendor, makes the fleet safe to run together.

## 2. Threat model (what the sandbox must bound)

Assets (article §7.5): source/artifacts, secrets & personal data, canonical
policy/instruction files, project memory, budgets, the trajectory itself.

Adversary the sandbox specifically addresses (blast-radius limiter, complementary
to authorization which blocks and prompts which dissuade):
- **Compromised / prompt-injected / buggy worker** writing outside its footprint
  (protected canonical files, secrets, other projects) — proven possible today on
  codex (edited AGENTS.md through fully-wired hooks) and on open models (no guard
  at all).
- **Malicious open-model endpoint / adapter** exfiltrating repo contents or secrets
  over the network, or a worker reading `.env`/keys and POSTing them out.
- **Runaway process** (fork bomb, memory, wall-time) — partly covered by `esh`.

Non-goals (kept honest): this sandbox does not make model output correct, does not
replace authorization/approval (§7.4: complementary), and does not claim
kernel-grade isolation on Windows (see §5).

## 3. Primitives we already have (build on these, don't reinvent)

- **`esh` / `run_process_tree_bounded`** (`processes.py`) — Windows Job Object +
  CREATE_SUSPENDED + stdin DEVNULL. Already bounds the process TREE and kill
  accounting. *Gap:* no memory/child-count/wall-clock caps wired; not applied to
  every spawn surface.
- **Worktrees** (`prepare-worktrees` / `apply-merge`, CONTROLLED_PARALLEL_WRITES) —
  fs isolation by CONVENTION; merge-time footprint check. *Gap:* nothing stops the
  worker PROCESS from writing outside the worktree at runtime.
- **`filter_spawn_env` (S1, SPEC-119)** — least-privilege env allowlist. *Gap:*
  wired for workflow workers + (now) dispatch; not for open-model HTTP workers;
  doesn't yet scrub network/proxy creds beyond the vendor key.
- **SEC.1 pre-egress gate** (`discovery.py`) — covers only the `discover` chain
  (Gemini/NVIDIA discovery), not arbitrary worker HTTP.
- **codex `sandbox_mode` (S3)** — reliable codex write control, driven by
  writeAllowed. Keep as the codex inner layer.

## 4. Architecture — four confinement dimensions × worker class

The sandbox is a **spawn-time wrapper** (`sandbox_spawn(manifest, vendor, argv,
env)`) that every spawn surface routes through. Input = the worker's resource
manifest (§3.5: declared read/write/effect sets + risk tier). It composes:

### D1 — Filesystem confinement (the priority)
Goal: a worker can only write inside its declared footprint; protected/out-of-scope
paths are physically unwritable, not just policy-denied.
- **Read roles:** isolated worktree/temp workspace as cwd; the tree is a checkout,
  writes land in the disposable workspace, never merged. codex → `sandbox_mode
  read-only` (reliable). claude → read-only toolset (S2). open model → no fs tool
  at all (HTTP worker has no filesystem tool; already true).
- **Write roles:** isolated worktree; **protected + out-of-scope paths made
  read-only at the OS level** (Windows: `icacls` deny-write for the worker's
  restricted token, or simply ABSENT from the worktree so the path doesn't exist to
  write). Pre-integration scan (already have) rejects any change outside footprint
  as defense-in-depth. codex → `sandbox_mode workspace-write` scoped to the
  worktree dir. The apply_patch parser (shipped this session) feeds a harness-side
  pre-write validator where the vendor doesn't honor deny.
- **Windows-honest:** true per-process fs namespaces don't exist on Windows;
  the practical control is (a) disposable worktree + (b) ACL deny-write on protected
  paths + (c) merge-time footprint gate. Good enough for the threat model; not
  kernel isolation.

### D2 — Process confinement
Extend `esh` Job Objects with `JOB_OBJECT_LIMIT_ACTIVE_PROCESS` (child cap),
memory cap, and wall-clock kill. Apply to EVERY spawn (workflow, dispatch, chat
engine, HTTP worker). Mostly wiring of an existing primitive.

### D3 — Environment / credential scoping
Every spawn (incl. open-model HTTP workers, currently unfiltered) goes through
`filter_spawn_env` with a per-vendor keep-list that includes ONLY the one endpoint
credential the worker needs. Strip proxy vars, other vendors' keys, and anything
not on the manifest. Closes the "worker reads secret then the model/endpoint sees
it" path at the env layer.

### D4 — Network egress control (hardest; phased)
Goal: a worker (esp. an open-model endpoint) can only reach its declared endpoints.
- **Phase-later:** a harness egress broker/proxy — workers get `HTTP(S)_PROXY`
  pointed at a local broker that allowlists destinations (extends SEC.1 beyond
  discover). Windows lacks cheap per-process network namespaces, so a proxy +
  credential-scoping is the realistic lever. For HTTP workers we control the client
  (`openai_worker.py`), so we can enforce the allowlist IN the client first (cheap),
  then generalize to a broker for tool-driven egress.

## 5. Windows reality check (why architecture-first matters here)

Linux would give namespaces/cgroups/seccomp cheaply. Windows does not. The honest
levers we have: Job Objects (process), restricted tokens + `icacls` (fs ACLs),
disposable worktrees (fs blast radius), env scoping, and an egress proxy/in-client
allowlist (network). A naive "just sandbox it" on Windows is a trap; this design
deliberately composes the achievable primitives and marks D4 (network) as the
hardest, phased last. AppContainer/restricted-token spawning is a possible future
hardening but is heavy and deferred.

## 6. Phased plan (cheap-and-real first)

- **P1 (fs + env floor, reuses what we have):** route EVERY spawn (incl. HTTP
  workers) through a `sandbox_spawn` wrapper that (a) sets an isolated cwd/worktree,
  (b) applies `filter_spawn_env` per-vendor, (c) ACL-deny-writes the protected set
  for write workers, (d) wraps in the `esh` Job Object. Deterministic, testable,
  covers the open-model gap. codex keeps `sandbox_mode` (S3) as inner layer.
- **P2 (process caps + pre-write validator):** Job Object memory/child/wall caps;
  a harness-side pre-write validator for codex (uses the apply_patch parser) that
  runs BEFORE the merge, since codex ignores hook deny.
- **P3 (egress):** in-client allowlist for HTTP workers → general egress broker.

## 7. Conformance + red-team tests (article §7.5 / §5.9)

Every threat maps to a test:
- red-team: a write worker attempts to edit a protected canonical file → blocked at
  the OS/fs layer (not just merge-time), for EACH vendor incl. open model.
- red-team: a worker attempts to read `.env` and POST it to a non-allowlisted host →
  blocked (env-scoped + egress).
- red-team: a worker writes outside its footprint → change never integrates AND the
  worktree write itself is denied for protected paths.
- conformance (§5.9 runtime): crash mid-spawn resumes without a duplicate effect;
  Job Object kills the whole tree.
- the existing isolation-audit fixture extends to cover spawn (today it only covers
  the target-gate path).

## 8. Decisions (owner, 2026-07-18)

1. **D4 egress:** in-client allowlist for our HTTP workers NOW (cheap, covers the
   open-model gap); the general egress broker goes to the **backlog**.
2. **Protected files in write worktrees:** **Option A** — deny-write ACL, files
   present but unwritable (the worker can still READ them; only mutation blocked).
3. **Restricted tokens / AppContainer:** **deferred**, AND the whole sandbox must
   have **cross-OS equivalence** — no Windows-only hack; each confinement dimension
   needs a documented per-OS backend behind one OS-agnostic interface (§10).
4. **`sandbox_spawn` chokepoint:** **one wrapper** (recommended), but with the
   **consequences made explicit and mitigated** (§11).

## 9. (was open questions — now resolved above)

## 10. Cross-OS equivalence (owner requirement, Q3)

The sandbox is an **OS-agnostic interface with per-OS backends**. The interface is
the contract; each backend implements it with native primitives. Critically, a
**missing backend FAILS CLOSED** — on an OS/dimension we don't yet confine, an
R1+ (write/effect) spawn is REFUSED with a clear reason, never run unconfined
(article §3.5: indeterminate → deny; a missing sandbox is not "no sandbox", it is
"cannot run this risk tier here"). R0 read-only spawns may proceed with the
env/process layers alone.

| Dimension | Interface | Windows backend | Linux backend | macOS backend |
|---|---|---|---|---|
| D1 filesystem | `fs_confine(workspace, ro_paths)` | worktree + `icacls` deny-write ACL (+ restricted token later) | worktree + `mount --bind -o ro` / overlayfs in a mount namespace (`unshare`), or ACL + merge gate | worktree + `sandbox-exec` deny file-write profile, or chmod + merge gate |
| D2 process | `proc_bound(limits)` | Job Object (esh) + active-process/memory/time limits | cgroups v2 (memory, pids) + rlimits + pgid kill | rlimits + process-group kill (no cgroups) |
| D3 env/cred | `env_scope(keep)` | `filter_spawn_env` (already OS-agnostic) | same | same |
| D4 egress | `egress_allow(hosts)` | in-client allowlist in `openai_worker.py` (OS-agnostic); broker later | same | same |

The merge-time footprint gate (CONTROLLED_PARALLEL_WRITES) is the OS-agnostic
backstop under ALL backends: even where fs ACL is weaker, a write outside the
declared footprint never integrates. So the fail-closed floor is: env-scope +
process-bound + merge-gate everywhere; the fs ACL / egress are per-OS hardening on
top.

## 11. Consequences of the single `sandbox_spawn` chokepoint (owner requirement, Q4)

Choosing one wrapper is right, but it is load-bearing — the consequences, each with
its mitigation:

1. **Single point of failure.** A bug in `sandbox_spawn` affects EVERY spawn.
   → Mitigation: it FAILS CLOSED (a sandbox-setup error refuses the spawn, never
   spawns unconfined); keep it small, reviewed, and heavily self-checked.
2. **Every spawn surface must be migrated to route through it.** Today spawns
   happen via `processes.launch_detached`/`run_quiet`, `async_runtime`,
   `chat_engines`, `openai_worker`, `route_dispatcher`. Missing one leaves an
   unconfined path. → Mitigation: reuse the **existing no-raw-subprocess ratchet**
   to forbid raw `Popen`/launch outside `sandbox_spawn` (a gate check makes "you
   bypassed the sandbox" a CI failure, not a silent hole).
3. **Latency on cheap fan-outs.** Every spawn paying worktree+ACL+JobObject setup
   would tax read-only lookups. → Mitigation: cost scales with **risk tier** — R0
   read-only workers get env-scope + process-bound only (no worktree/ACL); R1+
   write workers get the full stack.
4. **Central coupling.** `sandbox_spawn` must stay vendor-agnostic. → Mitigation:
   its only inputs are the resource manifest + vendor tag; vendor specifics (codex
   `sandbox_mode`, claude allowedTools) are composed as inner layers behind the
   same interface, never leaked into callers.
5. **Fail-closed can block work on an unsupported OS/dimension.** An operator on a
   backend we haven't implemented gets "sandbox backend unavailable → refusing R1+
   spawn," not silent unconfined execution. → This is the correct safety trade-off,
   but must be a LOUD, documented refusal with an escape hatch only via explicit
   owner-tokened override (never a silent downgrade).

## 12. Next steps

Design agreed → write the SPEC-116 door-NEW intake + spec, then implement **P1**
(the `sandbox_spawn` chokepoint: isolated cwd/worktree + `env_scope` per vendor +
`icacls` deny-write for write workers + `esh` Job Object; cross-OS interface with
Windows backend first, Linux/macOS backends stubbed fail-closed; the
no-raw-subprocess ratchet extended to enforce the chokepoint). P2 = process caps +
codex pre-write validator (uses the shipped apply_patch parser). P3 = egress
in-client allowlist. Broker + restricted-tokens/AppContainer = backlog.
