# Playbook archaeology — incident narratives behind the rules

Moved out of `.harness/prompts/overseer-playbook.md` (owner directive
2026-07-23: playbooks carry rules, not history; history lives where records
and doc-find can retrieve it). Each entry keeps the FULL narrative that
justified a playbook rule; the playbook cites `(arch: <id>)`. Do not delete
entries — they are the evidence trail for the rules.

## arch-fuel-origin — why the fuel check exists (2026-07-23)

The 2026-07-23 session delegated two opus lanes with the Claude week at 13% —
the gauge existed and was not consulted. Owner ruling the same day: reading
the vendor gauge before EVERY delegation is a review-ritual violation of the
same class as skipping the footprint check when omitted. The hold-swap
pre-launch check covers WORKER-RUN scenario verifications too — a worker
running its verification IS a scenarios run holding the tree (2026-07-23
~17:00: a codex lane's apply_patch write-blocked inside that window; a
clean-tree retry succeeded).

## arch-claude-usage-probe — the pct=null bug and the cheap probe pin (SPEC-168)

`probe_claude` runs `claude -p "/usage"` and parses the subscription panel
(session/week/per-model % used -> pct-remaining) into
`.harness/state/vendor-fuel.json`. The earlier `pct=null` was a bug: Git-Bash
MSYS mangled `/usage` into a path; via subprocess LIST args there is no shell,
so it passes intact. The probe is pinned to the CHEAPEST model
(`_PROBE_MODEL`, haiku — owner 2026-07-23): the `/usage` panel is CLI-rendered
so the model does no work; measured cost_usd ~= 0 (the default Fable turn had
billed ~$0.37). The cadence stopped being cost-constrained: refresh freely,
week-% still moves slowly, once per integration is plenty.

## arch-codex-rollout-gauge — the day's third overturned codex claim (2026-07-23)

The "no non-interactive surface / pct=null" verdict for codex was wrong
(owner-corrected). Every `codex exec` run writes
`~/.codex/sessions/Y/M/D/rollout-*.jsonl` whose token_count events carry REAL
`rate_limits` (primary.used_percent over window_minutes 10080 = week, plus
resets_at). `fuel probe` reads the newest rollout — a zero-cost file read —
and reports `pct = 100 - used_percent` with reset time and rollout age. No
recent rollout -> pct null with honest detail; the cheap refresh escalation is
ONE minimal `codex exec --model gpt-5.6-luna -c model_reasoning_effort=low`
turn to mint a fresh rollout (never the sol default — a bare `codex exec`
bills a full sol-high turn). The future worker load-balancer (D017) is the
load-bearing consumer.

## arch-codex-npm — the ENOTCACHED verdict was a shell-quoting mangle (2026-07-23)

CORRECTED 2026-07-23 (owner-challenged, probe-proven): the workspace-write
sandbox DOES have network — direct fetch to registry.npmjs.org returned 200
from inside a codex lane. The ENOTCACHED failure was a SHELL-QUOTING MANGLE:
codex ran npm through nested powershell->cmd where `^` is cmd's escape char,
mutilating the `@^6.12.2` version spec — the same failure family as the
Git-Bash `/usage` path-mangle. Practice distilled into the playbook: pin EXACT
versions (no `^`/`~` in argv) or the overseer pre-installs at dispatch.

## arch-codex-browser — the EPERM is the sandbox's process-spawn wall (2026-07-23)

The 2026-07-22 "codex cannot spawn a browser" lesson was OUR FLAG's fault, not
codex's. Under the lane recipe's `--sandbox workspace-write`, Chromium spawn
EPERMs because the Playwright binary (AppData\ms-playwright) and profile
(TEMP) live OUTSIDE the workspace (probe 2026-07-23, terra, verbatim EPERM
log). The owner tests GUI in codex CLI/GUI fine under its normal sandbox.
In-workspace PLAYWRIGHT_BROWSERS_PATH was TESTED 2026-07-23 and FAILED —
spawn EPERM persists with binary+profile+TMP fully inside the workspace: the
workspace-write sandbox restricts PROCESS SPAWN, not file location. Only route
to codex browser lanes is `--sandbox danger-full-access`, OWNER-GATED. Until
sanctioned, terra UI-test lanes cover source-level testing and browser
EXECUTION stays on Claude-family workers.

## arch-d038-outliers — lane-brief economy, measured (2026-07-20 .. 2026-07-22)

Baseline 2026-07-20: 113k/126k/203k tokens per lane at ~2.6k/tool-use. A
2,400-line read dominated a 203k-token lane -> rule 1 (pre-assembled context:
paste the exact excerpts, function + ~20 lines). A bare smoke run leaked ~800
green lines into a worker's context -> rule 2 (quiet validation). v2
(2026-07-22, cost-outlier audit, loop-6h): `file:line` references WITHOUT the
pasted excerpt made the two outlier lanes — 302k/105 tool-uses and 184k/66 vs
118-122k on excerpt-carrying briefs — the workers re-read ~3,700-line files.
The 140k delegation ceiling stays: it caught exactly the badly-briefed lanes.
Effort/model stay AS PINNED (owner decision — no per-lane tuning).

## arch-hold-swap — worker read the swapped baseline tree (2026-07-22 20:24)

The gate-hold SWAPS the live `.harness` tree for the baseline during a
scenarios/gate run. A codex worker launched mid-run read the swapped tree —
weeks-old baseline — did not find its brief and aborted (honest; a less
disciplined worker would have implemented against stale state). Corollary:
overseer writes to held paths during the hold land in the baseline and are
DISCARDED on release — rewrite after. Hence the mandatory pre-launch check:
`.harness/runs/gate-hold/` EMPTY before ANY repo-reading lane.

## arch-surface-guard — the false "8/8 FASE COMPLETA" strike (2026-07-22)

GUI remediation origin of the surface-declaration rule: phases 5/6/7 were
struck "FASE COMPLETA" with ZERO sections native in `domainMap.ts` — the
"8/8" claim was false for the React GUI. Since then: every GUI-* brief
declares `Surface: ui/src/domains/<d>/ (React)` in its first section; the
legacy panel (`scripts/harness_ui_page.py`) is read-only reference until
parity; striking a GUI phase requires `native: true` for the phase's
sections.

## arch-tsv-boundary — format belongs to the consumer (owner doctrine, 2026-07-22)

Live case: mr 17/19 failed under exported compact — scenarios parsing CLI
output choked on agent-format TSV. Doctrine distilled: TSV/compact exists for
AGENT-facing traffic; system-to-system communication (scenarios parsing CLI,
panel subprocessing verbs, reduce reading results) uses JSON and must be
IMMUNE to the ambient env, not merely spared by discipline. Parsers live only
at the seams: app JSON -> TSV render for agents (emit/TE.5, exists);
agent-written TSV -> ingest parser -> app JSON (planned); agent<->agent stays
TSV, app<->app stays JSON. Interim rule until `tsv-boundary-env-immunity`
lands (`_lib.run()` scrubs `HARNESS_AGENT_OUTPUT` from child envs): scenarios
run with `HARNESS_QUIET=1` only — never export compact around scenario
executions.

## arch-wf-churn — the #1 cycle-time amplifier, measured (2026-07-20)

Workflow-efficiency round: the gate is the DRUM (Theory of Constraints),
~8min serial, 35% isolation tax. Live measurement: fix A gated ~3x; a 15-min
task became 45min+. Hence batch-fix (accumulate related fixes, gate ONCE,
bisect on failure) and WIP-pipelining (WIP~=2: item N gating while N+1
preps, disjoint footprints; the verify-ledger is the join token). Full
analysis: docs/research/loop-workflow-efficiency-round.md. A formal
cross-item scheduler stays a deferred prototype unless a throughput signal
justifies machinery over discipline.

## arch-review-mechanized — why review steps 1-4 are a tool (2026-07-13)

v2 2026-07-13: `harness.py review --plan <brief>` mechanized footprint,
blank-fraud arithmetic, HEAD-attributed mojibake and gaming hunts. The
canonical blank-fraud catch: "moved 72 lines" cannot explain a 384-line
reduction — blank-line stripping with all gates green. Mojibake judged with
python because PowerShell's UTF-8 display LIES; only positive deltas vs HEAD
are the worker's; `mojibake-ok` lines exempt. 12 real plan-brief examples:
`.harness/handoff/plan-q*.md` (session 2026-07-13).

## arch-ui-serve-headless — the bare `ui` verb pops the owner's browser (2026-07-20)

Owner report: UI serve checks are HEADLESS — `harness.py ui --no-open` + plain
HTTP GET, then kill the server. A worker must NEVER open a browser; the bare
`ui` verb is hook-DENIED from the Bash tool (deny_hitl_flags). Real browser
e2e = the playwright-headless-smoke row, not the owner's desktop.
