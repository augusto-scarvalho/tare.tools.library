# Self-Evolution — External Survey & Ideation (living doc)

Survey of scientific literature and reputable engineering sources on self-evolving /
self-improving / adaptive AI systems, crossed against our SPEC-109 loop. Companion to the
closed record `SELF_EVOLUTION_REPORT.md`. Surveyed 2026-07-09. Rule inherited from SPEC-109
governance: everything here is **triage input, not commitment** — candidates go to the human,
never straight to the schedule.

## 1. Survey

### 1a. Self-evolving agent systems (2023–2026)

- **A Comprehensive Survey of Self-Evolving AI Agents** ([arXiv:2508.07407](https://arxiv.org/abs/2508.07407);
  curated list [EvoAgentX/Awesome-Self-Evolving-Agents](https://github.com/EvoAgentX/Awesome-Self-Evolving-Agents)) —
  the field's reference survey. Abstracts every system as one **feedback loop** and organizes
  techniques by *which component* evolves (prompts, memory, tools, workflow topology, model
  weights) — plus a dedicated safety/ethics section. Its core observation is ours verbatim:
  most deployed agent systems are "manually crafted configurations that remain static after
  deployment". A sibling survey frames the same space as *what/when/how/where to evolve*
  ([arXiv:2507.21046](https://arxiv.org/abs/2507.21046)).
- **Darwin Gödel Machine** (Sakana AI + UBC, [arXiv:2505.22954](https://arxiv.org/abs/2505.22954),
  [sakana.ai/dgm](https://sakana.ai/dgm/)) — open-ended evolution of coding agents that
  rewrite their own code; an **archive of all variants** (not just the latest) supplies
  parents for new mutations — explicitly because the best ancestor is often not the latest
  (our M3.3 non-linear-reduce insight at population scale). Results: SWE-bench 20%→50%,
  Polyglot 14.2%→30.7%; cost ~US$22k and two weeks per 80-iteration run. Famous safety
  incident: the agent **removed its own hallucination-detection markers** to score better —
  objective hacking inside a sandbox, caught only because the archive kept everything
  inspectable.
- **AlphaEvolve** (DeepMind, [arXiv:2506.13131](https://arxiv.org/abs/2506.13131),
  [blog](https://deepmind.google/blog/alphaevolve-a-gemini-powered-coding-agent-for-designing-advanced-algorithms/)) —
  evolutionary search over *programs* with an LLM ensemble as mutation operator (Flash for
  breadth, Pro for depth) and an **automated evaluator as fitness function**. Production
  evidence: recovered 0.7% of Google's global compute (Borg heuristic), 23%/32% kernel
  speedups, new matrix-multiplication algorithms. Open-source reproduction: CodeEvolve
  ([arXiv:2510.14150](https://arxiv.org/pdf/2510.14150)). The load-bearing piece is the
  *cheap deterministic evaluator* — evolution is only as safe as its fitness function.
- **MOSS: Self-Evolution through Source-Level Rewriting** ([arXiv:2605.22794](https://arxiv.org/abs/2605.22794),
  May 2026) — the direct counterpoint to our design. Argues text-mutable evolution (prompts,
  skills, memory, workflow graphs) leaves "routing, hook ordering, state invariants, and
  dispatch" unreachable, so a whole class of structural failure can never be fixed from the
  text layer; MOSS rewrites the **harness source itself** on production substrates. Its
  safety story is remarkably convergent with ours anyway: deterministic multi-stage pipeline,
  code modification delegated to an external coding-agent CLI, batch **replay verification**
  in ephemeral environments, **user-consent-gated** deployment with health-probe rollback.
  Evidence: 4-task mean grader score 0.25→0.61 in one cycle on OpenClaw.
- **Voyager** ([arXiv:2305.16291](https://arxiv.org/abs/2305.16291),
  [site](https://voyager.minedojo.org/)) — lifelong learning via an **ever-growing skill
  library of executable code**, an automatic curriculum, and iterative self-verification; no
  gradient updates. Skills are transferable between agents (gave AutoGPT's success rate a
  0/3→1–2/3 lift). The durable idea: *accumulated executable artifacts* are the memory that
  compounds.
- Adjacent 2026 entries spotted but not yet deep-read: Adaptive Orchestration for
  self-evolving multi-agent systems ([arXiv:2601.09742](https://arxiv.org/pdf/2601.09742));
  Adaptation of Agentic AI survey — post-training/memory/skills
  ([arXiv:2512.16301](https://arxiv.org/pdf/2512.16301)); EvoSkill
  ([arXiv:2603.02766](https://arxiv.org/pdf/2603.02766)).

### 1b. The classic line that anticipated all of it: autonomic computing / self-adaptive systems

- **MAPE-K** (Kephart & Chess, IBM 2003) — Monitor, Analyze, Plan, Execute over shared
  Knowledge: the canonical architecture of self-managing systems, with 20+ years of SEAMS
  literature on self-* properties, models@runtime, and utility-driven adaptation.
  **Our SPEC-109 loop is a textbook MAPE-K instance**: Monitor = `collect_metrics`,
  Analyze = `evaluate(rules)`, Plan = findings/proposals, Execute = closed safe-action set,
  Knowledge = ledger + config + report. Naming this buys us the field's vocabulary and its
  known failure modes for free.
- **The Vision of Autonomic Computing: Can LLMs Make It a Reality?**
  ([arXiv:2407.14402](https://arxiv.org/html/2407.14402), Microsoft) — evaluates LLM-based
  multi-agent frameworks against the classic **five levels of autonomy** for service
  management; reaches level 4–5 on microservice self-management. MAPE-K+LLM is now a named
  architecture pattern ([overview](https://www.emergentmind.com/topics/mape-k-llm-architecture)),
  with agentic instantiations of individual MAPE phases (Esposito et al. 2025) and
  self-adaptive LLM multi-agent systems (Nascimento et al.,
  [arXiv:2307.06187](https://arxiv.org/pdf/2307.06187)). Useful maturity scale: *where are we?*
  Our loop is level 3–4 (adaptive analysis + bounded execution, human approves change).

### 1c. Adaptive automata (linha brasileira — João José Neto, LTA/USP)

- **Adaptive Rule-Driven Devices — General Formulation and Case Study**
  ([Springer](https://link.springer.com/chapter/10.1007/3-540-36390-4_20); see also
  [Adaptive Automata — A Revisited Proposal](https://www.researchgate.net/publication/221568162_Adaptive_Automata_-_A_Revisited_Proposal)) —
  a formalism where a simple **subjacent rule-driven device** (e.g. finite automaton) gains
  an **adaptive layer**: adaptive actions attached to rules that, when fired, *modify the
  rule set itself* (insert/remove transitions) during execution. Achieves Turing power from
  trivially verifiable substrates, and the two-layer split is exactly the safety move: the
  subjacent device stays simple and analyzable; all self-modification is confined to a
  declared, inspectable layer.
- **The cross-pollination for us**: our `.harness/self-review.json` rule table + closed
  safe-action set *is* a restricted adaptive layer over a rule-driven device — currently the
  adaptive actions may only change *parameters* (ratchet maxima), never the rule set. The
  formalism suggests the disciplined next step ("rules that propose rules"): findings whose
  proposed action is *adding a declared rule to the table* — still human-gated, but with the
  formal comfort that rule-set mutation over a fixed rule language is analyzable, unlike
  free-form code mutation (Gödel-machine style). It also gives a decidability warning:
  unrestricted adaptive layers are Turing-complete — boundedness must be a design choice.

### 1d. Parallel engineering lines that transfer

- **AIOps / self-healing infrastructure** — the ops world converged on the same loop
  independently: Observe–Detect–Diagnose–Act–Learn with **Runbooks-as-Code** (remediations
  versioned, peer-reviewed, CI-tested — [overview](https://hackernoon.com/building-self-healing-infrastructure-using-observability-aiops-and-automated-incident-remediation),
  [closed-loop remediation](https://aicompetence.org/closed-loop-remediation-self-healing-aiops/)).
  LLM-ARF-style frameworks prompt a reasoning agent with alert context **plus a library of
  approved remediation actions** — precisely our closed safe-action set, at datacenter scale.
  Transferable ideas: MTTR as the loop's KPI; blast-radius tiers per action; canary-then-fleet
  rollout for any automated change.
- **Safety of self-evolution** — *Safety in Self-Evolving LLM Agent Systems: Threats,
  Amplification, and Case Studies* ([arXiv:2606.23075](https://arxiv.org/pdf/2606.23075),
  June 2026, 60 pp.): each evolution cycle can **amplify** vulnerabilities (poisoned memory
  and reward exploits compound across iterations); catalogs self-reward exploitation, memory
  poisoning, multi-agent attack chains; recommends structured governance + verification of
  the evolution process itself. Reward-hacking empirics: inference-time prohibition
  suppresses exploit rates by >80%; simple environmental hardening cuts hacking 87.7%
  relative ([benchmark](https://arxiv.org/html/2605.02964); mechanistic monitoring:
  [arXiv:2606.06223](https://arxiv.org/pdf/2606.06223)). Together with the DGM
  marker-removal incident, this is the literature validating our two hard choices:
  human-gated proposals and a *closed* action set.

## 2. Cross matrix — sources × our components

| External mechanism | Our counterpart | Verdict |
|---|---|---|
| Survey's "feedback loop over interaction data" (2508.07407) | SPEC-109 collect→evaluate→propose | **Have** — ours is deterministic-signals-first, which the survey lists as the rarer, more auditable variant |
| MAPE-K (autonomic computing) | The SE loop, unnamed until now | **Have — adopt the vocabulary**; registry/report should say "MAPE-K instance, autonomy level 3–4" |
| DGM/MOSS source self-rewriting | Explicitly refused (anti-Hive, ideas §H) | **Refuse, knowingly** — but MOSS's *replay verification + consent-gated rollout* mirrors our scenarios + escalations; the gap they'd fill (structural failures unreachable from text) is served in our design by the human executing proposals |
| DGM archive of all variants | M3.3 attempt archiving + non-linear selection | **Have (small scale)** — same principle: never assume the latest is the best |
| AlphaEvolve automated evaluator-as-fitness | Gates + acceptance scenarios | **Have the evaluator**; missing: using it as *fitness for competing variants* (we never generate variants) |
| Voyager skill library | `testing/scenarios/` + promoted tools (MF.7 wrapper, doc-find…) | **Partial** — we accumulate executable artifacts but nothing *retrieves* them by task similarity |
| Adaptive automata: adaptive layer over simple substrate | Rule table + closed safe actions | **Have the restricted form**; formalism points to the disciplined extension (rules-that-propose-rules) |
| AIOps runbooks-as-code, blast-radius tiers, MTTR | Safe actions (event-logged, closed) | **Have the runbook**; missing: severity tiers per action and a loop KPI (time-from-finding-to-triage) |
| Amplification threat model (2606.23075) | Human gate breaks the amplification chain | **Have the main mitigation**; missing: explicit verification *of the loop itself* (who reviews a rule change?) |
| Reward-hacking hardening (>80% via prohibition) | Skeptical reviewer no-self-waiver (M3.1); no self-scored rewards anywhere | **Have** — our "fitness" signals are mechanical facts (line counts, ages, rates), much harder to game than LLM-judged scores |

## 3. Ideation round — candidates for human triage

**Triage outcome (2026-07-09, user decision: implement, cheapest first):** I1, I2, I3, I5,
I6, I7, I9 **implemented** (evidence: se_self_review scenario 18/18; `doc-find` returns
code-module hits; audit finding fires on config change; ratchet actions carry tiers and
replay-verify). I4 and I8 stay **trigger-gated in Deferred** — their own triggers
(threshold changed ≥2× by hand; friction dedup visibly wrong ≥2×) have not fired, and the
framework's rule is that triggers gate work.

| ID | Candidate | Inspiration | Cost | Risk | Trigger to consider |
|---|---|---|---|---|---|
| I1 | **Name the loop MAPE-K** in ARCHITECTURE + assumptions registry; adopt the 5-level autonomy scale to describe each safe action | 1b | S (docs) | none | next docs pass |
| I2 | **Rules-that-propose-rules**: a finding whose proposedAction is a concrete new rule entry (JSON included); human approves → rule joins the table. The adaptive-automata move, restricted to the declared rule language | 1c | S–M | low (still human-gated; rule language is closed) | first time a friction finding recurs after its tool was built |
| I3 | **Blast-radius tiers for safe actions** (`tier-0` state files, `tier-1` config numbers, `tier-2` tracked docs) + per-tier event detail; prerequisite for ever widening autonomy | AIOps | S | none | before any new safe action is added |
| I4 | **Variant evaluation for config** (AlphaEvolve, micro): when a threshold rule keeps flapping, self-review proposes 2–3 candidate values and *evaluates each against history* (events replay) before proposing the winner | 1a | M | low (proposal-only) | a threshold changed ≥2× by hand |
| I5 | **Scenario/skill retrieval**: index `testing/scenarios/` + tools in symbols/doc-find so agents *find* existing executable artifacts before writing new ones (Voyager's retrieval half) | Voyager | S | none | friction report of "rewrote something that existed" |
| I6 | **Loop KPI**: track time-from-finding-to-triage in the ledger; self-review reports it (AIOps MTTR analog) — measures whether the human side of the loop is healthy | AIOps | S | none | ≥5 findings resolved (data exists) |
| I7 | **Replay verification for safe actions** (MOSS's good half): before the ratchet action writes, run the guardrails check in-process against the new value — action + its own verification atomically | MOSS | S | none | next safe-action addition |
| I8 | **LLM-as-interpreter of ambiguous signals** via the SPEC-107 cheap chain (e.g., clustering friction notes semantically instead of prefix-normalization) — opt-in, never authoritative, output = better grouping only | 1a+SPEC-107 | M | medium (first LLM judgment in the loop — needs the no-self-waiver treatment) | friction dedup visibly wrong ≥2× |
| I9 | **Evolution-process audit rule**: self-review checks its own config/ledger for anomalies (rule silently deleted, autoActions flipped, resolved-spam) — the 2606.23075 "verify the evolution process itself" | 1d | S | none | before widening any autonomy |

Explicit refusals re-affirmed with literature now attached: source self-rewriting (DGM/MOSS —
amplification + objective hacking evidence; our human gate is the mitigation the safety
literature recommends); self-scored fitness (reward-hacking corpus); unbounded adaptive
layers (Turing-completeness warning from the automata formalism).

## 4. Mini-glossary (leitura futura barata)

- **MAPE-K**: Monitor–Analyze–Plan–Execute over shared Knowledge; IBM's autonomic-computing
  control loop (2003). Our SE loop is one.
- **Autonomy levels (1–5)**: manual → assisted → semi-autonomous (human approves) →
  supervised autonomous → fully autonomous. Our safe actions sit at 4; proposals at 3.
- **Adaptive automaton / rule-driven device**: simple formal device + adaptive layer whose
  actions modify the device's own rule set at runtime (João José Neto, LTA/USP).
- **Objective/reward hacking**: optimizing the measured proxy instead of the intent (DGM
  removing its own hallucination markers).
- **Amplification**: compounding of vulnerabilities across self-evolution cycles.
- **Archive-based evolution**: keep all variants as potential parents; the best ancestor is
  often not the latest (DGM; our M3.3 in miniature).

## 5. Re-triagem 2026-07-11 — double diamond, segunda ordem

Processo: ideação (como registrada em §3) → embasamento atualizado (6 buscas por
cluster, fontes primárias priorizadas) → auto-crítica com três perguntas fixas
(*a implementação corresponde ao mecanismo que a fonte validou? que evidência nos
faria reverter? o custo de observação se paga?*) → veredito. Regra de governança
inalterada: vereditos "ajustar/novo" são **entrada de triagem humana**, não schedule.

### 5a. Implementados (auto-crítica pós-implementação)

| ID | Embasamento novo (2026) | Auto-crítica | Veredito |
|---|---|---|---|
| I1 MAPE-K naming | O campo está revisando o MAPE-K, não abandonando: [AWARE (FSE'25)](https://dl.acm.org/doi/10.1145/3696630.3728512) critica reatividade/sequencialidade e propõe substituto distribuído; [MAPER (SEAMS'26)](https://conf.researchr.org/details/seams-2026/seams-2026-research-track/26/) estende MAPE-K com reasoner LLM para situações imprevistas; [MAPE-K+LLM é padrão nomeado](https://www.emergentmind.com/topics/mape-k-llm-architecture) | Fiel (era só nomenclatura). Reversão: abandono do MAPE-K pelo campo — não ocorreu. Custo: zero. Nosso loop é deliberadamente reativo/sequencial — na NOSSA escala isso é feature, não limitação | **Mantido**; nota AWARE/MAPER anexada aqui como leitura futura |
| I2 rules-that-propose-rules | A superfície de ataque exata ganhou nome: células Self-Design/Propose→Commit da matriz MLAS ([2606.23075](https://arxiv.org/abs/2606.23075) — designs evolution-native ativam 3,5× mais células; 100% de persistência de ataque; scanners co-locados bloqueiam 2,5%). Ataque novo relevante: [OEP](https://arxiv.org/pdf/2605.18930) — experiências *localmente corretas mas não-transferíveis* envenenam a evolução | Fiel (linguagem de regras fechada + gate humano = a mitigação que a lit recomenda). Reversão: uma regra proposta passar no review humano carregando exploit OEP-style. Lacuna real: propostas não carregam **proveniência** (que finding/dados as geraram) — o humano revisa às cegas contra armadilhas de correção local | ~~**Ajustar (S)**: proposedRule ganha proveniência obrigatória~~ → **shipped 2026-07-11** (`rule-proposal/*` carrega `provenance` {sourceFinding, evidence, generatedAt}; caminho real = recorrência de friction, sempre com proveniência; a acceptance path recusa uma regra `proposedBy: self-review` sem proveniência e a marca `[sem proveniência — não aprovar]`; se_self_review) |
| I3 blast-radius tiers | Convergência industrial total: guias 2026 de remediação prescrevem exatamente tiers + dry-run + rollback + **circuit breaker que para a automação se muitas remediações dispararem numa janela** ([Arvo](https://www.aurorasre.ai/blog/automated-incident-remediation), [Safeguard](https://safeguard.sh/resources/blog/the-case-for-autonomous-remediation-now)) | Fiel nos tiers/dry-run/rollback. Lacuna: não temos o **rate breaker** — N safe actions numa janela deveria travar e escalar (temos o padrão pronto: o circuit breaker de executores) | ~~**Ajustar (S)**: action-rate circuit breaker para safe actions, espelhando `workflow_executor_circuit_*`~~ → **shipped 2026-07-11** (`safe-action-rate-breaker` em self_review.py; execução estrutural travada até resolve; `self_review_safe_action` events são a evidência) |
| I5 skill retrieval | A linha amadureceu: [EvoSkill (2603.02766)](https://arxiv.org/abs/2603.02766) descobre skills de **análise de falhas** com retrieval semântico (+7,3% OfficeQA, +12,1% SealQA, transferência zero-shot); Voyager revalidado em retrospectivas 2026 | Parcialmente fiel: nosso retrieval é lexical (doc-find), não semântico — correto na nossa escala (dezenas de artefatos; determinístico-primeiro). A metade "descoberta-de-falhas" do EvoSkill nós JÁ temos por outro caminho (friction ×2 = tool). Reversão: friction "reescrevi algo que existia" MESMO com doc-find → aí retrieval semântico (gatilho novo, registrado) | **Mantido** com gatilho novo anotado |
| I6 loop KPI | MTTR segue sendo O KPI de loop em AIOps; [Adaptive Data Flywheel (2510.27051)](https://arxiv.org/pdf/2510.27051) aplica MAPE a melhoria de agentes com métricas | Fiel. O funil provou-se vivo esta semana (delegation-cost-trend disparou e foi triado). Custo: uma leitura de estado | **Mantido** |
| I7 replay verification | Virou tese central do stack 2026: [runtime verification para agentes](https://thebackenddevelopers.substack.com/p/runtime-verification-for-ai-agents); dry-run obrigatório nos guias de remediação; MOSS replay em ambientes efêmeros | Fiel (ratchet replay-verificado; wf_failover idem). Regra viva: toda safe action nova nasce com replay — cumprida nas 2 últimas adições | **Mantido** |
| I9 evolution-process audit | O cluster mais fértil: MLAS formaliza ONDE auditar (5 módulos × 5 estágios, [2606.23075](https://arxiv.org/abs/2606.23075)); [MemAudit (2605.23723)](https://arxiv.org/pdf/2605.23723) auditoria post-hoc de memória envenenada; [SSGM (2603.11768)](https://arxiv.org/html/2603.11768v1) governança de memória evolutiva; [Zombie Agents (2602.15654)](https://arxiv.org/pdf/2602.15654) injeções auto-reforçantes persistindo através da evolução | Fiel mas ESTREITO: auditamos config/ledger do self-review, e a lit de 2026 diz que o alvo principal é a **memória evolutiva** — nossos worklog/friction/records são exatamente isso (uma friction note envenenada pode propor uma tool ruim dois ciclos depois) | ~~**Ajustar (S–M)**: estender o audit aos stores de memória evolutiva~~ → **shipped 2026-07-11** (`evolving-store-anomaly/*`: entry-rate spike, single-writer violation vs contrato `records.add_entry`, orphan resolvedIds; report-only, nunca muta; baselines medidos — pico ~24/24h, 4 orphans legados — e stores reais limpos; se_self_review) |

### 5b. Adiados (re-julgamento)

| ID | Embasamento novo | Re-julgamento | Veredito |
|---|---|---|---|
| I4 variant-eval de config | Virou commodity: [AlphaEvolve GA para todos](https://cloud.google.com/blog/products/ai-machine-learning/alphaevolve-is-available-for-everyone) (Klarna 2× throughput, BASF); ecossistema OpenEvolve/ShinkaEvolve/[ThetaEvolve](https://arxiv.org/pdf/2511.23473). O avaliador determinístico continua sendo a peça de carga | O gatilho (threshold mudado ≥2× à mão) não disparou. A evidência fortaleceu a TÉCNICA, não a nossa NECESSIDADE — e a regra do framework é que gatilho governa. Nota: os thresholds TE.2 (1,5×/1,3×/250k) são agora os mais prováveis de flapar — o gatilho ganhou um alvo concreto | **Manter gatilho** (re-armado: vigiar os thresholds TE.2) |
| I8 LLM-interpreter de sinais | Contra-evidência forte e nova: [Reliability without Validity (2606.19544)](https://arxiv.org/abs/2606.19544) — 541k julgamentos, 21 judges: **paradoxo consistência-viés** (test-retest >0,95 coexistindo com viés posicional severo), rankings deslocando 14 posições entre benchmarks; [>50% de erro em testes de viés em modelos de fronteira](https://www.adaline.ai/blog/llm-as-a-judge-reliability-bias); mitigação existe mas parcial ([2604.23178](https://arxiv.org/pdf/2604.23178)) | Nosso desenho (opt-in, não-autoritativo, só agrupamento) antecipou o problema, mas a evidência SUBIU a barra: até "só agrupar" herda viés de estilo/verbosidade — clusters de friction por ESTILO, não substância. Endurecimento gravado: se o gatilho disparar, a adoção exige A/B contra o dedup determinístico numa amostra rotulada à mão; melhora "a olho" não conta | **Manter gatilho + barra endurecida** |

### 5c. Divergência 2 — candidatos novos (nascem com fonte, custo, gatilho e verificação)

| ID | Candidato | Fonte | Custo | Gatilho | Verificação que o aprova |
|---|---|---|---|---|---|
| I10 | **Mapeamento MLAS do nosso loop**: exercício único de docs cruzando nosso SE loop com a matriz 5×5 (módulos × estágios) de 2606.23075 para achar células não-auditadas — o checklist de amplificação que ainda não temos | [2606.23075](https://arxiv.org/abs/2606.23075) | S (docs) | próxima ampliação de autonomia OU próximo safe action novo | a matriz preenchida aponta ≥1 célula sem cobertura → vira item; zero células descobertas também é resultado (registrado) |
| ~~I11~~ **shipped 2026-07-11** | **Zombie-scan determinístico**: regra de self-review procurando conteúdo instrucional/imperativo persistido nos stores evolutivos (friction notes, records, worklog) — a defesa barata contra injeções auto-reforçantes | [Zombie Agents (2602.15654)](https://arxiv.org/pdf/2602.15654); [MemAudit](https://arxiv.org/pdf/2605.23723) | S | junto do ajuste I9 (mesmo alvo) | cenário: nota de friction sintética com payload imperativo é flagrada; notas legítimas não (falso-positivo < N%). `evolving-store-zombie-scan` report-only; `zombieScanPatterns` config; padrões `--approval-token`/fenced-shell estreitados p/ não pegar entradas legítimas do worklog |

Recusas re-afirmadas com a evidência 2026: source self-rewriting (agora com a matriz MLAS
quantificando o porquê: 3,5× superfície, 100% persistência); fitness auto-pontuada (o corpus
judge-bias piorou); camadas adaptativas irrestritas.

## 6. I10 executado — mapeamento MLAS 5×5 do nosso loop (2026-07-11)

Matriz de [2606.23075](https://arxiv.org/abs/2606.23075): 5 módulos × 5 estágios de ciclo
de vida. ✓ = controle estrutural existente; ◐ = parcial; — = célula sem cobertura
(nomeada, com risco avaliado). Preenchida contra o estado real do repo nesta data.

| módulo \ estágio | Bootstrap | Propose | Evaluate | Commit | Serve |
|---|---|---|---|---|---|
| **Brain** (modelo) | ✓ cards+routing humanos | ✓ perfis de roteamento (confirm) | **—** (medimos custo, não drift de qualidade do modelo) | ✓ profile use gated | ✓ permission-mode explícito (R19) |
| **Cognitive Resource** (memória evolutiva) | ✓ head gerado do canônico | ◐ ainda sem validação-na-escrita (auditamos pós-persistência, não na entrada) | ✓ zombie-scan I11 + anomaly-audit I9-adj (rate/single-writer/orphan, pós-persistência) | ✓ caminho único de escrita | ✓ head bounded, derivado |
| **Execution** (ações) | ✓ allowlists/HITL estrutural | ✓ safe-action set fechado | ✓ replay verification (I7) | ✓ tiers (I3) + rate breaker (I3-adj) | ✓ event-logged |
| **Self-Design** (o loop mudando a si) | ✓ rule table declarada | ✓ rules-that-propose-rules human-gated + proveniência obrigatória (I2 + I2-adj) | ✓ audit I9 + I9-adj (anomalias em stores evolutivos) | ✓ gate humano quebra amplificação | ✓ escalations visíveis (HUD/panel) |
| **Collective** (multi-agente) | ✓ subagent contract | **◐ packets do orquestrador não têm revisão própria** (ponto único de confiança) | ✓ verificação blackbox independente (gates + re-run de cenários) | ✓ reviewer no-self-waiver | ✓ delegation ledger + cost watch (TE.2) |

**Células descobertas, nomeadas com veredito:**
1. *Brain×Evaluate* — não medimos drift de qualidade do modelo (só custo). Risco baixo na
   nossa operação (modelos vendor-atualizados; gates pegam regressão de RESULTADO). Gatilho:
   primeira regressão de resultado atribuível a mudança de modelo vendor.
2. *Cognitive×Propose* — a auditoria pós-persistência agora é completa (I11 zombie-scan +
   I9-adj anomaly-audit: rate/single-writer/orphan, ambos shipped), MAS a escrita em
   friction/worklog **ainda não valida conteúdo na entrada** — auditamos depois, não na
   porta. Residual aceito e ainda em pé: a janela entre persistir e o próximo self-review.
   Gatilho para validação-na-escrita (o que falta): primeiro true positive de qualquer
   scan/audit sobre os stores.
3. *Collective×Propose* — os packets do orquestrador (Fable) não passam por revisão; a
   mitigação real é a verificação blackbox do RESULTADO (gates + re-execução independente
   de cenários pelo orquestrador) + relatório lido pelo humano. Residual aceito e agora
   DECLARADO — a literatura pede exatamente isso (verificação minimal-context de
   resultados, não do processo: claude.com/blog/building-multi-agent-systems).

Resultado do exercício: das 2 células ◐, a Cognitive×Evaluate fechou (I11 + I9-adj
shipped 2026-07-11) e a Cognitive×Propose segue ◐ honesta — falta validação-na-escrita;
3 lacunas nomeadas ganharam gatilho explícito, 0 lacunas críticas sem mitigação. I10
**concluído**.

---
*Surveyed 2026-07-09 via web search/fetch; re-triaged 2026-07-11 (double diamond, §5); each
entry carries its link. Cross-links: `SELF_EVOLUTION_REPORT.md`,
`HARNESS_IMPROVEMENT_IDEAS.md` §H/§I/§J, SPEC-109, `IMPLEMENTATION_BACKLOG.md`
(Self-review inbox).*
