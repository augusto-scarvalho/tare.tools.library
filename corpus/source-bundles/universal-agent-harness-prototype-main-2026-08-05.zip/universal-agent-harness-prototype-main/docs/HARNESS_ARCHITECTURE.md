# Harness Architecture

> Scope: architecture of the harness itself; adopting-project architecture belongs in `docs/ARCHITECTURE.md`.

The harness is a lightweight checkpoint, routing, and validation layer for coding agents.

```text
canonical state -> handoff builder -> task classifier -> spawn profile -> executor adapter -> agent run -> validation -> updated state
```

## Layer diagram

```mermaid
graph TB
    subgraph Supervisor["Human / supervising agent"]
        OP[Operator commands<br/>approval tokens, reviews]
    end

    subgraph Canonical[".harness/ — canonical state layer"]
        PJ[project.json<br/>policy surface]
        ST[state/<br/>task, quality, workflow]
        CX[context/<br/>CONTEXT, STATE, NEXT_STEPS, DECISIONS]
        HO[handoff/<br/>generated continuity package]
        RT[routing/<br/>task-profiles, executors]
        PR[prompts/<br/>subagent-contract]
        WF[workflows/<br/>profiles + active packets]
    end

    subgraph Runtime["scripts/ — runtime layer"]
        CLI[harness.py<br/>CLI router]
        LIB[harness_lib/<br/>async_runtime, workflow_reduce,<br/>controlled_writes, processes, handoff,<br/>tracing, state_store, graphify_*]
    end

    subgraph Validation["validation layer"]
        GATE[spec_test_gate.py<br/>45 checks + 31 fixtures<br/>harness_lib/gate_checks_policy + gate_checks_structure + gate_checks_release + gate_checks_content]
        REL[release_integrity.py<br/>package-release.py]
    end

    subgraph Adapters["thin agent adapters"]
        CA[.claude/<br/>agents + hooks]
        CO[.codex/ + codex/<br/>profiles + hooks + shims]
        KI[.kiro/]
    end

    subgraph Executors["executors"]
        EC[codex CLI]
        EL[claude CLI]
        EG[generic / project-defined]
    end

    HK[tools/hooks/<br/>write guard, search guard,<br/>protected files] -. guards tool calls .-> Adapters
    GR[Graphify<br/>graphify-out/ graph + report] -. structural discovery .-> Executors

    OP --> CLI
    CLI <--> Canonical
    CLI --> LIB
    CLI -- spawn-command --> Adapters
    Adapters --> Executors
    Executors -- HARNESS_RESULT / WORKER_RESULT --> CLI
    GATE --> ST
    CLI -. runs gates .-> GATE
    REL -. release evidence .-> Validation
```

## Boundaries

- `.harness/` is generic and canonical.
- `.codex/`, `codex/`, and `.claude/` are adapters.
- Project-specific specs and tasks are optional and live outside the adapter directories.
- Test commands are project configuration, not harness assumptions.

## CLI layout

`scripts/harness.py` is the CLI entry point but no longer the parser mass: the
non-workflow top-level verbs register in `scripts/harness_lib/cli_registry.py`
(MF.1-r2), and the `workflow <cmd>` subcommand tree registers in
`scripts/harness_lib/cli_workflow_tree.py` (workflow-block r2, SPEC-132).
harness.py keeps the `workflow` parent parser, every `cmd_*` handler function,
and dispatch. A new verb is one `add_parser` line in the matching registry
module plus its handler — zero parser edits in harness.py. The gate's
`workflow-command-surface` check scans harness.py + cli_workflow_tree.py and
compares the union against `.harness/project.json`'s declared workflow
commands.

## Agent abstraction layer

The harness routes abstract task profiles to concrete executor configurations, e.g. `implementation` + Codex → GPT profile with high reasoning; `security` + Claude → auditor profile with max effort. A third-party executor is added by extending `.harness/routing/executors.json` and `.harness/routing/task-profiles.json`.

## Per-role context diet (SPEC-118 v5/v6)

A role in `.harness/routing/model-routing.json` may declare a vendor-neutral `contextDiet` block (`vendorUserLayer`, `canonicalReinject`, `keepTools` in capability names — never vendor tool ids). `scripts/harness_lib/context_diet.py` translates the intent into executor flags; non-Claude executors are no-ops. The diet cuts three dead-weight layers for command-driven roles: the vendor user layer (user-scope plugins, −12.0K tok), unused tool schemas (−7.0K), and canonical pack reinjection (−3.8K) — measured 40,264 → 16,520 tok/turn (−59%) on the front-desk chat. Read-only workers get a default trim worth −2,670 tok/turn; a `writeAllowed` worker is never trimmed. Owners edit diets per role on non-canonical profiles via `harness.py routing diet ...` (CLI) or the GUI role editor's "Context diet" section. Spec owner: `specs/40-features/worker-live-tail.md` (SPEC-118 v5/v6).

## Task loop

```mermaid
sequenceDiagram
    actor Op as Operator
    participant H as harness.py
    participant HS as .harness/ state
    participant Ag as Agent (via adapter)
    participant G as Validation gate

    Op->>H: handoff --task "..."
    H->>HS: read task/quality/workflow state
    H->>H: classify task -> profile + risk
    H->>HS: write handoff.json/.md + next-agent-prompt.md
    Op->>H: spawn-command --executor codex|claude|generic
    H-->>Op: concrete agent command (model + effort per profile)
    Op->>Ag: run the agent
    Ag->>HS: required startup reads (handoff, context, state)
    Ag->>Ag: bounded work on the task
    Ag-->>Op: HARNESS_RESULT JSON (evidence, escalation flags)
    Op->>G: harness-test.py <gate>
    G->>HS: update quality-state.json (counts, validatedAt)
    Op->>H: handoff (regenerate for the next agent)
```

## Validation flow

```text
spec / task / acceptance criteria
  -> profile classification
  -> bounded agent execution
  -> targeted validation
  -> HARNESS_RESULT evidence
  -> harness gate summary
  -> compact quality state
```

Expensive gates should be explicit and proportional. Runtime logs and full validation histories belong in ignored `.harness/runs/` files, not in active context.

## Runtime portability

Runtime/interpreter assumptions must follow `docs/RUNTIME_PORTABILITY.md`. Adapters may invoke harness scripts, but must not depend on executor-bundled runtimes or private executor runtimes or implicit local environments. Project runtimes must be configured explicitly.


## Graphify structural discovery layer

Graphify is integrated as a mandatory search/navigation layer, not as canonical state. The harness records graph status in handoff data, asks agents to use Graphify before broad repository search, and requires source verification before edits or final claims. Generated graph artifacts remain ignored by default.

## Workflow packet layer

Large tasks can use `.harness/workflows/` to create map-reduce or fork-join packets. This layer sits above normal task routing and below executor adapters. It creates bounded prompts and compact worker results, then reduces them into a single synthesis.

## Agentic workflow runner

Large context-heavy work can be decomposed through `.harness/workflows/` as map-reduce or fork-join packets. The runner is intentionally conservative: it can execute read-only worker packets with controlled concurrency, capture worker logs, validate `WORKER_RESULT`, reduce results, finalize workflow state, and promote recommended follow-up tasks. Parallel writes are not enabled by the universal harness.

The workflow layer is an extension of the existing router:

```text
large task -> workflow profile -> split strategy -> worker packets -> controlled run -> validation -> reduce -> finalize/promote
```

Use workflow profiles for repeatable scenarios such as repository review, diff review, pre-release review, security triage, coverage-gap inventory, and migration impact mapping.

### Map-reduce workflow lifecycle

```mermaid
sequenceDiagram
    actor Op as Operator
    participant H as harness.py workflow
    participant P as Packet dir (.harness/workflows/active/WF-*)
    participant W as Workers (spawned executors)
    participant R as Reducer

    Op->>H: plan --profile repository-review --task "..."
    H->>P: workflow.json + per-worker packets/prompts (token-budgeted)
    Op->>H: run (blocking) or start/await (durable async)
    H->>W: spawn workers under concurrency caps + run lock
    W->>P: WORKER_RESULT JSON per worker
    Op->>H: validate-results (schema + manual checks)
    Op->>H: reduce
    H->>R: join policy, dedup findings, worker status counts
    R->>P: REDUCE_RESULT (+ optional reviewer packet)
    opt review gate (high-risk profiles)
        Op->>H: review-reduce -> REVIEWER_RESULT validated
    end
    Op->>H: finalize (regenerates handoff)
    Op->>H: promote --to canonical-task (optional)
```

### Controlled-write track

Read-only is the default. Parallel source edits require every step of this track:

```mermaid
flowchart TD
    A[workflow plan --write-allowed<br/>+ approval token] --> B[prepare-write<br/>compute path locks per worker]
    B --> C{lock conflicts?}
    C -- yes --> X[refused — replan scopes]
    C -- no --> D[isolated workspaces<br/>temp copies or git worktrees]
    D --> E[workers edit only locked paths<br/>inside their workspace]
    E --> F[merge-plan<br/>ordered apply plan]
    F --> G[apply-merge<br/>+ validation gate per worker]
    G --> H{gate failed?}
    H -- "yes + rollback flag" --> I[rollback from backups]
    H -- no --> J[final gate]
    J --> K{final gate failed?}
    K -- "yes + rollback flag" --> I
    K -- no --> L[review-merge -> finalize]
```

## Hook and guard layer

Agent adapters wire lifecycle hooks (`.claude/settings.json`, `.codex/hooks.json`) that guard tool calls before they touch the repository:

```mermaid
flowchart LR
    T[Agent tool call] --> PT{PreToolUse}
    PT -- "Edit/Write" --> WG[workflow_write_guard<br/>enforce worker write scope]
    PT -- "Edit/Write" --> PF[protect_files<br/>block secrets/generated state]
    PT -- "Glob/Grep" --> SG[graphify_search_guard<br/>nudge graph-first discovery]
    WG & PF & SG --> D{allow?}
    D -- deny --> R[tool call blocked]
    D -- allow --> X[tool executes]
    X --> PO[PostToolUse:<br/>update_agent_handoff]
    S[Agent stop] --> VS[Stop hook:<br/>validate_before_stop]
```

`protect_canonical_files.py` additionally snapshots canonical instruction files (AGENTS.md, CLAUDE.md, root shims, `.harness/prompts/`) so installer or sync steps cannot silently replace them.

## Layer interactions and supervision

Who reads and writes what:

| From \ To | `.harness/` state | Runtime CLI | Agents | Validation | Supervisor |
|---|---|---|---|---|---|
| **`.harness/` state** | — | read by every command | required startup reads | gates read policy + write quality-state | reads handoff/status |
| **Runtime CLI** | reads policy, writes state/handoff/packets | — | produces spawn commands + prompts | invokes gates | returns JSON for every command |
| **Agents** | read handoff/context; write only via contracts | invoke `harness.py` subcommands | workers never spawn workers | asked to run proportional gates | emit `HARNESS_RESULT` with escalation flags |
| **Validation** | writes `quality-state.json` | invoked via `harness-test.py` | validates WORKER/REDUCE/REVIEWER results | — | pass/fail evidence |
| **Supervisor** | owns intentional edits to protected files | issues all commands | approves spawns, reviews results | decides which gate to run | — |

Interaction with agents is contract-first: adapters (`.claude/`, `.codex/`, `codex/`, `.kiro/`) stay thin and defer to `AGENTS.md`; the JSON shapes in `.harness/prompts/subagent-contract.md` (`HARNESS_RESULT`, `WORKER_RESULT`, `REDUCE_RESULT`, `REVIEWER_RESULT`) are the only way work re-enters harness state. Agents do not change their own model or effort — the harness classifies the task and picks the spawn profile; agents request changes via `requiresEscalation`/`suggestedProfile` instead.

Supervision points, in increasing strictness:

1. **Escalation flags** — any agent can stop and return `requiresEscalation: true` with a `suggestedProfile` instead of widening scope.
2. **Review gates** — high-risk workflow profiles (pre-release-review, security-triage) and merges can require a validated `REVIEWER_RESULT` before finalize.
3. **Approval tokens** — the controlled-write track refuses to prepare, apply, or merge without the explicit `I_APPROVE_CONTROLLED_WRITES` token from the operator.
4. **Protected files** — canonical instruction files are sha256-snapshotted; drift fails gates until the supervisor reviews and regenerates the snapshot.
5. **Deferred autonomy boundaries** — agentic reduction, reviewer execution, and workflow auto-run are deliberately operator-triggered, never automatic (see `docs/HARNESS_TECHNICAL_DEBT.md`, TD-040/041/042).

## Capability assumptions registry (SPEC-103)

Every harness component encodes an assumption about what current models cannot reliably do.
Those assumptions decay: a mechanism that is essential for one model generation is dead weight
for the next (Anthropic long-running-apps: context resets were essential for Sonnet 4.5,
overhead for Opus 4.6; academically, arXiv 2606.25447 — scaffolding interacts with
post-training). This registry names each load-bearing assumption and the signal that says
"re-test it". Components are hypotheses, not permanent fixtures; when a signal fires, re-run
the cheapest experiment that could retire the component instead of tuning it.

| Component | Capability assumption it encodes | Re-evaluate signal |
|---|---|---|
| Worker packet sizing (`maxWorkerOutputChars`, shard splitting) | Models lose coherence past a bounded working set; big tasks must be pre-chunked for them | Workers consistently finishing far under budget, or single-agent runs matching workflow quality on tasks that used to need splitting |
| Context reset per packet (fresh agent per worker, no shared session) | Models cannot maintain reliable state across long sessions; accumulated context degrades output | A model generation where long-session runs stop degrading (compare same task with/without resets); reset overhead dominating small-task latency |
| Skeptical reviewer pass (M3.1: named criteria, no self-waiver) | Generator self-evaluation is biased toward approval; even external reviewers talk themselves into leniency | Reviewer rejections dropping to ~zero while downstream defects also stay zero across a sustained period — the review may have become redundant, or the tasks too easy |
| Task classifier thresholds (keyword scoring + risk tie-breaker) | Models cannot be trusted to self-select scope/effort; the harness must route tasks | Frequent operator overrides of classification, or escalations tagged `specification` caused by mis-routing |
| Pre-implementation contracts (M3.2: criteria before code, medium+ risk) | Models reconstruct "done" after the fact instead of agreeing on it up front | Proposed criteria matching final graded criteria ~always with no mid-task renegotiation — the proposal step may be ritual; or contract overhead dominating medium-task cost |
| Non-linear reduce (M3.3: attempts compared by criteria) | The latest retry is not reliably the best attempt | `attemptSelection` picking `current` in ~all selections over a sustained period |
| Graphify-code-AST-first discovery | Models over-read repositories when unguided; cheap structure beats bulk reading | Context costs per task not dropping when the graph is available, or models navigating better without it |
| Target governance (SPEC-110) | A project governed only from inside its own repo limits agents to one codebase; central governance assumes one harness brain per target | Targets needing their own CI-resident gates (shim demand), or two harnesses contending for one target |
| Self-review loop (SPEC-109, MAPE-K level 3–4) | Improvement signals go unobserved unless a mechanism owns them; humans forget periodic reviews | Findings consistently empty across many runs (repo may have outgrown the rule set), or triage latency growing (human side of the loop unhealthy — see loop KPI) |

Maintenance: when adding a mechanism that constrains agents, add a row here in the same
change. When a signal fires, record the experiment and outcome in
`docs/HARNESS_IMPROVEMENT_IDEAS.md` §C before removing or keeping the component.

## Governance by subject (SPEC-110)

The harness is a governance engine parameterized by *subject*: `self` (its own repo) or any
registered target repository (`.harness/targets/<name>/target.json` — one canonical profile
per project, no file sprawl; secrets stay in the single root `.env` and targets declare key
names only). Per subject: the proportional gate (`harness-test.py <gate> --target <n>` =
generic structural checks + the target's own commands, quality-state + red-check history under
`.harness/state/targets/<n>/`), knowledge (`--target` on graph/discover/doc-find →
`graphify-out/targets/<n>/`), protected-instruction snapshots, and the self-review loop
(target findings in the same escalations funnel; per-target ratchets; layered thresholds;
customRules scoped by `"target"`). Target agents receive deny-by-default env (`requiresEnv`
only) and the on-demand adapter from `targets sync`. Subjects are independent: a red target
gate blocks agents committing to that target, never the harness's own gate.

## Self-evolution loop (SPEC-109) — a MAPE-K instance

The self-review loop is a textbook MAPE-K autonomic control loop (Kephart & Chess, IBM 2003;
see `SELF_EVOLUTION_IDEATION.md` §1b): **M**onitor = `self_review.collect_metrics` over
existing state, **A**nalyze = `evaluate()` against the declarative rules in
`.harness/self-review.json`, **P**lan = findings routed into the supervision funnel
(escalations + backlog inbox), **E**xecute = the closed safe-action set, **K**nowledge = the
durable supervision ledger (`.harness/state/escalations.json`) + self-review state/report.

On the field's five-level autonomy scale (manual → assisted → semi-autonomous →
supervised-autonomous → fully-autonomous), components sit deliberately at:

| Piece | Autonomy level | Why it stays there |
|---|---|---|
| Findings/proposals | 3 — human approves | anti-Hive invariant; amplification threat model (arXiv:2606.23075) |
| Safe actions (ratchet tightening, inbox, own state) | 4 — supervised autonomous, blast-radius tiered, event-logged | deterministic, reversible, closed set |
| Anything touching code/policy/prompts/model chains | 1 — manual only | objective-hacking evidence (DGM marker-removal incident) |

Safe actions carry blast-radius tiers: `tier-0` (own gitignored state), `tier-1` (numeric
config values, never loosening), `tier-2` (tracked docs — the backlog inbox). Widening any
tier or adding an action is a human policy decision, not a rule change.
