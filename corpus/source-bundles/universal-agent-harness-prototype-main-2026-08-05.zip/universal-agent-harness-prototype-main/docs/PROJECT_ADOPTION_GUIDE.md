# Project Adoption Guide

> Scope: harness adoption workflow, not project or harness architecture; see `docs/ARCHITECTURE.md` and `docs/HARNESS_ARCHITECTURE.md`.

Use this guide to adapt the harness to any repository.

## Greenfield project

1. Fill `.harness/project.json` with project metadata.
2. Create the first task from `tasks/TASK_TEMPLATE.md`.
3. Add initial specs under `specs/` if using SDD.
4. Add validation commands to `.harness/project.json` as soon as build/test commands exist.

## Existing project

1. Inspect source roots, test roots, package manager, and build commands.
2. Update `.harness/project.json`.
3. Create tasks that describe the current migration or feature work.
4. Run `scripts/harness-test.sh smoke`.
5. Add project-specific gates incrementally.

## Keeping it generic

Do not hardcode product names, languages, frameworks, vendors, or deployment targets in the harness core. Put project specifics in `.harness/project.json`, `specs/`, `tasks/`, or docs.


## Universal baseline

Do not remove `specs/00-universal/`. It is the default quality/security baseline for every adopted project.

When adapting the harness:

1. Keep universal specs unchanged unless improving the generic baseline.
2. Put product/domain rules under `specs/10-project/`.
3. Put architecture rules under `specs/20-architecture/`.
4. Put language/framework rules under `specs/30-stack/`.
5. Put feature specs under `specs/40-features/`.
6. Put deployment/operations rules under `specs/90-operations/`.


## Validation and coverage adoption

1. Run `./scripts/harness-test.sh --list-detected` to see advisory command suggestions. Do not run detected commands automatically until you trust them.
2. Configure real commands under `.harness/project.json`:
   - `validation.smoke.commands`
   - `validation.commit.commands`
   - `validation.feature.commands`
   - `validation.release.commands`
   - `validation.coverage.commands` or `coverage.commands`
3. Decide coverage mode in `.harness/project.json` and document project-specific rules in `testing/COVERAGE_POLICY.md`.
4. Keep expensive gates out of hooks. Use hooks for guardrails and handoff nudges; run full gates deliberately.
5. For SDD work, ensure tasks map acceptance criteria to tests or explicit manual evidence.

## Runtime portability

Runtime/interpreter assumptions must follow `docs/RUNTIME_PORTABILITY.md`. Adapters may invoke harness scripts, but must not depend on executor-bundled runtimes or private executor runtimes or implicit local environments. Project runtimes must be configured explicitly.


## Graphify adoption

For projects with non-trivial code structure, install Graphify through a project/operator-managed tool environment and generate `graphify-out/` before broad architecture or impact-mapping tasks. Keep generated artifacts out of version control unless the project explicitly decides otherwise.

## Structural discovery cost controls

Adopters should start with Graphify code AST-first discovery before installing external Graphify tooling or enabling any API-assisted enrichment. Keep Gemini API assistance disabled unless the project explicitly opts in for text/image enrichment, sets `GEMINI_API_KEY`, and confirms the configured free-tier model policy is still appropriate for the project account.

## Installing skills, plugins, MCPs, or agent adapters

Before running setup that may write agent instruction files, capture protected-file state:

```bash
python tools/hooks/protect_canonical_files.py snapshot --output /tmp/harness-protected-before.json
```

After setup, verify no canonical instruction files were silently overwritten:

```bash
python tools/hooks/protect_canonical_files.py check --snapshot /tmp/harness-protected-before.json
```

If the check fails, review the diff and convert the change into an explicit harness task. Do not accept generic installer replacements for `AGENTS.md`, `CLAUDE.md`, or root handoff shims.


### Market-recognized agent instruction file protection

The protected-file policy covers not only root `AGENTS.md`/`CLAUDE.md` shims, but also market-recognized instruction files and rule directories used by Codex, Claude Code, GitHub Copilot/VS Code, Cursor, Gemini CLI, Cline, Devin/Windsurf, Roo Code, and harness-owned adapter shims. Optional files are snapshot-if-present: installer creation or overwrite is drift until reviewed and added to `.harness/protected-files.snapshot.json`.
