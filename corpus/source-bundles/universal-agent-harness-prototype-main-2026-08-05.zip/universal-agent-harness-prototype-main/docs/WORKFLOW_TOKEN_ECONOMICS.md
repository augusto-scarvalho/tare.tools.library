# Workflow Token Economics

This document records the reusable harness token-consumption audit by workflow profile/type. The audit is dependency-free and uses the harness estimator configured in `.harness/project.json`: `estimatedTokens = ceil(chars / charsPerToken)`, currently `charsPerToken = 4`.

## Scope and caveats

- Measures generated workflow packets, reducer/reviewer prompts, planned worker-output budget, and observed result payloads when `WORKER_RESULT`/reducer outputs exist.
- Does not claim exact vendor billing tokens; real Codex/Claude/local-tokenizer counts can vary by model.
- Does not include executor-side hidden system prompts, tool-call overhead, or files an agent chooses to open after receiving the packet.
- The goal is regression detection and workflow profile budgeting, not vendor invoice reconciliation.
- `totalPlannedTokens` is the pre-run worst-case budget. `totalObservedTokens` is post-run harness-visible prompt/result payload volume and is expected to be lower before all workers have produced results.

## Implemented guardrails

- `workflow plan` writes token metadata into each worker and the workflow-level `tokenAudit` summary.
- `workflow token-audit <workflowId>` regenerates `reduce/token-audit.json` and `reduce/token-audit.md`.
- `workflow token-audit` without a workflow id aggregates active workflows by workflow type.
- `.harness/project.json` defines global token budgets under `workflows.budgets.tokenBudget`.
- `.harness/workflows/workflow-profiles.json` defines per-profile token budgets.
- The `spec-pack` gate checks token-budget config and per-profile budget presence.
- The `token-budget` workflow fixture now plans every profile at configured `maxWorkers`, writes one compact sample worker result, validates observed-output accounting, and checks by-type rollup.

## Handoff context-pack budget

The harness now applies a separate `workflows.budgets.handoffBudget` for agent startup context. Handoffs use a **minimal-first** layout:

- `requiredReads` contains only the always-needed operating contract/state pack.
- `conditionalReads` contains heavier baseline/spec files that should be loaded only when the routed profile or escalation requires them.
- `contextBudget` records required/conditional read bytes and estimated tokens.
- `contextBudget.budgetDemotedReads` records profile-specific reads that were intentionally moved from required to conditional because they would exceed `maxRequiredReadTokens`.
- changed files in handoff markdown/JSON are capped by `handoffBudget.maxChangedFiles` to prevent large diffs from bloating startup context.

Current template baseline after this burn-down:

| Pack / scenario | Bytes | Estimated tokens | Policy |
|---|---:|---:|---|
| Default required startup reads | 16357 | 4090 | Under `maxRequiredReadTokens=5000` |
| Default conditional spec reads | 13764 | 3441 | Deferred until needed |
| Security task required reads | 19156 | 4789 | Under budget after demoting 4 security/API/privacy specs to conditional reads |
| Implementation task required reads | ~18612 | ~4653 | Under budget after demoting 2 implementation/testing specs to conditional reads |

The `workflow:handoff-context-pack` policy check validates the currently generated handoff context pack. The standalone `handoff-budget` workflow fixture additionally regenerates security and implementation handoffs to prove high-risk profiles stay under the configured required-read budget.

## Per-role context diet (SPEC-118 v5/v6)

Beyond handoff packs, per-turn session context is trimmed per role via `contextDiet` in `.harness/routing/model-routing.json` (vendor-neutral: `vendorUserLayer` / `canonicalReinject` / `keepTools` capabilities, translated by `scripts/harness_lib/context_diet.py`). Measured with haiku probes (per-turn context, not multi-turn observedTokens):

- Front-desk chat full diet: user layer −12.0K tok, unused tool schemas −7.0K, canonical pack −3.8K → **40,264 → 16,520 tok/turn (−59%)**.
- Read-only workers: denying web/agents/plan capabilities saves **−2,670 tok/turn**; denying edit tools (−722) and Skill (±0) was measured and rejected. `writeAllowed` workers are never trimmed.

Configure per role on non-canonical profiles: `python scripts/harness.py routing diet --profile <p> --role <r> [--keep <caps>] [--user-layer on|off] [--reinject on|off] [--clear]`, or the GUI "Routing by role" editor (Context diet section; ✂ badge in the matrix). Details: `specs/40-features/worker-live-tail.md`.

## Baseline by workflow type

| Workflow type | Profiles | Workflows | Workers | Status | Planned tokens | Observed fixture tokens | Avg planned / workflow | Avg observed / workflow |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `fork-join` | `migration-impact-map, pre-release-review, security-triage` | 3 | 15 | `pass` | 23695 | 9049 | 7898 | 3016 |
| `map-reduce` | `coverage-gap-inventory, diff-review, graph-impact-map, repository-review, spec-consistency-review` | 5 | 38 | `pass` | 56834 | 21419 | 11367 | 4284 |

## Baseline by profile

| Profile | Type | Workers | Status | Worker prompt | Max worker prompt | Avg worker prompt | Reducer prompt | Planned output | Total planned | Observed result | Total observed | Budget |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `coverage-gap-inventory` | `map-reduce` | 8 | `pass` | 4273 | 539 | 534 | 118 | 7000 | 11391 | 117 | 4508 | 24000 |
| `diff-review` | `map-reduce` | 8 | `pass` | 4249 | 536 | 531 | 115 | 7000 | 11364 | 117 | 4481 | 24000 |
| `graph-impact-map` | `map-reduce` | 8 | `pass` | 4260 | 537 | 532 | 116 | 8000 | 12376 | 117 | 4493 | 32000 |
| `migration-impact-map` | `fork-join` | 5 | `pass` | 2773 | 555 | 555 | 117 | 5000 | 7890 | 118 | 3008 | 21000 |
| `pre-release-review` | `fork-join` | 5 | `pass` | 2791 | 560 | 558 | 116 | 5000 | 7907 | 118 | 3025 | 21000 |
| `repository-review` | `map-reduce` | 8 | `pass` | 4260 | 537 | 532 | 116 | 8000 | 12376 | 117 | 4493 | 32000 |
| `security-triage` | `fork-join` | 5 | `pass` | 2782 | 558 | 556 | 116 | 5000 | 7898 | 118 | 3016 | 21000 |
| `spec-consistency-review` | `map-reduce` | 6 | `pass` | 3209 | 539 | 535 | 118 | 6000 | 9327 | 117 | 3444 | 24000 |

## Interpretation

- Map-reduce profiles have higher aggregate prompt cost because they can fan out to six to eight workers.
- Fork-join profiles have lower aggregate prompt cost because they normally run five perspective branches.
- In the baseline, worker-output budget dominates total planned tokens more than prompt boilerplate. This is intentional: worker results are bounded and reduced instead of concatenated.
- Observed fixture tokens are lower than planned tokens because the baseline writes one compact sample `WORKER_RESULT` per workflow; real observed output grows as workers settle.
- `diff-review` and `coverage-gap-inventory` use lower output budgets than repository-scale reviews because they should focus on changed/test-gap findings instead of broad narrative.

## Operator playbook

- Run `python scripts/harness.py workflow token-audit <WF-ID>` after planning any unusually broad workflow and again after workers/reducers settle.
- Run `python scripts/harness.py workflow token-audit` to group active workflow economics by `map-reduce` vs `fork-join`.
- If `workerPrompt:max` warns/fails, split oversized shards or reduce `promptBudget.maxPaths`.
- If `workerPrompt:total` warns/fails, lower `maxWorkers`, prefer `changed-files`, or use Graphify partitioning.
- If `plannedWorkerOutput:perWorker` warns/fails, lower `maxWorkerOutputChars` or require finding-only output.
- If `observedWorkerResult:max` warns/fails, tighten `WORKER_RESULT` compactness instructions for that profile.
- If `plannedTokens:total` warns/fails, split the workflow into multiple smaller workflows before reduction.

## Validation commands

```bash
python -m py_compile scripts/harness.py scripts/spec_test_gate.py scripts/package-release.py
python scripts/harness-test.py spec-pack
python scripts/harness-test.py --fixture token-budget
python scripts/harness-test.py --fixture profile-planning
```

## Graphify code AST-first economy

For structural discovery, prefer the Graphify code AST graph before broad source reads or API-assisted summarization. Gemini API assistance is disabled by default and, when enabled by a project, must remain text/image free-tier-only and source-verified. This keeps workflow planning bounded by local graph paths instead of repository-wide token loading.

## Role calibration bake-off (RF.1 phase 1 — observe-only)

Role -> (model, effort) routing is hand-tuned; the bake-off gives one role an
empirical value table without touching routing (spec:
`specs/40-features/role-calibration.md`).

```bash
# dry-run (default): prints the planned matrix, spawns nothing
python scripts/harness.py routing bake-off planner --models opus,fable --efforts high,xhigh --task-cmd "your-task --model {model} --effort {effort}"

# operator-only (real token spend): run the matrix
python scripts/harness.py routing bake-off planner --models opus,fable --efforts high --task-cmd "..." --execute
```

- Quality signal is deterministic: a cell passes iff its command exits 0 — no
  LLM judge (CQ independence).
- `--execute` writes `.harness/state/bakeoff/<utc-ts>.json` and prints the
  table pass-first/cheapest-first plus a `recommended:` line. tokens come from
  the task's stdout result JSON when reported, else null (phase 2 joins the
  `cost_metrics` ledger delta).
- Phase-2 boundary: the recommendation NEVER flips routing. Feeding it into
  `model-routing.json` is owner-gated and stays open; no gate or scenario may
  ever pass `--execute`.

## TE ideation — cost-optimization candidates (research round 2026-07-11)

Trigger: the delegation-cost audit (11 opus rounds, tool-uses 31→101 at constant
~3k tok/use; the 309k SPEC-115 outlier passed unflagged until TE.2). Shipped from
this round: quiet gates/scenarios (TE.1), the `delegation-cost-outlier`/`-trend`
self-review findings (TE.2), the layered verification policy in the subagent
contract (TE.3). Below are the researched candidates for the NEXT rounds — each
carries its source, an estimated gain, and the verification that must gate it
(net-cost-positive rule: an optimization ships only with a measurement proving it).

| # | Candidato | Ganho estimado (fonte) | Verificação que o aprova | Status |
|---|---|---|---|---|
| TE.5 | **Saída agent-facing compacta/tabular**: quando `HARNESS_AGENT_OUTPUT=compact` (setado pelos engines do chat e por packets), harness.py imprime JSON compacto (sem indent) e listas homogêneas (`models list`, `records search`, `targets list`) como TSV/tabela | JSON compacto ≈37% menor que indentado em dados aninhados; TSV ≈62% menor para registros planos (experimento de 9 formatos, jangwook.net; medium.com/another-integration-blog); nossos payloads recorrentes (`status`, `routing show`) são consumidos a cada turno de agente sob OUTPUT_CAP | Fixture determinística: chars/token-estimate dos payloads reais nos dois modos; cenário prova default byte-idêntico | **shipped** (`te_compact_output.py`): compact `routing show` = 73.3% dos chars pretty (aninhado), TSV `models list` = 43.9% (plano); TSV allowlist = `models list/catalog`, `records search/recent`; `targets list` é dict-envelope → JSON compacto (não TSV). Producers: engines do chat só no caminho do agente (`human=False`); packets do worker ficam de fora (orçamento em chars já calibrado) — follow-up |
| TE.6 | **Esqueleto de packet estável para cache**: prefixo fixo (contrato, fatos do repo, convenções) antes do conteúdo dinâmico da tarefa, maximizando prefix-cache hits nas delegações | contexto re-enviado ≈62% da conta (leanopstech); cache read = 10% do preço de input (docs Anthropic via digitalapplied); reestruturar prefixo = zero mudança de API (agentmarketcap) | Telemetria `claude -p`: share de cache_read_input_tokens entre duas rodadas com packet estruturado vs. atual | candidato → backlog |
| TE.7 | **Cascata de modelo para rodadas de baixo risco** (FrugalGPT): rodadas estreitas de GUI/polish vão primeiro a um implementer sonnet high; escalada a opus só em falha de gate/cenário — expressável nos perfis de roteamento SPEC-115 (papel `implementation-light`) | cascatas: até 94% de redução em cenários compatíveis (FrugalGPT via apxml/mindstudio); Playwright E2E (v5.3) derrubou o risco que justificava opus em toda rodada | A/B em 2 rodadas reais de polish: custo total (incl. retrabalho/escalada) vs. média opus equivalente do ledger | candidato → backlog |
| — | Formatos exóticos (TOON/Zen Grid/JTON) | 23–60% vs JSON compacto (logrocket; arxiv 2604.05865) | — | **não promovido**: ganho marginal sobre TE.5 não paga a dependência/novidade (parser fora da stdlib; ecossistema imaturo) |
| — | Paralelizar mais subagentes por rodada | — | — | **não promovido**: overhead multi-agente 3–15× (Anthropic multi-agent research; augmentcode); nosso desenho 1-implementer-por-rodada já é o lado certo dessa curva |

Fontes completas: jangwook.net/en/blog/en/llm-token-cost-data-format-experiment;
medium.com/another-integration-blog (tokenization CSV/JSON/YAML/TOON);
blog.logrocket.com/reduce-tokens-with-toon; arxiv.org/pdf/2604.05865 (JTON);
leanopstech.com (agentic cost runaway); digitalapplied.com (prompt caching 2026);
agentmarketcap.ai (cache hit-rate engineering); claude.com/blog/building-multi-agent-systems;
augmentcode.com/guides/multi-agent-cost-compounding; arxiv.org/pdf/2605.20485 (ZEBRA);
FrugalGPT (arXiv:2305.05176, via apxml/mindstudio surveys).
