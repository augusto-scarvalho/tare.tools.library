# Harness Technical Debt Register

Only live items belong here. Resolved debt history lives in the records ledger (`python scripts/harness.py records recent`).

## Deferred autonomy boundaries

Intentionally not treated as blocking debt: the safety posture keeps expensive or risky multi-agent automation operator-approved.

### TD-040: Agentic reducer execution is prepared/adopted, not automatic

**Status:** Deferred · **Area:** Reducer, semantic synthesis, cost control

`workflow reduce --agent` prepares a compact reducer packet and spawn command; `workflow adopt-agent-reduce` validates and adopts a candidate `REDUCE_RESULT`. The harness does not automatically invoke a real LLM reducer, because automatic agentic reduction increases cost and can mask deterministic evidence unless explicitly requested.

### TD-041: Reviewer execution is prepared/validated, not automatic

**Status:** Deferred · **Area:** Review, safety, human-in-the-loop

`workflow review-reduce` / `workflow review-merge` prepare reviewer packets and validate `REVIEWER_RESULT`. High-risk profiles and controlled-write workflows can block finalization until review is approved, but the harness does not auto-run reviewer agents: that depends on executor availability, cost, and project risk tolerance.

### TD-042: Workflow candidate detection suggests rather than auto-runs workflows

**Status:** Deferred · **Area:** Routing, automation safety

`classify` and `workflow suggest` identify workflow candidates; the harness never auto-runs workflows from classification alone. Multi-agent runs can be expensive, slow, and potentially destructive when write workflows are involved.

## Project-specific calibration items

Not template debts — these must be configured during adoption.

- **PC-001 Executor error mapping** — tune runtime error patterns and retry/backoff for real Codex/Claude/local executors (rate limits, credits, auth, network).
- **PC-002 Validation gates** — map `--validation-gate` / `--final-gate` to meaningful project commands.
- **PC-003 Branch and worktree policy** — choose branch names, base branches, remote policy, cleanup and merge rules for `git-worktree` isolation.
- **PC-004 Graphify adapter tuning** — some projects may need adapters for their exact `graphify-out/graph.json` shape.
- **PC-005 Review policy by domain** — tune which workflow profiles require reducer review, semantic merge review, security review, or human approval.
- **PC-006 Containerized execution** — container isolation is an optional adoption-specific extension (executor/isolation adapter, mount/network/env policy, cleanup). The template does not claim it as built-in.
- **PC-007 Async executor policy calibration** — tune concurrency, queue size, timeouts, retry/backoff, circuit-breaker thresholds, cancellation grace, partial-reduction policy, and cost posture per executor; only conservative safe baselines are hard-coded.
