# Project Architecture

> Scope: architecture of the adopting project; the harness architecture is documented in `docs/HARNESS_ARCHITECTURE.md`.

Use this document as the short current-state architecture index for the adopted project.

Keep it concise. Agents should be able to read this file quickly to understand the system shape before opening more specific architecture specs.

## Recommended content after adoption

- System purpose and primary runtime boundaries.
- Major components, modules, services, packages, or deployable units.
- Important dependency direction rules.
- Data stores, external systems, message flows, or file boundaries.
- Trust boundaries and security-sensitive surfaces.
- Where detailed architecture specs live under `specs/20-architecture/`.

## Content hygiene

Do not turn this file into a long history of decisions. Move historical detail to changelogs, ADRs, or `.harness/context/DECISIONS_ARCHIVE.md`. If the architecture is still unknown, leave this file as an index and create a `scan` or `plan` task to document the current system.
