# Harness Improvement Ideas — Beyond the UI

Living document. Candidate improvements to the harness itself (contracts, evaluation, flow
control, resilience, policy), consolidated from the comparative survey in
`SUPERVISION_UI_IDEATION.md` §3/§3b and from lessons this repo learned about itself. UI/GUI ideas
live in that other document; this one is everything else. When an idea graduates, move it to a
task under `tasks/` and link back.

Each candidate lists: the evidence, where it lands in this repo, and effort/return. Scheduling
lives in `IMPLEMENTATION_BACKLOG.md` (milestones M1–M5 with MVP validation scenarios); this doc
remains the evidence base.

## A. Contracts and specification

MAST (arXiv 2503.13657, Berkeley) found that **specification issues** are one of the three
root-cause classes covering all 14 empirical failure modes of multi-agent systems — and the
Anthropic long-running-apps article converged on the same point from practice.

### A1. Pre-implementation contracts
**Evidence:** Anthropic article — generator and evaluator negotiate "what done looks like" for a
chunk of work *before any code is written*; bridges high-level spec and testable implementation
without over-specifying early.
**Here:** extend `.harness/prompts/subagent-contract.md`: the worker's first output is proposed
acceptance criteria; a reviewer (or the supervisor) approves them before implementation starts.
`HARNESS_RESULT` gains an `acceptanceCriteria` field so the evaluator grades against the agreed
contract, not its own reconstruction of the task.
**Effort/return:** medium / high on large tasks; overhead on small ones — gate it by task
classification, like the validation ladder already does.

### A2. Keep planner output high-level
**Evidence:** Anthropic article anti-pattern — detailed technical specs from planners create
cascading errors; high-level specs with post-hoc contract negotiation (A1) proved superior.
**Here:** a guardrail sentence in the planner-facing prompt(s): product context and architecture,
not implementation detail. Cheap; mostly prompt hygiene.
**Effort/return:** low / medium.

## B. Evaluation and verification

MAST's other big class is **task verification**; the Anthropic article spent most of its tuning
budget here ("out of the box, Claude is a poor QA agent").

### B1. Skeptical evaluator
**Evidence:** Anthropic article — evaluators identify legitimate issues, then "talk themselves
into deciding they weren't a big deal and approve the work anyway"; self-evaluation "confidently
skews positive". Fixes that worked: hard thresholds per criterion (fail one → fail the sprint),
prompts tuned toward proactive edge-case testing, explicit anti-leniency instructions.
**Here:** tune the `reviewer` spawn profile and the `REVIEWER_RESULT` contract: named criteria
with pass/fail thresholds, a required "issues found and why each one does or does not block"
section, and an explicit prohibition on approving with known unresolved blockers.
**Effort/return:** low / high — attacks the documented default bias of the model itself.

### B2. Non-linear reduce
**Evidence:** Anthropic article — later iterations were sometimes *worse* than middle ones;
improvement is non-linear.
**Here:** the workflow `reduce` step should not assume the last worker result is the best of a
retry chain. Keep intermediates comparable (they're already on disk under `WF-*/`); let the
reducer pick by criteria, not recency.
**Effort/return:** low / situational.

### B3. Evaluation proportional to the capability edge
**Evidence:** Anthropic article — "for tasks within [the model's] boundary, the evaluator became
unnecessary overhead; at the edge of the generator's capabilities it continued to give real
lift." Our gate ladder (smoke/spec-pack/commit) already scales verification by blast radius; this
adds a second axis: scale it by task difficulty relative to the model.
**Here:** the task classifier that picks spawn profiles could also emit an "edge-ness" hint that
decides whether a reviewer pass is scheduled at all.
**Effort/return:** medium / medium — needs a workable difficulty signal first.

## C. Model-capability lifecycle

### C1. Assumptions registry
**Evidence:** Anthropic article — "every component in a harness encodes an assumption about what
the model can't do on its own"; context resets were essential for Sonnet 4.5 and dead weight for
Opus 4.6; the sprint construct was removed a model-generation later. Academic backing: arXiv
2606.25447 shows harness scaffolding interacts with post-training and should not be treated as
fixed engineering detail.
**Here:** a section in `HARNESS_ARCHITECTURE.md` (or a small JSON next to
`workflow-profiles.json`): component → the model-capability assumption it encodes → the signal
that it should be re-evaluated. On every model upgrade, walk the registry and stress-test what can
be deleted. Candidates to record first: packet sizing, context-reset-per-packet, reviewer pass,
task classifier thresholds.
**Effort/return:** low / compounds at every model upgrade.

## D. Flow control and human intervention

### D1. Intervention nodes
**Evidence:** Hive — first-class graph nodes that pause execution for human input, with
configurable timeouts and escalation policies. Our human pauses today exist only *between* steps
(handoff → spawn → result); nothing inside a workflow can declare "a human decides here".
**Here:** a `pauseForHuman` step type in `workflow-profiles.json`: blocks the DAG at that point,
surfaces a question, resumes on operator answer, applies a declared fallback (abort / safe
default / escalate) on timeout. Complements — does not replace — the approval-token track.
**Effort/return:** medium / high on long workflows.

### D2. Budget enforcement
**Evidence:** Hive enforces spend limits per team/agent/workflow with automatic model degradation;
our `workflow token-audit` only *reports*.
**Here:** a `budget` field per workflow (and optionally per worker) checked at `start` and between
workers: refuse to launch or continue past the limit, with an explicit operator override.
**Effort/return:** low / high on paid executors.

### D3. Dry-run for the expensive/irreversible commands
**Evidence:** OpenHarness previews resolved settings, auth, skills, and tools before executing
anything.
**Here:** `--dry-run` on `workflow execute` (print resolved packets, spawn commands, estimated
token cost — then exit) and on `workflow apply-merge` (print the merge plan, path locks, and
which backups would be taken — then exit). Both commands already compute this information; the
flag just stops before acting.
**Effort/return:** low / high — it converts "trust me" into "see for yourself" at zero runtime
risk.

### D4. Per-item approval in controlled writes
**Evidence:** OpenHarness per-action permission dialogs; arXiv 2504.17934 argues for in-context
consent at the moment of the risky action rather than blanket upfront authorization.
**Here:** an `--interactive` mode for `apply-merge` stepping diff-by-diff (approve/deny each),
instead of one `I_APPROVE_CONTROLLED_WRITES` covering the whole batch. The batch token remains for
CI/unattended use.
**Effort/return:** medium / high on the riskiest track we have.

## E. Resilience and state

### E1. Named snapshot/restore of a whole workflow set
**Evidence:** OpenRig's `rig down` captures the full topology; `rig up <name>` restores it.
**Here:** we persist per-workflow state already; the missing piece is a named bundle ("save
everything active as `pre-refactor`, restore later"). Probably a thin layer over what
`.harness/workflows/active/` + `state/` already contain.
**Effort/return:** medium / medium — most valuable when several WFs run concurrently, which is
not yet our common case.

### E2. Checkpoints with one-click rollback
**Evidence:** Conductor's automatic snapshots with rollback; Hive's checkpoint-based crash
recovery.
**Here:** we have rollback only inside controlled writes (backups + gate-failure restore). A
lightweight `checkpoint` subcommand (git tag or stash-like snapshot keyed to the workflow id)
would extend that safety to ordinary task flows.
**Effort/return:** low if git-based / medium value; mostly covered when the operator uses git
discipline anyway — verify demand before building. <!-- ponytail: git already does this if the operator commits; build only if real runs show operators don't -->

## F. Policy legibility (lessons from this repo's own history)

### F1. Self-announcing policies
**Evidence:** local experience (2026-07-09). An agent edited `tools/agent-sync/py-run.sh` to probe
`.venv`, violating a documented invariant — and only discovered the violation after an expensive
exploration, because the binding rule lived in a *different file* (`AGENT_SYNC.md`) than the point
of contact. Fix applied: unambiguous header comment at the edit site, the file registered in
`.harness/protected-files.json`, and the block message now carries the registry's
`replacementPattern` as guidance (a field that existed but nothing read).
**Generalized principle:** every invariant should announce itself **where it gets violated** —
comment at the edit site, hook message with remediation, doc last. When adding any new policy,
budget the "point of contact" copy first. F4 extends this to error paths.
**Status:** implemented for `py-run.sh`; the principle applies to future policies. Candidate
follow-up: register `.harness/project.json` the first time someone edits `forbiddenFallbacks`
directly.

### F2. Unambiguous policy wording
**Evidence:** same incident — the phrase "never assumes a private **executor** virtual
environment" invited the false inference "so the *project's* venv is fine". One imprecise word
cost a full exploration cycle.
**Generalized principle:** policy text at the point of contact must name what is forbidden
concretely (including the tempting near-misses), not by category. Audit pass over
`.harness/prompts/` and hook messages for similar near-miss wording is cheap and worth one run.
**Effort/return:** low / medium.

### F3. Loaded prompt language causes convergence
**Evidence:** Anthropic article — "the best designs are museum quality" pushed outputs toward one
visual style. Prompt adjectives are steering vectors, intended or not.
**Here:** one audit pass over spawn-profile prompts and `.harness/prompts/` for superlatives and
aesthetic/quality adjectives that could homogenize outputs.
**Effort/return:** low / low-medium — cheap insurance.

### F4. Self-announcing errors (token economics)
**Evidence:** local experience (2026-07-09), the diagnosis side of the F1 incident. The original
`py-run.sh` error was already *partially* self-announcing — it said to set `HARNESS_PYTHON` — and
diagnosis still cost a full exploration cycle, because it didn't say **why** the PATH interpreters
were being rejected (Store alias stubs failing the version probe) or which fallback was
policy-forbidden. For an LLM agent, a mute or partial error triggers the expensive path: repo
exploration, doc reads, subagents. A complete error ends the diagnosis inside the error itself —
roughly ~50 tokens of reading versus an entire Explore cycle.
**Generalized principle:** every failure message the harness emits (hooks, gates, CLI refusals,
`py-run.sh`) answers three questions in ≤3 lines:

```
<what failed>
cause: <the policy or state that produced it>
fix: <the sanctioned remediation — exact command when one exists>
```

**Where to apply first (cheap sweep):** hook block messages (partially done via
`replacementPattern`, F1); workflow CLI refusals (locks, blocked reduce, missing approval token);
gate failures. Each should carry the remediation command that today lives only in
`OPERATOR_GUIDE.md` §8 — that troubleshooting table is proof the information exists but lives far
from the error that needs it.

**Gates and tests are the highest-value target, and the cheapest.** Every one of the ~266 checks
in `scripts/spec_test_gate.py` routes through a single choke point — `result()`
(`spec_test_gate.py:66`), which prints `✗ <name>: fail — <detail>`. Today `detail` says *what*
("missing", a bare exception string), never cause or fix. Because check names are namespaced
(`protected-files:*`, `runtime-portability:*`, `release-hygiene:*`…), a small remediation map
keyed by name prefix, consulted inside `result()` on `fail`, retrofits the cause/fix format onto
every existing and future check at once — no per-check edits. The agent reading a red gate then
sees `fix: python tools/hooks/protect_canonical_files.py snapshot` inline instead of grepping the
gate source to learn what the check wanted. Same applies to fixture assertions: a failing fixture
should state the expected/actual contract it tested, not just its name.
**Limit:** three lines, not a manual — over-verbose errors become noise and recreate the
cognitive-load failure mode the oversight literature warns about (`SUPERVISION_UI_IDEATION.md`
§3b). G2 is the success-path twin of this pattern (outcome + state + next action).
**Effort/return:** low / high — it converts every future failure from an exploration into a read.

## G. Observability

### G1. MAST failure tagging
**Evidence:** MAST's three root-cause classes (specification / inter-agent misalignment / task
verification) achieved κ=0.88 inter-annotator agreement — they are legible categories, usable by
an agent at report time.
**Here:** one optional field in `HARNESS_RESULT`/`WORKER_RESULT` (`failureClass`) plus the same
tag on gate failures. The escalation queue (and any future UI) groups by root cause; trends over
time show which layer of the harness needs work.
**Effort/return:** low / compounds with usage.

### G2. CLI replies with outcome + state + next action
**Evidence:** OpenRig's CLI pattern, designed for dual human/agent consumption: every command
reports what happened, current state, and the suggested next command.
**Here:** `harness.py status` half-does this. Make it uniform across subcommands — the "next
action" line is also what a supervision UI would render as its primary button.
**Effort/return:** low / medium, and it benefits agents as much as humans.

## H. Anti-patterns we explicitly keep refusing

Recorded so future contributors don't "fix" these on purpose:

- **Self-evolving topology** (Hive): on failure the system rewrites its own DAG and redeploys.
  Directly contradicts our contract that agents never change their own scope/profile — failure
  escalates to a human (`requiresEscalation`), it does not self-modify.
- **Self-evaluation as the only evaluation** (Anthropic article): generation and judgment stay
  separated; the generator's own "it works" is never sufficient evidence.
- **Harness as settled infrastructure** (arXiv 2606.25447): the opposite of C1 — components are
  hypotheses about model limitations, re-tested per generation, not permanent fixtures.
- **Auto-discovering project runtimes** (this repo, 2026-07-09): convenience fallbacks that guess
  at `.venv`/`node_modules` hide environment defects and violate `runtime.python.forbiddenFallbacks`;
  the sanctioned override (`HARNESS_PYTHON`) stays explicit.

## I. Platform & runtime integrity (SPEC-108 lessons)

Debt class found while hardening on Windows/stdlib-only installs — each entry is an incident,
not a speculation:

- **Silent capability no-ops are illegible failures.** `jsonschema` missing meant documented
  runtime validation never ran, with no signal. Fixed: `status` and result payloads expose
  `schemaValidation: active|inactive`. Rule: any optional dependency that gates a documented
  behavior must announce its absence in the surface that behavior serves.
- **Text-mode writes are platform-dependent writes.** Windows text mode rewrites LF as CRLF
  while `.gitattributes` pins `eol=lf`; hashed/committed artifacts drift and fixtures false-fail.
  Fixed: shared writers force `newline="\n"`; fixture backup/restore cycles round-trip bytes.
  Rule: writers of committed or hash-checked files never use platform-default newline handling.
- **Cleanup must be a command, not a convention.** Manual deletion of test-workflow residue
  failed twice (once leaving an empty dir that tripped release-hygiene). Fixed:
  `workflow scrub` owns the whole footprint (active/ + state-store mirror + empty parents)
  and refuses non-terminal phases. Corollary found while building it: event mirroring can
  resurrect a directory mid-deletion (tracing writes workflow-local spans), and rmtree on
  OneDrive-synced trees needs retries.
- **events.jsonl growth** — no rotation; Deferred with trigger: file >1MB or `escalations`
  noticeably slow.
- **Provider chains are perishable config** (M2W live ops, 2026-07-09): 5 model ids died
  within ~24h of being researched — timeouts, empty-graph responders, 404s despite catalog
  listing. Rule: any config derived from measurement (model chains, latency orderings) needs
  a re-measurement command, or it silently becomes fiction. Backlog: P1 `providers probe`;
  facts recorded in SPEC-107 "Operational findings".
- **Cleanup and freshness must not fight** (SPEC-108 H5 retro): `cleanup_test_artifacts`
  deletes `graphify-out/` at every gate start while the freshness check rebuilds it — the
  gate repairs what it deletes (~1s, acceptable today). The manual rebuild standard existed
  precisely because of this hidden fight. Rule: when a check keeps "fixing" the same state,
  find who keeps breaking it — it is usually another part of the same system. Deferred:
  stop deleting graphify-out (trigger: rebuild >~2s).

- **Stringly-typed dependency injection needs its own static check** (MF.1 r2 / HT
  execution, 2026-07-09): the `bind(env)` idiom that enabled all the fragmentation passes
  dependencies as dict keys — three latent-NameError incidents in one day (try-imported
  `jsonschema` invisible to top-level AST scan; runtime re-exports via EXPORTED_FUNCTIONS;
  an anchor patching the wrong env dict), each only detectable at runtime on the exercised
  path. Rule: an idiom that removes static resolution must be paired with a gate check that
  restores it (QA.1: bind-env completeness verified by AST at gate time). The idiom stays —
  it paid for the burn-down targets — but unverified it is a defect class, not a pattern.

## J. Token economy (proactive review 2026-07-09, user directive)

Standing lens for every future review: agents should communicate through shortcuts, not by
re-reading large surfaces or reprocessing data. Principles extracted from measured findings:

- **Write-only artifacts are pure waste.** `docs-enrichment.json` cost ~100k free-tier tokens
  to build and had zero consumers. Rule: any artifact the harness produces must have a named
  consumer (command, check, or prompt) in the same milestone — otherwise don't produce it.
- **Navigation beats reading.** The AST graph parses every function name and then discards the
  line numbers, so agents grep after every lookup anyway. Indexes (symbol → path:line,
  topic → doc#section) turn O(file) reads into O(1) jumps. Backlog: MF.3, MF.4.
- **Ratchets that never tighten are decoration.** `maxHarnessLines: 5200` against 3,625 actual
  lines means growth is invisible until it is a crisis; `spec_test_gate.py` got within 61
  lines of its ceiling unnoticed. Rule: after every extraction, lower the max to actual+10%;
  a burn-down target without enforcement does not burn down.
- **Friction performed twice is a tool not yet written.** The protected-edit dance (allow-env,
  edit script, snapshot, check) ran 3× in one day; five scenario runners copy the same 40
  lines. Rule: the second manual repetition of a multi-step dance is the trigger to wrap it.

## What the survey validated (do not break)

- **File-based handoffs and contracts** as the only way work re-enters harness state — the
  Anthropic article's core mechanism, OpenRig's CLI-only writes, MAST's spec-failure evidence all
  point the same way.
- **Context reset over compaction** — fresh agent per packet is the article's recommended
  mechanism for long tasks.
- **Proportional validation** (gate ladder) — matches the article's "evaluator is overhead within
  capability, lift at the edge".
- **Declarative workflow profiles** (`workflow-profiles.json`) — AutoGen Studio's declarative JSON
  spec is the same bet, independently validated at 200k downloads.
- **Protected canonical files** — OpenHarness's path-level deny rules are the same idea; ours adds
  hash snapshots.

---
*Consolidated 2026-07-09 from the survey in `SUPERVISION_UI_IDEATION.md` (§3 projects, §3b
academic sources) plus this repo's own incident history. Effort/return ratings are judgment
calls, not measurements.*
