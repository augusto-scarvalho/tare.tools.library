# Workflow Operations Runbook

This runbook explains how to operate agentic map-reduce and fork-join workflows in the universal harness.

## Operating principles

- Workflows are read-only by default.
- Concurrent execution does not grant edit permission.
- Workers may write only their `WORKER_RESULT` file and runtime logs.
- The reducer synthesizes worker findings; it must not concatenate long worker outputs.
- `workflow finalize` produces a workflow-level `HARNESS_RESULT` and updates compact context by default.
- Use `--concurrency 1` until the executor adapter is known to be safe and rate-limit tolerant.

## Common commands

Create a workflow:

```bash
python scripts/harness.py workflow plan --profile repository-review --task "Review the repository"
```

Inspect planned workflows:

```bash
python scripts/harness.py workflow list
python scripts/harness.py workflow status
python scripts/harness.py workflow status WF-YYYYMMDD-HHMMSS-ffffff
```

Preview worker execution:

```bash
python scripts/harness.py workflow run WF-YYYYMMDD-HHMMSS-ffffff --executor claude --dry-run
```

Audit token budget before execution:

```bash
python scripts/harness.py workflow token-audit WF-YYYYMMDD-HHMMSS-ffffff
python scripts/harness.py workflow token-audit
```

The workflow-specific command writes `reduce/token-audit.json` and `reduce/token-audit.md`; the no-id form aggregates active workflows by type. Use it before broad or expensive workflows to catch prompt bloat, excessive planned worker output, observed worker-result verbosity, and reducer/reviewer prompt growth. See `docs/WORKFLOW_TOKEN_ECONOMICS.md`.


Run pending/missing workers:

```bash
python scripts/harness.py workflow run WF-YYYYMMDD-HHMMSS-ffffff --executor claude --concurrency 1
```

Resume only missing/incomplete workers:

```bash
python scripts/harness.py workflow resume WF-YYYYMMDD-HHMMSS-ffffff --executor claude --concurrency 1
```

Validate and reduce:

```bash
python scripts/harness.py workflow validate-results WF-YYYYMMDD-HHMMSS-ffffff
python scripts/harness.py workflow reduce WF-YYYYMMDD-HHMMSS-ffffff
```

Finalize and update compact context:

```bash
python scripts/harness.py workflow finalize WF-YYYYMMDD-HHMMSS-ffffff
```

Promote reducer recommendations into task drafts:

```bash
python scripts/harness.py workflow promote WF-YYYYMMDD-HHMMSS-ffffff
```

## Locks and interruption recovery

`workflow run` creates `.harness/workflows/active/<workflow>/.run.lock` so the same workflow is not executed twice at the same time.

If a process is interrupted and the lock is stale:

```bash
python scripts/harness.py workflow unlock WF-YYYYMMDD-HHMMSS-ffffff --stale-only
```

If human inspection confirms the lock is stale but the process still appears active:

```bash
python scripts/harness.py workflow unlock WF-YYYYMMDD-HHMMSS-ffffff --force
```

## Round limits

The harness enforces `maxRounds` to prevent retry loops. When the limit is reached, inspect the reducer output before continuing. Only after human review:

```bash
python scripts/harness.py workflow resume WF-YYYYMMDD-HHMMSS-ffffff --force-round
```

## Placeholder executors

The `generic` executor is intentionally non-runnable. Configure `.harness/routing/executors.json` before real runs. Use `--allow-placeholder` only for local harness testing.

## When to increase concurrency

Use `--concurrency 2+` only when:

- workers are read-only;
- the executor adapter is configured;
- rate limits are understood;
- worker scopes are independent;
- runtime logs are acceptable outside Git.

Do not use ordinary concurrent workers for source edits. Parallel writes must go through the controlled-write path with explicit approval, locks, isolated temp-copy or git-worktree workspaces, merge plans, rollback, and validation.

## Hardened read-only pipeline

A full read-only map-reduce workflow can be run step-by-step or with `workflow execute`. Prefer the step-by-step form while tuning a project executor:

```bash
python scripts/harness.py workflow plan --profile repository-review --task "Review repository"
python scripts/harness.py workflow run WF-... --executor claude --concurrency 2
python scripts/harness.py workflow validate-results WF-...
python scripts/harness.py workflow reduce WF-...
python scripts/harness.py workflow finalize WF-...
python scripts/harness.py workflow promote WF-...
```

`workflow reduce` now refuses to run while a workflow has an active run lock or queued/running workers. Use `--allow-partial` only after confirming that the active run should not continue. `workflow finalize` regenerates the handoff by default; use `--no-regenerate-handoff` only when preparing a reusable template snapshot.

Concurrency is capped by `.harness/project.json` `workflows.agentRuntimeLimits`. A request such as `--executor claude --concurrency 8` is reduced to the configured Claude cap. Runtime/rate-limit signals in stdout/stderr mark workers blocked when `stopOnRateLimit` is enabled.

## New maturity commands

Ask the harness whether a task should become a workflow before planning it:

```bash
python scripts/harness.py workflow suggest --task "Full audit of repository consistency"
python scripts/harness.py classify --task "Full audit of repository consistency"
```

Plan changed-file reviews with explicit diff sources:

```bash
python scripts/harness.py workflow plan --profile diff-review --split changed-files --diff-scope staged --task "Review staged changes"
python scripts/harness.py workflow plan --profile diff-review --split changed-files --base origin/main --task "Review branch changes"
python scripts/harness.py workflow plan --profile diff-review --split changed-files --range abc123..def456 --task "Review commit range"
```

Use pause points for controlled end-to-end execution:

```bash
python scripts/harness.py workflow execute --profile repository-review --task "Review repo" --executor claude --pause-before-reduce
```

Prepare optional semantic review packets after deterministic reduction:

```bash
python scripts/harness.py workflow reduce WF-... --agent --executor claude
python scripts/harness.py workflow review-reduce WF-... --executor claude
```

Promote recommendations into canonical task files only after review:

```bash
python scripts/harness.py workflow promote WF-... --to canonical-task
```

Replay workflow events during troubleshooting:

```bash
python scripts/harness.py workflow events WF-...
python scripts/harness.py workflow events WF-... --worker-id worker-003
```

## Executor validation

Before running a project-specific executor, validate adapter coverage:

```bash
python scripts/harness.py executor validate
python scripts/harness.py executor validate claude
```

Executors can provide `defaultSpawn` as a fallback when a task profile does not define an executor-specific spawn mapping.

## Reviewer gate validation

For high-risk profiles, run `workflow review-reduce WF-... --executor <executor>` after reduction, save `reduce/reviewer.result.json`, then validate it with:

```bash
python scripts/harness.py workflow review-reduce WF-... --validate-existing
```

If a profile enforces review, `workflow finalize` will block until the reviewer result is valid and approved, unless `--skip-review` is used after explicit human approval.


## Controlled write operations

Use controlled writes only after a bounded plan and explicit approval. The safe sequence is: `workflow plan --write-allowed --approval-token ...`, `workflow prepare-write`, `workflow run`, `workflow merge-plan`, `workflow apply-merge --approval-token ...`, and, if needed, `workflow rollback`. See `docs/CONTROLLED_PARALLEL_WRITES.md`.


## Audit hardening notes

Reducer/reviewer packet commands now return `preparedOnly: true` and `executionRequired: true` when the harness prepares a packet but does not invoke an external agent. `workflow execute` returns the effective run validation at top-level `validation` for easier automation. Use `python scripts/harness-test.py --clean-fixtures` to remove stale test-created workflow fixtures after interrupted local gate runs.

## Async-await operations

Use `workflow start` for non-blocking worker execution:

```bash
python scripts/harness.py workflow start WF-... --executor claude --concurrency 4 --mode all-settled
```

Operational checks:

```bash
python scripts/harness.py workflow async-status WF-...
python scripts/harness.py workflow watch WF-... --follow
python scripts/harness.py workflow collect WF-... --recover
```

Settlement:

```bash
python scripts/harness.py workflow await WF-... --mode all-settled --timeout 1800
python scripts/harness.py workflow reduce WF-... --allow-partial
```

Cancellation/recovery:

```bash
python scripts/harness.py workflow cancel WF-... --reason "operator stop"
python scripts/harness.py workflow cancel WF-... --worker-id worker-002
python scripts/harness.py workflow async-recover WF-...
```

Do not run `workflow reduce` while the async supervisor lock is active unless you intentionally allow partial reduction after collecting settled tasks.


## StateStore mirror

Inspect the workflow state-store mirror and recovery metadata with:

```bash
python scripts/harness.py workflow state <WF>
```

The workflow packet files remain the canonical human-readable state, while the state-store mirror provides a local recovery boundary.
