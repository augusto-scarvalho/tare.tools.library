# Graphify Integration

Graphify is the mandatory structural discovery layer for this harness template. The economical default is Graphify-code-AST-first: Graphify builds or uses a dependency-free pure-AST code graph before any external/API-assisted discovery. This reduces broad search, improves impact mapping, and keeps agent context focused.

## Architecture rule

Graphify is the structural discovery layer. The harness remains the canonical state and routing layer. Source files, specs, tasks, tests, and Git remain authoritative.

```text
handoff -> Graphify status/report/query -> focused source reads -> edit/review -> HARNESS_RESULT
```

## Required policy

Use **graphify-code-ast-first, source-verified** for non-trivial repository discovery:

1. Check `.harness/handoff/handoff.json` and `.harness/project.json.knowledgeGraph` for graph status and policy.
2. Prefer Graphify code AST discovery first. If `graphify-out/graph.json` is missing and `graphifyAst.autoBuildWhenMissing=true`, generate it with `python scripts/harness.py graph-build-code-ast`.
3. If `graphify-out/GRAPH_REPORT.md` exists, read it before broad search.
4. Use Graphify query/path/explain operations when the task is architectural, cross-file, dependency-oriented, security-oriented, or unfamiliar.
5. Verify findings by reading source/spec/test/config files.
6. Report usage in `HARNESS_RESULT.contextDiscovery.graphify`.

## When raw search is still allowed

Raw search is allowed for exact strings, newly created or unindexed files, test/log output, source verification after a graph query, missing/stale graph cases, and tiny single-file edits.


## Cost policy: Graphify code AST before Gemini

The universal template must prefer deterministic Graphify code AST structure before paid or rate-limited APIs:

1. **Graphify code AST first.** `scripts/harness_lib/graphify_code_ast.py` builds `graphify-out/graph.json` and `GRAPH_REPORT.md` from Python AST using only the standard library. This is Graphify-owned code graphing, not an LLM replacement for Graphify.
2. **Existing Graphify artifacts second.** If project/operator-generated Graphify output exists, the adapter may use it for richer graph shapes.
3. **Gemini API text/image free tier only, opt-in.** API-assisted enrichment is disabled by default and is limited to text/image summarization or non-authoritative graph-gap notes. It must not be used as the primary code graph builder. When a project enables it, it must use configured free-tier/budget models, require `GEMINI_API_KEY`, avoid network calls by default, and never silently switch to paid tier.
4. **Source remains authoritative.** Gemini text/image summaries or Graphify summaries are navigation aids only; source/spec/test/config verification is mandatory.

## Discovery wrapper (SPEC-107): `harness.py discover`

`python scripts/harness.py discover <paths...>` is the single cheap entrypoint that enforces the
cost policy mechanically instead of by prose:

- **code (`.py`)** → local pure-AST graph rebuild, never an API (`forbiddenInputKinds` honored in
  code);
- **text (md/txt/json/yaml/…)** and **images (png/jpg/webp/gif)** → the provider chain from
  `knowledgeGraph.apiAssistedProviders.order`: Gemini free tier
  (`llmAssisted.enabled` + `GEMINI_API_KEY`), then NVIDIA Build free credits
  (`apiAssistedProviders.nvidia.enabled` + `NVIDIA_API_KEY`, key from build.nvidia.com).
  Keys live in the OS vault (`harness.py keys set NAME`; real env wins,
  `HARNESS_NO_VAULT=1` disables injection) — the `.env` tier was removed, SPEC-169 v2;
- **anything else** → refused with a reason.

Each provider is a sibling script under `tools/graphify/` (`gemini_extract_fallback.py`,
`nvidia_extract_fallback.py`) sharing the stdlib OpenAI-compatible client
(`tools/graphify/openai_compat.py` — both providers expose the same `/chat/completions` shape).
The client retries transient failures (429/5xx/timeouts, honoring `Retry-After`) —
`GRAPHIFY_API_RETRIES` total attempts (default 3) with exponential backoff, per-request timeout
`GRAPHIFY_API_TIMEOUT` seconds (default 180). Exhausted retries fall through to the next model in
the chain, then to the next provider. Provider errors are redacted before printing. Results land in
`graphify-out/docs-enrichment.json` / `image-enrichment.json` plus a routing report at
`graphify-out/discover-report.json`.

**Fail-safe:** when no provider is available, the per-file status is `refused` with a
what/cause/fix message naming the exact dependency to provision — the sanctioned manual fallback
is *focused* raw search on the named paths. The expensive coder LLM (Claude/Codex) is never the
bulk reader; that is the wrapper's reason to exist.

**Cache and doc-find (MF.4):** extraction is per-file with a sha256 cache
(`graphify-out/discover-cache.json`) — unchanged files never hit an API twice, so re-running
`discover` over the whole docs tree is free after the first pass. Enrichment sidecars carry
per-file provenance (schema `discover-enrichment/v2`), and
`python scripts/harness.py doc-find <topic terms>` answers "where is X documented" with ranked
file pointers plus the matched concepts — read only the hits instead of the docs tree.

## Runtime policy

Graphify must be installed and managed by the project/operator. The harness must not silently install it or depend on Codex/Claude/private agent runtimes.

Allowed examples:

- project-managed tool environment;
- operator-managed PATH installation;
- CI-managed tool installation.

Forbidden defaults:

- hardcoded user or OS paths;
- private executor virtual environments;
- silent installation during an implementation task.

## Generated artifacts

Generated Graphify artifacts are ignored by default:

- `graphify-out/GRAPH_REPORT.md`
- `graphify-out/graph.json`
- `graphify-out/graph.html`
- `graphify-out/symbols.json` — flat index `symbol name -> ["path:line", ...]` for every
  Python function/class (MF.3). Agents: check it before grepping for a definition — it turns
  an O(repo) search into one lookup. Rebuilt with the graph (gate-owned freshness).

A project may intentionally version selected artifacts, but that must be a local project decision, not a universal harness default.

## Subagent guidance

The harness spawns bounded subagents by profile. Graphify is not a replacement orchestrator. Each subagent should use Graphify only as part of its context-discovery phase, then verify source files before acting.


## Graph adapter metadata

Graphify workflow planning now records `graphAdapter`, `graphNormalizer`, and `normalizationStatus` in partition metadata. This makes generic adapter behavior visible and leaves a stable extension point for project-specific `graph.json` formats.

## CLI

- `python scripts/harness.py graph-status` shows graph policy, Graphify code AST settings, the optional Gemini text/image free-tier policy, and whether an external `graphify` tool is on PATH (`externalGraphifyTool`).
- `python scripts/harness.py graph-build-code-ast` generates a Graphify code AST graph for Python code files without installing Graphify or calling the network.
- `python scripts/harness.py graph-build-code-ast --gemini-doc <path>` additionally runs opt-in Gemini text enrichment on the named doc(s) through the free-tier model fallback chain, writing a non-authoritative sidecar `graphify-out/docs-enrichment.json`. It refuses unless `knowledgeGraph.llmAssisted.enabled` is true and `GEMINI_API_KEY`/`GOOGLE_API_KEY` is set in the environment.

## Gemini model fallback chain

`tools/graphify/gemini_extract_fallback.py` wraps Gemini extraction with a model fallback chain so a rate-limited or retired preview model degrades to a stable free-tier one instead of producing an empty result. Chain resolution: `--models` → `GRAPHIFY_GEMINI_MODELS` env → `knowledgeGraph.llmAssisted.models` in `.harness/project.json` → built-in default. The API key is read from the environment only; committed key files are never used. Run `python tools/graphify/gemini_extract_fallback.py --selftest` to validate the fallback ordering offline.

When a project/operator installs the external Graphify tool (for multi-language AST and richer analysis), `.graphifyignore` at the repo root controls what enters the graph; the harness adapter already normalizes external `graph.json` shapes.
