# Harness Content Guide

This package is a reusable template. Keep the core generic and move project-specific knowledge into project folders.

## What belongs in the core

- `.harness/` continuity, routing, state, and prompts.
- `specs/00-universal/` language-agnostic quality and security baseline.
- generic templates under `tasks/`, `specs/`, `schemas/`, and `testing/`.
- executor adapters under `.codex/`, `codex/`, `.claude/`, and `.harness/routing/`.

## What does not belong in the core

- product names, domain rules, customer workflows, regional policies, historical execution logs, local settings, generated caches, vendor-specific build/test assumptions, or long status reports from a previous project.

## Where project-specific content goes

- product/domain rules: `specs/10-project/`;
- architecture and boundaries: `specs/20-architecture/`;
- language/framework conventions: `specs/30-stack/`;
- feature behavior: `specs/40-features/`;
- deployment/operations: `specs/90-operations/`;
- task execution plan: `tasks/`;
- project metadata and commands: `.harness/project.json`.

## Efficiency rules

- Startup context should stay short and current.
- Handoff should point to relevant files instead of embedding long histories.
- Generated logs belong in `.harness/runs/` and are ignored by Git.
- Audit/review reports should not be part of the reusable template unless they describe reusable policy.
- Optional compatibility packs should stay minimal and must not introduce stack assumptions into the core.


## Minimal-first handoff rules

- Keep `requiredReads` limited to the operating contract and current state needed to start safely.
- Put broad baseline/spec files in `conditionalReads` unless the selected profile clearly needs them immediately.
- Cap changed-file lists in handoff output; agents can inspect Git directly when they need the full set.
- Record byte/token estimates in `handoff.json.contextBudget` so context growth is visible in validation.

## Anti-bloat module rules

- Agents should read `scripts/harness.py` only for CLI/router behavior. Domain-specific implementation review should jump directly to the owning module under `scripts/harness_lib/`.
- Reducer/reviewer behavior lives in `scripts/harness_lib/workflow_reduce.py`; token accounting lives in `workflow_token_audit.py`; async runtime lives in `async_runtime.py`; controlled writes live in `controlled_writes.py`.
- Do not paste long worker logs or historical burn-downs into prompts. Prefer compact reducer inputs, result JSON paths, and bounded Markdown summaries.
- New docs that describe a completed burn-down must end with a compact status and link to evidence rather than duplicating full logs.
