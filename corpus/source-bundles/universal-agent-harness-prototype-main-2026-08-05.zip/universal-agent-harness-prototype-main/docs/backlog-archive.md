# Implementation Backlog Archive — shipped history

> History moved from `docs/IMPLEMENTATION_BACKLOG.md` 2026-07-19; source of
> truth = `git log` + the records ledger (`python scripts/harness.py records
> recent --kind milestone`). Nothing here is actionable; the live backlog
> keeps only open/actionable items + PARK/DEFER + ideation.

This file preserves, verbatim: the whole `## Recently shipped` log (including
its LOOP QUEUE subsections), the self-review inbox + loop-surfaced items, the
`## LOOP QUEUE 7 — FECHADA` closure, and every shipped (`~~...~~`/✅) roadmap
table row moved out of the live backlog tables.

---

## Recently shipped (staleness guard — source of truth is `git log` + the records ledger)

Do NOT re-propose these; they are landed in source. Verify at the named commit before planning on top.

⚠️ **SLICE DISCIPLINE:** many rows below shipped only their FIRST PHASE (an *observe-only* / *slice* /
*half* of a larger roadmap item). Shipping a slice does NOT close the parent item — the remaining
phases stay OPEN in the CE/DW/CQ/SEC/roadmap sections below and must still be built. Do NOT treat an
"observe-only" or "slice" entry as a complete feature. Specifically still-OPEN follow-ons:
CQ.1 → gate-DEPTH-selection/enforce (only the risk-tier *classifier* is observe-only-landed);
~~security-baseline → block/route ENFORCE~~ RESOLVED: security-diff-routing shipped (ROUTE, 2026-07-13 loop);
DW.4 → adaptive AUTO-FORK (only the `--explain` verdict landed; recommendedWorkers is hard-1);
MF.1-r2 → workflow-block extraction r2 (only the NON-workflow parser table moved);
SEC.2 ratchet is complete but SEC.3–SEC.7 remain; CQ.2 capsule is complete but CQ.4/CQ.5 remain.
- **2026-07-12 (this session, batch 1-3):** CE.1 containment fix, CE.2 economy meter, CE.3 handles-lint, en-gui-strings,
  DW.1 fan-out secret-scan + trustTier, DW.3 graph-shape metrics, en-default-guard (SPEC-122), DW.2 typed
  workflow.json IR, gate gitignored-skip (F1), workspace-state-exclusion, worktree-admin pruner (`tools/prune_worktrees.py`, F2),
  MF.1-r2 CLI registry extraction (`harness_lib/cli_registry.py`), security-baseline-mvp (observe-only), CPT-drift self-only calibration.
- **2026-07-12 (this session, batch N+3 = SEC/CQ/DW spine, Fable-xhigh implemented):** SEC.1 pre-egress gate (`discovery.py`),
  CQ.1 risk-tier classifier observe-only, CQ.3 provenance record (finalize), DW.4 topology-router `--explain` (observe-only).
- **2026-07-12 (this session, infra):** argv0 registry-PATH resolution fix (stale-launcher PATH); executors multi-vendor —
  codex worker card fixed (`exec`), new `gemini-compat` cheap tier (both verified with a live gemini→codex research smoke).
- **2026-07-12 (loop, batch N+4):** SEC.2 security-regression ratchet (spec_test_gate, security['new']∩changed), CQ.2 optional
  oracleEvidence QA capsule (WORKER_RESULT schema + result_contracts + SPEC-121), repo-health `doctor` verb (SPEC-123, via cli_registry, zero harness.py edits).
- **2026-07-12 (loop, batch N+5):** SEC.3 control-plane liveness healthcheck (6 declared controls, SPEC-125), spec-index read-only
  inventory verb (SPEC-124, via cli_registry), spec-retrofit (SDD specs for the 5 pre-rule landed features DW.2/SEC.1/CQ.1/CQ.3/DW.4).
- **2026-07-12 (loop, batch N+6):** gate-lines-burndown r1 (6 structure checks → harness_lib/gate_checks_structure.py, spec_test_gate 1985→1822),
  RF.2 research-admin verb (`research list`/guarded `delete`, SPEC-125 research-admin — cosmetic dup vs the SEC.3 report label; files distinct),
  RF.1 phase-1 role-calibration bake-off runner (observe-only; phase 2 routing feedback stays OPEN + owner-gated).

- **2026-07-13 (loop, batch N+7):** OB.1 failure-pattern clustering verb (SPEC-126, via cli_registry), mr-hermeticity fix
  (`cli:spawn-command-canonical` now active-profile-aware, 18/18 under fable-max AND canonical; model-routing.md v1.1), UX-GA.1
  deterministic risk-summary strip above the Attention bay (additive `riskSummary`, GUI-writes-no-state, ui_e2e 19/19 real chromium).
- **2026-07-13 (loop, batch N+8):** UX-GA.2 grouped fan-out worker cards (additive `workerGroups`, ui_e2e 20/20 real chromium),
  OB.2 per-model/agent delegation cost+latency trend (extends the TE.2 trend family, SPEC-128), docs-tree-printer read-only verb
  (SPEC-127, via cli_registry), gate-lines-burndown r2 (release-hygiene → harness_lib/gate_checks_release.py, spec_test_gate 1822→1660).
  FOLLOW-UP (found N+8): the panel snapshot-key-set assertions (rs-3/wg-3) are exact-equality → every new additive key edits a sibling
  scenario; refactor to subset/`in` checks or a shared key registry. Small; loop-eligible.  [RESOLVED in N+9 — rider on UX-GA.3.]
- **2026-07-13 (loop, batch N+9):** UX-GA.3 phase-1 evidence bundle + `workflow evidence` verb (SPEC-129, handles-not-bodies; GUI half
  DEFERRED), config-keys-cli phase-1 read-only masked inventory (SPEC-130; config-set write is phase 2, owner-gated), gate-lines-burndown r3
  (4 content checks → gate_checks_content.py; spec_test_gate 1660→1495, ~490 off the original 1985 across r1–r3). Rider resolved the N+8 key-set follow-up.
- **2026-07-13 (loop, batch N+10 — LAST clean deterministic Fable batch):** UX-GA.3 phase-2 panel evidence drill-in + `/api/evidence`
  (CLOSES UX-GA.3; UX-GA.4 LLM-explain still deferred), OB.3 deterministic anomaly card (SPEC-131; the opt-in LLM explanation half stays
  deferred), workflow-cli-tree extraction (SPEC-132 — all 44 workflow parsers → `harness_lib/cli_workflow_tree.py`, harness.py 3235→3144,
  ZERO `wsub.add_parser` left; the harness.py CLI burndown is COMPLETE).

- **2026-07-13 (owner session, panel-chat QoL — SPEC-133):** chat markdown GUI (`MD` module, /vendor HL reuse) +
  CLI (`md_ansi.py`), multiline textarea w/ `/paste` framing, gates last-run age + honest metrics tiles (total/today;
  session dim added to the cost ledger), records-ledger header + escalation-resolve producer, branch chip sha+dirty,
  and the **plan/question event contract** (`plan`/`question` frames + `/approve` + `postPlanMode` pref — the stable
  capture surface for future approval UIs/tabs; codex approval passthrough + dedicated tab stay DEFERRED in the spec).
  Acceptance `qol_panel_chat.py` 12/12; ui_e2e 27/27 real chromium.

**▶️ LOOP RESUMED 2026-07-13 03:09 (owner AFK ~7h, window ends ~10:09 -03:00).** The N+10 pause reason no longer
holds: owner decisions 1–5 (2026-07-13) refilled the ready pool with P1 items. Fable works the **LOOP QUEUE** below
directly (one item per batch → spec SPEC-116 + scenario + doc + gate green → commit → next). Attention points become
open escalations for owner review — never silent scope expansion. Stop only on app/host-destroying risk.

### LOOP QUEUE 3 — 2026-07-13 PM (continuation; same roles/rules as QUEUE 2)

| # | item | lane | plan brief |
|---|---|---|---|
| Q8 | gui-research-screen (ðŸ”¬ Research panel gallery) | opus | `.harness/handoff/plan-q8-panel-research-screen.md` |
| ~~Q9~~ ✅ | ~~rec-wf-15/16 scrub-guard coverage~~ shipped (codex gpt-5.6-sol, wsg 3/3, kept 100%) | codex | `.harness/handoff/plan-q9-scrub-coverage.md` |
| ~~Q11~~ ✅ | ~~rec-chat-9..17,19 chat tail batch~~ shipped (Opus 4.8, rct 5/5, honest source-pins for inline guards) | opus | `.harness/handoff/plan-q11-chat-tail-batch.md` |
| ~~Q12~~ ✅ | ~~cm-4 ledger legibility tooltip~~ shipped (codex gpt-5.6-sol, surgical 7-line diff, LAST loop iteration) | codex | `.harness/handoff/plan-q12-ledger-tooltip.md` |

### Backlog de cobertura TOTAL do artigo (2026-07-18)

O manuscrito inteiro (3.218 linhas) foi destrinchado item a item em
`docs/research/article-coverage-backlog.md` — status ✅/🟡/⬜/🔬/🅿️/⛔ por item.

**▶️ ORDEM DE EXECUÇÃO CANÔNICA (2026-07-18):** a seção final daquele doc
("ORDEM DE EXECUÇÃO DO BACKLOG INTEIRO") é a fila mestra — itens derivados novos
(enablers E-*, tasks T-*, EXP-21, rodadas RD-*) + o backlog aberto INTEIRO
ordenado por dependência em Fases 0-5. Começar pela FASE 0. Esta LOOP QUEUE 7
abaixo é o subconjunto do artigo; a fila mestra a engloba e sequencia com os
near-bugs e o backlog clássico.

### LOOP QUEUE 7 — 2026-07-18 (pós-rodadas D012; ordem por CRITICIDADE, owner-delegada)

As 5 rodadas D012 fecharam (R1-R5 commitadas). Owner: "começa a elaborar os
planos, ordem sequencial por criticidade". Ordem decidida pelo overseer por
criticidade (severidade do gap que fecha), NÃO por facilidade. Cada linha
aponta seu plano elaborado. Implementação começa do topo; um item por vez,
ritual de review por completion. Perguntas salvas em cada plano (índice durável
`docs/research/lq7-implementation-briefs.md`).

| # | item | por que aqui (criticidade) | plano | tamanho |
|---|---|---|---|---|
| Q7-1 | **harness-own sandbox SB-1/2/3** (SPEC-151) | P0 — buraco de contenção REAL: worker open-model escreve/spawna sem confinamento (defense-stack s5 §7.4; requisito multi-vendor+open-models). Segurança > tudo | `specs/40-features/harness-own-sandbox.md` (SPEC-151) + intake | L |
| Q7-2 | **C1 constantes de decisão + graus de evidência** | governança fundacional barata — dá rigor a TODA promoção/experimento futuro; regra lexicográfica (segurança nunca trocada) é o princípio central §15 | `.harness/handoff/plan-lq7-c1-methodology-constants.md` | S |
| Q7-3 | **C18 route churn probe + C6 CTS** | measure-before-control (§4.2/§9.5): churn é pré-req da histerese C9; CTS confirma economia de delegação. Baratos, measure-only | `plan-lq7-c6-cts.md` + brief C18 (abaixo) | S |
| Q7-4 | **C3 capability support-states** (SPEC-113 amend) | formaliza degradação honesta native/emulated/degraded; consumido pelo manifest do sandbox E pelo EXP-20 (lane nativo = emulated) | `.harness/handoff/plan-lq7-c3-capability-states.md` | S |
| Q7-5 | **C2 residual risk register** (SPEC-152) | governança de risco §7.5/§14.7 — CONSOME a saída do Q7-1 (o sandbox fecha o risco "HTTP sem contenção"), então vem depois | `.harness/handoff/plan-lq7-c2-residual-risk-register.md` | S-M |
| Q7-6 | **C5 métricas do serviço de aprovação** | observabilidade §7.7 (anti-fadiga mensurável); polish, sem desbloquear nada crítico | `.harness/handoff/plan-lq7-c5-decide-metrics.md` | S |
| Q7-7 | **C19 Π-lite + C20 recovery probes** | measure-only §3.5/§5.7; menor urgência, alimentam o M-frame interno | brief conjunto (abaixo) | S-M |

**OWNER-GATED (não entram na fila — precisam de decisão sua):** EXP-20 medição
(muda default de topologia), enforcement de memória governada (N6 trigger),
route regret/ECE (precisam da função de utilidade U + campo predictedP no router).

### LOOP QUEUE 6 — 2026-07-18 (pós-decisões D009-D011)

D009 (codex nativo D+E, paridade sempre), D010 (largura paramétrica), D011
(M-produto parkeado). Ordem: smoke D primeiro (desbloqueia E), D010 barato
(playbook, MF.7 do overseer — protected) e plumbing depois.

| # | item | lane | plan/nota |
|---|---|---|---|
| ~~L14~~ ✅ | ~~EXP-19: smoke fork-join NATIVO do codex~~ shipped 1d62e97 (aposta D PROVEN; PING consolidado; nomes underscore; toml não carrega sob exec) | overseer (execução de experimento) | EXP-19 no registry |
| ~~L15~~ ✅ | ~~D010 barato: regra de largura no research-playbook~~ shipped 1d62e97 (Phase 0 declara modo+largura+justificativa) | overseer via MF.7 (protected) | inline |
| ~~L16~~ ✅ | ~~D010 plumbing: largura paramétrica no workflow plan/profiles~~ kept + overseer rework (Opus; escalação honesta do worker: enforcement quebrava 6 callers → regra por-construção p/ branches explícitos + flags nos fixtures wv/dw1; rs 32/32, wv 7/7, m5 87/87) | opus | `.harness/handoff/plan-l16-parametric-width.md` |
| ~~L17~~ ✅ | ~~aposta E: paridade SPEC-113 agent profiles~~ kept (Opus; 9 tomls rendered + call-params exec-surface de UMA derivação; ap 17/17; 1 correção do overseer: prosa falsa sobre workflow_spawn_command_for_prompt no spec) | opus | `.harness/handoff/plan-l17-aposta-e-parity.md` |
| ~~L18~~ ✅ | ~~livraria de métodos + advisory + 3ª declaração + grade Taguchi EXP-18~~ shipped 9e9c1fc (wave 2); grade Taguchi RODADA nesta sessão: regra B recall 0.6 (<0.8 promoção) → detector segue measure-only | sonnet miner → opus builder → overseer MF.7 | probe `testing/probes/exp18_taguchi_grid_probe.py` |

### LOOP QUEUE 5 — 2026-07-18 PM (as 3 apostas finais; owner: "implementa todas, começando da que deixa as próximas mais fáceis")

Ordem: C3 epoch (vocabulário de identidade que os demais herdam) → hook-trust
(paralelo, disjunto) → noise floor (herda epoch; gatilho EXP-18). Mesmas regras.

| # | item | lane | plan brief |
|---|---|---|---|
| ~~L11~~ ✅ | ~~SPEC-149 ownership epoch~~ kept 75ccda1 (Opus; chokepoint único workflow_update p/ sync+async; oe 4/4) | opus | `.harness/handoff/plan-l11-ownership-epoch.md` |
| ~~L12~~ ✅ | ~~SPEC-150 codex hook-trust~~ kept 75ccda1 (Opus; decisão congelada + gatilho de reabertura; sc-5) | opus | `.harness/handoff/plan-l12-hook-trust.md` |
| ~~L13~~ ✅ | ~~A3 noise floor~~ kept f8c3f0a (Opus; piso do EXP-18 = cosine range 0.33/stdev 0.12; metodologia wirada) | opus | `.harness/handoff/plan-l13-noise-floor.md` |

### LOOP QUEUE 4 — 2026-07-18 (article leftovers; owner "bora loop"; overseer Fable)

Ref: `docs/research/harness-reference-architecture-adoption.md`. N5 unlocked (SPEC-148
sandbox_spawn tiers are the consumer that was missing). EXP-15 control change stays
OWNER-GATED — L6 is the measure-only probe. Same rules: disjoint footprints, one
integration at a time, review ritual per completion, workers never commit.

| # | item | lane | plan brief |
|---|---|---|---|
| ~~L1~~ ✅ | ~~N5 risk tiers R0-R3~~ shipped fba2fe2 (Opus 4.8, kept; hsb-10 + rt-18; R3-unreachable reality pinned) | opus | `.harness/handoff/plan-l1-risk-tiers.md` |
| ~~L2~~ ✅ | ~~approval SLO + expiry~~ shipped fba2fe2 (codex sol, kept + overseer rework: flag relocation, di-8b mutant kill, invariant+map) | codex | `.harness/handoff/plan-l2-approval-slo.md` |
| ~~L3~~ ✅ | ~~replay-class nos eventos~~ kept (Opus; 2 chokepoints reais + 2 bypass writers fechados pelo overseer; rce 3/3; oracle reforçado) | opus | `.harness/handoff/plan-l3-replay-class.md` |
| ~~L4~~ ✅ | ~~trace-completeness report~~ kept feb73f3 (Opus; advisory doctor check 9 + rht-1; overseer wirou riskTier no emit do dispatch — sem isso nunca dispararia ao vivo) | opus | `.harness/handoff/plan-l4-trace-completeness.md` |
| ~~L7~~ ✅ | ~~route ledger durável + demandId~~ kept 8732dbb (Opus; demo ao vivo: 9 rows keyed sobrevivendo ao wipe; 3 catches do overseer incl. kill-switch anti-poluição de corpus) | opus | `.harness/handoff/plan-l7-route-ledger.md` |
| ~~L5~~ ❌ | ~~EXP-17 regret probe~~ REJECTED em review: o probe JA EXISTIA (era N4, 271 linhas, superior); brief pulou covered-check (defeito do overseer), codex clobberou sem reportar — revertido, outcome rejected. Medicao rodada no instrumento real: corpus transiente vazio, zeros honestos | codex | `.harness/handoff/plan-l5-regret-probe.md` |
| ~~L6~~ ✅ | ~~EXP-15 dedup PROBE~~ kept (codex; hipótese de normalização REFUTADA — 0 merges; convergência é parafrástica; recomendação: não mexer no reduce) | codex | `.harness/handoff/plan-l6-dedup-probe.md` |

### LOOP QUEUE 2026-07-13 (priority-ordered; strike items as they land)

Ordering rationale: (A) items the owner explicitly decided/unblocked come first — demand is proven;
(B) the security/isolation spine the roadmap itself marks "most urgent"; (C) Wave-0 collectors that
unblock GUI screens; (D) self-review-inbox maintenance as filler. Deps are inlined — never start a
child before its dep row.

| # | item | tier | size | why here |
|---|---|---|---|---|
| ~~1~~ ✅ | ~~`security-diff-routing`~~ shipped (loop AFK batch 1, 2026-07-13) | A | S | P1, owner decision #1 (ROUTE + FP exemption registry); named entry point for the future pipeline |
| ~~2~~ ✅ | ~~`tasks-board-read`~~ shipped (loop AFK batch 2, 2026-07-13) | A | M | high-pri collector; dep of #3 |
| ~~3~~ ✅ | ~~`tasks-store-cli`~~ shipped (loop AFK batch 3, 2026-07-13); GUI `tasks-move` action + A2 enqueue stay OPEN | A | M | owner decision #3 (tasks.json canonical + TE.5 compact rider; markdown tables freeze post-import) |
| ~~4~~ ✅ | ~~`config-keys-cli` phase 2~~ shipped (loop AFK batch 4, 2026-07-13); `config-keys-gui` stays OPEN | A | M | owner decision #2 (keyring vault backend, `keys set` via stdin, `.env`→vault migration verb) |
| ~~5~~ ✅ | ~~`esc-subject-scope`~~ shipped (loop AFK batch 5, 2026-07-13) + rider: ratchet replay-scope bugfix | B | M | subject primitive on escalations (records half landed); dep of #6 and esc-scoped-hitl-view |
| ~~6~~ ✅ | ~~`isolation-audit-gate`~~ shipped (loop AFK batch 6, 2026-07-13); escalation raised: workflow gate has 7 PRE-EXISTING reds (protected-files drift needs owner review) | B | M | dual-subject deterministic gate; the enforcement half of the isolation round |
| ~~7~~ ✅ | ~~`svc-registry-mvp`~~ shipped (loop AFK batch 7, 2026-07-13); P1 autostart + P2 MCP wiring stay OPEN; ponytail entry waits on the MCP-transport owner decision | B | M | service bootstrap (ponytail MCP case); its dep win-hidden-spawn-helper landed |
| ~~8~~ ✅ | ~~`perf-metrics-rung`~~ shipped (loop AFK batch 8, 2026-07-13) | C | S | P1, no deps; `durationMs` on gates, self-measured |
| ~~9~~ ✅ | ~~`security-baseline-targets`~~ shipped (loop AFK batch 9, 2026-07-13) | C | S | P1; run the landed baseline against governed targets via gate_generic |
| ~~10~~ ✅ | ~~`docs-audit-refs`~~ shipped safe half (loop AFK batch 10, 2026-07-13); B1 SPEC-105-ghost ESCALATED (decision #4 pending) | C | S | P1; CHANGELOG refs + scope banners are safe — the SPEC-105-ghost half ties owner decision #4: if it exits the SPEC-116 freeze, ESCALATE and ship the rest |
| ~~11~~ ✅ | ~~`chat-tool-chips`~~ shipped (loop AFK batch 11, 2026-07-13) | C | M | P1; unlocks chat-plan-hud (owner decision #5 TodoWrite PERMIT) |
| ~~12~~ ✅ | ~~`chat-plan-hud`~~ shipped (loop AFK batch 12, 2026-07-13) | C | M | P1 once #11 lands; decision #5 unblocked it |
| ~~13~~ ✅ | ~~`queue-view-live`~~ shipped (loop AFK batch 13, 2026-07-13) | C | M | high-pri collector; unlocks queue-cancel-worker + queue-start-action (decision #1 approved) |
| ~~14~~ ✅ | ~~`CAP.1`~~ shipped (loop AFK batch 14, 2026-07-13) | C | M | high-pri capabilities snapshot + `agents skills`/`agents mcp` CLI |
| ~~15~~ ✅ | ~~`research-index`~~ shipped (loop AFK batch 15, 2026-07-13) | C | M | P1 collector for the research gallery |
| ~~16~~ ✅ | ~~`M5.rec`~~ shipped (loop AFK batch 16, 2026-07-13) | C | M | records & changelogs screen collector (diff/code viewer reuse) |
| ~~17~~ ✅ | ~~`ui_panel.py` fragmentation~~ shipped (loop AFK batch 17, 2026-07-13): 1473 → 851 + ui_composer 158 + ui_actions 279 + ui_chat_bridge 275, re-exports keep callers unchanged; inbox finding cleared (next over-budget: async_runtime 1009) | D | M | self-review inbox: 1470 lines > 900 budget (MF discipline) |
| ~~18~~ ✅ | ~~`esc-scoped-hitl-view`~~ shipped (loop AFK batch 18, 2026-07-13) | B | M | after #5; scoped escalation view + guarded resolve |
| ~~19~~ ✅ | ~~`queue-cancel-worker`~~ shipped (loop AFK batch 19, 2026-07-13) | C | S | after #13 |
| ~~20~~ ✅ | ~~`security-directive-map`~~ shipped (loop AFK batch 20, 2026-07-13) — **QUEUE COMPLETE** | C | S | P2 security round closer |

Below-the-line (pool for the loop if the queue empties): DW.5, SEC.4, CE.4, M5.mem, M5.sum,
graph-provider-abstraction, graphs-metrics-cli, no-raw-subprocess-gate, svc-autostart-owners,
svc-mcp-wiring, en-docs/en-comments, OB.4, wiki-sources chain, handoff-subject-confinement,
per-target-token-calibration, subject-tagged-events, gui-specs/research screens, CAP.2/3.
OWNER-GATED (do NOT start): RF.1 phase 2, CQ.1 enforce, DW.4 auto-fork, security-baseline
block-vs-route beyond #1's scope, target-worker-world (open decision #2), pyo3-accel-prototype.

**GATE DEBT — PAID (owner-reviewed 2026-07-13):** ~~`harness-line-budget` 3173 > 2961~~ ✅
burned down same day (codex-drafted trace trio kept after overseer review; whitespace-stripping
and mojibake rewrite REJECTED and reverted; overseer completed honestly: `cmd_workflow_tail` →
`workflow_observability.py`, `write_worker_prompt` → `worker_prompt.py`, 2922 ≤ 2961, workflow
gate 514/0). The other 04:14 reds were cleared same-day: protected-files (CRLF-only drift,
re-smudged from git, no re-snapshot), function-size-budget (3 splits), baseline catalog+index
(sdd-bdd-flow.md entries). **Executor-adapter follow-ups (from the codex run):** (a) codex exec
under a background pipe hangs waiting stdin EOF — adapter should launch with stdin closed;
(b) codex ≥0.144 ignores project-local `.codex/config.toml` `profiles` — the adapter's
model/effort pinning silently no-ops (ran gpt-5.6-terra/medium instead of gpt-5.5/high).

**CODEX NO LOOP (owner decision 2026-07-13; adapter fixed: executor-spawn-hygiene / esh):**
the implementation loop MAY delegate a first draft to codex for items that are M-sized and
mechanical (extractions, collectors, migrations, doc sweeps) or explicitly marked `[codex-draft]`.
Protocol, validated end-to-end on harness-lines-burndown:
1. Brief file at `.harness/handoff/codex-<item>-brief.md`: hard constraints (frozen surfaces,
   static-integrity boundary greps, function-size budget, NO `git add/commit`, no protected
   files/specs/state), verify commands spelled with `.venv\Scripts\python.exe`, deliverable =
   `codex-<item>-result.md`, revert-and-report if the target is unreachable honestly.
2. Launch with stdin CLOSED (`$null | codex exec ...` — an open pipe hangs it) using the routed
   model/effort flags (`--model X -c model_reasoning_effort=Y`; project-local `.codex` profiles
   are IGNORED by codex ≥0.144). `--sandbox workspace-write` is the overseer's interactive launch
   only; workflow-runtime workers stay `read-only` per the executor card.
3. Overseer review is MANDATORY before commit: diff every file; hunt metric gaming (the burndown
   draft "paid" 325 lines by stripping blank lines) and encoding damage (grep `â€”` — the draft
   mojibake'd every non-ASCII char); rerun the item's scenarios + spec-pack + workflow gate
   yourself; revert what is not honestly earned; log spend via `harness.py delegation`.
4. Codex never commits. The overseer commits, recording kept/rejected in the message.

### LOOP QUEUE 3 — 2026-07-13 PM (continuation; same roles/rules as QUEUE 2)

| # | item | lane | plan brief |
|---|---|---|---|
| Q8 | gui-research-screen (ðŸ”¬ Research panel gallery) | opus | `.harness/handoff/plan-q8-panel-research-screen.md` |
| ~~Q9~~ ✅ | ~~rec-wf-15/16 scrub-guard coverage~~ shipped (codex gpt-5.6-sol, wsg 3/3, kept 100%) | codex | `.harness/handoff/plan-q9-scrub-coverage.md` |
| ~~Q11~~ ✅ | ~~rec-chat-9..17,19 chat tail batch~~ shipped (Opus 4.8, rct 5/5, honest source-pins for inline guards) | opus | `.harness/handoff/plan-q11-chat-tail-batch.md` |
| ~~Q12~~ ✅ | ~~cm-4 ledger legibility tooltip~~ shipped (codex gpt-5.6-sol, surgical 7-line diff, LAST loop iteration) | codex | `.harness/handoff/plan-q12-ledger-tooltip.md` |

### LOOP QUEUE 2 — 2026-07-13 PM (owner AFK)

Roles (owner-corrected): **the overseer (Fable) writes EVERY plan** — design decisions made,
file footprint fixed, spec skeleton + check list included — and hands it as a brief; **Opus 4.8
xhigh** and **codex gpt-5.6-sol high** both implement full items from those briefs (CODEX NO
LOOP protocol for codex: closed stdin, workspace-write, never commits). Parallelization is the
overseer's risk to manage: pairs run concurrently ONLY with disjoint file footprints declared
in the briefs; one merge/gate/commit at a time, by the overseer. OWNER-GATED untouched.

| # | item | lane | plan brief |
|---|---|---|---|
| ~~Q1~~ ✅ | ~~rec-wf-4/13/14 workflow-gates coverage batch~~ shipped (Opus 4.8, plan-exact + honest divergence pin) | opus | `.harness/handoff/plan-q1-wf-gates.md` |
| ~~Q2~~ ✅ | ~~OB.4 failure-focused trace digest (`trace --digest`)~~ shipped (codex gpt-5.6-sol, plan-exact, kept 100%) | codex | `.harness/handoff/plan-q2-trace-digest.md` |
| ~~Q3~~ ✅ | ~~rec-chat-4..8 chat-contract coverage batch~~ shipped (Opus 4.8, 3 honest plan-vs-code pins) | opus | `.harness/handoff/plan-q3-chat-contracts.md` |
| ~~Q4~~ ✅ | ~~M5.sum records summarize (deterministic stub path)~~ shipped (codex gpt-5.6-sol, plan-exact, kept 100%) | codex | `.harness/handoff/plan-q4-records-summarize.md` |
| ~~Q5~~ ✅ | ~~cm-3 option-select-as-form investigation~~ CLOSED verified-shipped (P8/9c50dbf; residual = codex-stream-parity row) | overseer | 47a8f52 |
| ~~Q6~~ ✅ | ~~backlog stale rows + P-11 wording + rec-cli-9/12 notes~~ shipped (codex gpt-5.6-sol, kept 100%) | codex filler | `.harness/handoff/plan-q6-docs-refresh.md` |
| ~~Q7~~ ✅ | ~~gui-specs-screen (📋 Specs panel view, SPEC-134)~~ shipped (Opus 4.8, 4 honest plan-vs-code pins incl. spec-number allocation) | opus | `.harness/handoff/plan-q7-panel-specs-screen.md` |

**POST-LOOP (owner-requested 2026-07-13):** ~~`ckpt` context checkpoint + post-compact reinjection~~ ✅
shipped — root cause: the SessionStart hook read `.harness/context/*.md` and printed only a banner
(hook stdout IS the injection channel; content was discarded) and nothing produced fresh state into
STATE.md/NEXT_STEPS.md. Fix pair: `checkpoint` verb (bounded inflight block in NEXT_STEPS.md, redacted,
carry-over fields) + hook now prints the real mtime-badged/capped content. Spec `context-checkpoint.md`
+ `context_checkpoint.py` 4/4 + docs/CONTEXT_CHECKPOINT.md.

**LOOP FOLLOW-UPS — RESOLVED:**
- ~~`mr_model_routing.py` `cli:spawn-command-canonical` non-hermetic to fable-max~~ FIXED in N+7 (active-profile-aware, 18/18 both profiles).
- ~~stale PT assert `"execu"` in ui_panel self-check (post SPEC-122)~~ FIXED in N+7 (UX-GA.1, `"running"`).
- **Prior (Fable re-verified landed, rows below may still read open):** win-hidden-spawn-helper,
  target-gate-env-filter, path-hygiene-scrub-and-gate, records-subject-dimension, en-lib-strings.

**AUTONOMOUS LOOP ACTIVE (owner AFK 2026-07-12):** overseer runs Fable-plan → Fable-xhigh-implement → cherry-pick-integrate
in a continuous loop; disjoint-hub-file batches; every item ships spec (SPEC-116) + scenario test + doc; all committed for audit.
Stop only on an app/host-destroying risk. Ready-now pool the loop draws from: SEC.2/SEC.3/SEC.4, CQ.2, DW.5/DW.6, TE.*,
Panel/UX, Security & isolation, Ops-hygiene rows — one per hub file per batch.

<!-- self-review-inbox:start -->
## Self-review inbox (auto-generated — triage, then resolve the escalation)

| finding | observed | proposed action | ref |
|---|---|---|---|
| `delegation-cost-outlier` | C19/C20 predictability+recovery probes: ~260679 est tokens vs median 119030 of previous 10 | inspect that delegation: over-broad brief, missing context reuse, or a task that should have been split — delegations are the one spend stream self-review now watches (TE.2) | — |
| `harness-lines-burndown` | 2909 lines | run the next extraction round (MF.1 round 2: workflow lifecycle + CLI parser table) | MF.1 |
| `self-lib-file-budget` | scripts/harness_lib/chat_operator.py 1538 lines (+5 more over budget) | fragment the module (MF discipline: extract a cohesive domain, bind() or pure module) | — |
| `workflow-cost-outlier` | WF-20260712-004425-895025 ~22878 est tokens vs median 1632 | inspect that workflow's plan/profile: smaller shards, cheaper profile, or better split (routing changes stay human-gated) | — |

<!-- self-review-inbox:end -->
### Loop-surfaced items (2026-07-18, backlog loop)
- **function-size-budget debt (P2):** `spec_test_gate.py:main@1422=233 > 220` — pre-existing workflow-gate red, unrelated to any loop item; needs a `main()` refactor/extraction owner.
- **sandbox follow-ups (ceilings from SPEC-151, non-blocking):** JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE hardening (D2); read-worker scope deny-write ACL (D3, currently env-scope + no-write-tool + merge gate); register `workflows.workerSandbox` in `config_keys.py` (D6).
- **SECURITY REVIEW OWED:** SPEC-151 sandbox committed with requiresSecurityReview:true — run `/security-review` on the containment before relying on it.

## LOOP QUEUE 7 — FECHADA (2026-07-19): fila buildavel do artigo zerada

Loop overseer (owner: "vamos fazer loop ate zerar esse backlog"). 14 itens
entregues em 5 fases, 13 delegacoes (todas kept), gate verde em cada integracao,
ritual de review completo por item (footprint + mojibake python-judged + oracle
mutate isolado + rerun-tudo).

- **Fase 0** (enablers): C1 constantes+evidenceGrade; E-ROUTESCORES (scores+predictedP
  no route ledger); C3 capability supportStates. Commit 718a60c.
- **Fase 1** (P0 seguranca): sandbox SPEC-151 (manifest + egress-honesty, DELTA de
  SPEC-148). Commit 5ec7b3c. requiresSecurityReview.
- **Fase 2** (probes measure-only): C6 CTS; C18 route-churn; C5 approval metrics;
  C19 Pi-lite; C20 recovery. Commits 50f7dd7, 260b7d7.
- **Fase 3** (memoria governada): GM-5 shadow-challenge (achado: memoria precisa
  store 1a classe); + fix do hook cp1252. Commits 0ac1645, e90611f.
- **Fase 4** (hardening trajetoria/adapter): T-HASHCHAIN (hash-chain eventos,
  requiresSecurityReview); T-ADAPTERCONF (conformance + accountingSemantics, achou
  c9/c10 fails reais = pre-req do N-VENDORCREDIT); E-3LANE (instrumento 3-lane,
  --live owner-gated); T-CAUSALPARENT (parent ids causais). Commits 1b0e3b3, 91c716f.
- **Decisoes do owner** D013-D017 (DECISIONS.md) + itens novos N-AUTHCHAIN/
  N-SECREVIEWER/N-TRUTHRECON/N-RACEMODE/N-VENDORCREDIT. Commit cffff43.

**Catches do overseer no loop**: 3 near-bugs ja shipados (riscados); 1 oracle fraco
consertado (E-ROUTESCORES rl-4); premissa errada de brief corrigida (C5 invalidated
nao persistido); store de memoria inexistente (Fase 3 re-escopada); bug latente do
hook cp1252 (fix duravel); disciplina anti-fabricacao segurou (metricas nao-mensuraveis
dropadas 🔬, nao fabricadas).

**Diferido por medicao**: C9 histerese (churn ~zero; gatilho: churn > noise floor).

**OWNER-GATED restante (nao construir sem decisao)**: C2/N-AUTHCHAIN (design de
authority tipada); /security-review (sandbox SPEC-151 + T-HASHCHAIN); GM-3/N-TRUTHRECON
(enforcement de memoria/reconciliacao de fontes-da-verdade); EXP-20/21 medicao
(race-mode); N-VENDORCREDIT (pre-req pronto). Escalacao advisory: self-review flagou
o custo do C19/C20 (~260k, 2x mediana).


---

## Shipped roadmap rows (moved from the live backlog tables)

Verbatim rows lifted from the roadmap tables in IMPLEMENTATION_BACKLOG.md as
their features shipped. Grouped by the table they came from.


### M5 — Interactive panel

| ~~SPEC-116~~ ✅ | ~~SDD+BDD spec flow (two doors, no third)~~ shipped 2026-07-11: law `specs/00-universal/sdd-bdd-flow.md`; rich `specs/SPEC_TEMPLATE.md` + door-NEW `specs/templates/intake-refinement.md`; deterministic `feature-spec-conformance` in the spec-pack gate (`scripts/harness_lib/spec_conformance.py` — required template sections + Gherkin `Scenario:[id]`→named-check mapping; legacy frozen in `.harness/project.json` `specConformance.legacy`); acceptance `testing/scenarios/sc_spec_conformance.py`; retrofit pilot `supervision-m5-interactive-panel.md` carries a Gherkin block resolving to real m5 checks | user request 2026-07-11 | process+gate | M |

### Chat overlays — `docs/roadmap/chat-overlays.md`

| ~~chat-tool-chips~~ ✅ | shipped 2026-07-13 (loop AFK batch 11): `tool_descriptor` id+capped input_digest + `tool_result_descriptor` + `parse_chat_stream(on_tool_result=)`, `tool`/`tool-result` frames, GUI `<details class=tchip>` chips w/ icon map + output-by-id, CLI dim line + `/tool [n]` inspector (per-turn buffer, never persisted); spec `chat-overlays.md` + `ct_tool_chips.py` 4/4; qol 12/12, m5 77/77, ui_e2e rc0 | M | P1 | — |
| ~~chat-plan-hud~~ ✅ | shipped 2026-07-13 (loop AFK batch 12): `plan-steps` frame (distinct from SPEC-133 `plan`), `stream_json.plan_steps` + `on_plan`, TodoWrite PERMIT in the chat allowlist (decision #5), CLI HUD bottom rows (`format_plan_rows`, finished plan → checklist history) + non-HUD transition lines, GUI floating minimizable `#planCard`; chat-overlays.md v2 + `cp_plan_hud.py` 4/4 | M | P1 | chat-tool-chips |

### Tasks board + work queue — `docs/roadmap/screens-tasks-queue.md`

| ~~tasks-board-read~~ ✅ | shipped 2026-07-13 (loop AFK batch 2): `harness_lib/tasks_board.py` derived collector (backlog tables + inbox + escalations + live workers; never-crash rows), `tasks list` via cli_registry w/ TE.5 compact TSV, `/api/tasks` + `▦ Tasks` panel view; spec `panel-tasks-board.md` + `tb_tasks_board.py` 4/4 | M | high | — |
| ~~tasks-store-cli~~ ✅ | shipped 2026-07-13 (loop AFK batch 3): `harness_lib/tasks_store.py` single-write-path store, `tasks import/add/move/close` (idempotent import preserving lanes; derived running/review refused; HarnessError exit 2), board reads store-first post-freeze; spec `tasks-store.md` + `ts_tasks_store.py` 4/4. **NB: `tasks import` on the real repo = the freeze trigger, owner-run.** GUI `tasks-move` action deferred | M | med | tasks-board-read |
| ~~queue-view-live~~ ✅ | shipped 2026-07-13 (loop AFK batch 13): `harness_lib/ui_queue.py` derived-per-poll snapshot (phase labels, per-status counts, EN stage chips honestly labeled as declared profile, target scope chip, never-crash), `/api/queue` + `▶ Queue` view w/ visible-only 3s poll; spec `panel-work-queue.md` + `wq_queue_view.py` 3/3 | M | high | — |
| ~~queue-cancel-worker~~ ✅ | shipped 2026-07-13 (loop AFK batch 19): `workflow-cancel` builder ganha `workerId` opcional (`--worker-id` no CLI existente; recovery gate já valida a shape antes do argv), botão ✕ por worker pending/queued/running na Queue view (confirm + mesma trilha /api/action); panel-work-queue.md v2 + `qcw_cancel_worker.py` 3/3 | S | high | queue-view-live |

### Specs inspector + research — `docs/roadmap/screens-specs-research.md`

| ~~spec-index~~ ✅ | shipped 2026-07-12 (`5842380`): read-only spec inventory verb (SPEC-124, via `cli_registry`) | S | P1 | — |
| ~~research-index~~ ✅ | shipped 2026-07-13 (loop AFK batch 15): `harness_lib/research_index.py` — best-effort round parser (phases/question/budget/evidence-by-confidence/waves/experiments + parseErrors, never crashes on hand-written docs), `research_snapshot` joins admin fields + live research WFs (feed do futuro gui-research-screen), `research show <slug>` (+`--json` snapshot) na verb existente; research-admin.md v2 + `ri_research_index.py` 3/3 | M | P1 | — |

### Skills + MCP panels — `docs/roadmap/screens-capabilities.md`

| ~~CAP.1~~ ✅ | shipped 2026-07-13 (loop AFK batch 14): `harness_lib/capabilities_view.py` — scoped skills snapshot (harness/user; undeclared user-profile skills visible-never-granted), exact-form `referencedBy`, path-confined `skill_file` viewer (trust boundary tested), `mcp_snapshot` across 5 declaration points w/ env key-names-only + grant-path empty state; `agents skills [list\|show]` + `agents mcp` via cli_registry; spec `capability-panels.md` + `cap_capabilities.py` 4/4 | M | high | — |

### Memory snapshot + records/changelogs — `docs/roadmap/screens-memory-records.md`

| ~~M5.mem~~ ✅ | shipped 2026-07-13 (loop AFK batch 28): `harness_lib/ui_memory.py` — registro FECHADO de fontes escopo×propósito (auto-memory do usuário via slug per-char, CONTEXT head, worklog+archive, escalations, cost, calibration, self-review, quality-state, índice derivado), TODO byte por `secret_scan.redact_text` (promovido: 1 seam, 2 consumidores), `/api/memory[/file]` + view `≣ Memory` + `records sources`; spec `panel-memory-snapshot.md` + `mem_snapshot_panel.py` 4/4. M-A3/A4 OPEN | M | high | — |
| ~~M5.rec~~ ✅ | shipped 2026-07-13 (loop AFK batch 16): `harness_lib/ui_commits.py` (validated branch/grep/sha filters — no flag injection; detail capped 200KB + secret-redacted server-side first-4+len), `/api/commits` + `/api/commit`, `≡ Changelog` view + dialog reusing `colorizeDiff`; spec `panel-records-changelogs.md` + `rec_changelog_panel.py` 3/3. M5.sum (LLM summary) + M5.tgt stay OPEN | M | high | — |

### Configs/keys + graphs — `docs/roadmap/screens-config-graphs.md`

| ~~config-keys-cli~~ ✅ | phase 1 SHIPPED (N+9, SPEC-130); **phase 2 shipped 2026-07-13 (loop AFK batch 4)**: `harness_lib/keys_vault.py` — keyring 25.6.0 (pinned, `requirements-optional.txt`), read cascade env→vault→.env in `load_env_file`, `keys list/set(stdin)/unset/migrate`, records entries name-only, `keys-meta.json` lastRotated + doctor `keys-staleness` WARN; config-keys.md v2 + `kv_keys_vault.py` 4/4 | M | high | — |
| ~~graph-provider-abstraction~~ ✅ | shipped 2026-07-13 (loop AFK batch 25): `harness_lib/graph_providers.py` (builtin + externos declarados em config; seleção `knowledgeGraph.provider` c/ override per-target; fallback determinístico BARULHENTO `{fellBackTo,reason}`; spawn mediado; stamp `generatedAt`), 4 call sites religados (discovery/gate-policy/gate-generic/shards autobuild; verbo builtin + fixture ficam no builtin), CLI `graph providers|set`; spec `screen-graphs-providers.md` + `gp_graph_providers.py` 4/4. Destrava graphs-metrics-cli (B2) | M | high | — |
| ~~graphs-metrics-cli~~ ✅ | shipped 2026-07-13 (loop AFK batch 26): `graph metrics [--target] [--json]` — structure/freshness/artifacts/consumo por subject; regra de freshness EXTRAÍDA pra `graph_providers.staleness` e consumida pelos DOIS gates (tela e gate nunca discordam); screen-graphs-providers.md v2 + `gm_graph_metrics.py` 3/3 | S | med | — |

### PyO3 optimization — `docs/roadmap/pyo3-optimization.md`

| ~~perf-metrics-rung~~ ✅ | shipped 2026-07-13 (loop AFK batch 8): `result()` durationMs + coarse-block/scenario/fixture timing in the gate, `cost_metrics.record_gate` (kind gate, slowest top-5, per-kind trim 150) + `summarize().gates` (stats/byGate/bySlowest/series), graphify stats durationS; spec `perf-metrics-rung.md` + `pm_perf_metrics.py` 4/4; first real record verified in-ledger | S | P1 | — |

### Docs revision + Wiki — `docs/roadmap/docs-wiki.md`

| ~~docs-audit-refs~~ ✅ (safe half) | shipped 2026-07-13 (loop AFK batch 10): scope banners on the 6 two-scope files (docs/ARCHITECTURE, PROJECT_ADOPTION_GUIDE, specs 10/20/30/90 stubs); B3 CHANGELOG mentions verified already tagged in records-ledger.md; B4 README already explains the .example copy. **B1 SPEC-105-ghost ESCALATED** (`spec-105-ghost-vs-legacy-freeze@…`) — owner decision #4 on the legacy freeze | S | P1 | — |

### Security / OWASP enforcement — `docs/roadmap/security-owasp-enforcement.md`

| ~~security-baseline-mvp~~ ✅ | shipped 2026-07-12 (`e16c0b5`): observe-only `security_baseline.evaluate` gate + `requiresSecurityReview` routing (SPEC-116) | M | P1 | — |
| ~~security-baseline-targets~~ ✅ | shipped 2026-07-13 (loop AFK batch 9): `gate_generic.check_security_baseline` — same evaluator per target, snapshot HARNESS-side (`state_dir(n)/security-baseline.snapshot.json`, target tree stays byte-clean), tree-wide sink scan, per-target `requiresSecurityReview` in quality-state; security-baseline.md v4 + `sbt_baseline_targets.py` 3/3 | S | P1 | security-baseline-mvp |
| ~~security-diff-routing~~ ✅ | shipped 2026-07-13 (loop AFK batch 1): `harness_lib/security_routing.py` `route()` named entry point (pipeline slot), FP registry `.harness/state/security-exemptions.json` `{pattern,reason,reviewedAt}` (invalid entry = gate fail), ratchet hits now ROUTE to a durable idempotent security-triage escalation; 7th control-liveness probe; security-baseline.md v3 + `sdr_security_routing.py` 4/4 | S | **P1** | security-baseline-mvp |
| ~~security-directive-map~~ ✅ | shipped 2026-07-13 (loop AFK batch 20): `harness_lib/security_directives.py` (ids = hash normalizado dos bullets de `## Invariants` dos 6 specs; mapping-file-only), `testing/security-directive-map.json` seed revisado (54 diretivas: 16 check / 3 trigger / 35 prose VISÍVEL), gate check `security-directive-map` falha em unmapped/stale/invalid; spec + `sdm_directive_map.py` 4/4 | S | P2 | security-baseline-mvp |

### Cross-project data isolation — `docs/roadmap/cross-project-isolation-data.md`

| ~~isolation-audit-gate~~ ✅ | shipped 2026-07-13 (loop AFK batch 6): `gate_fixtures_isolation.py` dual-subject fixture (2 temp git targets, real target-gate flows) — env-canary + b-tree-clean + cross-bleed + records-credit HARD (the once-xfail phases all landed), calibration gap stays a NAMED observe-only row; in the workflow-gate fixture list + `--fixture isolation-audit`; spec `cross-project-isolation-data.md` + `ia_isolation_audit.py` 5/5 | M | high | — |
| ~~per-target-token-calibration~~ ✅ | shipped 2026-07-13 (loop AFK batch 21): `token_calibration` per-subject (`subject=` → `state_dir(t)/token-calibration.json`; self inalterado), budget sizing cascade target→harness→seed no call site com workflow em escopo, `summarize().estimator.byTargetCpt` report-only (feed do futuro writer per-target, que fica OPEN), isolation-audit `calibration-scope` virou check HARD (write de target nunca move harness/sibling); cross-project-isolation-data.md v2 | S | med | records-subject-dimension |
| ~~subject-tagged-events~~ ✅ | shipped 2026-07-13 (loop AFK batch 22): `append_event` carimba `subject` estrutural (param > payload target > self), RUNS writer carimba self, `run_target_gate` carimba o nome do target em cada row (campo, não convenção de prefixo); pooled-but-attributed mantido (arquivos per-subject seguem deferidos); cross-project-isolation-data.md v3 + `ste_subject_events.py` 3/3 | S | low | subject-primitive |

### Escalation / human / LLM isolation — `docs/roadmap/cross-project-isolation-escalation.md`

| ~~esc-subject-scope~~ ✅ | shipped 2026-07-13 (loop AFK batch 5): `subject` stamped at all 4 producers (harness-result target, WF fold, self-review structural derivation, security-routing self), `list_escalations(subject=, root=)` + `bySubject`, `scoped_resolve_check` (cross-subject resolve refused; bare CLI stays the unscoped escape hatch), `escalations --target`; spec `escalation-subject-scope.md` + `es_subject_scope.py` 5/5. Rider: `tighten_ratchets` replay now scoped to the keys it tightened (pre-existing revert-loop spammed 1 event/run and broke se inbox-stability). Phases 2/3 (HITL view, handoff) stay OPEN | M | high | — |
| ~~esc-scoped-hitl-view~~ ✅ | shipped 2026-07-13 (loop AFK batch 18): panel rows/strips carry subject (+`[target]` label), subject filter chips + badge, Resolve SEMPRE forwards `--target` (cross-subject recusado server-side; CLI puro segue escape hatch), chat nag por-subject + `!escalations` default `--target` em sessão /repo; escalation-subject-scope.md v2 + `ehv_scoped_hitl.py` 4/4 | M | high | esc-subject-scope |

### Dependency / service bootstrap — `docs/roadmap/dependency-bootstrap.md`

| ~~svc-registry-mvp~~ ✅ | shipped 2026-07-13 (loop AFK batch 7): `harness_lib/services.py` (idempotent `ensure` + tcp/http ready probe fail-closed + orphan-free tree stop + status reap of dead/ownerless), seeded `.harness/services.json` + `target.json` `services` scope (deny-by-default env), `services` CLI verb; spec `service-bootstrap.md` + `sv_services.py` 5/5 real-spawn. P1/P2 open; ponytail seed waits owner MCP-transport decision | M | high | win-hidden-spawn-helper |
| ~~svc-autostart-owners~~ ✅ (panel+chat) | shipped 2026-07-13 (loop AFK batch 24): `ensure_autostart(entry_point)` + `stop_owned` (contrapartida explícita do reap); painel ensures `ui` pós-bind + atexit, chat REPL ensures `chat` + atexit; **workflow(target) owner hook fica OPEN** (precisa do settle-stop simétrico no async runtime — svc-mcp-wiring); service-bootstrap.md v2 + `sao_autostart.py` 3/3 | S | med | svc-registry-mvp |

### Black terminal windows (Windows) — `docs/roadmap/black-terminal-windows.md`

| ~~no-raw-subprocess-gate~~ ✅ | shipped 2026-07-13 (loop AFK batch 23): `harness_lib/spawn_ratchet.py` — AST scan (kind,file), `processes.py` isento, baseline write-once (28 sites legados congelados), gate check `raw-subprocess-ratchet` falha em site NOVO com fix route-or-rebaseline; spec `raw-subprocess-ratchet.md` + `srg_spawn_ratchet.py` 3/3 | S | med | win-hidden-spawn-helper |

### Path hygiene + git/OneDrive — `docs/roadmap/git-onedrive-path-hygiene.md`

| ~~onedrive-repo-health-check~~ ✅ | shipped as the repo-health `doctor` verb (SPEC-123): onedrive-path + git-reparse-point + autocrlf checks | S | med | path-hygiene-scrub-and-gate |
| ~~repo-out-of-onedrive-decision~~ ✅ | **done 2026-07-13 (owner):** repo relocated to `C:\projects\universal-agent-harness-prototype`; doctor all-OK (no OneDrive path, no reparse point, repo-local `core.autocrlf=false`) | M | owner | — |

### CE — Communication efficiency roadmap (research round 2026-07-12; full round + verdict table in `docs/research/agent-communication-protocols.md`)

| ~~CE.1~~ ✅ | shipped 2026-07-12 (batch 1-3): seam `_record_executor_outcome` records the worker's REAL outcome (fulfilled+failed, rc=0 rejected/missing → breaker failure); scenario `ce1_containment.py` 5/5 — re-verified live 2026-07-17 (ref-arch adoption round N1; this row had gone stale) | reliability | `async_runtime.py:336,538` | useful-fan-out / budget-accuracy | S | ✅ |
| ~~CE.4~~ ✅ | shipped 2026-07-13 (loop AFK batch 27): `harness_lib/cli_catalog.py` — verbo `catalog` (81 verbos incl. subtree workflow, uma linha compacta cada; `catalog <verb>` pagina UM --help; TSV sob compact), ganho MEDIDO: página = **15%** dos helps completos (`catalogShare` no --json); spec `cli-tool-catalog.md` + `cc_cli_catalog.py` 3/3 | G2 | 75 `add_parser` calls in `harness.py` → new `harness_lib` introspection helper | tool-disclosure-overhead | M | P2 |

### CQ — Code quality roadmap (research round 2026-07-12; full round + verdict table in `docs/research/code-quality-agents.md`)

| ~~CQ.5~~ ✅ | ~~**Mutation-probe**~~ un-deferred by owner mandate + SHIPPED 2026-07-13 (overseer-toolkit batch): `harness_lib/mutation_probe.py` + `oracle mutate` verb — diff-scoped AST mutants (≤3, deterministic menu), diff-linked scenario as the oracle, byte-identical restore, killed/survived/error/timeout/skipped incl. the reserved `exitClass` extension; observe-only (gate check = fase 2, ainda deferida); first live run correctly returned 3 SURVIVED vs a surface-only scenario. Spec `mutation-probe-oracle.md` + `mpo_mutation_probe.py` 3/3 | CQ1 (test strength) | `oracle` verb (cli_registry) + future gate check | test-strength | M | shipped (probe) |

### TE — Token economy (research round 2026-07-11; sources + gains in `docs/WORKFLOW_TOKEN_ECONOMICS.md` §TE ideation)

| ~~TE.5~~ ✅ | ~~Agent-facing compact/tabular output: `HARNESS_AGENT_OUTPUT=compact` → compact JSON + TSV for homogeneous lists; default byte-identical; fixture measures the real payloads~~ done: `te_compact_output.py` — compact `routing show` 73.3% / TSV `models list` 43.9% of pretty chars; default byte-identical | 9-format token experiment (jangwook.net; ~37% nested / ~62% flat) | cli | M |
| ~~TE.6~~ ✅ | ~~Cache-stable delegation-packet skeleton~~ done 2026-07-11 (`7117850`): frozen-prefix template in `.harness/prompts/implementer-packet.md`; `cacheReadTokens` now a first-class chat-turn ledger field (evidence accrues per turn) | prompt-caching engineering (digitalapplied/agentmarketcap; cache read = 10% of input price) | process | S |
| ~~TE.7~~ ✅ | ~~Model cascade for low-risk rounds~~ done 2026-07-11 (`7117850`, reshaped per user): canonical `ui-validation` task profile (sonnet-high claude / gpt-5.4-mini codex; Playwright-guarded; escalate-on-gate-failure documented). First A/B: 101k tok / 7 min vs 170-230k opus baseline, green first try | FrugalGPT (arXiv:2305.05176); enabled by Playwright E2E safety net (v5.3) | routing | M |

### Deferred (needs a demand signal first — do not schedule)

| ~~Promote `_rmtree_robust` to common~~ — **trigger fired and executed 2026-07-09** (gate cleanup's swallowed transient left an empty dir; now `common.rmtree_robust` serves scrub + cleanup) | SPEC-108 H3 retro | — |

---

## Archive pass 2 — audited shipped-but-open rows (2026-07-19)

The 2026-07-19 audit (3 read-only scanners, overseer-verified against code +
scenarios) found these rows listed OPEN in the live backlog but actually
SHIPPED. Moved here verbatim from the live backlog tables, grouped by source
table, each annotated `[verified shipped 2026-07-19 audit: <evidence>]`. The
3 partials (RF.1, M5.tgt, queue-start-action, config-keys-gui) and CE.8 stayed
OPEN in the live backlog with their shipped half annotated — they are NOT here.

### M5 — Interactive panel

| M5.1 | `scripts/harness_ui.py`: single-file stdlib `http.server` panel; polls state JSONs; POST endpoints run the M2 command allowlist via `subprocess`. Escalation queue panel first, then the §4 table order [verified shipped 2026-07-19 audit: harness_ui.py stdlib panel + m5 scenarios] | §4b | gui | L |
| M5.2 | Security hardening: bind `127.0.0.1`, per-session token, strict subcommand allowlist (= the M2 command list), confirm dialog injecting the approval token for controlled writes [verified shipped 2026-07-19 audit: harness_ui.py 127.0.0.1 bind + per-session token allowlist] | §4b | gui | S |
| M5.3 | Escalation queue ranks by blast radius, not arrival; panels categorize, never stream (human-factors requirement) [verified shipped 2026-07-19 audit: escalation-queue blast-radius ranking] | §3b/§4 | gui | S |
| SPEC-115 | Model-card CRUD + role-based routing profiles with fallback chains, CLI (`models`/`routing`) + panel Config view (cards grid + routing matrix + hidden advanced JSON); `canonical` derived live from task-profiles. Spec `specs/40-features/model-routing.md`; acceptance `testing/scenarios/mr_model_routing.py`. Mid-workflow failover now shipped (rule 15; `async_state.workflow_next_failover` + `testing/scenarios/wf_failover.py`) [verified shipped 2026-07-19 audit: mr_model_routing.py + wf_failover.py] | user request 2026-07-10 | cli+gui | L |

### Chat overlays — `docs/roadmap/chat-overlays.md`

| chat-gate-tracker | Gate sub-tracker under the test step, harness ≠ target depends-on:chat-plan-hud [verified shipped 2026-07-19 audit] | S | P2 | chat-plan-hud |
| codex-stream-parity | CodexEngine Popen streaming for mid-turn events depends-on:chat-tool-chips [verified shipped 2026-07-19 audit] | M | P2 | chat-tool-chips |

### Tasks board + work queue — `docs/roadmap/screens-tasks-queue.md`

| tasks-enqueue | "Send to work queue" (reuse compile-gated `composer-create`) depends-on:tasks-board-read [verified shipped 2026-07-19 audit] | S | med | tasks-board-read |
| tasks-target-board | Per-target boards (SPEC-110) depends-on:tasks-board-read [verified shipped 2026-07-19 audit] | M | low | tasks-board-read |

### Specs inspector + research — `docs/roadmap/screens-specs-research.md`

| gui-specs-screen | Specs inspector (breadcrumbs, conformance badges) depends-on:spec-index [verified shipped 2026-07-19 audit: SPEC-134, plan-q7] | M | P2 | spec-index |
| gui-research-screen | Research gallery/detail screen depends-on:research-index [verified shipped 2026-07-19 audit: plan-q8 research panel] | M | P2 | research-index |

### Skills + MCP panels — `docs/roadmap/screens-capabilities.md`

| CAP.2 | GUI card grids + read-only prompt/schema/file viewers depends-on:CAP.1 [verified shipped 2026-07-19 audit] | M | high | CAP.1 |
| CAP.3 | Target discovery + `undeclared` badges + separation SDD spec depends-on:CAP.1 [verified shipped 2026-07-19 audit] | M | med | CAP.1 |

### Memory snapshot + records/changelogs — `docs/roadmap/screens-memory-records.md`

| M5.sum | On-demand round summary (cheap LLM sonnet/haiku, sha-cached) depends-on:M5.rec [verified shipped 2026-07-19 audit: M5.sum records summarize, plan-q4] | S | med | M5.rec |

### Docs revision + Wiki — `docs/roadmap/docs-wiki.md`

| docs-tree-printer | `harness.py docs-tree` structure-printer (deterministic, scope-tagged) [verified shipped 2026-07-19 audit: SPEC-127 docs-tree verb] | S | P1 | — |

### Security / OWASP enforcement — `docs/roadmap/security-owasp-enforcement.md`

| security-baseline-sdd | SDD spec + `sb_security_baseline.py` scenario depends-on:security-baseline-mvp [verified shipped 2026-07-19 audit: sb_security_baseline.py scenario] | S | P1 | security-baseline-mvp |

### Cross-project data isolation — `docs/roadmap/cross-project-isolation-data.md`

| target-gate-env-filter | Deny-by-default env for target build/test commands (full-env leak `gate_generic.py:177`) [verified shipped 2026-07-19 audit: Fable re-verified landed] | S | **P0** | — |
| records-subject-dimension | `subject` dimension on `records.add_entry` + scoped CONTEXT head depends-on:subject-primitive [verified shipped 2026-07-19 audit: Fable re-verified landed] | S | high | subject-primitive |
| workspace-state-exclusion | Exclude `.harness/state` + `targets` registry from workspace copies (`controlled_writes.py:47`) [verified shipped 2026-07-19 audit: batch 1-3] | S | med | — |

### Black terminal windows (Windows) — `docs/roadmap/black-terminal-windows.md`

| win-hidden-spawn-helper | `processes.py` hidden-spawn helper + swap supervisor `DETACHED_PROCESS`→`CREATE_NO_WINDOW` + route worker spawns [verified shipped 2026-07-19 audit: Fable re-verified landed] | M | **high (do-now)** | — |

### Path hygiene + git/OneDrive — `docs/roadmap/git-onedrive-path-hygiene.md`

| path-hygiene-scrub-and-gate | Scrub the 2 JSON leaks + fix `harness.py:295` + tighten the `local-absolute-paths` regex (doubled-backslash/forward/git-bash, fail-closed) + gitignore `target.json`/conflict-copies [verified shipped 2026-07-19 audit: Fable re-verified landed] | S | **high (do-now)** | — |

### English-default terminology — `docs/roadmap/terminology-en-default.md`

| en-gui-strings | Translate `harness_ui_page.py` PAGE strings (~75-90) in lockstep with their 3 test assertions [verified shipped 2026-07-19 audit: batch 1-3] | M | P1 | — |
| en-lib-strings | Clear 9 remaining `harness_lib` pt strings (+1 assertion) [verified shipped 2026-07-19 audit: Fable re-verified landed] | S | P1 | — |
| en-default-guard | `check_en_default_strings` gate (SPEC-122) — pt-diacritic + STRING-token + curated word scan depends-on:en-gui-strings depends-on:en-lib-strings [verified shipped 2026-07-19 audit: SPEC-122] | S | P1 | en-gui-strings, en-lib-strings |

### CE — Communication efficiency roadmap (research round 2026-07-12)

| CE.2 | **Communication-economy meter** — compute amplification / stale-context / context-utilization at finalize from artifacts already on disk (one economy record per workflow; no new spawn, no LLM) [verified shipped 2026-07-19 audit: economy meter, cost_metrics.record_workflow] | G1 | `cost_metrics.record_workflow` (cost_metrics.py:108) @ `workflow_lifecycle.py:98` | communication-amplification | M | P1 |
| CE.3 | **handles-lint (observe-only)** — a collect/DLP gate check flagging oversized inline payloads that should be handles; report-only first, enforce later depends-on:CE.2 [verified shipped 2026-07-19 audit: handles-lint] | G5 | `spec_test_gate.py` check @ the collect/`secret_scan.py` seam | duplicate-context ratio | S | P1 |

### DW — Dynamic workflows roadmap (research round 2026-07-12)

| DW.1 | **Secret-scan the fan-out surface + card trust tier** — `plan_workflow` writes worker prompts + context-digest with NO secret_scan (the K1 scan runs only on `--validate-only` over argv; `context_digest.py` has zero scan calls; fold scan is post-dispatch); scan at the generation seam BEFORE the N× fan-out multiplier, and add a trust/tier field to executor/model cards [verified shipped 2026-07-19 audit: fan-out secret-scan + trustTier] | D5 (trust boundary) | `harness.py:1636-1666` (plan materialize) + `context_digest.py` + `.harness/routing/executors.json` | unscanned-fanout-surface | S | **P0** |
| DW.2 | **Formalize workflow.json as the typed IR + slots** — it is already schemaVersion 1.1 read by plan/schedule/execute/policy; promote to THE canonical IR via a stdlib schema validated at plan, explicit LLM-fillable "slots", unify the 3 confirmed budget locations into one typed section; reserve a `dependsOn` field (from DW.7). Zero migration. Foundation: DW.3/DW.4/DW.5 all write fields into it depends-on:DW.1 [verified shipped 2026-07-19 audit: typed workflow.json IR] | D3 (typed IR) | schema over `harness.py:1448` + `workflow_token_audit.py:217` + `workflow_writes.py:208` (3 schemaVersion-1.1 docs) | schema-conformance / slot-boundedness | M | P1 |
| DW.3 | **Graph-shape metrics into cost_metrics** — 4 deterministic fields (fan-out/depth/makespan/critical-path) added to `record_workflow` from data already on disk; extends CE.2, zero new state. The epistemic keystone — nothing auto-adapts until this is measured depends-on:DW.2 [verified shipped 2026-07-19 audit: graph-shape metrics] | D5→DW5 (metrics) | `cost_metrics.py:108` (record_workflow) | graph-shape (fan-out/depth/makespan) | S | P1 |
| DW.4 | **Topology-router `--explain` (observe-only)** — a deterministic verdict in the plan compile loop that DEFAULTS to single-agent (N=1) and reports why it would/wouldn't fork (budget gate + independence + circuit state + CE.2 cost-per-finding); records its inputs+verdict into workflow.json for replayability; **no auto-fork yet** (LLM only estimates decomposability, observe-only) depends-on:DW.3 [verified shipped 2026-07-19 audit: topology-router --explain observe-only] | D1 (topology router) | `harness.py` plan compile + `workflow_token_audit` | fan-out-justification / cost-per-finding | M | P2 |

### CQ — Code quality roadmap (research round 2026-07-12)

| CQ.1 | **Per-patch risk-tier gate selection** — a deterministic diff-glob + sink-token classifier (reuse `security_baseline._classify_sink`, NOT `evaluate()`'s snapshot side-effect; intake_triage is pre-diff, wrong seam) that SELECTS gate depth and CONSUMES the security-baseline `new` diff currently REPORTED-BUT-UNCONSUMED; observe→enforce; unknown/unclassifiable diff → **medium (fail-closed)**; critical tier adds revert-cleanliness + human approval. A cost ALLOCATOR, not adder [verified shipped 2026-07-19 audit: risk-tier classifier observe-only] | CQ2 (risk-adaptive) | `spec_test_gate.py:1778-1783` (the dangling `security['new']`) + `security_baseline.py:81` (`_classify_sink`) | risk-routed depth | S | **P1 (first)** |
| CQ.2 | **QA evidence capsule + rerunCmd** — a capped, structured `oracleEvidence` capsule (which oracle ran, `exitClass`, a HANDLE to a pre-scrubbed failing artifact, a `rerunCmd`) in WORKER_RESULT; review cost O(capsule) not O(re-run). Handles-not-bodies (collect withholds secret-shaped results) depends-on:CQ.1 [verified shipped 2026-07-19 audit: oracleEvidence capsule, SPEC-121] | CQ5 (evidence capsules) | WORKER_RESULT schema + collect boundary (`workflow_reduce.py:93-105`) | review-cost | S | P1 |
| CQ.3 | **Provenance record** — one `records.add_entry` at finalize (author agent/model, oracle evidence handles, risk tier, commit sha); agentic-debt is a LAZY on-demand git-derived VIEW (blame/log), no daemon. Payload = handles + sha, never raw oracle output; ship the view only after a backfill proves it's queried. Label the "agentic-debt" metric exploratory depends-on:CQ.2 [verified shipped 2026-07-19 audit: provenance record at finalize] | CQ3 (provenance) | `records.py:128` (`add_entry`) + workflow finalize | provenance coverage | S | P1 |

### SEC — Code security roadmap (research round 2026-07-12)

| SEC.1 | **Pre-egress secret/path gate on the discover chain** — `discover_paths` ships an absolute file path (and up to ~60k chars/file) to the Gemini/NVIDIA provider extractors with ZERO secret_scan anywhere in the chain. Add a deterministic pre-egress secret + path-denylist gate at the single `discover_paths` seam (reuse `secret_scan`) BEFORE any bytes leave the process [verified shipped 2026-07-19 audit: pre-egress gate, discovery.py] | SEC3 (egress leak) | `discovery.py:118-124` (discover_paths) + `tools/graphify/gemini_extract_fallback.py:88` | egress-leak-contained | S | **P0 (verified hole)** |
| SEC.2 | **Security-regression ratchet** — a diff-scoped check that intersects the security-baseline `new` diff (REPORTED-but-unconsumed at `spec_test_gate.py:1782`) with the changed-files manifest; enforce secure-AND-functional (a diff must not add a baseline pattern; a fix must remove the target). Pure set-intersection of two already-computed signals; MUST pin its git base ref. Second consumer of `new` (composes with CQ.1) depends-on:SEC.1 [verified shipped 2026-07-19 audit: security-regression ratchet] | SEC5 (secure+functional) | `spec_test_gate.py:1778-1783` (`security['new']`) ∩ changed-files | secure-functional-pass-rate | S | P1 |
| SEC.3 | **Control-plane liveness healthcheck** — a gate check that FAILS if a declared control is dead / fail-open (hook not installed, `enabled=False`, snapshot stale, ledger with no consumer). Split out of P3 because a silently-partial control is itself the top operational vuln depends-on:SEC.2 [verified shipped 2026-07-19 audit: control-plane liveness, SPEC-125] | SEC3 (control liveness) | `spec_test_gate` + the declared-controls registry | control-liveness | S | P1 |

### RF — Owner refinement requests (2026-07-12)

| RF.2 | **Research round cleanup / delete** — config experiments generate throwaway research rounds (`docs/research/*.md` round docs + their scrubbed WFs + records entries); there is no way to list + delete/archive a garbage round. Build a research-admin verb: `research list` (round docs + status + linked WF ids + records refs) and a GUARDED `research delete <round>` (rm the round doc, scrub any lingering WFs via the existing `workflow scrub`, tombstone in records — deterministic, dry-run default like `tools/prune_worktrees.py`, `--apply` to act). Never touch a committed round without an explicit flag. [verified shipped 2026-07-19 audit: research-admin verb, SPEC-125] | throwaway research rounds accumulate as garbage; no inventory/delete | new `harness_lib/research_admin.py` + `docs/research/` + `workflow scrub` (async_runtime) + records tombstone; CLI verb via `cli_registry` | garbage-rounds-cleaned / research-inventory | S | P2 |

### UX-GA — Generative-AI supervision UX roadmap (research round 2026-07-13)

| UX-GA.1 | **Extend deterministic Attention into a risk summary** — aggregate the already-computed risk signals (escalation blast-radius ranking, risk-tier from CQ.1, control-liveness, breaker state) into an at-a-glance "what needs a human now" panel widget; pure deterministic aggregation of existing signals, each row EVIDENCE-LINKED (handle/path/records ref). No new state, no LLM. [verified shipped 2026-07-19 audit: risk-summary strip, ui_e2e] | UX1+UX3 | `harness_ui_page.py` Attention/escalation section + the risk/escalation state JSONs | review-cost / needs-human surfaced | S | P1 |
| UX-GA.2 | **Grouped fan-out cards** — extend the flat worker cards into grouped (who/what/cost/status) cards for a whole wave, so N parallel workers stay legible without streaming (categorize-not-stream); reads the workflow/worker state snapshot. [verified shipped 2026-07-19 audit: grouped fan-out cards, ui_e2e] | UX2 | `harness_ui_page.py` worker-cards render + the workflow state snapshot | parallel-work legibility | S | P2 |
| UX-GA.3 | **Deterministic evidence bundle** — for a result/diff, assemble the evidence handles (failing snippet handle, oracle capsule from CQ.2, scenario id, paths) into one compact bundle a reviewer reads without re-running; pure assembly of existing handles, GUI writes no state. depends-on:CQ.2 [verified shipped 2026-07-19 audit: evidence bundle + workflow evidence, SPEC-129] | UX4 (prereq) | a `run_action` read collector + WORKER_RESULT `oracleEvidence` (CQ.2) + records | review-cost O(bundle) | S | P2 |

### OB — Generative-AI observability roadmap (research round 2026-07-13)

| OB.1 | **Failure-pattern clustering** — a deterministic rollup across the records/escalation ledger: which `failureClass` / role / executor repeats, and how often. Pure aggregation of durable signals, verify-on-demand, no LLM. Build first (cheapest, highest signal) [verified shipped 2026-07-19 audit: failure-pattern clustering, SPEC-126] | OB4 | `records` ledger + escalation ledger (`failureClass`, role, executor fields) | repeat-failure visibility | S | P1 |
| OB.2 | **Cross-run cost/latency trend** — extend the existing `delegation-cost-trend` to trend cost/duration per role/profile/model over the cost_metrics history (deterministic rolling-avg/regression); flag drift. Do NOT duplicate the existing narrow slice — extend it depends-on:OB.1 [verified shipped 2026-07-19 audit: cost/latency trend, SPEC-128] | OB1 | `cost_metrics` history + the existing `delegation-cost-trend` | drift caught early | S | P2 |
| OB.3 | **Anomaly diagnosis feature card** — for a cost-outlier (the self-review escalation already fires), a DETERMINISTIC feature card (fan-out/depth/makespan from DW.3, per-worker cost breakdown, profile) that names likely cause factors; an OPTIONAL evidence-cited LLM explanation sits on top of the card (opt-in, view-only) depends-on:OB.2 [verified shipped 2026-07-19 audit: anomaly card, SPEC-131] | OB2 | DW.3 graph metrics + cost_metrics per-worker + the cost-outlier escalation | outlier → cause | M | P2 |
| OB.4 | **Failure-focused trace digest** — enrich the existing trace/events export into a compact "what happened + where it broke" digest (failure-focused, evidence-linked to the failing step), not a log re-dump depends-on:OB.3 [verified shipped 2026-07-19 audit: failure-focused trace digest] | OB3 | `trace`/`trace-export` + events.jsonl | trace review cost | M | P3 |
