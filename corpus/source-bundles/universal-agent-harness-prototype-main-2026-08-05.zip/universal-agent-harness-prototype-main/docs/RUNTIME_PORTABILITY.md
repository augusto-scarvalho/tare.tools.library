# Runtime Portability Policy

The harness must remain independent of operating system, coding agent, shell,
language stack, and local virtual-environment layout.

## Invariants

- Do not depend on an executor-owned Python, Node, or shell runtime.
- Do not hardcode specific executors, operating systems, shells, or user-specific paths.
- Do not assume `.venv`, `node_modules`, Conda, Nix, Docker, or any other project
  runtime unless the adopted project explicitly configures it.
- Harness scripts that require Python must run with a project/operator-managed
  Python 3 interpreter available on PATH or through `HARNESS_PYTHON`.
- Shell wrappers are convenience adapters. The cross-platform validation
  entrypoint is `python scripts/harness-test.py`.
- Project build/test/lint commands belong in `.harness/project.json` under
  `validation.<gate>.commands`; they must not be hidden in agent-specific
  adapters.

## Recommended adoption flow

1. Install or select a stable Python 3 interpreter for harness tooling.
2. Optionally set `HARNESS_PYTHON` to that interpreter path in the operator
   environment or CI job.
3. Configure project-specific validation commands in `.harness/project.json`.
4. Run `python scripts/harness-test.py smoke`.
5. Run `python scripts/harness-test.py spec-pack`.

## What adapters may do

Agent adapters may call the generic launcher or the Python entrypoint, but they
must not introduce canonical state, hidden runtime assumptions, or fallback to
executor-bundled interpreters. If an adapter cannot find Python, it should fail with
actionable instructions instead of silently using a private agent runtime.


## Graphify runtime

Graphify is a mandatory structural discovery skill, but its runtime must remain project/operator-managed. Do not rely on Codex, Claude, or any other executor's private runtime to provide Graphify. Do not silently install Graphify during ordinary implementation work. Configure it explicitly in the project/operator environment when the adopted project needs graph-based discovery.
