# Agent Compatibility

The harness is designed for Codex, Claude Code, and future CLI-style or API-style coding agents.

Requirements for any new executor:

1. It can receive a task prompt.
2. It can read the repository files.
3. It can write files when permitted.
4. It can return or log a `HARNESS_RESULT` block.
5. It can be represented in `.harness/routing/executors.json`.

## Runtime portability

Runtime/interpreter assumptions must follow `docs/RUNTIME_PORTABILITY.md`. Adapters may invoke harness scripts, but must not depend on executor-bundled runtimes or private executor runtimes or implicit local environments. Project runtimes must be configured explicitly.


## Graphify compatibility

Any executor that performs broad repository discovery must follow the Graphify policy in `AGENTS.md`: graph-first, source-verified. Executors that cannot call Graphify directly must still check `graphify-out/GRAPH_REPORT.md` when present and report graph availability in `HARNESS_RESULT.contextDiscovery.graphify`.
