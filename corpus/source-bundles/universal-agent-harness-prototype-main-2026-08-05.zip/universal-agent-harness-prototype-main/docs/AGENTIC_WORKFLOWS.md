# Agentic Workflows

The harness supports large-task workflows for context-heavy work. These workflows are not autonomous swarms. They are bounded packet workflows generated, executed, validated and reduced by the harness.

## Map-reduce

Use map-reduce when many items need the same type of analysis. The planner creates shards, workers analyze shards, and a reducer synthesizes normalized findings.

Good candidates:

- repository-wide spec compliance review;
- large documentation consistency checks;
- security triage across many modules;
- dependency inventory;
- coverage-gap inventory;
- migration impact mapping.

Supported split strategies:

- `roots`: split by configured project roots;
- `changed-files`: split the current Git diff/status by top-level area;
- `graphify`: split using `graphify-out/graph.json` when available, with root fallback;
- `explicit`: use operator-provided `--shard` values;
- `specs-tasks-docs`: focus on specification/task/documentation consistency.

## Fork-join

Use fork-join when a complex task needs independent perspectives. The planner creates branches such as security, testing, architecture, documentation, dependency, or operations. A join step compares branch results and produces one decision-ready synthesis.

## Operational runner

The command `workflow run` can execute worker packets using the configured executor adapter:

```bash
python scripts/harness.py workflow run WF-YYYYMMDD-HHMMSS-ffffff --executor generic --concurrency 1
```

The runner:

- updates worker lifecycle status;
- captures stdout/stderr under the workflow runtime directory;
- saves a `WORKER_RESULT` returned through stdout when the worker did not write the result file;
- validates each worker result;
- keeps runtime logs out of Git.

Concurrency is available but conservative. Read-only workers remain the default. Controlled write workers require explicit approval, isolated workspaces, locks, merge planning, and approval-gated apply; see `docs/CONTROLLED_PARALLEL_WRITES.md`.

## Reduction and promotion

`workflow reduce` deduplicates findings, preserves conflicting recommendations, ranks by severity and writes both JSON and Markdown summaries. `workflow finalize` updates canonical workflow state. `workflow promote` creates a recommended task list under `tasks/generated/` for human review.

## Safety defaults

- Workers are read-only by default.
- Worker output is compact `WORKER_RESULT` JSON.
- Reducer output is `REDUCE_RESULT` JSON plus a concise Markdown summary.
- Graphify is used for structural discovery when applicable.
- Source files must verify graph-derived findings.
- Parallel writes require the explicit controlled-write policy: file-disjoint locks, isolated temp-copy or git-worktree workspaces, merge plans, human approval, rollback, and final validation.


## Operational hardening

The current workflow runner supports read-only concurrent worker execution with run locks, lifecycle states, retry/resume, output budgets, worker event logs, reducer synthesis, workflow-level finalization, durable async orchestration, and an explicit controlled-write track. Ordinary concurrent workers remain read-only; source edits must use controlled writes with locks, isolated temp-copy or git-worktree workspaces, merge plans, rollback, and final gates.

See `docs/WORKFLOW_OPERATIONS_RUNBOOK.md` for operator commands and recovery procedures.

## Current implementation boundary

The harness now implements the read-only agentic map-reduce/fork-join workflow as an operational runtime: profile-based planning, worker packets, controlled concurrent run, result validation, reducer synthesis, final HARNESS_RESULT generation, compact context update, and handoff regeneration.

Parallel source editing is implemented only as an explicit controlled-write workflow. It requires file ownership, lock files, isolated temp-copy or git-worktree workspaces, merge plans, rollback, shard validation, final full gates, and human approval before merge. Shared working-tree source edits remain unsupported.

## Latest read-only maturity features

The read-only workflow runtime now includes workflow candidate detection, `workflow suggest`, explicit changed-file baselines, semantic Graphify partitioning when graph metadata is available, phase-aware status, stable reducer finding IDs, canonical task promotion, optional agentic reducer/reviewer packets, and event replay.

The deterministic reducer remains the source of truth by default. Agentic reducer and reviewer packets are optional second-pass review aids; their outputs must still be validated before adoption.

## Output examples and review gates

Valid worker outputs for `done`, `partial`, `blocked`, and `failed` are documented in `docs/WORKER_RESULT_EXAMPLES.md`. High-risk workflow profiles can declare `reviewPolicy` and require a valid `REVIEWER_RESULT` before finalization.


## Controlled write track

Read-only workflows remain the default. Controlled write workflows require explicit approval, `workflow prepare-write`, file locks, isolated worker workspaces, `workflow merge-plan`, approval-gated `workflow apply-merge`, optional validation gates, and rollback support. See `docs/CONTROLLED_PARALLEL_WRITES.md`.


## Execution output contract

`workflow execute` returns the effective worker-result validation at top-level `validation` in addition to `run.validation`. Agentic reducer/reviewer helpers distinguish packet preparation from external execution with `preparedOnly: true` and `executionRequired: true`.

## Reviewer evidence bundle

| Command | Purpose |
|---|---|
| `python scripts/harness.py workflow evidence WF-... [--worker-id worker-001]` | Deterministic reviewer bundle (SPEC-129): per-worker status/failureClass/result paths plus the CQ.2 `oracleEvidence` capsule, `harnessResultPath`, records refs, and `riskFlags.requiresSecurityReview`. Pure assembly of existing handles — no re-run, no LLM, never artifact bodies. The panel render of this bundle is deferred (CLI half only). |

## Durable async-await orchestration

For long-running parallel tasks, prefer the async command family when the initiating terminal should not block:

```bash
python scripts/harness.py workflow start WF-... --mode all-settled
python scripts/harness.py workflow await WF-...
python scripts/harness.py workflow collect WF-...
```

This path differs from `workflow run`: it persists a task registry under the workflow's `async/` directory and exposes explicit settlement policies. Reducer/reviewer/finalize still run as explicit commands after await/collect so async execution does not hide cost, write behavior, or review requirements.
