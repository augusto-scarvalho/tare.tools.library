# Supervision UI/CLI — Ideation and Comparative Learnings

Living document. Captures what we learned surveying comparable projects and articles against this
harness, and the candidate designs for a human-supervisor GUI/CLI. Nothing here is implemented;
when an idea graduates, move it to a task under `tasks/` and link it back here.

## 1. Goal

Give the human operator a surface to **supervise the overseer model and interfere in the flow**:
see what agents are doing, approve or deny the irreversible steps, redirect work before it burns
tokens, and review what changed.

**Fixed design premise** (decided during ideation, applies to every candidate below): the UI never
invents state or writes it directly. It *reads* the JSON state under `.harness/` and *acts* only
by invoking an allowlist of `scripts/harness.py` subcommands — the same contract imposed on
agents. A UI with its own database or write path would be a second brain to keep in sync, and the
first source of drift.

## 2. What the harness already offers (the UI is a skin over this)

Supervision points, in increasing strictness (`HARNESS_ARCHITECTURE.md`, "Layer interactions and
supervision"):

1. **Escalation flags** — agents return `requiresEscalation: true` + `suggestedProfile` instead of
   widening scope.
2. **Proportional gates** — smoke / spec-pack / commit, chosen by blast radius.
3. **Approval tokens** — controlled writes refuse to run without `I_APPROVE_CONTROLLED_WRITES`.
4. **Protected files** — sha256-snapshotted canonical files; drift fails gates until reviewed.

Readable state (the UI's entire read API):

| Source | What it answers |
|---|---|
| `.harness/state/task-state.json`, `quality-state.json`, `workflow-state.json` | where are we, last validation, active workflow |
| `.harness/workflows/active/WF-*/` | worker packets, per-worker status, merge plans |
| `.harness/runs/` | agent results (`HARNESS_RESULT`, `WORKER_RESULT`), escalation flags |
| `.harness/handoff/` | what the next agent has been told to do |
| `tools/hooks/protect_canonical_files.py check` | protected-file drift |

## 3. Comparative learnings

| Project / source | What it is | Validates in ours | Gap it exposes | Worth stealing | Do NOT copy |
|---|---|---|---|---|---|
| [OpenRig](https://github.com/mvschwarz/openrig) | TS/Node daemon + Hono HTTP + React UI + SQLite + tmux; agents are tmux sessions; MCP server with 17 topology tools | CLI as the single write API (even their UI goes through it) | we have no live view of running agents | **tmux attach as the ultimate intervention** (human types into the agent's terminal — zero engineering cost); topology graph with pods; named snapshot/restore of a whole team (`rig down` / `rig up <name>`); CLI replies with *outcome + current state + next action*; `rig discover`/`adopt` for orphan sessions | the infrastructure: daemon + SQLite + React contradicts our stdlib-only, file-state, no-resident-process decisions. tmux is POSIX-only (we run on Windows) |
| [OpenHarness](https://github.com/HKUDS/OpenHarness) (HKUDS) | Python re-implementation of a Claude-Code-style agent engine (loop, 43+ tools, skills, memory, permissions); React+Ink TUI | UI as disposable shell over a pure core (their conclusion too) | our supervision is entirely **asynchronous** (review after the agent finishes); theirs is at-the-moment-of-action | per-action approval dialogs with tool detail; path-level deny rules; **dry-run** that previews resolved settings/auth/skills/tools before anything executes | the layer itself — we orchestrate existing agents, we don't re-implement the agent loop |
| [Anthropic: harness design for long-running apps](https://www.anthropic.com/engineering/harness-design-long-running-apps) | Engineering article: 3-agent architecture (Planner/Generator/Evaluator), GAN-style design loop, multi-hour autonomous builds | file-based handoffs between agents; context **reset** over compaction (fresh agent per packet); evaluation proportional to task ("evaluator is overhead within capability, real lift at the edge" = our gate ladder) | (1) no **pre-implementation contracts** — worker never proposes "what done looks like" for review before coding; (2) evaluator not tuned for skepticism — "out of the box, Claude is a poor QA agent", identifies real issues then talks itself into approving; (3) no **assumptions registry** — which model-capability assumption each harness component encodes, so nothing tells us what to strip on a model upgrade | hard thresholds per criterion (fail one → fail the sprint); evaluator prompt tuning toward proactive edge-case testing; stress-test harness components per model generation | assuming last iteration is best — improvement is non-linear (middle iterations sometimes beat final ones; relevant to our `reduce`); loaded prompt language ("museum quality") causes output convergence |
| [Vibe Kanban](https://github.com/BloopAI/vibe-kanban) (Bloop, now community-maintained) | Web kanban (To Do/In Progress/Review/Done) driving 10+ local agents, one git worktree per workspace, inline diff review, MCP card creation | task-decomposition-first workflow | our WF states have no board-like at-a-glance view | **kanban as the supervision metaphor** — columns map 1:1 to our workflow states (queued/running/needs-review/done); review-changes-like-a-PR panel | company shut down (Apr 2026) — a warning about scope: the paid cloud layer died, the local OSS tool survived |
| [claude-squad](https://github.com/smtg-ai/claude-squad) | Go TUI over tmux + git worktrees; dashboard of instances, diff preview, auto-accept mode, commit/push from the TUI | isolation per task (worktrees) | — | smallest useful surface: a **list of running instances + diff + attach** covers 80% of supervision; auto-accept toggle = our supervised/autonomous distinction as one switch | tmux dependency (POSIX-only) |
| [Conductor](https://conductor.build) (Mac app) | Native Mac app, worktree per workspace, checkpoints/rollback, multi-model compare, GitHub/Linear integration | — | we have no checkpoint/rollback story outside controlled-write backups | **checkpoints** (automatic snapshots + one-click rollback); running two models on the same prompt side-by-side to compare (cheap A/B for spawn profiles) | Mac-only native app; platform lock-in for a cross-platform harness |
| [OpenClaw](https://github.com/openclaw/openclaw) | Self-hosted personal assistant (TypeScript/Node daemon); routes 22+ chat channels (WhatsApp, Telegram, Slack…) to agents; sandboxed sessions; skills registry | operator-in-the-loop as explicit design goal; local-first | supervision in our harness requires sitting at the machine — no remote/notification surface | **supervision where the human already is**: chat channel as control surface, with `/`-commands (`/status`, `/usage`, `/trace on`) for real-time visibility; **pairing-code approval** (unknown sender → code → explicit operator approve → allowlist) as a pattern for authorizing new actors; `doctor` command that proactively surfaces risky configuration | the always-on daemon + 22-channel surface — massive attack/maintenance area; our supervisor needs 1 channel, not 22 |
| [Hive](https://github.com/aden-hive/hive) (Aden) | Python execution harness that compiles a natural-language goal into a strict DAG of role-based agents; LiteLLM (100+ providers); checkpoints, crash recovery, control plane with dashboard | its thesis is ours: "reliability and production value are determined by the harness"; role-based memory ≈ our packets/handoffs | (1) our human pauses exist only *between* steps — Hive has **intervention nodes**: first-class graph nodes that pause execution for human input, with configurable timeouts and escalation policies; (2) we audit token cost (`token-audit`) but don't **enforce budgets** — Hive enforces spend limits per team/agent/workflow with automatic model degradation | intervention-node semantics for our workflow profiles (a declared pause-for-human step with timeout + fallback policy, instead of everything-async); budget enforcement bolted onto `token-audit` | **self-evolving graphs** (on failure the system rewrites the DAG and redeploys itself) — directly contradicts our contract that agents never change their own scope/profile; failure should escalate to a human, not self-modify |

### 3b. From the research literature

| Paper | Venue / group | Finding relevant to us | Consequence for this harness |
|---|---|---|---|
| [Why Do Multi-Agent LLM Systems Fail? (MAST)](https://arxiv.org/abs/2503.13657) | UC Berkeley (Stoica, Zaharia, Gonzalez, Klein et al.) | First empirical failure taxonomy for multi-agent systems: **14 failure modes in 3 categories — specification issues, inter-agent misalignment, task verification** — from 1600+ annotated traces across 7 frameworks (κ=0.88) | The 3 categories map directly onto our layers: specification → handoff/contract quality; misalignment → packet boundaries; verification → gates/evaluator. Use MAST categories as the **organizing principle of the escalation/monitoring panel** (group failures by root-cause class, not chronologically). Also validates contract-first: most failures are spec and verification, exactly what contracts + gates attack |
| [AutoGen Studio](https://arxiv.org/abs/2408.15247) | Microsoft Research | First open no-code UI for multi-agent dev: declarative JSON workflow spec + drag-drop + **profiling views (message flow between agents, costs, tool invocations, tool output status)** | Validates our declarative `workflow-profiles.json`. The profiling views are the academic version of our "active workflows" panel — message-flow + cost-per-agent visualization is proven useful for *debugging*, not just monitoring |
| [Dark Patterns Meet GUI Agents](https://arxiv.org/abs/2509.10723) | arXiv 2025 | Human oversight of agents improves outcomes but **introduces its own failure modes: attentional tunneling and cognitive load** | A supervision UI is not free for the human. Design constraint for §4: prioritized, categorized alerts — never a firehose; the escalation queue must rank by blast radius, not arrival time |
| [The Interplay of Harness Design and Post-Training in LLM Agents](https://arxiv.org/abs/2606.25447) | arXiv 2026 | Harness scaffolding (which tools are exposed, how described) is "typically treated as a fixed engineering detail" but **interacts with model post-training** | Academic backing for the Anthropic article's lesson and our §6 assumptions registry: the harness must be re-evaluated per model generation, it is not settled infrastructure |
| [Code as Agent Harness](https://arxiv.org/abs/2605.18747) | arXiv 2026 | Survey of harness mechanisms (planning, memory, tool use) for long-horizon execution across coding, GUI/OS automation, enterprise workflows | Background survey; useful citation map when we formalize harness docs |
| [LLM-Based Human-Agent Collaboration and Interaction Systems: A Survey](https://arxiv.org/abs/2505.00753) | ACL 2026 | Survey of human-agent collaboration systems; companion [awesome-list](https://github.com/HenryPengZou/Awesome-Human-Agent-Collaboration-Interaction-Systems) | Reference index for future deep-dives on specific interaction patterns |
| [Toward a Human-Centered Evaluation Framework for Trustworthy LLM-Powered GUI Agents](https://arxiv.org/abs/2504.17934) | arXiv 2025 | GUI agents with limited oversight raise privacy/security risk; proposes **risk assessments and in-context consent** in the loop | Supports our per-action approval direction (§5): consent at the moment of the risky action, not blanket upfront authorization |

## 4. GUI candidates, laziest first

| # | Candidate | Effort | Supervision reach | Verdict |
|---|---|---|---|---|
| a | `harness.py status --html`: generate a static snapshot page on demand | hours | read-only — no interference | good first step, insufficient alone |
| b | **Single-file local panel**: `scripts/harness_ui.py`, stdlib `http.server`, one HTML page polling the state JSONs (1–2 s); buttons POST to endpoints that run allowlisted `harness.py` subcommands via `subprocess` | days | full: all 4 supervision points clickable | **recommended** — zero deps, honours stdlib-only, cross-platform |
| c | TUI (Textual/Rich) | days | same as (b) | adds a dependency; stdlib `curses` is poor on Windows |
| d | Full web app (FastAPI + React + DB) | weeks | same as (b) | rejected: duplicates the state machine the CLI already is; permanent second brain |

Panel layout for (b), mapped to the supervision points in §2:

| Panel | Reads | Supervisor action (via CLI) |
|---|---|---|
| Escalation queue | `HARNESS_RESULT.requiresEscalation` in `.harness/runs/` | approve → `spawn-command` with `suggestedProfile`; or deny + edit handoff |
| Active workflows | `workflow-state.json`, `WF-*/` | `token-audit` before spending, `await`, `unlock`; **reduce** button enabled only when no worker is running |
| Controlled writes | WF merge plan | "Approve" with confirm dialog that injects `I_APPROVE_CONTROLLED_WRITES` — token stays a deliberate act, just clickable |
| Protected-file drift | `protect_canonical_files.py check` | side-by-side diff → "accept & re-snapshot" or "revert" |
| Gates / health | `quality-state.json`, `task-state.json` | trigger smoke / spec-pack / commit, see results |
| Handoff | `.harness/handoff/` | read/edit the handoff **before** approving a spawn — the main "interfere with what the overseer decided" hook |

Security requirements (non-negotiable if built): bind `127.0.0.1` only, session token in the URL
(any page open in the browser can POST to localhost — CSRF), and the action endpoint accepts a
strict **allowlist of `harness.py` subcommands**, never arbitrary shell.

Human-factors requirement (from the dark-patterns oversight study, §3b): oversight has its own
failure modes — attentional tunneling and cognitive load. The escalation queue therefore ranks by
blast radius, not arrival time; panels categorize rather than stream; and anything that can be
resolved by a default should not page the human at all.

## 5. CLI refinements (valuable with or without a GUI)

- **Outcome + state + next action** (OpenRig pattern): every `harness.py` subcommand ends its
  output with the current state and the suggested next command. `status` half-does this; make it
  uniform.
- **`--dry-run`** (OpenHarness pattern) for `workflow execute` and `workflow apply-merge`: print
  resolved packets / merge plan / locks and exit without spending tokens or touching files.
- **Per-item approval** in controlled writes: today `I_APPROVE_CONTROLLED_WRITES` approves the
  whole batch; an `--interactive` mode stepping diff-by-diff (approve/deny each) is the
  OpenHarness at-the-moment-of-action model applied to our riskiest track.

## 6. Harness backlog (beyond UI)

> Elaborated in full — with evidence, repo mapping, and anti-patterns — in
> `HARNESS_IMPROVEMENT_IDEAS.md`. The table below is the quick index.

| Candidate | One-line scope | Effort / return |
|---|---|---|
| Skeptical evaluator | anti-leniency tuning in the reviewer profile + `REVIEWER_RESULT`: hard thresholds per criterion, proactive edge cases, explicit ban on "approve despite identified issues" | low / high — attacks the documented default bias |
| Pre-implementation contracts | extend `subagent-contract.md`: worker proposes acceptance criteria up front; reviewer/supervisor approves before implementation starts | medium / high on large tasks |
| Assumptions registry | section in `HARNESS_ARCHITECTURE.md`: component → model-capability assumption it encodes → re-evaluate-on-upgrade signal | low / compounds at every model upgrade |
| Non-linear `reduce` | reduce step should not assume the last worker result is the best; keep intermediates comparable | low / situational |
| Intervention nodes (Hive) | a declared pause-for-human step in workflow profiles, with timeout + escalation policy, instead of supervision only between steps | medium / high on long workflows |
| Budget enforcement (Hive) | `token-audit` today only reports; add per-workflow spend limits that refuse to start/continue past budget | low / high on paid executors |
| MAST failure tagging | tag gate failures and escalations with a MAST category (specification / inter-agent misalignment / verification) so the escalation queue groups by root-cause class and trends are visible over time | low / compounds with usage |

## 7. Decision criteria and open questions

- **Does stdlib-only extend to the UI?** Working assumption: yes for anything that ships in the
  repo (candidate b honours it). A richer UI would live outside the repo as an optional adapter,
  like `.claude/` does.
- **Live attach vs. async supervision.** OpenRig-style attach requires agents in interactive
  terminals (tmux, POSIX-only). Our model is async-by-contract: the agent finishes, evidence lands
  in `.harness/runs/`. Interference is therefore *between* steps, not *during* them. The cheap
  middle ground: surface the `spawn-command` so the operator runs the agent in their own terminal
  — which is interactive attach, for free, today.
- **Which panel first?** The escalation queue is the highest-leverage single panel: it is the one
  place an agent explicitly asks a human for a decision, and today it is buried in JSON.
- **Does the supervisor need a page at all?** OpenClaw's model suggests a cheaper channel: push
  escalations and approval requests to where the human already is (one chat platform, not 22),
  answered with `/`-style commands. Could complement or even precede the web panel — but it
  reintroduces a resident process, which the panel (started on demand) avoids.

## 8. Strategy: CLI first, then GUI

> Operationalized as an ordered backlog with per-milestone MVPs in `IMPLEMENTATION_BACKLOG.md`.

Not one option among several — it is the topological order our own design premise (§1) imposes:
the GUI never writes state, every button invokes a `harness.py` subcommand, so anything a panel
needs that the CLI cannot do becomes CLI work first anyway. CLI improvements also serve **agents**
(they read the same errors and outputs); the GUI serves only the human. Build the shared layer
first.

References in parentheses point to this doc and to `HARNESS_IMPROVEMENT_IDEAS.md` (letters).

### Phase 1 — CLI as a complete supervision surface (no GUI at all)

| Order | Item | Why this order |
|---|---|---|
| 1.1 | Self-announcing errors in gates/hooks/refusals (F4) — remediation map in `spec_test_gate.py::result()` | cheapest, highest reach; every later phase inherits legible failures |
| 1.2 | Outcome + state + next action on every subcommand (G2) | the "next action" line **is** the future GUI's primary button — designing it in text first is designing the GUI |
| 1.3 | `--dry-run` on `workflow execute` / `apply-merge` (D3) | preview before spend; later becomes the GUI's confirmation screen for free |
| 1.4 | `harness.py escalations` — list pending `requiresEscalation` results with suggested profile, one per line | the escalation queue (§4's first panel) as a command; proves the read path before any rendering |
| 1.5 | Budget refusal (D2) | enforcement must live in the CLI anyway; a GUI toggle over it is trivial later |

**Exit criterion:** a human can supervise a full workflow — see state, preview cost, approve,
escalate, diagnose a red gate — from the terminal alone, with no file spelunking.

### Phase 2 — read-only GUI (rendering, zero new capability)

`harness.py status --html` (§4a): one static snapshot page generated from the same state the
Phase 1 commands read. No server, no actions, no security surface. Its only job is to validate
that the state files answer every question a panel would show — gaps found here are Phase 1
regressions, fixed in the CLI.

**Exit criterion:** the page renders escalations, workflows, gates, drift, and handoff without
needing any data the CLI doesn't already expose.

### Phase 3 — interactive panel (§4b)

The single-file `http.server` panel. By now every button maps 1:1 to a Phase 1 command — the
POST allowlist is literally the Phase 1 command list, already hardened and already legible when
it fails (1.1). Panels arrive in the §4 table's order, escalation queue first.

**Exit criterion:** feature-parity with Phase 1 — the panel never does anything the terminal
cannot.

### Phase 4 — only if demand proves it

Intervention nodes' answer flow (D1), chat-channel push (§7's open question), kanban view.
Each reintroduces cost (resident process, notification infra); each needs a real usage signal
first.

The MAST failure tagging (G1) rides along whenever convenient — it changes result schemas, not
surfaces, and every phase benefits from it.

---
*Sources surveyed 2026-07-09: OpenRig, OpenHarness (HKUDS), Anthropic engineering article on
long-running harness design, Vibe Kanban (BloopAI), claude-squad (smtg-ai), Conductor
([madewithlove review](https://madewithlove.com/blog/conductor-running-multiple-ai-coding-agents-in-parallel/)),
OpenClaw, Hive (Aden). Crystal was renamed Nimbalyst; treated as legacy, not surveyed separately.
Academic sources in §3b surveyed the same day (MAST/Berkeley, AutoGen Studio/MSR, ACL 2026 survey,
arXiv 2025–2026 harness papers).*
