# Flow composer (the Compose screen)

The **Compose** tab in the supervision panel is a *view and editor* over the
workflow profiles the harness already ships (`.harness/workflows/workflow-profiles.json`)
plus the fork-join *branch objects* those profiles declare. It is **not** a free
canvas: you do not draw arbitrary nodes and wires. You pick a profile, tweak its
branches, and the DAG picture is *derived* from that — the profile JSON stays the
source of truth. Because the layout is recomputed from form state on every edit,
nothing is stored and the view can never drift out of sync with what would
actually run.

## Lifecycle at a glance

```
pick profile
   → edit branches (role / taskProfile / workerRole)
      → Compile   (validates; writes NOTHING; shows tokens + errors)
         → Criar  (materializes a `planned` workflow; confirm-gated; does NOT start)
            → start it separately  (CLI `workflow start <id>`, or the panel)
               → Descartar         (remove a STOPPED one you no longer want)
```

1. **Pick a profile.** The dropdown is a *closed* list — only known profiles.
   A fork-join profile shows editable branch rows; a map-reduce profile derives
   its shards at compile time, so its branches are not per-row editable.
2. **Edit branches.** For each branch you can set the title, the `taskProfile`
   (also a closed list of known task profiles), and the `workerRole`. The DAG
   label re-renders live as you type — that is just the picture updating, still
   nothing written.
3. **Compile (validate-only).** Sends the composed candidate to the compiler.
   It **writes nothing** and creates no workflow directory. You get back a
   verdict: valid or not, the per-worker rows, the token audit, and any errors.
   Think of it as "dry run the plan".
4. **Criar (create).** Enabled *only* after a green compile. It materializes a
   real workflow directory and its worker prompts from your composed branches —
   a workflow in the **`planned`** phase, workers `pending`. It is **confirm-gated**
   and it **does not start anything**: no agent is spawned, no tokens are spent.
   The new workflow now shows as agent cards on the dashboard.
5. **Start it (separately).** Creating is deliberately not starting. Run the
   workflow when you actually want the agents to spawn: `workflow start <id>`
   from the CLI, or the panel's start control.
6. **Descartar (discard).** If you created a workflow you no longer want and it
   was **never started** (or has already stopped), Descartar removes it — the
   directory and its worker cards — so the board clears. See the safety note
   below: discard only works on a **stopped** workflow.

## The two-step safety (Compile, then Create)

Create and Compile are split on purpose. **Compile is the trust boundary**: it is
the only thing that decides whether a browser-composed candidate is allowed to
become real work. It enforces three things before anything is written:

- **closed vocabulary** — the profile and every `taskProfile` must be in the
  known set; an unknown name is rejected, not guessed;
- **secret scan** — the task/goal text and branch content are scanned for
  secret-shaped values;
- **budget** — the token audit must pass (or warn), not breach.

**Criar re-runs that exact compile in-process and refuses unless it is valid.**
You can only create what validates. There is no way to create straight from
browser input without a passing compile.

## The verbs

| Verb | What it does | Side effects |
|------|--------------|--------------|
| **Compile** | Validate a composition | Read-only — writes nothing |
| **Criar** | Materialize a `planned` workflow | Creates a WF dir + prompts; does **not** start it, spends no tokens |
| **Iniciar** (start) | Run the workflow | Spawns agents, **burns tokens** |
| **Cancelar** (cancel) | Stop a **running** workflow | Signals the live task's processes; a no-op on a WF that never started |
| **Descartar** (discard) | Remove a **stopped** workflow | Deletes the WF dir + its cards; refused while the WF is running |

Two rules keep the destructive power scoped:

- **Cancel is for running work; Discard is for stopped work.** Cancel only
  signals a *running* workflow's async task PIDs. A workflow that was created but
  never started has no such process, so cancel does nothing and the cards stay —
  that is exactly the gap Descartar fills. The panel's cancel dialog reminds you:
  for a workflow that never started, use Descartar.
- **Discard is scrub, restricted.** Descartar runs `workflow scrub <id>` with
  **no `--force`**. Before it runs, the panel checks the workflow id against the
  live `active/` state and **refuses if the workflow is running** (a live run
  lock or supervisor process). Only a stopped workflow — planned, settled,
  failed, or cancelled — can be discarded from the browser. Scrubbing *running*
  work, and the `--force` override, stay **CLI-only** on purpose: you cannot nuke
  live work from a browser tab.

## Where this fits

- [SPEC-120 — renderer-first flow composer](../specs/40-features/flow-composer.md)
  (the derived DAG + validate-only compile).
- [SPEC-119 — fork-join branch objects / `--branch-json`](../specs/40-features/research-skill.md)
  (how composed branch objects materialize).
- [SPEC-114 — supervision panel](../specs/40-features/supervision-m5-interactive-panel.md)
  (the panel this screen lives in, including the discard action).
- Background on why an agent GUI wants these verbs at all:
  [agent GUI/CLI features research](research/agent-gui-cli-features.md).
