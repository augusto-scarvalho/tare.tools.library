# Worker isolation — modelo de ameaça e o teto do confinamento OS-level

Registro do que o confinamento de workers do harness isola DE VERDADE, contra qual
modelo de ameaça, e por que a fronteira é OS-level (Job Object + ACLs) e não
container/VM. Origem: pergunta do owner 2026-07-21 durante a fila de segurança
SECREV (H1/M2, D043). Isto é uma decisão de design consciente, não uma limitação
por omissão — se o modelo de ameaça mudar, a fronteira muda com ele (última seção).

## O modelo de ameaça REAL do harness (hoje)

O harness é **local-first, single-tenant, na máquina do dono**. O worker roda código
que o MODELO (Claude/Codex) gerou para editar o REPO DO PRÓPRIO DONO, sob o mesmo
usuário do SO. A ameaça que isso enfrenta é:

- **O agente ERRA** — loop infinito, fork-bomb acidental, vazamento de memória,
  escrita fora do escopo, processo que sobrevive ao pai.
- **O agente é ENVENENADO** — conteúdo externo (docs de vendor, saída de tool, memória
  recuperada) tenta induzir uma ação que o agente não deveria tomar (poisoning, prompt
  injection).

O que NÃO é o modelo de ameaça hoje:

- **O agente é um ATACANTE** com intenção e execução de código arbitrário para escapar
  do confinamento e comprometer a máquina. O código que o worker roda não é código
  não-confiável de terceiros — é auto-gerado sobre o repo do dono.

## O que o confinamento OS-level entrega (contra o modelo real)

| Superfície | Mecanismo | Estado |
|---|---|---|
| Recursos (fork-bomb, memória, processo órfão) | Windows Job Object (cap de processos/memória, kill em árvore) | 1 de 3 seams hoje → 3 de 3 após H1 (SPEC-163 fase 2) |
| Escrita nos arquivos canônicos | `fs_confine_nt` (ACE deny + read-only nos protegidos) | sólido; M3 fecha o furo da junction no teardown |
| Herança de segredos de ambiente | `filter_spawn_env` (allowlist) nos 3 seams | sólido (parecer SECREV) |
| cwd fora da árvore viva | R1+ refuse se `cwd == root` | sólido |
| Honestidade do que foi aplicado | `procApplied`/`fsApplied` no manifest (SPEC-163 fase 1) | shipped |

Para o modelo "erra ou é envenenado", isto É isolamento de verdade e de custo baixo:
o worker não derruba a máquina, não reescreve o que é canônico, não vaza segredo de
env — e agora o manifest não mente sobre o que foi aplicado.

## Os tetos DECLARADOS (o que OS-level NÃO isola)

1. **Rede / egress.** Bloquear rede por processo no Windows exige admin (WFP). Sem
   isso o `--allow-hosts` é advisory, não fronteira — o worker PODE fazer rede.
2. **Leitura de disco.** Workers R0 (read) têm confinamento de escrita mas ZERO de
   leitura — podem ler qualquer arquivo da máquina, inclusive segredos fora do repo.
3. **Mesmo usuário.** É confinamento no nível do SO, não uma cela. O worker roda como
   o dono. Contra código genuinamente adversarial com intenção de escapar, OS-level
   não é uma fronteira de segurança — e nenhum item da fila SECREV muda isso.

## Por que NÃO container/VM (hoje)

Container/VM é a fronteira CERTA para um modelo de ameaça mais forte (código
não-confiável). É a fronteira ERRADA para o modelo ATUAL, por cinco razões concretas:

1. **Quebra o zero-friction / local-first (D024).** O princípio é "clona e roda". No
   Windows (ambiente primário do dono), container Linux exige WSL2/Hyper-V
   (virtualização) — muitos devs não têm ou não podem ligar (BIOS/política
   corporativa). VM é ainda mais pesado. Exigir isso mata o "sem setup".
2. **O worker PRECISA da árvore de código.** O trabalho do worker É editar o repo,
   rodar gates, commitar. Um container isolado precisaria de bind-mount da árvore — e
   o isolamento de fs VAZA pelo mount: o worker escreve no repo montado, que é a mesma
   superfície que se queria proteger. O isolamento forte do container é exatamente o
   que atrapalha o trabalho que o worker existe para fazer.
3. **Custo/latência por spawn.** Subir container/VM por worker é ordens de magnitude
   mais caro que `Popen` (segundos vs milissegundos). O harness faz fan-out de muitos
   workers; o overhead mataria o throughput que o paralelismo existe para ganhar.
4. **Estado compartilhado.** O harness coordena workers via `.harness/` (locks, holds,
   receipts, o hash-chain). Cruzar a fronteira container↔host para esse estado é
   plumbing frágil (o que o backlog `target-worker-world` tangencia).
5. **O modelo de ameaça não pede.** Container/VM defende contra ESCAPE de execução
   arbitrária. O worker não roda código não-confiável — roda código auto-gerado sobre
   o repo do dono. Pagar o custo (1-4) para uma ameaça que não é a nossa seria controle
   sem a medição que o justifica (o anti-padrão measure-before-control do repo).

Resumindo: OS-level casa o modelo de ameaça real com custo baixo e preserva o
zero-friction; container/VM resolveria uma ameaça que não temos, ao preço de quebrar o
que faz o harness ser usável.

## Quando a fronteira DEVE mudar para container/VM (gatilhos)

A escolha se inverte se o modelo de ameaça mudar. Gatilhos que reabrem a decisão:

- **Rodar código de TERCEIROS não-confiável**: deps arbitrárias, MCP servers
  desconhecidos, executores externos que o dono não auditou (relates: `SEC.4`
  hash-pinned admission ledger).
- **Multi-operador / multi-tenant**: workers de usuários diferentes na mesma máquina
  (o single-tenant deixa de valer).
- **Egress que precisa ser fortemente bloqueado** além do que WFP/admin dá.
- **Target workers confinados fora da árvore do harness** (`target-worker-world`).

Quando um desses virar real, a fronteira vira container/VM (ou um sandbox de kernel
mais forte) — e aí o custo (1-4) passa a se justificar. Até lá, endurecer o OS-level
(a fila SECREV) é o investimento certo. Esta decisão é REVERSÍVEL: nada no design
atual impede trocar a fronteira quando o gatilho chegar.
