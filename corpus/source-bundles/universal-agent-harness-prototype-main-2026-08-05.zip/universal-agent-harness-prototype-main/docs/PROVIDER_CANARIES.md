# Provider canary policy

Real Codex, Claude, Gemini, or other provider canaries are deliberately downstream opt-in. The reusable template must never call authenticated providers, send network traffic, or write to a project workspace during product-release validation.

## Template contract

The template ships a `provider-canary` fixture that verifies policy, not live credentials:

- provider canaries are disabled by default;
- the opt-in environment variable is `HARNESS_RUN_PROVIDER_CANARIES`;
- network execution is disabled by default;
- write canaries require an explicit sandbox;
- executor adapters classify rate-limit, auth, and quota failures.

```bash
python scripts/harness-test.py --fixture provider-canary
```

## Downstream canary modes

Adopting projects may add live jobs for:

1. read-only preflight: small prompt, no repository writes;
2. write-sandbox: writes only inside a disposable fixture repository or worktree;
3. auth-failure classification: intentionally missing/invalid credentials in a safe job;
4. rate/quota classification: controlled simulation or mocked provider response.

Live canaries should be separate from `product-release` and must be marked non-secret in logs. Never run live provider canaries from installer hooks or pre-edit hooks.
