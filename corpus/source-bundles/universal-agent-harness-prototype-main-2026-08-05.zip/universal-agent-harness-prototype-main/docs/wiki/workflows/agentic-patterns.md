# Agentic Patterns

## In plain terms

Complex work is rarely one straight line. The harness supports a few standard
shapes for agent work: splitting into parallel branches and rejoining
(fork/join), fanning many similar items out and combining the results
(map/reduce), and running steps that wait on each other (async/await). Picking the
right shape keeps work parallel where it is safe and ordered where it must be.

## Going deeper

Each pattern is a language-agnostic baseline spec under `specs/00-universal/`, so
it applies regardless of stack. Fork/join defines how branches split and
reconverge; map/reduce defines the fan-out plus a reducer step; async/await
defines dependency-ordered steps. The workflow model doc shows how these map onto
the concrete runtime.

## Sources

- [specs/00-universal/agentic-fork-join.md](../../../specs/00-universal/agentic-fork-join.md)
- [specs/00-universal/agentic-map-reduce.md](../../../specs/00-universal/agentic-map-reduce.md)
- [specs/00-universal/agentic-async-await.md](../../../specs/00-universal/agentic-async-await.md)
- [docs/AGENTIC_WORKFLOWS.md](../../AGENTIC_WORKFLOWS.md) — runtime mapping.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
