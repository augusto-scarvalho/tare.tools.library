# Flow Composer

## In plain terms

The Compose screen lets you build a workflow visually — arranging steps and
branches — instead of hand-writing its definition. It is the graphical front door
to the same workflow model the CLI uses.

## Going deeper

The Flow Composer doc describes the Compose screen and serves as the model for
per-screen manuals; the feature spec (flow-composer) owns the normative behavior.
The composer's server-side logic lives in `scripts/harness_lib/ui_composer.py`.
Per the panel parity rule, the composer adds no capability the workflow CLI lacks
— it renders the same underlying subcommands.

## Sources

- [docs/FLOW_COMPOSER.md](../../FLOW_COMPOSER.md) — Compose screen manual.
- [specs/40-features/flow-composer.md](../../../specs/40-features/flow-composer.md) — feature spec.
- [scripts/harness_lib/ui_composer.py](../../../scripts/harness_lib/ui_composer.py) — composer logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
