# Workflows

How the harness shapes agent work into runnable, resumable units — the patterns,
the day-to-day operations, safe parallel writes, token cost control, and the
visual Compose screen.

## Topics

- [Agentic Patterns](agentic-patterns.md)
- [Workflow Operations](workflow-operations.md)
- [Controlled Parallel Writes](controlled-parallel-writes.md)
- [Token Economics](token-economics.md)
- [Flow Composer](flow-composer.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
