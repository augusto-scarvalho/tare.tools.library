# Workflow Operations

## In plain terms

Once a workflow is running you need to watch it, pause or resume it, and recover
it if something goes wrong. This is the operator's side of workflows: the
practical playbook for keeping runs healthy.

## Going deeper

The operations runbook is the authoritative procedure list (launch, monitor,
recover) and is gate-checked for consistency with the runtime. The lifecycle
state machine that these operations drive lives in
`scripts/harness_lib/workflow_lifecycle.py`, with workflow state persisted through
the state modules. Commands are exposed through the `scripts/harness.py` CLI.

## Sources

- [docs/WORKFLOW_OPERATIONS_RUNBOOK.md](../../WORKFLOW_OPERATIONS_RUNBOOK.md) — operator procedures.
- [scripts/harness_lib/workflow_lifecycle.py](../../../scripts/harness_lib/workflow_lifecycle.py) — lifecycle state machine.
- [scripts/harness_lib/workflow_state.py](../../../scripts/harness_lib/workflow_state.py) — persisted workflow state.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
