# Controlled Parallel Writes

## In plain terms

When several agents work at once, they can collide by editing the same files. The
harness runs write-producing agents in isolated workspaces and merges their
results under control, so parallel work does not corrupt the tree or silently
overwrite each other.

## Going deeper

The controlled-parallel-writes doc defines the isolation-then-merge model; the
implementation is `scripts/harness_lib/controlled_writes.py`. Scenario isolation
for parallel runs is specified separately (parallel-scenarios), keeping each
worker's checks from contaminating siblings. Protected canonical files are locked
in write-worker workspaces so that mutation attempts surface at merge rather than
silently landing.

## Sources

- [docs/CONTROLLED_PARALLEL_WRITES.md](../../CONTROLLED_PARALLEL_WRITES.md) — isolation/merge model.
- [scripts/harness_lib/controlled_writes.py](../../../scripts/harness_lib/controlled_writes.py) — implementation.
- [specs/40-features/parallel-scenarios.md](../../../specs/40-features/parallel-scenarios.md) — isolated scenario runs.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
