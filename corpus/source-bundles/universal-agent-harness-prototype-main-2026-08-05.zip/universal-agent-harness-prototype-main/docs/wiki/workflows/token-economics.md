# Token Economics

## In plain terms

Every agent action costs tokens (money). The harness tracks that cost and pushes
work toward the cheapest option that still does the job — for example, cheap
discovery tools before expensive bulk reads, and small models for lookups. This
keeps large multi-agent runs affordable.

## Going deeper

The token-economics doc lays out the cost model and directives. Token accounting
during workflow reduction lives in `scripts/harness_lib/workflow_token_audit.py`,
and the broader economics helpers in `scripts/harness_lib/token_economics.py`.
These feed the reducer and reviewer stages so context growth stays visible in
validation rather than surfacing only on the bill.

## Sources

- [docs/WORKFLOW_TOKEN_ECONOMICS.md](../../WORKFLOW_TOKEN_ECONOMICS.md) — cost model and directives.
- [scripts/harness_lib/workflow_token_audit.py](../../../scripts/harness_lib/workflow_token_audit.py) — token accounting.
- [scripts/harness_lib/token_economics.py](../../../scripts/harness_lib/token_economics.py) — economics helpers.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
