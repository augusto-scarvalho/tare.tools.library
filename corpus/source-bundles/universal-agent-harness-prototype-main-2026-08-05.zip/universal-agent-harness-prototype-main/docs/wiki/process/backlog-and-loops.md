# Backlog and Loops

## In plain terms

Planned work lives in a central backlog of rows (like the `wiki-sources` row that
produced this wiki). Work runs in loops that pick up rows, deliver them, and close
them out — with guards that stop a row being marked done before it really is.

## Going deeper

The implementation backlog (docs/IMPLEMENTATION_BACKLOG.md) is the central list of
rows with sizes, priorities, and dependencies. Closure is guarded by the
backlog-closure-guard spec so a row cannot be struck without its deliverable and
evidence. Rows unblock dependents (this row unblocks `wiki-screen` and
`wiki-spec-guard`), which is how loops sequence work.

## Sources

- [docs/IMPLEMENTATION_BACKLOG.md](../../IMPLEMENTATION_BACKLOG.md) — central backlog.
- [specs/40-features/backlog-closure-guard.md](../../../specs/40-features/backlog-closure-guard.md) — closure guard.
- [Specs and SDD](specs-and-sdd.md) — how backlog rows become specs.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
