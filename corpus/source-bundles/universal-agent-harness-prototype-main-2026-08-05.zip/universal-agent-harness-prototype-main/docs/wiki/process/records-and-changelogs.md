# Records and Changelogs

## In plain terms

Instead of long status reports piling up in docs, the harness keeps a records
ledger — a compact, queryable log of what was done. This keeps history available
without bloating the startup context every agent reads.

## Going deeper

The records-ledger feature spec defines the ledger and replaced the old
free-standing changelog file; the logic lives in `scripts/harness_lib/records.py`
(exposed via the `records` CLI command). This is the mechanism the content guide
points to when it says completed burn-downs should link to evidence rather than
duplicate full logs.

## Sources

- [specs/40-features/records-ledger.md](../../../specs/40-features/records-ledger.md) — records ledger spec.
- [scripts/harness_lib/records.py](../../../scripts/harness_lib/records.py) — ledger logic.
- [docs/HARNESS_CONTENT_GUIDE.md](../../HARNESS_CONTENT_GUIDE.md) — anti-bloat rules the ledger serves.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
