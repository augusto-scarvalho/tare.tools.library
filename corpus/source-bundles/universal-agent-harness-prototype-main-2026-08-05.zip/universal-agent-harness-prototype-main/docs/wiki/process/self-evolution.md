# Self-Evolution

## In plain terms

The harness is meant to improve itself: propose changes to how it works, try them
as experiments, and keep the ones that measurably help. This is the loop that turns
ideas about the harness into shipped improvements.

## Going deeper

The self-evolution-loop feature spec defines the improvement loop; the ideation
ledger (docs/SELF_EVOLUTION_IDEATION.md) is the living survey of candidate ideas.
The loop leans on the experiment machinery (see Research) to judge changes honestly
rather than by intuition.

## Sources

- [specs/40-features/self-evolution-loop.md](../../../specs/40-features/self-evolution-loop.md) — improvement loop spec.
- [docs/SELF_EVOLUTION_IDEATION.md](../../SELF_EVOLUTION_IDEATION.md) — ideation ledger.
- [Experiments](../research/experiments.md) — how changes are measured.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
