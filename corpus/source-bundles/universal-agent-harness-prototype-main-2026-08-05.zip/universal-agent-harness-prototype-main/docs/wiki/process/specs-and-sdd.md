# Specs and SDD

## In plain terms

Features are described in specs before they are built, and the description is
written so it can be tested (spec-driven / behavior-driven development). This is why
the specs are the canonical truth and this wiki only summarizes them.

## Going deeper

The specs index (specs/SPECS.md) lists the corpus; the universal sdd-bdd-flow spec
defines the spec-then-Gherkin-then-check flow. Conformance — making sure feature
specs keep the required shape and map to their checks — is enforced by
`scripts/harness_lib/spec_conformance.py`. Feature specs live under
`specs/40-features/` and stay whole (conformance owns their format); the wiki
fragments orientation, not the specs.

## Sources

- [specs/SPECS.md](../../../specs/SPECS.md) — specs index.
- [specs/00-universal/sdd-bdd-flow.md](../../../specs/00-universal/sdd-bdd-flow.md) — SDD/BDD flow.
- [scripts/harness_lib/spec_conformance.py](../../../scripts/harness_lib/spec_conformance.py) — conformance enforcement.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
