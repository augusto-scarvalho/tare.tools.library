# Process

How work is planned and remembered: spec-driven development, the backlog and its
loops, the records/changelog ledger, and the self-evolution process by which the
harness improves itself.

## Topics

- [Specs and SDD](specs-and-sdd.md)
- [Backlog and Loops](backlog-and-loops.md)
- [Records and Changelogs](records-and-changelogs.md)
- [Self-Evolution](self-evolution.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
