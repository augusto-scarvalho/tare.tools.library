# Threat Model

## In plain terms

Running autonomous agents introduces risks a normal codebase does not have: an
agent could leak secrets, be steered by a malicious instruction, or corrupt shared
state. The threat model names these risks explicitly so the harness's defenses can
be checked against them.

## Going deeper

The harness threat model (a release-manifest-required doc) catalogs the general
risks; the worker-isolation threat model focuses on the specific dangers of running
write-producing workers in parallel. Together they justify the sandbox, protected
files, and controlled-write mechanisms documented elsewhere in this section.

## Sources

- [docs/THREAT_MODEL.md](../../THREAT_MODEL.md) — overall threat model.
- [docs/WORKER_ISOLATION_THREAT_MODEL.md](../../WORKER_ISOLATION_THREAT_MODEL.md) — worker isolation risks.
- [Sandbox](sandbox.md) — the isolation defense.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
