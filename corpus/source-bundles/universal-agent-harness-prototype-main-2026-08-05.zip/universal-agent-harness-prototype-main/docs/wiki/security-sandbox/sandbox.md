# Sandbox

## In plain terms

Agents run inside a sandbox — a confined environment — so a misbehaving or
misdirected agent cannot reach outside its allowed workspace. This is what makes it
safe to let agents execute commands and edit files autonomously.

## Going deeper

The sandbox design doc describes the isolation approach; the harness-sandbox feature
spec owns the normative behavior, including the honesty rule that a sandbox must not
claim isolation it does not enforce (sandbox-manifest-honesty). Spawn-time
sandboxing logic lives in `scripts/harness_lib/sandbox_spawn.py`.

## Sources

- [docs/HARNESS_SANDBOX_DESIGN.md](../../HARNESS_SANDBOX_DESIGN.md) — sandbox design.
- [specs/40-features/harness-sandbox.md](../../../specs/40-features/harness-sandbox.md) — sandbox spec.
- [scripts/harness_lib/sandbox_spawn.py](../../../scripts/harness_lib/sandbox_spawn.py) — spawn-time sandboxing.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
