# Protected Files

## In plain terms

Some files are load-bearing instructions the agents themselves follow — `AGENTS.md`,
`CLAUDE.md`, the harness contracts. If an agent could silently rewrite these, it
could rewrite its own rules. Protected-file rules make sure those files cannot be
blindly overwritten.

## Going deeper

The canonical-file-protection universal spec defines the protection contract; the
enforcement logic lives in `scripts/harness_lib/protected_files.py`, with a hook at
`tools/hooks/protect_canonical_files.py`. In write-worker workspaces the protected
paths carry an OS-level lock, so a mutation attempt fails there by design and
surfaces at merge as a `protected-path-modified` finding (see `CLAUDE.md`).

## Sources

- [specs/00-universal/canonical-file-protection.md](../../../specs/00-universal/canonical-file-protection.md) — protection contract.
- [scripts/harness_lib/protected_files.py](../../../scripts/harness_lib/protected_files.py) — enforcement logic.
- [tools/hooks/protect_canonical_files.py](../../../tools/hooks/protect_canonical_files.py) — protection hook.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
