# Secrets and Release

## In plain terms

Agents must never leak API keys or ship a tampered release. The harness scans for
secrets before they escape and enforces release integrity so what gets published is
verifiable and untampered.

## Going deeper

The universal secrets-and-configuration spec defines how secrets and config are
handled safely; secret scanning is implemented in
`scripts/harness_lib/secret_scan.py`. Release integrity (SBOM and verification) is
documented in the release-integrity doc. These are the outbound-safety half of the
security story that the threat model motivates.

## Sources

- [specs/00-universal/secrets-and-configuration.md](../../../specs/00-universal/secrets-and-configuration.md) — secrets/config handling.
- [scripts/harness_lib/secret_scan.py](../../../scripts/harness_lib/secret_scan.py) — secret scanning.
- [docs/RELEASE_INTEGRITY.md](../../RELEASE_INTEGRITY.md) — release integrity/SBOM.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
