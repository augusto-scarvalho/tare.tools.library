# Security and Sandbox

How the harness stays safe while running autonomous agents: the threat model,
sandbox isolation for workers, protection of canonical files, and secrets/release
integrity.

## Topics

- [Threat Model](threat-model.md)
- [Sandbox](sandbox.md)
- [Protected Files](protected-files.md)
- [Secrets and Release](secrets-and-release.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
