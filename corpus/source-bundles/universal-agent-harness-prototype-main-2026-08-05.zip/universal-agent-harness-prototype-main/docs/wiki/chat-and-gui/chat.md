# Chat

## In plain terms

The chat workspace is where a human talks to the harness's agents — issuing
requests and watching responses stream — inside the panel rather than a separate
tool. It is the conversational front end to the same routed, workflow-backed work.

## Going deeper

The Chat tab manual (docs/PANEL_CHAT.md) is the per-screen guide; the
chat-workspace feature spec owns the behavior. Chat engine logic lives in
`scripts/harness_lib/chat_engines.py`, with related modules for the chat operator,
HUD, and setup (`chat_operator.py`, `chat_hud.py`, `chat_setup.py`). Chat routes a
message through the same model/executor routing described in Models and Routing.

## Sources

- [docs/PANEL_CHAT.md](../../PANEL_CHAT.md) — Chat tab manual.
- [specs/40-features/chat-workspace.md](../../../specs/40-features/chat-workspace.md) — chat behavior spec.
- [scripts/harness_lib/chat_engines.py](../../../scripts/harness_lib/chat_engines.py) — chat engine logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
