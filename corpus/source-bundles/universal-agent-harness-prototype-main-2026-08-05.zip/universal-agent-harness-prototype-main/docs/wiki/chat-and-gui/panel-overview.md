# Panel Overview

## In plain terms

The panel is the harness's graphical supervision surface: a read-only-then-
interactive view of what agents and workflows are doing. It grew through
milestones — first making failures legible, then a CLI surface, then trustworthy
evaluation, then a read-only GUI, and finally an interactive panel.

## Going deeper

The read-only GUI is specified in supervision-m4-readonly-gui; the interactive
panel (the largest supervision spec) in supervision-m5-interactive-panel. The
panel's server-side snapshots and view logic live in
`scripts/harness_lib/ui_panel.py`. A guiding rule across milestones: every GUI
element is a rendered subcommand, so the panel never exceeds what the CLI can do.

## Sources

- [specs/40-features/supervision-m4-readonly-gui.md](../../../specs/40-features/supervision-m4-readonly-gui.md) — read-only GUI.
- [specs/40-features/supervision-m5-interactive-panel.md](../../../specs/40-features/supervision-m5-interactive-panel.md) — interactive panel.
- [scripts/harness_lib/ui_panel.py](../../../scripts/harness_lib/ui_panel.py) — panel snapshots/logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
