# Chat and GUI

The human-facing surface: the supervision panel that shows what agents are doing,
the chat workspace for interacting with them, and the observability layer beneath
both.

## Topics

- [Panel Overview](panel-overview.md)
- [Chat](chat.md)
- [Observability](observability.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
