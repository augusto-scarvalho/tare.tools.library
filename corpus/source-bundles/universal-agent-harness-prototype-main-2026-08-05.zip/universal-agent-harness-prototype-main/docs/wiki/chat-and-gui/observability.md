# Observability

## In plain terms

You cannot supervise what you cannot see. The harness emits a consistent trace of
what happened during a run — events, timings, decisions — so the panel and
operators can reconstruct and trust any run after the fact.

## Going deeper

The observability doc defines the trace contract (a release-manifest-required
document). Workflow-level observability emission lives in
`scripts/harness_lib/workflow_observability.py`. This trace is what the panel
renders and what gate observability builds on.

## Sources

- [docs/HARNESS_OBSERVABILITY.md](../../HARNESS_OBSERVABILITY.md) — trace contract.
- [scripts/harness_lib/workflow_observability.py](../../../scripts/harness_lib/workflow_observability.py) — observability emission.
- [Panel Overview](panel-overview.md) — where traces are rendered.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
