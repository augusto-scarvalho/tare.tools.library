# What is the Harness

## In plain terms

The harness is a control layer that lets different AI coding agents (Claude,
Codex, and others) work on the same repository without depending on prior chat
history. It keeps a small, shared record of what is happening — current state,
routing, and handoffs — so any supported agent can pick up work safely where the
last one left off.

## Going deeper

The canonical control layer lives under `.harness/`: `context/` for compact
current state, `state/` for structured workflow and quality state, `handoff/` for
the continuity package handed to the next bounded run, and `routing/` for task
profiles and executor mappings. Executor adapters (`.claude/`, `.codex/`, `codex/`)
are thin spawn profiles; canonical truth never lives in them. The technical
backbone that ties state, routing, and workflows together is documented in the
architecture doc.

## Sources

- [.harness/HARNESS.md](../../../.harness/HARNESS.md) — control-layer contract and subdirectory rules.
- [docs/HARNESS_ARCHITECTURE.md](../../HARNESS_ARCHITECTURE.md) — technical architecture backbone.
- [README.md](../../../README.md) — repository entry point.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
