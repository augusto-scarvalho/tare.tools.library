# Getting Started

New here? Start with what the harness is, then set it up, then run your first
workflow. Each topic links to the canonical setup docs.

## Topics

- [What is the Harness](what-is-the-harness.md)
- [Installation and Setup](installation-and-setup.md)
- [Your First Workflow](your-first-workflow.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
