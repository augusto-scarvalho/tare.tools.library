# Your First Workflow

## In plain terms

A workflow is a structured unit of agent work — a task broken into steps that the
harness can plan, run, and check. Instead of one long freeform chat, work is
shaped into workflows so it can be resumed, reviewed, and validated. This page
points you at how to run and operate one.

## Going deeper

The agentic-workflows doc describes the workflow model and its runtime
consistency (it is gate-checked so the doc stays in sync with the code). The
operations runbook is the hands-on guide for launching, monitoring, and recovering
workflows in practice. The lifecycle logic itself lives in
`scripts/harness_lib/workflow_lifecycle.py`; the CLI entry point is
`scripts/harness.py`.

## Sources

- [docs/AGENTIC_WORKFLOWS.md](../../AGENTIC_WORKFLOWS.md) — the workflow model.
- [docs/WORKFLOW_OPERATIONS_RUNBOOK.md](../../WORKFLOW_OPERATIONS_RUNBOOK.md) — operating workflows.
- [scripts/harness_lib/workflow_lifecycle.py](../../../scripts/harness_lib/workflow_lifecycle.py) — lifecycle implementation.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
