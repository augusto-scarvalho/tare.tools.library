# Installation and Setup

## In plain terms

To use the harness on a project you adopt it: point it at your repository, fill in
a few project settings, and pick which executor/runtime you want to run agents
with. The adoption guide walks a new project through this step by step.

## Going deeper

Project-specific settings live in `.harness/project.json` (docs roots, spec roots,
commands, and conformance configuration). Runtime and executor selection are kept
out of Git as local state; the portability policy explains which pieces are
portable versus machine-local, including the `executor-state.example.json` file
that an operator copies into place before first run. The adoption guide is the
end-to-end setup path for a fresh repository.

## Sources

- [docs/PROJECT_ADOPTION_GUIDE.md](../../PROJECT_ADOPTION_GUIDE.md) — step-by-step adoption.
- [docs/RUNTIME_PORTABILITY.md](../../RUNTIME_PORTABILITY.md) — portable vs machine-local runtime state.
- [.harness/project.json](../../../.harness/project.json) — project metadata and commands.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
