# Research Workflow

## In plain terms

Some tasks need investigation before implementation. The research workflow is a
structured way to run that investigation — gathering findings into rounds that are
recorded, rather than lost in a chat log.

## Going deeper

The research-skill feature spec defines the workflow; the research rounds index
(docs/research/RESEARCH.md) collects the outputs. Administrative logic lives in
`scripts/harness_lib/research_admin.py`, with the searchable index in
`research_index.py`. Research is deliberately structured so findings become
reusable knowledge under the records/docs conventions.

## Sources

- [specs/40-features/research-skill.md](../../../specs/40-features/research-skill.md) — research workflow spec.
- [docs/research/RESEARCH.md](../../research/RESEARCH.md) — research rounds index.
- [scripts/harness_lib/research_admin.py](../../../scripts/harness_lib/research_admin.py) — research admin logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
