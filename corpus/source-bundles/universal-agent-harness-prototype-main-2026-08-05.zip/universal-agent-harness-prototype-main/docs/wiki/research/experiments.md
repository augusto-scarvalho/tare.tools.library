# Experiments

## In plain terms

When the harness tries a change to how it works (a new heuristic, a routing tweak),
it runs it as a tracked experiment with a defined method, so results can be
compared honestly instead of judged by vibes.

## Going deeper

The experiment methodology doc defines how experiments are designed and measured;
the experiment-lifecycle feature spec owns the lifecycle states. The registry of
experiments lives in `scripts/harness_lib/experiment_registry.py`. Experiment
results feed the self-evolution process (see Process).

## Sources

- [docs/EXPERIMENT_METHODOLOGY.md](../../EXPERIMENT_METHODOLOGY.md) — experiment method.
- [specs/40-features/experiment-lifecycle.md](../../../specs/40-features/experiment-lifecycle.md) — lifecycle spec.
- [scripts/harness_lib/experiment_registry.py](../../../scripts/harness_lib/experiment_registry.py) — experiment registry.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
