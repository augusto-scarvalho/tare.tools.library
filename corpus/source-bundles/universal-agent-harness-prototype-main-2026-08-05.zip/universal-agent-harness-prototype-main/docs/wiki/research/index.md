# Research

How the harness gathers and structures knowledge: the research workflow, tracked
experiments, and Graphify-based code discovery that replaces random grepping.

## Topics

- [Research Workflow](research-workflow.md)
- [Experiments](experiments.md)
- [Graphify Discovery](graphify-discovery.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
