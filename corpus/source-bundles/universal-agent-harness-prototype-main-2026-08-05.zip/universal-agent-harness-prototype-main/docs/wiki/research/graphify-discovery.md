# Graphify Discovery

## In plain terms

Finding where something lives in a large codebase by grepping at random is slow and
expensive in tokens. Graphify builds an offline code graph so agents can navigate
by structure — imports, symbols, relationships — before falling back to raw reads.

## Going deeper

The Graphify integration doc explains the code-AST-first discovery policy; the
structural-discovery universal spec is the baseline rule behind it. The graph
report at `graphify-out/GRAPH_REPORT.md` is the cheap entry point, and doc/text
discovery is exposed through `scripts/harness_lib/discovery.py` (the `doc-find`
command). This is the policy `AGENTS.md` and `CLAUDE.md` require before broad
search.

## Sources

- [docs/GRAPHIFY_INTEGRATION.md](../../GRAPHIFY_INTEGRATION.md) — discovery policy.
- [specs/00-universal/structural-discovery.md](../../../specs/00-universal/structural-discovery.md) — baseline rule.
- [scripts/harness_lib/discovery.py](../../../scripts/harness_lib/discovery.py) — doc-find/discovery logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
