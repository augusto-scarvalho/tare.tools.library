# Executor Adapters

## In plain terms

The harness is agent-agnostic: the same work can run under different coding agents
(Claude Code, Codex, and others). An executor adapter is the thin layer that lets
a given agent runtime plug in without the canonical state depending on it.

## Going deeper

Compatibility across executors is defined by the compat-executor-routing spec, and
the agent-compatibility doc summarizes which runtimes are supported. Route
dispatch — turning a routed task into an executor invocation — lives in
`scripts/harness_lib/route_dispatcher.py`. Adapter directories (`.claude/`,
`.codex/`, `codex/`) hold spawn profiles only; canonical state stays in
`.harness/`.

## Sources

- [specs/40-features/compat-executor-routing.md](../../../specs/40-features/compat-executor-routing.md) — cross-executor routing.
- [docs/AGENT_COMPATIBILITY.md](../../AGENT_COMPATIBILITY.md) — supported runtimes.
- [scripts/harness_lib/route_dispatcher.py](../../../scripts/harness_lib/route_dispatcher.py) — dispatch logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
