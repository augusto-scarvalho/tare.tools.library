# Models and Routing

How the harness decides which model and which executor runs a given piece of work,
how risk changes that decision, and how it keeps agent spawning cheap.

## Topics

- [Model Routing](model-routing.md)
- [Risk Tier Routing](risk-tier-routing.md)
- [Executor Adapters](executor-adapters.md)
- [Spawn Economy](spawn-economy.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
