# Risk Tier Routing

## In plain terms

Some changes are low-stakes (a doc typo) and some are high-stakes (touching
security or core logic). Risk-tier routing sizes the caution to the stakes: higher
tiers get more careful handling, more review, and safer topology.

## Going deeper

The risk-tier-routing feature spec defines the tiers and how a task is scored into
one. The topology router decides the shape of execution (who runs, how work is
split) and is implemented in `scripts/harness_lib/topology_router.py`. Together
they turn a risk assessment into a concrete execution plan.

## Sources

- [specs/40-features/risk-tier-routing.md](../../../specs/40-features/risk-tier-routing.md) — tiers and scoring.
- [specs/40-features/topology-router.md](../../../specs/40-features/topology-router.md) — execution topology.
- [scripts/harness_lib/topology_router.py](../../../scripts/harness_lib/topology_router.py) — topology logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
