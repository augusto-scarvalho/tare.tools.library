# Spawn Economy

## In plain terms

Spawning a sub-agent is not free — a careless fan-out can run many read-only helpers
at an expensive model. Spawn-economy guards make sure sub-agents run at the right
(usually cheaper) model and that spawning stays hygienic instead of ballooning
cost.

## Going deeper

The spawn-economy-guard spec defines the cost guardrails; executor-spawn-hygiene
covers safe spawn practices. The guard logic lives in
`scripts/harness_lib/spawn_guard.py`. This is the enforcement behind the rule that
built-in agent types must never be spawned bare from an expensive session (see
`CLAUDE.md`).

## Sources

- [specs/40-features/spawn-economy-guard.md](../../../specs/40-features/spawn-economy-guard.md) — cost guardrails.
- [specs/40-features/executor-spawn-hygiene.md](../../../specs/40-features/executor-spawn-hygiene.md) — spawn hygiene.
- [scripts/harness_lib/spawn_guard.py](../../../scripts/harness_lib/spawn_guard.py) — guard logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
