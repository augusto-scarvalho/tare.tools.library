# Model Routing

## In plain terms

Not every task needs the biggest, most expensive model. Model routing chooses a
model that fits the task — a small cheap one for lookups and read fan-out, a
larger one for synthesis — so quality and cost both stay sensible.

## Going deeper

The model-routing feature spec defines the routing contract; the logic lives in
`scripts/harness_lib/model_routing.py`. Routing composes with the executor
(which agent runtime) and the risk tier (how careful to be), so a single task's
final assignment is a model plus an executor plus a risk posture.

## Sources

- [specs/40-features/model-routing.md](../../../specs/40-features/model-routing.md) — routing contract.
- [scripts/harness_lib/model_routing.py](../../../scripts/harness_lib/model_routing.py) — routing logic.
- [Risk Tier Routing](risk-tier-routing.md) — the risk dimension.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
