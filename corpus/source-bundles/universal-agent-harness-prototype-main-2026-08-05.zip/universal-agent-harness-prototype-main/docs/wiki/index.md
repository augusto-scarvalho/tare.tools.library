# Harness Wiki

> NOTE: This wiki is DERIVED orientation, not canonical truth. Every page gives a
> plain-language summary plus a short technical orientation, then LINKS to the
> specs, docs, and modules that own the authoritative detail. When this wiki and a
> linked spec/doc disagree, the linked spec/doc wins. Automated drift protection
> (`wiki-spec-guard`) is not shipped yet, so treat any wiki claim as a pointer to
> verify at its source, never as the last word.

The wiki maps the harness from a layman entry point down to technical detail. It
never copies normative content; it summarizes and links.

## Sections

- [Getting Started](getting-started/index.md) — what the harness is, how to set it up, your first workflow.
- [Workflows](workflows/index.md) — agentic patterns, operations, parallel writes, token economics, the Compose screen.
- [Models and Routing](models-and-routing/index.md) — model selection, risk tiers, executor adapters, spawn economy.
- [Validation Gates](validation-gates/index.md) — the pre-commit gate, structure checks, performance/observability, tests and scenarios.
- [Chat and GUI](chat-and-gui/index.md) — the supervision panel, chat workspace, observability surface.
- [Research](research/index.md) — the research workflow, experiments, Graphify-based discovery.
- [Security and Sandbox](security-sandbox/index.md) — threat model, sandbox isolation, protected files, secrets and release integrity.
- [Process](process/index.md) — specs/SDD, backlog and loops, records/changelogs, self-evolution.

## Canonical anchors

If you only read three source documents, read these:

- [docs/HARNESS_ARCHITECTURE.md](../HARNESS_ARCHITECTURE.md) — the technical backbone.
- [.harness/HARNESS.md](../../.harness/HARNESS.md) — the canonical control-layer contract.
- [docs/HARNESS_CONTENT_GUIDE.md](../HARNESS_CONTENT_GUIDE.md) — the documentation rules this wiki obeys.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
