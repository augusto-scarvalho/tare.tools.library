# Testing and Scenarios

## In plain terms

The harness verifies behavior with tests and named scenarios rather than trusting
that a change works. Scenarios are executable checks tied to specs, so a feature's
described behavior is actually exercised.

## Going deeper

The universal testing-and-quality-gates baseline defines the quality bar; the
agent-testing-strategy doc explains how agent-produced work is tested. Scenarios
run under isolation for parallel safety (parallel-scenarios), and specs map their
Gherkin `Scenario:` entries to named checks under `testing/scenarios/`.

## Sources

- [specs/00-universal/testing-and-quality-gates.md](../../../specs/00-universal/testing-and-quality-gates.md) — quality baseline.
- [docs/AGENT_TESTING_STRATEGY.md](../../AGENT_TESTING_STRATEGY.md) — testing agent work.
- [specs/40-features/parallel-scenarios.md](../../../specs/40-features/parallel-scenarios.md) — isolated scenario runs.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
