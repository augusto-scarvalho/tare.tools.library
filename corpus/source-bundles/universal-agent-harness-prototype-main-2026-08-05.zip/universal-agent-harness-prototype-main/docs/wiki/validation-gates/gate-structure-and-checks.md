# Gate Structure and Checks

## In plain terms

Part of the gate makes sure the repository is shaped correctly: files live where
they should, required documents exist, and structural rules hold. These checks
catch drift in layout before it becomes a mess.

## Going deeper

The gate-structure-checks spec defines the structural rules; the implementation is
`scripts/harness_lib/gate_checks_structure.py`. It sits alongside sibling check
families (content, policy, release) under `scripts/harness_lib/gate_checks_*.py`,
all orchestrated by the staged gate.

## Sources

- [specs/40-features/gate-structure-checks.md](../../../specs/40-features/gate-structure-checks.md) — structural rules.
- [scripts/harness_lib/gate_checks_structure.py](../../../scripts/harness_lib/gate_checks_structure.py) — implementation.
- [Validation Gate Overview](validation-gate-overview.md) — the gate that runs these.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
