# Validation Gates

The checks that stand between agent work and a commit: the pre-commit gate, the
structure checks, performance and observability governance, and the test/scenario
layer.

## Topics

- [Validation Gate Overview](validation-gate-overview.md)
- [Gate Structure and Checks](gate-structure-and-checks.md)
- [Gate Performance and Observability](gate-performance-and-observability.md)
- [Testing and Scenarios](testing-and-scenarios.md)

[Back to wiki index](../index.md)

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
