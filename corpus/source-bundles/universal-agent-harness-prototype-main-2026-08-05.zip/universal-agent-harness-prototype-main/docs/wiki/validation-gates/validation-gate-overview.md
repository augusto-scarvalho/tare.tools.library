# Validation Gate Overview

## In plain terms

Before changes land, the harness runs a validation gate — a batch of automated
checks. If the gate fails, the work does not merge. The staged gate is the one run
against staged changes and can take several minutes, so it is meant to run in the
background.

## Going deeper

The pre-commit validation gate is defined by its feature spec; the staged-gate
runner is `scripts/harness_lib/gate_staged.py`. A gate run holds a lock while it
executes, which is why writing to `.harness/` or committing during a run is unsafe
(see the validation-gate guidance in `CLAUDE.md`). The gate composes the structure,
performance, and content check families documented in the sibling topics.

## Sources

- [specs/40-features/precommit-validation-gate.md](../../../specs/40-features/precommit-validation-gate.md) — gate contract.
- [scripts/harness_lib/gate_staged.py](../../../scripts/harness_lib/gate_staged.py) — staged-gate runner.
- [Gate Structure and Checks](gate-structure-and-checks.md) — the check families.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
