# Gate Performance and Observability

## In plain terms

The gate itself is watched: how long it takes and what it emits are governed, so
the safety checks do not silently become slow or opaque. This keeps the gate
trustworthy and fast enough to run often.

## Going deeper

Gate observability (what the gate reports) is specified in gate-observability;
gate performance governance (keeping it within time budgets) in
gate-perf-governance. The performance-facing logic lives in
`scripts/harness_lib/gate_perf.py`. Broader run-level observability and the trace
contract are covered in the Chat and GUI section's observability topic.

## Sources

- [specs/40-features/gate-observability.md](../../../specs/40-features/gate-observability.md) — what the gate reports.
- [specs/40-features/gate-perf-governance.md](../../../specs/40-features/gate-perf-governance.md) — performance budgets.
- [scripts/harness_lib/gate_perf.py](../../../scripts/harness_lib/gate_perf.py) — performance logic.

<!-- wiki-sources: summarize-and-link; canonical detail lives in the linked docs -->
