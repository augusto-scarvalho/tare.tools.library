# Agent Testing Strategy

Validation is language-agnostic by default. The harness validates its own core files and reads project-specific commands from `.harness/project.json`.

## SDD testing loop

1. **Spec intent:** identify the spec or acceptance criterion that defines the behavior.
2. **Task scope:** choose the smallest gate that can validate the changed behavior.
3. **Implementation:** run targeted checks before broad gates.
4. **Evidence:** record commands, manual checks, failures, skipped checks, coverage notes, and deviations in `HARNESS_RESULT`.
5. **State update:** the harness writes compact gate status to `.harness/state/quality-state.json`; detailed history goes to `.harness/runs/validation-results.jsonl` and should not be loaded by default.

## Gate tiers

- `smoke`: cheap harness and syntax sanity checks;
- `spec-pack`: specs/tasks/docs/schema/routing consistency;
- `commit`: checks expected before commit;
- `feature`: acceptance validation for a story/feature;
- `release`: broad release/merge validation;
- `coverage`: coverage report or threshold validation when configured.

## Project commands

Commands are configured in `.harness/project.json` under `validation.<gate>.commands` or as legacy string/list values. The universal template starts empty. Auto-detection is advisory by default and must not run unknown commands unless the project explicitly enables `runDetected` for a gate.

## Coverage

Coverage is governed by `specs/00-universal/coverage-and-regression.md` and `testing/COVERAGE_POLICY.md`.

The template does not invent thresholds. Adopted projects should configure:

- coverage mode: `disabled`, `informational`, `enforced`, or `risk-targeted`;
- coverage commands;
- report paths;
- gate(s) where coverage should run or be enforced;
- exceptions and exclusions.

## Hermeticity

Acceptance checks must not assume machine-local routing state (e.g., which routing profile is active): assert consistency against the same resolution path the product code walks, not against a hard-coded expected value.
When a check needs a specific profile/state, build it on a temp root — never require (or mutate) the live registry.

## Spec retrofit policy

Features that landed with scenario checks but before the spec-per-item rule
get a retrofit SDD spec, not a rewrite: the existing scenario file is the
acceptance record, the new spec's `Scenario: [id]` blocks map to the EXISTING
check names, and the product code stays byte-identical. Retrofits enter via
the SPEC-116 NEW door (covered-check recorded in the spec) and must pass
`feature-spec-conformance` like any new spec — never via the legacy freeze
list.

## Duplicate-flow control

- Hooks should validate presence of harness files and nudge state updates; they should not run expensive suites on every edit.
- `smoke` and `spec-pack` are safe to run often.
- `commit`, `feature`, `release`, and `coverage` should run when they can produce new evidence.
- If a command is repeated across gates, document why or move it to the narrowest useful gate.
