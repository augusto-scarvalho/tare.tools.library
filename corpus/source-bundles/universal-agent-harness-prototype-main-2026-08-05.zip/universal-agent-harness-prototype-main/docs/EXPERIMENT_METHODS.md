# Experiment methods library

The harness's experiment-design reference, mined from the reference manuscript
(`docs/research/sources/adaptive-project-oriented-multi-agent-harness-architectures.md`;
raw inventory with line refs: `.harness/handoff/l18-methods-inventory.md`). It
answers one question: *given the experiment I am about to register, which
established method should shape its design?*

## How to consume this

Two entry points wire this library into the flow, stateless:

- **Research playbook, Phase 0 (`Declared design`, the third phase-0
  declaration).** When a round will produce or feed a measurable claim, a
  threshold change, or a promotion, Phase 0 names the design by **citing a
  card from this file** (see `.harness/prompts/research-playbook.md`). A
  measurable claim with no declared design is Phase-0 incomplete.
- **`experiment add` advisory.** After a card is registered, the CLI prints
  1-3 deterministic `[methods] consider: <card> (docs/EXPERIMENT_METHODS.md#<anchor>)`
  hints keyed off the title/hypothesis/metric. Pure advisory: it never blocks
  and never edits the card. The round doc records which card was chosen and why.

**Tier 1** below is 12 full cards for the methods we reach for most. **Tier 2**
is a one-line index of every remaining method in the inventory, grouped by
family, so nothing mined is lost.

`Source` lines are manuscript line numbers; `[N]` are the inventory's canonical
bibliography refs.

---

# Tier 1 — full cards

## Taguchi robust design

**Like I'm five.** Some knobs you get to set; the weather you don't. Instead of
tuning for a sunny day, you pick knob settings that still work when it rains.
You want the setting that is *least upset* by things you can't control.

**Technical.** Separate controllable factors from noise factors and search for
a configuration with low sensitivity to the noise, minimizing a robust loss
`R(theta) = E[L] + kappa*sqrt(Var)` (expected loss plus an instability penalty).
No signal-to-noise ratio required; the point is flatness of response across the
registered noise regimes, not the peak.

**When to use HERE.** Threshold / limiar tuning where the setting must survive
the noise floor and provider drift: pick the threshold that is insensitive to
the measurement substrate, not the one that wins on one lucky run.

**Recipe.**
1. `experiment add EXP-N "<threshold> tuning" --hypothesis ... --metric ...` —
   the advisory should point you back here.
2. Name the control factor (the threshold) and the noise factors (run order,
   cache warmth, provider snapshot) explicitly in the card.
3. Measure each candidate under repeated pinned controls; feed the spread to
   `testing/probes/noise_floor_probe.py` and record `experiment record` values.
4. Promote the flattest setting whose delta clears the noise floor, not the
   nominal best.

**Source.** Lines 1178-1185, 1662, 1671, 2018; robust loss 1180-1185.
[138-146; 140 Box/Bisgaard/Fung 1988 QREI]

## Screening designs

**Like I'm five.** You have twenty knobs and no time to try every combination.
A screening design is a short, clever list of settings that still tells you
which few knobs actually matter, so you spend the rest of your budget on those.

**Technical.** One-factor-at-a-time cannot estimate interactions. Fractional
factorials estimate main effects (and chosen interactions) at a fraction of the
full grid; Plackett-Burman screens many factors economically for main effects;
Definitive Screening Designs add a third level so second-order curvature is
separable. Follow a positive screen with a response-surface refit in the
qualified region.

**When to use HERE.** Many candidate factors under a token budget (config
sweeps, prompt-shape studies): screen first to find the vital few, then spend
the wave on them.

**Recipe.**
1. List every factor in the experiment card; mark the cheap-to-change vs
   expensive-to-change ones (the latter feed the split-plot card).
2. Run a Plackett-Burman or fractional screen as frozen workflows; log each
   arm's metric via `experiment record`.
3. Keep factors whose effect clears the noise floor; drop the rest and refine.

**Source.** Fractional/full factorials 1660-1670, 1959, 2016, 2020; PB 1660,
1669, 2620; DSD 1660-1663, 1669, 2623. [138 Plackett&Burman 1946 Biometrika;
139 Box&Wilson 1951 JRSS-B; 141 Jones&Nachtsheim 2011 JQT]

## Split-plot

**Like I'm five.** Some changes are cheap (flip a setting) and some are a pain
(reboot with a different engine). A split-plot puts the painful change on the
outside so you only do it a few times, and shuffles the cheap changes inside
each block.

**Technical.** A hard-to-change factor is the whole-plot; easy-to-change factors
are sub-plots randomized within each whole-plot level. The two error strata are
analyzed separately — ignoring the structure inflates confidence on the
whole-plot factor.

**When to use HERE.** Vendor / provider / model comparison where switching the
provider or model snapshot is the expensive move: the vendor is the whole-plot,
the per-task knobs are sub-plots. Pair with matched-budget controls (the C13
tuple: same provider snapshot, same budget) so the comparison is fair.

**Recipe.**
1. In the card, declare the whole-plot factor (vendor/model snapshot) and the
   sub-plot factors.
2. Batch all sub-plot runs within one provider snapshot before switching — one
   frozen workflow per whole-plot level.
3. Record which stratum each measurement belongs to; do not pool.

**Source.** Lines 1663, 1681, 1758. [142 Jones&Nachtsheim 2009 JQT]

## Covering arrays

**Like I'm five.** You can't try every combination of options, but most bugs
only need two options to be wrong at once. A covering array is a small set of
tests that guarantees every *pair* (or triple) of options is tried together at
least once.

**Technical.** A t-way covering array guarantees every t-tuple of factor levels
appears in at least one row (AETG-style). It is a coverage guarantee over
interactions, not a causal-effect estimator — it finds reproducible suspects,
it does not size effects.

**When to use HERE.** Interaction / combinatorial bugs across flags, executors,
and modes: cover every pair of config options with a handful of frozen runs
instead of the full cross-product.

**Recipe.**
1. Enumerate the categorical factors and levels in the card.
2. Generate a 2-way (or 3-way) covering array; run each row as a frozen
   workflow; `experiment record` pass/fail per row.
3. Any failing tuple is a reproducible suspect — file it, then design a causal
   follow-up (Taguchi/screening) if you need effect sizes.

**Source.** Lines 1156, 1664, 1673, 1871, 2629. [147 Cohen et al. 1997 IEEE TSE]

## Matched-budget controls

**Like I'm five.** If your team of robots beats one robot, maybe the team is
smarter — or maybe you just gave the team more snacks. A matched-budget control
gives the single robot the *same* snacks, so a win is about the method, not the
food.

**Technical.** A multi-agent (or any richer-compute) claim requires a
single-agent / single-arm baseline at equal token and tool budget. Without the
matched control the effect is confounded by compute, not attributable to the
architecture.

**When to use HERE.** Any vendor or architecture comparison, and every
fan-out-width claim: this is guard E1 behind the playbook's declared-width rule
(D010). Same provider snapshot, same budget, same tools (the C13 tuple).

**Recipe.**
1. For a multi-agent / wide-wave claim, add a paired card for the single-agent
   equal-budget baseline.
2. Cap both arms at the same token budget; run both as frozen workflows.
3. Report the delta only against the matched control; an unmatched win is not
   evidence.

**Source.** Lines 319, 490, 1603, 2668. [186 arXiv:2604.02460]

## Non-inferiority

**Like I'm five.** Sometimes you don't need the new thing to be *better* — just
*not meaningfully worse*, while it's cheaper or faster. You pick how much worse
is still OK before you start, then check you stayed inside that line.

**Technical.** A non-inferiority test bounds regression: it asks whether the new
arm's quality stays within a pre-declared margin `delta_Q` of the baseline
(one-sided), rather than proving superiority. The margin is fixed before data.

**When to use HERE.** The H-series hypotheses: shipping a cheaper/faster change
that must not regress quality. Declare `delta_Q` in the card's successCriteria
up front (it doubles as the abandonCriteria bound).

**Recipe.**
1. Set the non-inferiority margin in successCriteria before any run
   (pre-registration, below).
2. Size the sample by simulation for 80% power at that margin.
3. Ship only if the confidence bound sits inside the margin; otherwise shelve
   with the reversal evidence.

**Source.** Lines 1230, 1974, 1996, 2012-2033.

## Confirmatory discipline

**Like I'm five.** It's easy to fool yourself: peek at the data, then invent the
hypothesis that fits it. The fix is to write down your prediction and how you'll
judge it *first*, split your data into a play half and a graded half, and lock
away a final exam set you only look at once.

**Technical.** Pre-registration separates prediction from postdiction. Split
data into discovery / confirmation / promotion partitions with a sealed holdout;
size samples by simulation for a minimum detectable effect (MDE, 80% power);
reuse the discovery set only through an adaptive-data-analysis (reusable
holdout) discipline. The confirmation gap `G_conf = Delta_discovery -
Delta_sealed` measures adaptive overfitting; a promotion earns grade G_conf only
if the sealed delta holds.

**When to use HERE.** Any promotion of a default or a threshold: pre-register the
card (the six required fields already force hypothesis/metric/criteria before
data), keep the sealed holdout, and report `G_conf`.

**Recipe.**
1. `experiment add` with successCriteria/abandonCriteria written before any run.
2. Declare the MDE and the discovery/confirmation/sealed split in the card.
3. Tune on discovery, confirm on confirmation, and touch the sealed holdout once
   at verdict; record `G_conf`.

**Source.** Pre-registration 73, 640, 1783, 2570; MDE/power 1679, 1683, 2115;
partitions + sealed holdouts 1170, 1210, 1677, 2062; reusable holdout 1210,
1677, 1833, 2653; G_conf 1743-1747. [88 Nosek PNAS18; 171 Dwork Science15]

## Confidence sequences

**Like I'm five.** Normally you must pick how many measurements you'll take
before you start, or your "it's better!" call gets untrustworthy from peeking. A
confidence sequence lets you watch the number live and stop the moment it's
clearly good or bad — every peek stays honest.

**Technical.** Time-uniform confidence sequences (and alpha-spending) give
anytime-valid inference: the error guarantee holds at every step, so you can
monitor continuously and stop early without inflating the false-positive rate.

**When to use HERE.** Continuous monitoring of a canary or shadow rollout:
watch the metric stream and stop/roll back the instant the sequence crosses,
instead of waiting for a fixed N.

**Recipe.**
1. For a canary/shadow experiment, declare the alpha budget in the card.
2. Update the confidence sequence per batch of `experiment record` values.
3. Settle a verdict when the sequence excludes the null (or the abandon bound);
   no fixed-horizon peek penalty.

**Source.** Lines 1237, 1781, 1870, 2650. [168 Howard et al. AoS21;
169 Johari et al. OR22]

## Evidence grades

**Like I'm five.** Not all "it worked" is equal: a lucky one-off is weaker than
something that held up on a held-out exam and then survived a careful, limited
real rollout. Grades name how strong the evidence is before you let a change
become the default.

**Technical.** Grade evidence exploratory -> attributive -> confirmatory ->
promotion-qualified. Promotion additionally goes through shadow then canary
stages inside a determined-feasible region (safe/constrained Bayesian
optimization keeps exploration within the viable set at R0/R1 with canaries at
R2), and the delta must clear the noise floor to count.

**When to use HERE.** Promotion of a default / rollout: attach the current grade
to the card, require confirmatory-or-better plus a passing canary before flipping
the default, and re-check against the noise floor.

**Recipe.**
1. Tag the card's current evidence grade; a default flip needs
   promotion-qualified.
2. Run shadow, then a bounded canary (safe region only); `experiment record`
   each stage.
3. Confirm the promotion delta clears `noise_floor_probe`; then verdict shipped.

**Source.** Grades 3046-3053; shadow/canary + safe BO 1200, 1666, 2647-2649.
[165 SafeOpt ICML15; 166 Berkenkamp ML23; 167 Gelbart UAI14]

## Oracle recall

**Like I'm five.** If you send five explorers instead of one, are the extra four
worth it? Only if they find things the first one *misses*. These metrics measure
exactly that shared-blind-spot payoff, and where adding explorers stops helping.

**Technical.** OracleRecall / CoFailure / marginal contribution `Delta_m`
(approximate Shapley when economically feasible) quantify the value of parallel
diversity; `beta_C` bounds the ensemble ceiling — the point past which more
workers stop paying.

**When to use HERE.** Wave-width / fan-out / worker-count decisions: this is the
`Delta_m` lens behind the playbook's declared-width rule (D010). Each extra
worker must earn its cost against CoFailure, or the width is redundancy not
coverage (see EXP-15).

**Recipe.**
1. For a width claim, log per-worker findings so overlap is measurable.
2. Compute OracleRecall and `Delta_m` per added worker; stop when marginal
   contribution stalls (`beta_C` ceiling).
3. Pair with matched-budget controls so width is not just more compute.

**Source.** Lines 386-392, 1722-1737, 2036. [101 arXiv:2606.27288]

## Noise floor

**Like I'm five.** Even with nothing changed, run the same thing twice and the
number wiggles a little. That wiggle is the floor. If your "improvement" is
smaller than the wiggle, you didn't improve anything — you saw noise.

**Technical.** The measurement substrate, not the deterministic detectors,
carries the variance. Repeated pinned controls estimate a baseline noise floor
(the harness uses MAD by choice); a delta below the floor is not evidence.

**When to use HERE.** Before promoting any delta, especially a sub-10% gain or a
threshold change: run the noise-floor probe and compare the delta to the metric's
floor.

**Recipe.**
1. `./.venv/Scripts/python.exe testing/probes/noise_floor_probe.py` to estimate
   the floor for the metric.
2. Record the floor in the card; mark any below-floor delta as "below the floor"
   and do not promote.
3. Only deltas clearing the floor advance to an evidence grade.

**Source.** Lines 1789, 2008, 2614. [132 Anthropic 2026]

## Judge bias

**Like I'm five.** If a robot grades essays, it might secretly favor longer ones,
whatever's listed first, or its own writing. Before you trust the grades, you
test the judge for these habits and check two graders agree.

**Technical.** Audit LLM-judge bias (position, verbosity, self-preference); an
audited O5 judge is checked against blind O3/O4 tiers. Inter-rater reliability
(kappa / Krippendorff alpha / ICC >= 0.70) gates human-or-rubric agreement.
`agent_reported` vs `oracle_observed` disagreement is itself a tracked metric —
anti-self-report.

**When to use HERE.** Any use of an LLM-as-judge in the metric: audit the judge
for the three biases, require >= 0.70 inter-rater agreement on a blind subset,
and log agent-reported vs oracle-observed disagreement.

**Recipe.**
1. Before trusting a judge metric, run a bias audit (swap positions, vary
   verbosity, hide authorship).
2. Have a blind O3/O4 tier co-grade a subset; require ICC/kappa >= 0.70.
3. Record `agent_reported` and `oracle_observed` separately; treat the gap as a
   signal, not an error.

**Source.** Lines 1809-1811, 2395; inter-rater 1809, 2202; report-vs-observed
1811, 2010, 2114. [130 AACL-IJCNLP25; 126-131]

---

# Tier 2 — one-line index

Every remaining mined method, by family. `when to consider | lines | ref`.

## Design (remaining)

| Method | When to consider | Lines | Ref |
|---|---|---|---|
| Response-surface | refine within a qualified promising region | 1661, 1669 | [139] |
| Morris screening (elementary effects) | cheap global pre-triage of many factors | 1675, 1777, 2625 | [143 Morris 1991] |
| Sobol / variance-based sensitivity | variance-share attribution on a surrogate | 1675, 1777, 2626-2627 | [144 Sobol 2001; 145 Saltelli 2010] |
| CALIBRA | Taguchi-style fractional + local search for algo tuning | 1198, 1671, 2628 | [146 Adenso-Diaz&Laguna 2006] |
| Auto algorithm configuration (ParamILS, irace, OpenTuner, Hyperband/BOHB, Vizier, Ax, CherryPick, SelfTune, OPPerTune) | refine/optimize over categorical/conditional/expensive spaces | 1198, 1665, 2630-2640 | [148-158] |
| Safe / constrained Bayesian optimization | explore only inside a feasible region (R0/R1 + R2 canary) | 1200, 1666, 2647-2649 | [165; 166; 167] |
| Racing (irace-style) | allocate evaluations to promising arms | 1157, 1192, 1665 | [150] |
| Randomization / blocks / replicates | run order, caches, warm-up as first-class provenance | 1679, 1683, 1758, 1954 | [173; 174; 175] |
| Self-driving lab loop | hypothesis -> experiment -> measure -> governed decision (EDC analogy) | 1877, 2658-2660 | [176-178] |

## Inference / measurement (remaining)

| Method | When to consider | Lines | Ref |
|---|---|---|---|
| Hierarchical / mixed-effects (GLMM) | task/project/epoch effects | 1751-1758 | - |
| Logistic / beta-binomial; survival; ordinal; multivariate/Pareto | endpoint per outcome type | 1758-1773, 1856-1859 | - |
| Nested / crossed random effects | vendor x harness comparison | 1762-1769 | [180, 195-201] |
| Bootstrap CIs; Wilcoxon paired; Mann-Whitney; ANOVA | inferential support | 1773, 1969 | [159] |
| ECE (calibration <= 0.05) | router calibration gate | 1085, 1222, 1773 | - |
| Adaptive / off-policy estimators | reuse bandit/racing/BO logs | 1781, 1833, 2652-2654 | [170; 172] |
| HCOPE | offline routing evaluation | 1092, 1828 | [83 Thomas&Brunskill 2016] |
| Contextual bandits | per-project routing policy | 341, 1065, 2564, 2582 | [82; 100] |
| Route regret; CTS; decomposed TCO | economic metrics | 1710-1720, 1839-1844 | - |
| Causal estimands / ATE; replay grades (causal/off-policy/diagnostic) | what counts as causal evidence | 1815-1831 | [83, 172] |
| Lexicographic rule / constrained robust optimization | EDC promotion decision | 1848-1859 | - |
| A_ctx / D_ctx / used-context ratio | context economy | 988-1011 | [181-186, 205, 207] |

## Judge quality / review (remaining)

| Method | When to consider | Lines | Ref |
|---|---|---|---|
| Oracle tiers O1-O5 | validator governance (tests -> formal -> blind expert -> blind rubric panel -> calibrated judge) | 1797-1811 | - |
| Grading final environment state | agent evaluation on end-state, not narration | 1811, 2013 | [131 Anthropic 2026] |
| Policy mutation testing | enforce formal properties | 1341 | - |
| Model-based testing / BMC / fault injection (DGIOTS) | kernel conformance | 1331, 1888-1897, 2060 | [222-232] |

## Architecture / process

| Method | When to consider | Lines | Ref |
|---|---|---|---|
| Kitchenham&Charters SLR; Wohlin snowballing; PRISMA 2020; multivocal A-E | synthesis methodology | 79-105, 2331 | [9, 10, 11] |
| DSR (Hevner) + Peffers process | construction axis | 83 | [7, 8] |
| ATAM (24 scenarios) | architecture trade-off analysis | 83, 2147-2176 | [13 SEI] |
| GQM | goals -> questions -> metrics | 83, 2393 | [12 Basili 1994] |
| Maturity assessment (Becker; 0-3 scoring; M0-M7) | maturity model | 2178-2202 | [90 Becker 2009] |
| Human studies (counterbalanced within/between) | Study H (AHHI) | 1760, 1885 | - |
| Crash / fault injection at every boundary | durable runtime | 805, 1339, 2378 | - |
| Refinement checking (soundness / obligation coverage) | Study L formal | 1331, 1899 | [222-232] |
| Threat modeling (data-centric); SLSA; in-toto | security / supply chain | 1387, 1401 | [85, 86, 87] |
