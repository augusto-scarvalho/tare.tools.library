# StateStore contract

## Goal

Move the harness from file-only assumptions toward product-grade durable state
without forcing a database dependency on every template user.

## Interface

`scripts/harness_lib/state_store.py` defines:

- `StateStore` protocol;
- `FileStateStore` backend;
- `SQLiteStateStore` backend.

The common methods are:

```python
put_json(key, value)
get_json(key, default=None)
delete(key)
list_keys(prefix="")
```

Keys reject `..` traversal. SQLite uses a single `state` table and WAL mode for
local durability.

## Current integration level

The workflow packet layout under `.harness/workflows/active/<WF>/` remains the
canonical human-readable state for backward compatibility. Runtime workflow and
plan records are now also mirrored through `StateStore` when workflows are
planned or updated.

Default template config uses the file backend at `.harness/state-store`, which is
runtime-only and excluded from release packages. Projects can opt into the
SQLite backend with `.harness/project.json`:

```json
{
  "workflows": {
    "stateStore": {
      "enabled": true,
      "backend": "sqlite",
      "sqlitePath": ".harness/state-store/workflows.sqlite3",
      "mirrorWorkflowState": true,
      "fallbackOnMissingWorkflowJson": true
    }
  }
}
```

The CLI exposes the mirror with:

```bash
python scripts/harness.py workflow state WF-...
```

If `workflow.json` is missing but the mirrored workflow entry is still present,
`load_workflow()` can rehydrate the workflow packet from `StateStore`. This is a
local durability/recovery boundary, not a distributed queue or Temporal-style
workflow engine.


## Mirrored runtime records

The runtime now mirrors these records through `StateStore` while preserving the
human-readable workflow packet layout as canonical source of truth:

```text
workflows/<WF>/workflow
workflows/<WF>/plan
workflows/<WF>/token-audit
workflows/<WF>/async-group
workflows/<WF>/async-task-AT-001
```

This closes the recovery boundary for workflow planning, token accounting and
async orchestration metadata. Reducer output files, merge plans and controlled
write workspace artifacts remain file-packet artifacts unless a downstream
product decides to make `StateStore` fully authoritative.

## Runtime artifact mirror and recovery

The filesystem packet remains the operator-facing source of truth, but the harness now mirrors all important machine-readable workflow JSON artifacts into `StateStore`:

- `workflow`
- `plan`
- `locks`
- `validation`
- `token-audit`
- `reduce-result`
- `harness-result`
- `reviewer-result`
- `merge-plan`
- `merge-apply-result`
- `merge-reviewer-result`
- `rollback-result`
- `async-collect-result`
- `async-await-result`
- `async-cancellation`

Use:

```bash
python scripts/harness.py workflow state WF-... --mirror
python scripts/harness.py workflow state WF-... --recover-artifacts
```

This is intentionally JSON-only. Markdown summaries, stdout/stderr logs, prompts, and workspaces are derived or high-volume artifacts and remain filesystem-managed.
