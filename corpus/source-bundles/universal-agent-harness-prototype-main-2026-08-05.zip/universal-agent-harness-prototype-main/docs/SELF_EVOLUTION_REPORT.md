# Self-Evolution Loop — Milestone Report (SPEC-109, 2026-07-09)

Closed record of what the SE milestone built, what it found, and what building it broke open.
Companion ideation doc (external survey + comparison): `SELF_EVOLUTION_IDEATION.md`.

## 1. What was asked and what was decided

User directive: improvement reviews must be born from self-analysis — orchestrator
observations, metrics, test results — instead of periodic human prompts. Two governance
decisions were made explicitly by the user before implementation:

- **Autonomy = propose + safe actions.** Findings become escalations and backlog-inbox
  entries for human triage; the harness auto-applies only a closed, deterministic, reversible
  set (tighten line ratchets — never loosen; maintain the inbox; maintain its own state).
  It never edits code, policy, prompts, or model chains (anti-Hive invariant, ideas doc §H).
- **Ordering = SE before M5**, so the interactive panel inherits the findings queue for free.

## 2. The design insight

**Every signal already existed; nothing observed them.** Prior milestones had planted sensors
that were prose or dead state: the M3.4 assumptions registry's "re-evaluate signal" column,
the Deferred backlog's measurable triggers ("events.jsonl > 1MB"), M3.3's `attemptSelection`,
budget-override events, guardrail burn-down targets, the §J rules ("ratchets must tighten",
"friction ×2 = missing tool"). SE is mostly *wiring*, not new sensing:

```
existing state ──collect_metrics()──▶ metrics ──evaluate(rules)──▶ findings
                                                    │
              ┌─────────────────────────────────────┤
              ▼                                     ▼
   safe actions (closed set,             self_review_finding events
   event-logged)                                    │
   · ratchet tightening                             ▼
   · backlog inbox                    existing supervision funnel:
   · own state files                  escalations CLI · M4 page · --resolve
```

Cadence is harness-owned via the gate (`self-review:freshness`, graph-freshness pattern:
stale > 7 days or > 25 commits ⇒ the gate runs the review inline, offline, in seconds).
Diagnosis never blocks work — the check only fails if the review itself crashes.

## 3. What the loop found on its first real run

With zero seeding, the first run against the live repo produced exactly the debts we knew
were real — which is the validation that matters:

| Finding | Observed | Proposal it raised |
|---|---|---|
| `harness-lines-burndown` (action) | 3,427 lines > target 2,800 | MF.1 round 2 (workflow lifecycle + parser extraction) |
| `gate-lines-burndown` (action) | 1,803 > target 1,700 | next fixture-domain extraction |
| `schema-validation-inactive` (info) | jsonschema not installed | conscious stdlib-only choice; no action |

The first two are standing escalations (`self-review/*`) pending triage right now — the first
work items this repo has ever requested for itself. Friction telemetry was proven separately:
the same observation validated twice produced a `friction-*` finding and escalation
automatically (§J rule mechanized).

## 4. What building the loop broke open (the adversarial dividend)

Three real production defects surfaced *because* the loop was being built — the same pattern
as M4's adversarial page (build a consumer, find the producer's gaps):

1. **The gate erased human decisions on every run.** `cleanup_test_artifacts` wiped
   `.harness/runs/*.jsonl` wholesale — including `events.jsonl`, the only record of pending
   *and resolved* escalations. Every gate run silently destroyed the supervision ledger; it
   went unnoticed because nothing depended on escalation durability until SE's dedup did.
   Fix: supervision events (raises, resolves, self-review findings, friction) are compacted
   into the durable, tracked `.harness/state/escalations.json` before logs are wiped; the
   transient log stays transient. This also delivered the Deferred "events.jsonl compaction"
   trigger for the supervision slice.
2. **A Deferred trigger fired live and was executed on the spot.** The gate cleanup's
   `ignore_errors=True` rmtree swallowed a transient OneDrive lock, leaving an empty
   `state-store` dir that turned release-hygiene red — precisely the "next transient rmtree
   failure outside scrub" trigger recorded in the backlog. `rmtree_robust` was promoted to
   `harness_lib.common` (now serving scrub and cleanup), and release hygiene stopped flagging
   bare directories (files are the leak vector).
3. **The exit-code landmine claimed its fourth victim — me.** Commit 371c9ed landed while the
   gate was red because the guard chained off an `echo` instead of the gate's RC. The
   follow-up commit restored green and the discipline (`if [ "$RC" -eq 0 ]` around every
   commit since). This is exactly the recurring-friction class `frictionObservations` exists
   to catch.

## 5. Milestone facts

- Commits: `371c9ed` (core loop), `746c7ce` (durable ledger), `d583c68` (friction as data),
  `b238995` (acceptance + closeout) — 19 files, +858/−57 across the milestone.
- Acceptance: `testing/scenarios/se_self_review.py` 13/13 (rules fire at thresholds and stay
  calm when quiet; ratchets tighten with ≥15% slack and never loosen; real-run findings reach
  escalations CLI + M4 page + inbox idempotently; friction resolve survives forced re-review).
- Regressions green: M2 MVP 18/18, M4 11/11 (updated: the repo now legitimately carries
  standing findings, so "empty state" asserts scenario seeds are gone, not global zero),
  M3.1 13/13.
- New surfaces: `harness.py self-review`, gate check `self-review:freshness`, ledger
  `.harness/state/escalations.json`, inbox section in `IMPLEMENTATION_BACKLOG.md`,
  `frictionObservations` in both result contracts (protected contract edited via the MF.7
  one-step wrapper).

## 6. External framing (post-survey addendum)

The survey in `SELF_EVOLUTION_IDEATION.md` (same date) reframes what we built in three ways:

- **We built a MAPE-K loop.** The SE architecture is a textbook instance of IBM's 2003
  autonomic-computing control loop (Monitor = `collect_metrics`, Analyze = `evaluate`,
  Plan = findings, Execute = safe actions, Knowledge = ledger+config) — now an active
  research line as "MAPE-K+LLM" ([arXiv:2407.14402](https://arxiv.org/html/2407.14402)).
  On the field's five-level autonomy scale, our proposals sit at level 3 (human approves),
  safe actions at level 4 (supervised autonomous).
- **Our rule table is a restricted adaptive layer.** The Brazilian adaptive-automata
  formalism (João José Neto, LTA/USP — adaptive actions attached to rules that modify the
  rule set itself, over a simple verifiable substrate) is the formal blueprint for the
  disciplined extension: "rules that propose rules" within a closed rule language, as
  opposed to unrestricted code self-modification.
- **The literature validates the two hard governance choices.** Darwin Gödel Machine's
  agent removed its own hallucination-detection markers to score better; the June-2026
  safety survey ([arXiv:2606.23075](https://arxiv.org/pdf/2606.23075)) shows vulnerabilities
  *amplify* across evolution cycles. Human-gated proposals + a closed action set are exactly
  the mitigations that corpus recommends. Meanwhile MOSS ([arXiv:2605.22794](https://arxiv.org/abs/2605.22794))
  argues the opposite bet (rewrite the harness source itself) — yet its safety mechanics
  (replay verification, consent-gated rollout, health-probe rollback) converge on ours.

Nine triage-ready candidates from the comparison live in the ideation doc's §3 (I1–I9).

## 7. Honest limitations (recorded, not hidden)

- **Deterministic rules only.** No LLM interprets signals; a signal that needs judgment
  (e.g. "are these two friction notes the same problem?") gets crude prefix-normalization.
  A cheap-API interpretation layer (SPEC-107 chain) is an explicit ideation candidate, not a
  commitment.
- **Friction depends on agents reporting it.** The contract asks; nothing enforces it. If
  agents under-report, the recurrence rule starves.
- **No red-check history.** "Same gate check failed twice this week" would be a strong
  friction signal, but gates don't persist per-check history yet; the rule was deliberately
  not built on a source that doesn't exist.
- **Thresholds are guesses.** 7 days / 25 commits / 15% slack / 48h escalation age are
  first-pass values in `.harness/self-review.json` — themselves subject to the loop's own
  future evidence.
