# Harness threat model

## Assets

- source repository contents;
- secrets in environment/local config;
- workflow packets and worker outputs;
- merge plans, locks, worktrees and rollback state;
- executor credentials and API quotas.

## Trust boundaries

- worker output is untrusted data;
- executor stdout/stderr is untrusted data;
- controlled-write workspaces are less trusted than the main working tree;
- versioned harness config is trusted only after release hygiene gates pass;
- local `.harness/runs/*` and active workflow state are runtime evidence, not release inputs.

## Primary risks

- prompt injection in source files or worker outputs;
- malicious worker output asking reducers/reviewers to bypass gates;
- unauthorized write attempts during read-only analysis;
- path traversal from controlled-write sandboxes;
- secret exfiltration through prompts/logs;
- excessive agency through unchecked executor commands;
- supply-chain drift in CI/actions/plugins.

## Current mitigations

- read-only workers may only write their `WORKER_RESULT` path;
- controlled writes require explicit approval, locks, isolated workspace, merge plan and validation;
- release hygiene blocks local paths and runtime artifacts;
- release integrity produces SBOM, checksums, attestation, provenance, and a local signature artifact;
- baseline catalog guardrails prevent stale/incomplete security-spec indexes from silently drifting;
- token budgets reduce context-bloat/DoS risk;
- red-team fixture validates write/path traversal boundaries;
- worker results are schema-validated and treated as evidence, not instructions.

## Residual product work

- expand prompt-injection corpus;
- add secret scanning fixtures;
- add optional organization-backed signing/key-management integration beyond the local signature artifact;
- add executor-specific auth/rate-limit contract tests.

## Gemini API free-tier graph assistance

Gemini-assisted text/image enrichment is an optional external-service path, disabled by default. Threat controls: explicit opt-in, `GEMINI_API_KEY` requirement, no network by default, text/image-only free-tier model allowlist, no secrets in prompts, and mandatory source verification before claims or edits. Graphify code AST discovery is preferred to reduce data exposure and cost.

## Canonical instruction-file overwrite threat

**Threat:** a script, skill, plugin, MCP sync, or executor adapter installer silently overwrites `AGENTS.md`, `CLAUDE.md`, root handoff shims, or harness prompt contracts with broader permissions, stale instructions, or project-local state.

**Mitigation:** `.harness/protected-files.json` defines protected files, `.harness/protected-files.snapshot.json` records expected hashes, `tools/hooks/protect_canonical_files.py` supports pre/post-install checks, and the `protected-files` fixture fails CI/release on missing files or snapshot drift. Intentional protected-file edits must update specs/docs and regenerate release integrity artifacts.


### Market-recognized agent instruction file protection

The protected-file policy covers not only root `AGENTS.md`/`CLAUDE.md` shims, but also market-recognized instruction files and rule directories used by Codex, Claude Code, GitHub Copilot/VS Code, Cursor, Gemini CLI, Cline, Devin/Windsurf, Roo Code, and harness-owned adapter shims. Optional files are snapshot-if-present: installer creation or overwrite is drift until reviewed and added to `.harness/protected-files.snapshot.json`.

## Control liveness (SEC.3)

**Threat:** a declared security control dies silently — a scrub call deleted in a refactor, an env-filter flipped off, a protection snapshot gone — and nothing notices because the control still appears in docs while protecting nothing.

**Control:** the gate's `control-liveness` check probes an explicit registry (`scripts/harness_lib/control_liveness.py` `PROBES`, pure reads) of six declared controls and FAILS if any is dead:

- `collect-secret-scrub` — `secret_scan.scan` present in `scripts/harness_lib/workflow_reduce.py`;
- `discover-pre-egress` — `_pre_egress_reason` present in `scripts/harness_lib/discovery.py`;
- `target-gate-env-filter` — `filter_spawn_env` present in `scripts/harness_lib/gate_generic.py`;
- `security-baseline-wired` — `security_baseline.evaluate` present in `scripts/spec_test_gate.py`;
- `protected-files-snapshot` — `.harness/protected-files.snapshot.json` exists and parses;
- `worker-env-filter` — `workflows.workerEnvFilter` in `.harness/project.json` is not `false`.

A refactor that legitimately moves or renames a control must update `PROBES` in the same commit.

## Security-regression ratchet (SEC.2)

**Control:** the gate's `security-regression-ratchet` check intersects two signals it already computes — the security-baseline `new` diff (findings absent from `.harness/state/security-baseline.json`) and the changed-files manifest (working tree vs HEAD) — and FAILS when a new finding's file was touched by the current patch. Baseline-only findings and new findings in unchanged files never trip it, and a git failure fail-closes the manifest to empty, so the ratchet never false-reds. **Escape hatch:** for an intentional, reviewed finding, delete `.harness/state/security-baseline.json`; the next gate run re-baselines (write-once snapshot, day-one green).
