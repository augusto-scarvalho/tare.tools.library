# Operator Guide

Step-by-step instructions for running the Universal Agent Harness, from a fresh machine to daily operation. Architecture background is in `HARNESS_ARCHITECTURE.md`; this guide is only about *doing*.

## 1. Prerequisites

- **Python 3.11–3.13** on PATH, or [uv](https://docs.astral.sh/uv/) to manage one. The harness is stdlib-only except for one required package — `keyring`, the OS key vault backend (`requirements.txt`). It became mandatory on 2026-07-24 when the vault replaced `.env` as the sole secret store (SPEC-169 v2). **`setup.bat` / `setup.sh` installs it for you**; run either once after cloning. CI and containers can skip it and provision keys through real environment variables, which the cascade checks first.
- **git** — optional but strongly recommended (changed-file workflows, worktree isolation, and `lastStableCommit` tracking assume it).
- Windows, macOS, or Linux. On Windows, prefer running commands from Git Bash or PowerShell; gate output is UTF-8 safe.

## 2. Setup

From the harness root:

```bash
# with uv (works even with no system Python)
uv venv .venv --python 3.13
.venv/Scripts/python.exe --version     # Windows
.venv/bin/python --version             # macOS/Linux

# or with system Python
python -m venv .venv
```

```bash
# wire it into the harness hooks (they never auto-discover .venv, by policy)
export HARNESS_PYTHON="$PWD/.venv/Scripts/python.exe"   # Windows
export HARNESS_PYTHON="$PWD/.venv/bin/python"           # macOS/Linux
```

Claude Code users can instead put the same value under `env.HARNESS_PYTHON` in the gitignored `.claude/settings.local.json`.

API keys for the cheap discovery chain live in your **OS key vault** (Windows Credential Manager / macOS Keychain / Linux Secret Service) — never in a file. Install the backend once with `uv pip install --python .venv/Scripts/python.exe -r requirements-optional.txt`, then store each key:

```bash
python scripts/harness.py keys set GEMINI_API_KEY   # value read from stdin, never argv
python scripts/harness.py keys list                 # masked presence table
```

Real environment variables always take precedence over the vault, so CI and containers can provision the usual way. `HARNESS_NO_VAULT=1` suppresses vault injection (used by tests that must exercise the key-absent path). The `.env` tier was removed on 2026-07-24 (SPEC-169 v2) — a plaintext secret file was a second provisioning surface with none of the vault's protections.

Sanity-check the install:

```bash
python scripts/harness-test.py smoke
python scripts/harness.py status
```

Both must succeed before anything else. In the rest of this guide, `python` means your venv interpreter.

## 3. Adopting into a project

Full details in `PROJECT_ADOPTION_GUIDE.md`. The minimum:

1. Edit `.harness/project.json` — `projectName`, source/test roots, and real commands under `validation.<gate>.commands` when the project has them.
2. Create the first task from `tasks/TASK_TEMPLATE.md` into `tasks/<your-task>/`.
3. Generate the first handoff: `python scripts/harness.py handoff --task "describe the first task"`.

### Governing other repositories (SPEC-110)

```bash
# register: create .harness/targets/<name>/target.json with at least {"name", "path"}
python scripts/harness.py targets                  # health: files, budgets, graph, env, last gate
python scripts/harness-test.py commit --target <n> # the target's own proportional gate
python scripts/harness.py graph-build-code-ast --target <n>
python scripts/harness.py doc-find <terms> --target <n>
python scripts/harness.py targets sync <n>         # adapter: MCP config + deny-by-default env
```

Target findings (budgets, recurring red checks, drift) arrive in `escalations` and on the
supervision page automatically via self-review.

## 4. Daily loop

The normal cycle for every unit of work:

```bash
# 1. Where are we?
python scripts/harness.py status

# 2. Describe the next task; the harness classifies it and writes the handoff
python scripts/harness.py handoff --task "add input validation to the parser"

# 3. Get the concrete agent command for your executor
python scripts/harness.py spawn-command --executor claude   # or codex | generic

# 4. Run that command — the agent reads the handoff, works, and ends
#    with a HARNESS_RESULT JSON block (see .harness/prompts/subagent-contract.md)

# 5. Validate proportionally (gate table in ../testing/QUALITY_GATES.md)
python scripts/harness-test.py smoke        # tiny edits
python scripts/harness-test.py spec-pack    # specs/docs/config changed
python scripts/harness-test.py commit       # code changed

# 6. Regenerate the handoff for the next agent
python scripts/harness.py handoff
```

Escalation: if the agent returned `requiresEscalation: true`, re-spawn with the suggested profile instead of letting it widen scope.

Supervision extras (SPEC-102):

```bash
# everything currently waiting on a human decision, grouped by failure class
python scripts/harness.py escalations
python scripts/harness.py escalations --resolve <escalationId>

# one static page answering the five supervisor questions at a glance
# (what runs, what waits on a human, last gate, drift, next handoff)
python scripts/harness.py status --html   # -> .harness/state/supervision.html

# self-evolution loop (SPEC-109): the harness reviews its own metrics and
# raises improvement findings as escalations + a backlog inbox; the commit
# gate re-runs it automatically when stale (>7 days or >25 commits)
python scripts/harness.py self-review     # report: .harness/state/self-review.md

# preview a workflow without spending agent time (no writes, no spawns)
python scripts/harness.py workflow execute --profile repository-review --task "..." --dry-run

# a failing token audit blocks start/execute when enforceTokenBudget is on;
# override consciously (the override is recorded as an event)
python scripts/harness.py workflow start WF-<id> --executor claude --override-budget
```

### Recording work (SPEC-112)

After a meaningful commit, record it in the project ledger — this appends a
canonical worklog entry and refreshes the always-in-context head in
`.harness/context/CONTEXT.md`:

```bash
# record the last commit as a milestone (fills title/body/ref from HEAD)
python scripts/harness.py log milestone --from-head

# or record explicitly (kinds: milestone, change, decision, release, note)
python scripts/harness.py log decision --title "…" --body "…" --ref SPEC-112

# query the ledger just-in-time instead of re-reading big docs
python scripts/harness.py records recent --kind milestone
python scripts/harness.py records search <terms>
```

Markdown changelogs/backlog history are retired: `log` is the only write path
for new historical records, and the SQLite index (`records`) is rebuilt on
demand. Do not hand-author record markdown files.

## 5. Running workflows (large tasks)

For work that exceeds one context window, use map-reduce / fork-join workflows (operational detail: `WORKFLOW_OPERATIONS_RUNBOOK.md`).

```bash
# does this task even need a workflow?
python scripts/harness.py workflow suggest --task "review the whole repository"

# plan: creates .harness/workflows/active/WF-*/ with worker packets
python scripts/harness.py workflow plan --profile repository-review --task "review the whole repository"

# check the token cost before spending agent time
python scripts/harness.py workflow token-audit WF-<id>

# execute (blocking, runs workers + validation in one command)
python scripts/harness.py workflow execute --profile repository-review --task "..." --executor claude

# or durable async for long runs
python scripts/harness.py workflow start WF-<id> --executor claude --concurrency 4
python scripts/harness.py workflow async-status WF-<id>
python scripts/harness.py workflow await WF-<id> --mode all-settled

# after workers finish
python scripts/harness.py workflow validate-results WF-<id>
python scripts/harness.py workflow reduce WF-<id>
python scripts/harness.py workflow finalize WF-<id>          # regenerates handoff
python scripts/harness.py workflow promote WF-<id> --to canonical-task   # optional
```

Workers are read-only by default and must return `WORKER_RESULT`. Do not reduce while workers are queued/running — the harness blocks it.

## 6. Controlled writes (advanced)

Parallel source edits require the explicit approval track (full walkthrough: `CONTROLLED_PARALLEL_WRITES.md`):

```bash
python scripts/harness.py workflow prepare-write WF-<id> --approval-token I_APPROVE_CONTROLLED_WRITES
python scripts/harness.py workflow merge-plan WF-<id> --validation-gate smoke
python scripts/harness.py workflow apply-merge WF-<id> --approval-token I_APPROVE_CONTROLLED_WRITES \
    --validation-gate commit --rollback-on-validation-gate-failure
python scripts/harness.py workflow review-merge WF-<id> --executor claude
```

Every step is refused without the token; locks prevent two workers touching the same path; rollback restores from backups on gate failure.

## 7. Verifying the harness itself

The full verification & validation plan (what proves what, plus the latest executed results) is in `VV_PLAN.md`. Quick version:

```bash
python scripts/harness-test.py smoke
python scripts/harness-test.py spec-pack
python scripts/harness-test.py product-release --no-project-commands
python scripts/harness-test.py --fixture <name>       # targeted deep checks
```

### Repo-health doctor

```bash
python scripts/harness.py doctor
```

WARN-only diagnostics for where the repo physically lives: flags a repo path inside a
OneDrive-synced folder, a `.git` carrying a sync reparse point (index.lock/corruption
risk — the sync client uploads and can race git's internal writes), and a
`core.autocrlf=true` vs `.gitattributes eol=lf` conflict (spurious touched-file churn).
It always exits 0: it makes the risk visible, it never blocks. Background and the
pending relocate-off-OneDrive decision: `roadmap/git-onedrive-path-hygiene.md` (Phase 3).

### Spec index

```bash
python scripts/harness.py spec-index          # text table
python scripts/harness.py spec-index --json
```

Read-only inventory of `specs/**/*.md`: scope (first folder under `specs/`), title,
`Scenario:[id]`s (parsed with the same SPEC-116 conformance-gate parser, so the
inventory and the gate never disagree), and whether the spec sits on the frozen
`specConformance.legacy` exemption list. Always exits 0; changes nothing.

### Docs tree

```bash
python scripts/harness.py docs-tree          # indented tree
python scripts/harness.py docs-tree --json
```

Read-only, scope-tagged inventory of `docs/` and `specs/`: every directory,
markdown file (with its first `# ` heading as title) and other file, each tagged
with its top-level scope (`docs`, `docs/roadmap`, `specs/40-features`, ...).
Deterministic and byte-stable across runs. Always exits 0; changes nothing.
Spec: `specs/40-features/docs-tree.md`.

### Config keys

```bash
python scripts/harness.py config keys          # masked presence table (or --json)
python scripts/harness.py config list          # the expected-key registry itself
```

Read-only, MASKED inventory of the env/config keys the harness actually reads:
provider env keys (`GEMINI_API_KEY`, `NVIDIA_API_KEY`, ...) and the
`.harness/project.json` knobs their consumers use. Presence-only — a set env
key displays as `first2…length`, a key provisioned only in `.env` shows the
value-free marker `named in .env` (`.env` is parsed for key NAMES only), and a
raw secret value is never echoed in any output mode. Full values print only
for non-secret project knobs whitelisted in the registry. Always exits 0;
changes nothing — the `config-set` write action is phase 2.
Spec: `specs/40-features/config-keys.md`.

### Research rounds

```bash
python scripts/harness.py research list           # text table (or --json)
python scripts/harness.py research delete <slug>            # DRY-RUN: reports, deletes nothing
python scripts/harness.py research delete <slug> --apply    # act (untracked rounds only)
python scripts/harness.py research delete <slug> --apply --allow-committed  # also git-tracked rounds
```

Admin for throwaway research rounds under `docs/research/` (the `RESEARCH.md` index is
never listed nor deletable). `list` shows, per round: git-tracked flag, active workflows
whose task names the slug, and records-ledger references. `delete` is dry-run by default;
`--apply` unlinks the doc, scrubs linked workflows via the existing
`workflow scrub --force`, and writes a `research`/`tombstone` note to the ledger. A
git-tracked round additionally requires `--allow-committed` (fail-closed: if git cannot
answer, the round counts as tracked). Spec: `specs/40-features/research-admin.md`.

### Graph freshness

The validation gate owns graph freshness as a safety net: `graphify:graph-freshness`
rebuilds the code AST graph inline whenever it is stale, so you never have to remember it.
For an extra, per-commit refresh, opt in with `git config core.hooksPath tools/git-hooks` —
the `post-commit` hook then rebuilds the code graph (and runs doc discovery) for just the
files that commit touched. The white/blacklist (`codeGlobs`/`docGlobs`/`exclude`) lives in
`.harness/project.json` under `graphRefresh`.

## 8. Troubleshooting

Gate failures and workflow refusals now carry their own `fix:` line inline (SPEC-101) — remediate
from the error output first. This table is the fallback index.

| Symptom | Fix |
|---|---|
| `protected-files:snapshot-match` fails | Someone edited a canonical file (AGENTS.md, CLAUDE.md, prompts). If intentional: `python tools/hooks/protect_canonical_files.py snapshot`, then rerun the gate. If not: inspect the diff first. |
| Need to edit a protected file intentionally | One step: `python tools/hooks/protect_canonical_files.py edit -- <your edit command>` — runs it with writes allowed, regenerates the snapshot, and verifies (replaces the manual allow-env → edit → snapshot dance). |
| `release-hygiene:export-manifest` fails | Manifest drifted from the tree. Regenerate all release evidence: `python scripts/release_integrity.py generate`. |
| `Workflow WF-... is locked by another run` | A run crashed holding the lock: `python scripts/harness.py workflow unlock WF-<id>`. |
| Interrupted fixtures left `tmp-*` dirs or fixture workflows | `python scripts/harness-test.py --clean-fixtures`. |
| Finished/test workflow left dirs in `workflows/active/` or the state-store mirror | `python scripts/harness.py workflow scrub WF-<id>` (refuses non-terminal phases; `--force` for disposable artifacts). |
| `reduce` refuses to run | Workers still queued/running — check `workflow status WF-<id>`, use `workflow collect --recover` for orphans. |
| Gate output garbled on Windows console | Harmless mojibake in some terminals; gate results and exit codes are unaffected (output is forced to UTF-8). |
| Agent edited a file the hooks should have blocked | Check the adapter hook wiring (`.claude/settings.json` / `.codex/hooks.json`) is present in your session, and that `tools/agent-sync/py-run.sh` can find a Python interpreter (`HARNESS_PYTHON`). |
