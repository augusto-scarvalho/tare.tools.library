# Context checkpoint — surviving context compaction (`ckpt`)

Spec: `specs/40-features/context-checkpoint.md` · Acceptance:
`testing/scenarios/context_checkpoint.py` · Module:
`scripts/harness_lib/context_checkpoint.py`

## The problem

When an agent's context window fills, the vendor compacts it and in-flight
state (current item, phase, design decisions, verify incantations) evaporates.
The harness had a continuity layer that didn't work: the SessionStart hook
read `.harness/context/*.md` and printed only a banner — but **a hook's
stdout is the injection channel**, so nothing entered the fresh window — and
no producer ever wrote current state into STATE.md/NEXT_STEPS.md.

## The pair that fixes it

**Producer** — `python scripts/harness.py checkpoint`:

```
checkpoint "note"  [--item X] [--phase spec|test|impl|verify|commit] [--verify CMD]
checkpoint                      # show the current block
checkpoint --clear              # end the iteration
checkpoint --render             # print exactly what the hook will inject
```

Maintains ONE bounded `<!-- inflight:start/end -->` block in
`.harness/context/NEXT_STEPS.md`: omitted fields carry over between calls, the
note trail keeps the last 6 entries, and every field passes
`secret_scan.redact_text` before touching the tracked file. Workflow reduces
regenerate NEXT_STEPS.md wholesale; `workflow_lifecycle` routes through
`merge_preserving_inflight` so the block survives that rewrite.

**Delivery** — `tools/hooks/reload_context_after_compact.py` (SessionStart,
Claude + Codex via `.harness/capabilities.json`) now prints the real content
of NEXT_STEPS.md (first — the checkpoint is the payload), CONTEXT.md,
STATE.md and, when present, `.harness/handoff/handoff.md`; each body is
mtime-badged and capped head+tail beyond ~4KB, absences read calmly.

## Discipline for long autonomous runs

Checkpoint at phase transitions — one call when the design is decided, one
when tests exist, one before commit; `--clear` after the commit lands. The
cost is one command per phase; the payoff is that post-compact you resume
from your own notes instead of re-deriving the design.

Limits: a checkpoint is not a transcript — it holds pointers and decisions,
not diffs. There is deliberately no PreCompact auto-snapshot: a hook cannot
dump the agent's head; the discipline above plus real injection is the pair
that works.
