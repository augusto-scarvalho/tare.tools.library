**DRAFT — NON-CANONICAL.** Recovered spec material for the CLI surface (frozen
verb order, TE.5 compact/TSV contract, exit-code contract, workflow subtree).
Does not resolve to real checks yet. See `INDEX.md` for the full gap matrix.
Scenario/Gherkin ids use the fresh `rec-cli-` prefix.

# Recovered spec — CLI surface gaps

Source scan: `scripts/harness_lib/cli_registry.py`, `cli_workflow_tree.py`,
`cli_catalog.py`, `common.py` (TSV/compact emit), `harness.py` main()/exit
handling, cross-referenced against `specs/40-features/cli-tool-catalog.md`,
`workflow-cli-tree.md`, and `testing/scenarios/cc_cli_catalog.py`,
`te_compact_output.py`, `cli_registry.py` (scenario), `wt_workflow_tree.py`.

## Goal

Recover the CLI-wide contracts that exist only as code behavior or scattered
rider mentions — the frozen verb order, the exit-code contract, and above
all TE.5 (the compact/TSV agent-facing output mode) — so that a future
change to any one verb doesn't silently break a contract every other verb
relies on, and so TE.5 gets ONE home spec instead of four partial mentions.

## Applicability

`scripts/harness.py` main()/`closing_block` exit handling,
`scripts/harness_lib/cli_registry.py` (frozen top-level order),
`scripts/harness_lib/common.py` (`_tsv_cell`, compact/TSV emit logic),
`scripts/harness_lib/cli_catalog.py` (compact-vs-json precedence, verb-count
claim). Does not cover per-verb business logic — only the shared CLI-surface
contracts every verb sits on top of.

## Requirements / invariants (numbered, testable — recovered)

1. **HarnessError → exit code 2.** Any `HarnessError` raised during command
   dispatch results in the process exiting with code 2. Source:
   `harness.py:2884-2886`.
2. **argparse usage errors also exit 2.** argparse's own parse-error path
   uses Python's default exit code 2 — the same code as rule 1, with no
   distinct signal for "bad invocation" vs "runtime failure". `inferred` —
   not stated as deliberate anywhere; may be an accident of relying on
   argparse defaults.
3. **Frozen top-level verb order.** The bare `--help` listing enumerates all
   verbs in one fixed, byte-identical order (`workflow` always last); this
   order is asserted only inside the test file itself
   (`FROZEN_TOP_LEVEL` in `testing/scenarios/cli_registry.py`), not in a
   spec. Source: `cli_registry.py:38-40` docstring.
4. **TE.5 default output is byte-identical pretty JSON.** With
   `HARNESS_AGENT_OUTPUT` unset, output is `indent=2` JSON, unchanged from
   pre-TE.5 behavior. Source: `common.py:176-190`.
5. **TE.5 compact mode for nested payloads.** With
   `HARNESS_AGENT_OUTPUT=compact`, a nested/heterogeneous payload emits
   compact (no-indent) JSON. Source: `common.py:176-190`.
6. **TE.5 TSV mode for flat homogeneous lists.** Under the same env var, a
   flat list of same-shaped dicts (a "table-shaped" payload) emits TSV
   instead of JSON. The set of verbs that actually opt into this path is
   NOT centrally declared — today it includes at least `catalog`, `models
   list`, `tasks list`; whether `records`, `spec-index`, `docs-tree`,
   `failure-patterns` (all of which emit list-shaped output) participate is
   unspecified and untested. Source: `cli_catalog.py:101`, plus registry
   help strings for tasks/models; backlog rider `IMPLEMENTATION_BACKLOG.md:607`
   ("TE.5: ... TSV for homogeneous lists").
7. **TSV cell flattening.** Any tab, carriage return, or newline character
   inside a TSV cell value is flattened to a space, to keep rows aligned —
   critical for verbs whose values can contain multiline text (e.g. a
   `records`/`log` entry body). Source: `common.py:154-162` (`_tsv_cell`).
8. **Compact overrides `--json`.** In `cmd_catalog`, the
   `HARNESS_AGENT_OUTPUT=compact` branch is checked and returned BEFORE the
   `--json` flag branch — compact wins if both are present. Source:
   `cli_catalog.py:100-105`. `inferred` generalization: whether this
   precedence holds for every other verb supporting both compact and --json
   is unverified; recorded here only for the `catalog` verb.
9. **Unknown catalog verb refuses with a hint, exit 2.** Requesting
   `catalog <unknown-verb>` refuses with a message pointing back at `catalog`
   (which lists all real verbs) and exits 2. Source: `cli_catalog.py:75-79`;
   spec `cli-tool-catalog.md` requirement 3 already documents the behavior,
   but no test drives it through an actual subprocess (only the in-process
   raise is tested).
10. **`workflow-command-surface` gate covers both files.** The gate that
    verifies the CLI's registered workflow-command set matches
    `project.json`'s declared set scans BOTH `harness.py` and
    `cli_workflow_tree.py`, in both directions (extra-in-code and
    extra-in-config both fail). Source: `spec_test_gate.py:581`,
    `cli_workflow_tree.py:16-18`; already spec'd
    (`workflow-cli-tree.md` req 2) and tested (`wt-1`) — listed for
    completeness, not a gap.
11. **`closing_block` runs only on success.** The SPEC-102
    outcome/state/next-action block that prints after a subcommand only
    fires when the command exits 0; a `HarnessError` path skips it, so a
    failed command's stderr carries no structured next-step guidance.
    Source: `harness.py:2880-2893`. `inferred` — not stated as deliberate;
    could equally be an oversight.

## Gherkin scenarios

```gherkin
Feature: CLI surface recovered acceptance rules (DRAFT, non-canonical)

  Scenario: [rec-cli-1] a HarnessError exits the real CLI process with code 2
    Given a harness.py invocation that triggers a HarnessError deep in a command handler
    When the subprocess exits
    Then its returncode is exactly 2

  Scenario: [rec-cli-2] an argparse usage error also exits 2
    Given an invalid CLI invocation (unknown flag or missing required arg)
    When the subprocess exits
    Then its returncode is 2, same as a HarnessError — recorded as a naming collision, not asserted as desirable

  Scenario: [rec-cli-3] the top-level verb order is frozen
    Given a spec (not just the test file) declaring the canonical verb order
    When "harness.py --help" runs
    Then the verb order matches byte-for-byte

  Scenario: [rec-cli-4] TSV output flattens embedded newlines
    Given a records entry whose body contains an embedded newline
    When it is rendered under HARNESS_AGENT_OUTPUT=compact as TSV
    Then the newline is replaced with a space and the row stays single-line

  Scenario: [rec-cli-5] the TSV-eligible verb set is centrally declared
    Given the set of verbs whose list output is TSV-eligible under compact mode
    When each candidate verb (records, spec-index, docs-tree, failure-patterns, catalog, models list, tasks list) is checked
    Then its TSV eligibility matches one central allowlist, not scattered per-verb behavior

  Scenario: [rec-cli-6] compact mode wins over --json when both are set
    Given HARNESS_AGENT_OUTPUT=compact and --json both present for "catalog"
    When the command runs
    Then the output is the compact form, not the --json form

  Scenario: [rec-cli-7] an unknown catalog verb exits 2 through the real CLI
    Given "harness.py catalog nonexistent-verb"
    When the subprocess runs
    Then it exits 2 and stderr/stdout mentions "catalog" as the way to list real verbs
```

## Rationale & sources

| Rule | Source |
|---|---|
| Exit code 2 for HarnessError | `scripts/harness.py:2884-2886` |
| argparse exit 2 collision | argparse stdlib default; `harness.py:2886` |
| Frozen verb order | `scripts/harness_lib/cli_registry.py:38-40`; `testing/scenarios/cli_registry.py` `FROZEN_TOP_LEVEL` |
| TE.5 default/compact/TSV modes | `scripts/harness_lib/common.py:154-190`; backlog anchor `docs/IMPLEMENTATION_BACKLOG.md:607` ("TE.5 ... measured 73.3% nested, 43.9% flat") |
| TSV eligibility scattered | `scripts/harness_lib/cli_catalog.py:101`; registry help text for `tasks`/`models` |
| Compact-overrides-json precedence | `scripts/harness_lib/cli_catalog.py:100-105` |
| Unknown-verb refusal | `scripts/harness_lib/cli_catalog.py:75-79`; `specs/40-features/cli-tool-catalog.md` req 3 |
| closing_block success-only | `scripts/harness.py:2880-2893` |

## Test strategy

- Behaviors to verify: real subprocess exit codes for both HarnessError and
  argparse-usage-error paths (today only in-process raises are tested);
  TSV newline-flattening on a genuinely multiline value; a stated, testable
  TSV-eligibility allowlist across ALL list-emitting verbs, not just the two
  currently covered (`routing show`, `models list`); compact/--json
  precedence generalized beyond `catalog`.
- Edge cases: empty list under compact (falls back to compact JSON, not a
  malformed TSV header — `common.py:187-190`); a value containing a literal
  tab character.
- Regression risks: any exit-code change is CLI-breaking for scripts/CI
  that check `$?`; changing the frozen verb order breaks agent-facing
  parsing that expects positional stability.
- Coverage impact: `te_compact_output.py` currently exercises exactly 2 of
  ~8+ list-emitting verbs; extending it is additive, low-risk.

## Validation

Not yet built. Consolidation path: write a small `cli-contract.md` spec
covering exit codes + frozen order + TE.5 as one document (today spread
across `cli-tool-catalog.md` and three unrelated riders), then extend
`te_compact_output.py` and `cli_registry.py` (scenario) with the above
checks; `python testing/scenarios/te_compact_output.py` and
`cli_registry.py` green + `spec-pack` conformance.

## Amendments

(none — this is the initial recovery draft)
