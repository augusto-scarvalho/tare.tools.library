# Spec recovery — gap matrix (DRAFT — NON-CANONICAL)

Recovered by mining `git log`, `docs/IMPLEMENTATION_BACKLOG.md`, `specs/40-features/*.md`,
and `testing/scenarios/*.py` against each other. This is a consolidation menu for the
overseer, not a spec. Nothing here is authoritative; nothing here edits `specs/`,
`testing/`, `AGENTS.md`, `CLAUDE.md`, or `.harness/`.

Method: 4 parallel scanner subagents, one per priority area, each reading the actual
source files, canonical specs, regression scenarios, and rich commit messages /
backlog rows for that area. Findings below are their reports, deduplicated and
ranked. See `draft-*.md` in this folder for the SDD+BDD material recovered per area.

**Totals: 60 rules recovered across 4 areas. 47 UNTESTED today (no scenario check
exercises the rule at all, or only a narrower/indirect proxy exists). 13 already
covered (listed for completeness, not carried into the drafts).**

## CLOSED — consolidation log (2026-07-13, owner-directed hardening pass)

- **rec-gui-1** fixed `48f21fd` + pinned `rh_gui_hardening.py` (9cfdfc3); **rec-gui-2,
  rec-gui-6** pinned same scenario + M5 spec amendment.
- **rec-chat-1/2/3** pinned offline in `rh_codex_engine.py` (f81ec63).
- **rec-wf-1/2/3** pinned in `rh_reduce_policy.py` (0de8294); **rec-wf-12** spec
  `workflow-rollback-restore.md` + `wfrb_rollback_restore.py` (174cb85); **rec-wf-19**
  FIXED — worktree spawns routed through `processes.run_quiet`, ratchet re-baselined
  28→27 mediated-world sites (cm-5's stray console windows).
- **rec-cli-1/2/13** spec `cli-exit-code-contract.md` + `cec_exit_codes.py` (5cf38e8);
  **rec-cli-4/5/6/7/14** spec `te5-agent-output.md` + `te_compact_output.py` 6→9 (71035aa).
- **cm-1** fixed + spec + `cm1_profile_switch.py` (3205070); **cm-6** shipped as the
  intake queue (d2d4bf3); **cm-2/cm-7** verified already-shipped (overseer corrections).
- Still open, by choice or size: rec-wf-4/5/6/13/14/15/16/17 (M), rec-chat-4..19 (M/L),
  rec-cli-3/9/12/15 (L), rec-gui-3/4/5/7 (L), cm-3/cm-4/cm-8. The queue and this log
  are the source of truth for the next pass.

## Top-5 highest-risk gaps

1. **GUI worker drill-in drawer leaks secrets** — `ui_panel.worker_detail` returns raw
   `tail_lines(stdout/stderr)` with no `secret_scan.redact_text` call, unlike every
   other panel view (Memory, Commits). A key printed to a worker's own stdout renders
   unredacted in the browser. No spec, no test. `draft-gui-panel.md` rec-gui-1.
2. **Workflow rollback-on-gate-failure has zero test coverage** — `workflow_writes.py`
   replays `__actions.json` in reverse (create→remove, modify/delete→restore,
   rename→reverse) with no spec and no scenario exercising the actual data-restore
   path. A silent rollback bug is a data-loss surface. `draft-workflow-runtime.md`
   rec-wf-12.
3. **CLI exit-code contract (HarnessError → 2) is unspecified and untested end-to-end**
   — every scenario asserts the in-process `raise HarnessError`, never the subprocess
   `returncode == 2` a real caller sees; argparse usage errors collide on the same
   code 2 with no distinct signal. `draft-cli-surface.md` rec-cli-1/2.
4. **Codex chat engine (sandbox mode, effort flag, thread continuity) has real
   shipped behavior and zero scenario coverage** — `chat-stream-parity` is a named
   open backlog row, but the sandbox-mode mapping and reasoning-effort flag already
   ship untested. `draft-chat-operator.md` rec-chat-1/2/3.
5. **TE.5 compact/TSV output contract has no home spec** — it exists only as a rider
   line inside four unrelated feature specs; the TSV opt-in allowlist (which verbs
   emit TSV under compact) and the newline/tab cell-flattening rule are both
   unspecified and untested outside two read-only verbs. `draft-cli-surface.md`
   rec-cli-4/5/6.

## Gap matrix

Legend — Risk: H=high (user-visible break or data/secret exposure), M=medium, L=low
(cosmetic/drift). Test: scenario file + check id, or **UNTESTED**.

### GUI panel (`draft-gui-panel.md`)

| # | Rule | Documented today | Test coverage | Risk | Recommended action |
|---|---|---|---|---|---|
| rec-gui-1 | Worker drawer shows raw stdout/stderr, no redaction | `ui_panel.py:469-483` (code only) | UNTESTED | **H** | New check in `m5_ui_panel.py`: plant a key in worker stdout, assert drawer output is redacted; fix `worker_detail` to route through `secret_scan.redact_text` |
| rec-gui-2 | `rerun-gate` allowlist = exactly {smoke, spec-pack, scenarios} | `ui_actions.py:32` (code only) | Self-check only, no scenario | M | Amend `supervision-m5-interactive-panel.md` to enumerate `GATE_ALLOW`; add scenario check |
| rec-gui-3 | Discard-refusal EN string drifted from spec's Portuguese text | `ui_actions.py:142` vs spec line 808 | Tested (against wrong string) | L | Amend M5 spec text to match shipped EN string |
| rec-gui-4 | `_wf_running` is PID-liveness only; recycled PID false-refuses discard | `ui_actions.py:117-129` (ponytail comment) | UNTESTED | M | Document the ceiling in spec; add a regression scenario for the recycled-PID case |
| rec-gui-5 | Branch chip `@sha`/`●dirty` never renders — backend `gitInfo` unwired | `panel-chat-qol.md:190-194` (self-declared known gap) | Front-end contract tested; backend UNTESTED/unbuilt | L | Track as a follow-up item, wire `harness.py:current_commit` into `state_snapshot` |
| rec-gui-6 | Every panel action bounded: 900s timeout (rc124) + 8000-char output cap | `ui_actions.py:30-31,283-288` (code only) | UNTESTED | L | Add invariant to M5 spec + a scenario asserting the cap/timeout constants |
| rec-gui-7 | SPEC-122 (EN-default guard) has no `specs/40-features/*.md` file, only a gate check + scenario | commits/gate only | Gate-enforced (`en_default_guard.py`) but no spec doc | L | Write the missing `specs/40-features/en-default-guard.md` retroactively |

### Chat operator (`draft-chat-operator.md`)

| # | Rule | Documented today | Test coverage | Risk | Recommended action |
|---|---|---|---|---|---|
| rec-chat-1 | Codex sandbox mode mapping (plan→read-only, accept-edits→workspace-write; exec vs resume flag differs) | `chat_engines.py:300-324` (commit 2415ce7) | UNTESTED | H | New spec section + scenario driving CodexEngine through all 3 chat_mode values |
| rec-chat-2 | Codex effort via `-c model_reasoning_effort` (no `--effort` flag) on exec+resume | `chat_engines.py:319-322` | UNTESTED | M | Same scenario as rec-chat-1, assert argv shape |
| rec-chat-3 | Codex continuity via explicit `thread_id` from `thread.started`, not `resume --last` | `chat_engines.py:357-379` | UNTESTED | M | New scenario asserting thread_id capture + reuse |
| rec-chat-4 | Claude `_argv` always passes explicit `--permission-mode`; Enter/ExitPlanMode disallowed | `chat_engines.py:152-163` | Only telemetry tested; argv/permission-mode UNTESTED | M | Assert argv shape per chat_mode in a scenario |
| rec-chat-5 | accept-edits mode appends `Bash(...harness.py *)` to allowedTools | `chat_engines.py:174-177` (SPEC-111 R23) | gate_for truth table tested; allowedTools append UNTESTED | M | Add assertion on the constructed allowedTools list |
| rec-chat-6 | OpenAI engine agent-facing gate ladder (human-only blocked / plan proposes / confirm y-N / accept-edits auto) | `chat_engines.py:436-464` | `gate_for` unit-tested; `OpenAIEngine._run_tool_call` flow UNTESTED | M | Scenario driving OpenAIEngine through all 4 gate states |
| rec-chat-7 | OpenAI double-injection guard: `triage_packet` prepended only for openai engine (claude/codex get it via hook) | `chat_operator.py:751-755` (SPEC-117 inv.4, comment-only) | UNTESTED | M | Write the invariant into a spec; add assertion |
| rec-chat-8 | Bare `!escalations` in a `/repo` session auto-appends `--target <subject>` unless explicit --target given | `chat_operator.py:294-310,725-727` | Lib-level `scoped_resolve_check` tested; REPL auto-append UNTESTED | M | Scenario driving the chat REPL command, not just the lib function |
| rec-chat-9 | Finished-plan flush: all-completed plan flushes once as checklist, HUD rows drop | `chat_hud.py:333-345` (commit 2415ce7) | Pure formatter tested; live `Hud.set_plan` flush UNTESTED | M | Scenario exercising the stateful Hud object, not just `format_plan_rows` |
| rec-chat-10 | Non-HUD terminal prints step transitions only, never full rewritten list | `chat_operator.py:490-500` | UNTESTED | L | Add scenario assertion |
| rec-chat-11 | Target-switch re-resolve gate rebinds engine only if routing changed AND not flag/session-pinned | `chat_operator.py:327-336,604-625` (SPEC-114 R37) | Self-check only, no scenario | L | Promote self-check assertion into `_lib`-based scenario |
| rec-chat-12 | Cost ledger session dimension via `HARNESS_CHAT_SESSION` env, additive `session` field | `ui_chat_bridge.py:100-101` (SPEC-133 ceiling) | UNTESTED (not in qol:* checks) | L | Add a qol_panel_chat check |
| rec-chat-13 | Bridge lossless replay: cursor-based, 400-item window, stale cursor resets to full replay | `ui_chat_bridge.py:49-82,144-156` (SPEC-114 v11 R24) | Partially tested in m5_ui_panel | M | Add cursor-reset-specific scenario check |
| rec-chat-14 | P5 hint suppression under panel bridge (`HARNESS_CHAT_EVENTS=1`) | `chat_operator.py:104-127` (9c50dbf) | UNTESTED | L | Add scenario assertion |
| rec-chat-15 | Claude cost delta is cumulative under `--resume`; per-turn delta reported, negative falls back to raw | `chat_engines.py:243-248` | Telemetry mapping tested; delta-across-turns UNTESTED | L | Add multi-turn scenario |
| rec-chat-16 | Claude turn watchdog (`TURN_TIMEOUT` env) kills proc; stderr drained on a thread | `chat_engines.py:203-227,338-339,432` | UNTESTED | L | Add timeout-triggering scenario |
| rec-chat-17 | `plan-steps` (TodoWrite HUD) event is distinct from SPEC-133 `plan` approval event; both can co-emit | `chat_operator.py:486` vs `771-772` | Distinctness tested at source level; runtime co-emit only partial | L | Extend scenario to assert both frames appear in one turn |
| rec-chat-18 | `gitInfo` never wired at runtime (duplicate of rec-gui-5, chat-side symptom) | `panel-chat-qol.md:190-194` | Front-end only | L | Same fix as rec-gui-5 |
| rec-chat-19 | Emoji encode-probe fallback (`format_tool_line`/`_glyphs` degrade to `[tool]`/ASCII) | `chat_operator.py:348-352`, `chat_hud.py:41-49` | Icon-present path tested; fallback branch UNTESTED | L | Add a console-encoding-rejects-emoji scenario case |

Acknowledged backlog rows, not filed as gaps: `codex-stream-parity` (M/P2 — CodexEngine
gets no chips/plan HUD at all yet), `chat-gate-tracker` (S/P2). `IMPLEMENTATION_BACKLOG.md:239-240`.

### CLI surface (`draft-cli-surface.md`)

| # | Rule | Documented today | Test coverage | Risk | Recommended action |
|---|---|---|---|---|---|
| rec-cli-1 | `HarnessError` → process exit code 2 (uniform CLI failure contract) | `harness.py:2884-2886` (code only) | UNTESTED at the subprocess level | H | Write a CLI-wide exit-code spec; add a scenario asserting `returncode==2` through a real subprocess |
| rec-cli-2 | argparse parse-errors also exit 2, colliding with HarnessError's code | argparse default + `harness.py:2886` | UNTESTED, `inferred` | M | Decide distinct codes or document the collision as intentional |
| rec-cli-3 | Frozen top-level verb order (38 verbs, `workflow` last) | `cli_registry.py:38-40` docstring | Tested only inside the test file itself (`FROZEN_TOP_LEVEL` lives in the scenario, not a spec) | M | Promote the frozen order into `cli-tool-catalog.md` or a new CLI-contract spec |
| rec-cli-4 | TE.5 default byte-identical indent=2; compact JSON for nested; TSV only for opt-in flat lists | `common.py:176-190`, backlog `IMPLEMENTATION_BACKLOG.md:607` | Only 2 verbs tested (`routing show`, `models list`) | **H** | Write a dedicated TE.5 spec naming the TSV-eligible verb allowlist |
| rec-cli-5 | Which verbs emit TSV under compact is scattered/undefined (catalog/models/tasks list opt in; records/spec-index/docs-tree/failure-patterns unspecified) | `cli_catalog.py:101`, scattered registry strings | UNTESTED for records/spec-index/docs-tree/failure-patterns, `inferred` | M | Central allowlist in the TE.5 spec (same as rec-cli-4) |
| rec-cli-6 | TSV cell flattening: tab/CR/newline → space (data integrity for multiline bodies) | `common.py:154-162` `_tsv_cell` | UNTESTED (no embedded-newline test case), `inferred` | M | Add scenario with an embedded-newline `records`/`log` body |
| rec-cli-7 | `HARNESS_AGENT_OUTPUT=compact` overrides `--json` (compact branch returns before json branch) | `cli_catalog.py:100-105` | UNTESTED, `inferred` | L | Document precedence in the TE.5 spec |
| rec-cli-8 | catalog net-cost-positive: `catalogChars < fullHelpChars`, share < 0.5 | `cli_catalog.py:82-89` | `cli-tool-catalog.md` req 4 ✅, `cc_cli_catalog.py` cc-3 ✅ | — | No gap — covered |
| rec-cli-9 | Catalog verb-count claim ("81 verbs") is stale vs live ~82-verb surface | `cli-tool-catalog.md:15-18` | `cc-1` uses subset check, doesn't catch drift, `inferred` | L | Fix the hardcoded count or switch spec language to "N verbs (see catalog)" |
| rec-cli-10 | Unknown catalog verb refuses exit 2 with a `catalog` hint | `cli_catalog.py:75-79` | `cli-tool-catalog.md` req 3 ✅ but `cc-2` only tests in-process raise, not subprocess rc | M | Add subprocess-level assertion |
| rec-cli-11 | `workflow-command-surface` gate unions harness.py + cli_workflow_tree.py against project.json both ways | `spec_test_gate.py:581`, `cli_workflow_tree.py:16-18` | `workflow-cli-tree.md` req 2 ✅, `wt-1` ✅ | — | No gap — covered |
| rec-cli-12 | Internal/hidden workflow cmds (e.g. `async-supervisor`, argparse.SUPPRESS) excluded from help but tracked as internal | `cli_workflow_tree.py:94` | Indirectly covered by wt-1 surface set, `inferred` | L | Document the suppress/internal distinction explicitly |
| rec-cli-13 | `closing_block` (SPEC-102 outcome/next-action) runs only on rc=0, skipped on HarnessError | `harness.py:2880-2893` | UNTESTED, `inferred` | L | Document error-path suppression as intentional or fix |
| rec-cli-14 | Empty/non-homogeneous list under compact falls back to compact JSON, not a bad TSV header | `common.py:187-190` | UNTESTED edge case, `inferred` | L | Add edge-case test to TE.5 scenario |
| rec-cli-15 | te_compact thresholds hardcoded (0.75 nested / 0.55 flat), brittle to payload growth | `te_compact_output.py:50-54` | Self-referential test only | L | Note as a known ceiling in the TE.5 spec |

### Workflow runtime (`draft-workflow-runtime.md`)

| # | Rule | Documented today | Test coverage | Risk | Recommended action |
|---|---|---|---|---|---|
| rec-wf-1 | `testingFailureBlocksRelease`: a failed worker whose identifiers mention test/coverage forces reduce → `blocked` | `workflow_reduce.py:221-229` | UNTESTED | M | New map-reduce join-policy spec section + scenario |
| rec-wf-2 | `securityBlockerBlocksWorkflow` (default true): a security/privacy/secrets/auth/dependency blocker finding → `blocked` | `workflow_reduce.py:215-218` | Flag named in `research-skill.md:35` only; enforcement UNTESTED | M | Same as rec-wf-1 |
| rec-wf-3 | `missingWorkerMakesResultPartial` (default true): missing/invalid workers downgrade done→partial or →failed if all invalid | `workflow_reduce.py:236-239` | UNTESTED | M | Same as rec-wf-1 |
| rec-wf-4 | Reduce refuses while lock active or workers queued/running unless `--allow-partial` | `workflow_reduce.py:244-252` | UNTESTED (only happy-path await-all-settled tested) | M | New scenario for the allow-partial escape hatch |
| rec-wf-5 | Reduce numeric caps: maxFindings=100, maxConflicts=50, maxRecommendedTasks=20, maxMarkdownChars=12000 | `workflow_reduce.py:269-273,299-303` | UNTESTED | L | Document caps in map-reduce spec |
| rec-wf-6 | `cancelRestOnQuorum`: quorum satisfied cancels remaining sibling workers | `async_runtime.py:624-629` | UNTESTED, `inferred` | M | Amend `agentic-async-await.md` (documents race/first-success, not quorum) + scenario |
| rec-wf-7 | Circuit breaker records success only if task fulfilled AND `WORKER_RESULT.status` not in {failed,error} | `async_runtime.py:336-349` (CE.1) | Partially tested (`ce1_containment.py`) | M | Extend ce1 coverage to the task-fulfilled-but-status-failed case |
| rec-wf-8 | Mid-workflow failover re-spawns on next fallback card, bounded by failoverHistory, resolved against origin executor | `async_runtime.py:537-558` (SPEC-115) | Well-tested (`wf_failover.py`) | — | No gap — covered, but no canonical spec doc exists (commit-only); consider a small spec |
| rec-wf-9 | Controlled writes forbidden on target repos — locks/backups/merge stay harness-root-relative | `workflow_writes.py:56-61` (HT-T5b) | UNTESTED, `inferred` | M | `cross-project-isolation-data.md` is silent on the write path — amend + scenario |
| rec-wf-10 | Write concurrency force-capped to 1 unless `parallelWritesAllowed` | `async_runtime.py:685-687` | UNTESTED | M | Amend map-reduce spec (general parallel-writes-forbidden line exists, cap-to-1 mechanic doesn't) |
| rec-wf-11 | `maxRounds` reached → hard-error requiring `--force-round` after human review | `async_runtime.py:696-699`, `workflow_lifecycle.py:34-35` | UNTESTED | M | Same as rec-wf-10 |
| rec-wf-12 | Rollback-on-gate-failure replays `__actions.json` in reverse (create→remove, modify/delete→restore, rename→reverse) | `workflow_writes.py:349-455` | **UNTESTED — no rollback scenario at all** | **H** | Write the rollback spec + a scenario that actually exercises data restore |
| rec-wf-13 | Merge-plan flags unauthorized new files as `created-without-create-or-rename-lock` conflict (bounded 50) | `workflow_writes.py:170-180` | UNTESTED | M | New scenario |
| rec-wf-14 | Semantic merge-review gate blocks finalize when `requiresSemanticMergeReview` is set | `workflow_reduce.py:457-476`, `workflow_lifecycle.py:68-74` | UNTESTED | M | New scenario |
| rec-wf-15 | Secret-scrub at collect boundary invalidates secret-shaped results (redacted, withheld) + flags `requiresSecurityReview`, re-scanned on reduce output | `workflow_reduce.py:93-105,336-341` (SPEC-119 v5) | Covered in `data-protection-and-privacy.md` generally; collect-boundary specifics UNTESTED at workflow level | M | Add workflow-level scenario for the specific rule |
| rec-wf-16 | `scrub` allowed only in phases {planned, finalized, rolled_back} unless `--force`; refuses under active lock | `workflow_lifecycle.py:28,278-289` | UNTESTED | L | New scenario |
| rec-wf-17 | Worker exited 0 but no WORKER_RESULT → status `missing` (distinct from `failed`); rate-limited-with-no-result → `blocked` | `async_runtime.py:523-531` | `async-await.md:79` documents reject-on-missing; `missing` vs `blocked` distinction UNTESTED | L | Amend spec + scenario |
| rec-wf-18 | Non-linear reduce: best retry = (statusRank, evidence-count), recency only tie-breaks; retry archives prior result first (SPEC-103 M3.3) | `workflow_reduce.py:147-196`, `workflow_lifecycle.py:37-48` | Well-tested (`m3_3_nonlinear_reduce.py`) | — | No gap — covered |
| rec-wf-19 | Git worktree prepare/cleanup uses direct `subprocess.run`, outside the `processes.py` mediation layer | `workflow_writes.py:490-528` | Baselined by `srg_spawn_ratchet.py`, not routed, `inferred` | L | Track as a named ratchet debt item, not a silent exemption |

Already covered (listed for completeness, not carried into the draft): await modes
all/all-settled/race/first-success/quorum (`agentic-async-await.md:110-113`); reviewer
no-self-waiver (SPEC-103 M3.1, `m3_1_skeptical_reviewer.py`); token-budget refusal +
`--override-budget` (SPEC-102, `m2_mvp_scenario.py`); per-subject token calibration +
escalation subject scope (`ia_isolation_audit.py`, `es_subject_scope.py`); fold
only-on-finalized + unsealed-on-secret-hit (`wf_fold.py`).
