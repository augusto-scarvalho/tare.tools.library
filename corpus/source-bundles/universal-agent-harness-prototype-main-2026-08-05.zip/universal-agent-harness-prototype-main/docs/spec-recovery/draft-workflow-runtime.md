**DRAFT — NON-CANONICAL.** Recovered spec material for workflow-runtime
business rules (await/settle, reduce join policy, budget/round gates, writes
and rollback, isolation). Does not resolve to real checks yet. See `INDEX.md`
for the full gap matrix. Scenario/Gherkin ids use the fresh `rec-wf-` prefix.

# Recovered spec — workflow runtime gaps

Source scan: `scripts/harness_lib/workflow_reduce.py`, `workflow_writes.py`,
`workflow_lifecycle.py`, `async_runtime.py`, cross-referenced against
`specs/00-universal/agentic-map-reduce.md`, `agentic-async-await.md`,
`specs/40-features/cross-project-isolation-data.md`,
`raw-subprocess-ratchet.md`, and `testing/scenarios/ce1_containment.py`,
`wf_failover.py`, `m3_3_nonlinear_reduce.py`, `wf_fold.py`,
`m2_mvp_scenario.py`.

## Goal

Recover the map-reduce join-policy business rules, the workflow-write /
rollback mechanics, and the round/budget gates that ship in
`workflow_reduce.py`/`workflow_writes.py`/`async_runtime.py` but stop at
generic language in the universal specs ("deduplicate/rank", "max rounds",
"parallel writes forbidden") — the actual thresholds, status-downgrade
rules, and (most importantly) the rollback data-restore mechanics have no
spec and, in the rollback case, no test at all.

## Applicability

`scripts/harness_lib/workflow_reduce.py` (join-policy flags, numeric caps,
secret-scrub at collect boundary, semantic-merge-review gate),
`workflow_writes.py` (target-write confinement, write-concurrency cap,
merge-plan conflict detection, rollback replay), `async_runtime.py`
(quorum-cancel, circuit breaker success criteria, mid-workflow failover,
missing-vs-blocked worker status), `workflow_lifecycle.py` (maxRounds
hard-stop, scrub phase gating). Does not cover the already-well-specified
await modes, reviewer no-self-waiver, budget-refusal, or fold mechanics
(see INDEX.md "already covered" list).

## Requirements / invariants (numbered, testable — recovered)

1. **testingFailureBlocksRelease.** A failed worker whose `unitId`/`role`/
   `taskProfile`/`promptPath` text contains "test" or "coverage" forces the
   reduce status to `blocked`, regardless of other workers' outcomes.
   Source: `workflow_reduce.py:221-229`.
2. **securityBlockerBlocksWorkflow** (default true). Any blocker-severity
   finding tagged security/privacy/secrets/auth/authorization/dependency
   forces `blocked`. Source: `workflow_reduce.py:215-218`; the flag is named
   in `research-skill.md:35` but its reduce-time enforcement is not
   described there.
3. **missingWorkerMakesResultPartial** (default true). A missing or invalid
   worker result downgrades an otherwise-`done` reduce to `partial`; if
   every worker result is invalid, it downgrades to `failed` instead.
   Source: `workflow_reduce.py:236-239`.
4. **Reduce refuses on unsettled workers.** `workflow reduce` refuses while
   the workflow lock is active or any worker is still queued/running,
   unless `--allow-partial` is passed — "every worker settled or result
   silently dropped" is the design intent. Source:
   `workflow_reduce.py:244-252`.
5. **Reduce numeric caps.** `reduceBudget` bounds: maxFindings=100,
   maxConflicts=50, maxRecommendedTasks=20, maxMarkdownChars=12000. Source:
   `workflow_reduce.py:269-273,299-303`.
6. **cancelRestOnQuorum.** When an await-quorum condition is satisfied, the
   remaining sibling workers in that wave are cancelled (parallel to the
   already-documented `cancelRestOnRace`/`cancelRestOnFirstSuccess`).
   Source: `async_runtime.py:624-629`. `inferred` generalization of the
   documented race/first-success pattern to quorum, confirmed in code.
7. **Circuit breaker records real outcome, not process exit.** The breaker
   records a success only if the task was fulfilled AND
   `WORKER_RESULT.status` is not in `{failed, error}` — a worker that exits
   rc=0 but reports `status: failed` in its own result still counts as a
   breaker failure (this is the CE.1 containment-gap fix). Source:
   `async_runtime.py:336-349`.
8. **Mid-workflow failover resolution.** A worker hitting
   `rate_limit_or_runtime_limit` re-spawns on the next fallback card in the
   chain, bounded by a `failoverHistory` list, and is resolved against the
   ORIGIN executor's fallback chain (not the current one), per SPEC-115.
   Source: `async_runtime.py:537-558`. Already well-tested
   (`wf_failover.py`) but has no canonical spec file — it exists only in
   commit history and the `model-routing.md` "rule 15" backlog mention.
9. **Controlled writes stay harness-root-relative on target work.** Locks,
   backups, and merge state for a target-scoped workflow are always
   relative to the HARNESS root, never the target repo — "HT-T5b" in the
   commit history. Source: `workflow_writes.py:56-61`.
10. **Write concurrency force-capped to 1.** Unless `parallelWritesAllowed`
    is explicitly set, the write-apply phase forces concurrency to 1 even if
    the workflow profile requested more. Source: `async_runtime.py:685-687`.
11. **maxRounds hard-stop.** Reaching `maxRounds` makes a further
    start/retry hard-error, requiring an explicit `--force-round` after a
    human reviews the situation. Source: `async_runtime.py:696-699`,
    `workflow_lifecycle.py:34-35`.
12. **Rollback-on-gate-failure replay.** When a gate fails after a
    controlled write, rollback replays `__actions.json` in REVERSE order:
    a `create` action is undone by removing the file, `modify`/`delete`
    actions are undone by restoring the pre-write backup, and `rename`
    actions are undone by reversing the rename. Source:
    `workflow_writes.py:349-455`. **No spec, no test exercises this path at
    all** — the highest-risk recovered rule in this document.
13. **Merge-plan unauthorized-file conflict.** A merge plan flags any new
    file not covered by an existing create-or-rename lock as a
    `created-without-create-or-rename-lock` conflict, capped at 50 entries.
    Source: `workflow_writes.py:170-180`.
14. **Semantic-merge-review gate.** When a write is allowed, an apply
    result is produced, and `requiresSemanticMergeReview` is set, finalize
    is blocked until that review gate passes. Source:
    `workflow_reduce.py:457-476`, `workflow_lifecycle.py:68-74`.
15. **Secret-scrub at collect boundary, re-checked at reduce.** A
    secret-shaped value in a worker result invalidates that result (redacted
    and withheld from the collected payload) and flags
    `requiresSecurityReview`; the same scan re-runs on the REDUCE output,
    not just at collect (SPEC-119 v5). Source:
    `workflow_reduce.py:93-105,336-341`.
16. **Scrub phase gating.** `workflow scrub` is only allowed in phases
    `{planned, finalized, rolled_back}` unless `--force` is passed, and
    always refuses while a lock is active. Source:
    `workflow_lifecycle.py:28,278-289`.
17. **Missing vs blocked worker status.** A worker that exits 0 but never
    writes a `WORKER_RESULT` is marked `missing` (distinct from `failed`); a
    rate-limited worker that produced no result at all is marked `blocked`
    instead. Source: `async_runtime.py:523-531`;
    `agentic-async-await.md:79` documents "reject on missing" generally but
    not this two-way distinction.

## Gherkin scenarios

```gherkin
Feature: workflow runtime recovered acceptance rules (DRAFT, non-canonical)

  Scenario: [rec-wf-1] a failed test-named worker forces reduce to blocked
    Given a wave where one worker's unitId contains "test" and it reports status failed
    When reduce runs
    Then the reduce status is "blocked" regardless of the other workers

  Scenario: [rec-wf-2] a security-category blocker finding forces reduce to blocked
    Given a worker result with a blocker-severity finding tagged "security"
    When reduce runs with securityBlockerBlocksWorkflow at its default
    Then the reduce status is "blocked"

  Scenario: [rec-wf-3] a missing worker downgrades an otherwise-done reduce to partial
    Given N workers where one produced no WORKER_RESULT and the rest are done
    When reduce runs
    Then the status is "partial", and it downgrades further to "failed" if all are invalid

  Scenario: [rec-wf-4] reduce refuses on unsettled workers without --allow-partial
    Given a workflow with one worker still queued
    When "workflow reduce" runs without --allow-partial
    Then it refuses; with --allow-partial it proceeds and records the drop

  Scenario: [rec-wf-6] quorum satisfaction cancels remaining siblings
    Given an await-quorum wave where the quorum threshold is met
    When the quorum condition fires
    Then the remaining running/queued siblings in that wave are cancelled

  Scenario: [rec-wf-7] breaker treats a status:failed WORKER_RESULT as a real failure
    Given a worker that exits rc=0 but its WORKER_RESULT.status is "failed"
    When the circuit breaker records the outcome
    Then it records a failure, not a success

  Scenario: [rec-wf-9] target-scoped controlled writes never touch the target's own lock/backup paths
    Given a workflow scoped to a governed target repository
    When a controlled write executes
    Then its lock file, backups, and merge state live under the harness root, not the target tree

  Scenario: [rec-wf-10] write concurrency is capped to 1 by default
    Given a write-apply phase with parallelWritesAllowed unset
    When multiple write-eligible workers finish
    Then they are applied with concurrency 1

  Scenario: [rec-wf-11] maxRounds requires --force-round to proceed
    Given a workflow that has reached its configured maxRounds
    When a retry/start is attempted without --force-round
    Then it hard-errors; with --force-round it proceeds

  Scenario: [rec-wf-12] a gate-failure rollback restores every action type correctly
    Given a controlled write that created one file, modified one file, and renamed one file
    When the post-write gate fails and rollback runs
    Then the created file is removed, the modified file is restored from backup, and the rename is reversed — verified by re-reading the tree after rollback

  Scenario: [rec-wf-13] an unauthorized new file is flagged in the merge plan
    Given a proposed write introducing a file with no create-or-rename lock
    When the merge plan is computed
    Then it appears as a "created-without-create-or-rename-lock" conflict

  Scenario: [rec-wf-14] requiresSemanticMergeReview blocks finalize
    Given an apply result flagged requiresSemanticMergeReview
    When finalize is attempted before that review passes
    Then finalize is blocked

  Scenario: [rec-wf-17] a silently-missing WORKER_RESULT is distinguished from a blocked one
    Given one worker exiting 0 with no WORKER_RESULT and another rate-limited with no result
    When their statuses are computed
    Then the first is "missing" and the second is "blocked"
```

## Rationale & sources

| Rule cluster | Sources |
|---|---|
| Reduce join-policy flags + caps (1-5) | `workflow_reduce.py:215-273,299-303` |
| Await/breaker/failover (6-8) | `async_runtime.py:336-349,537-558,624-629`; `wf_failover.py` (already tested); backlog `model-routing.md` "rule 15" |
| Writes/rollback/merge (9,10,12,13) | `workflow_writes.py:56-61,170-180,349-455,490-528`; `685-687` in async_runtime.py for the concurrency cap |
| Round/scrub/status gates (11,14,16,17) | `workflow_lifecycle.py:28,34-35,68-74,278-289`; `workflow_reduce.py:457-476`; `async_runtime.py:523-531,696-699` |
| Secret-scrub at collect+reduce (15) | `workflow_reduce.py:93-105,336-341` (SPEC-119 v5) |

## Test strategy

- Behaviors to verify: every join-policy flag's actual status-transition
  outcome (1-4); the numeric reduce caps as boundary tests (5); quorum-cancel
  as a live async scenario, not just documented modes (6); the breaker's
  task-fulfilled-but-status-failed distinction, extending `ce1_containment.py`
  (7); **rollback's actual file-restore behavior end-to-end** (12) — this is
  the one rule in the whole recovery effort with zero existing test of any
  kind; merge-plan conflict detection (13); semantic-merge-review gate (14).
- Edge cases: all-workers-invalid downgrade to `failed` not `partial` (3);
  negative/zero maxFindings edge; a rollback where the backup file itself is
  missing (undefined today — flag as a follow-up if found true).
- Regression risks: rec-wf-12 (rollback) touches the same code path as
  `wf_fold.py`'s fold-on-finalized assumptions — a new rollback scenario
  should run alongside `wf_fold.py` to confirm no phase-state interference.
- Coverage impact: rec-wf-12 is the single highest-value new test in this
  entire recovery — a real, working rollback path with literally no
  regression net today.

## Validation

Not yet built. Consolidation path: amend `specs/00-universal/agentic-map-reduce.md`
with the numbered join-policy/cap rules (1-5,13-15), amend
`cross-project-isolation-data.md` with the write-confinement rule (9), and
write a new `workflow-writes-rollback.md` spec for 10-12,16 — then add a
`testing/scenarios/wf_rollback.py` (new file) plus extensions to
`ce1_containment.py` and `wf_failover.py`; `spec-pack` conformance once specs
land.

## Amendments

(none — this is the initial recovery draft)
