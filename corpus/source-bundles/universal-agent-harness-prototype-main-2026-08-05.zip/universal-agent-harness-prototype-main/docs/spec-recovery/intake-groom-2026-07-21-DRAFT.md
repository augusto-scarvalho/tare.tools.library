> DRAFT — NON-CANONICAL — miner output pending overseer audit

# Intake groom — fila de intake, 2026-07-21

Rodada report-only (miner Sonnet 5 medium, playbook
`.harness/prompts/backlog-groom-playbook.md`). Reusa a taxonomia de clusters
A..L do round 2026-07-18 (`docs/research/backlog-groom-2026-07-18.md`), com 4
clusters novos (M, N) para o material específico desta janela.

## 1. Totais

- Pending em `.harness/state/intake-queue.json`: **115**
- Proposto:
  - discard: 60
  - discard (done): 51
  - backlog: 2
  - keep-pending: 0 (os 2 do round anterior foram resolvidos nesta rodada — ver §3)
  - spec / experiment: 0 novos (o único candidato da janela, openai-compat
    fallback, já foi intakado e decidido nesta mesma janela — id
    `5fa854d6e56d` → spec, `specs/40-features/compat-executor-routing.intake.md`)

(60 + 51 + 2 + 2 = 115; os "2 pendentes deliberados" do round anterior contam
dentro do total e foram decididos abaixo, não ficam mais keep-pending.)

## 2. Cluster table

| Cluster | N | Decisão dominante |
|---|---|---|
| A. Steering/continuação de loop colado como ask | 33 | discard (instrução, não feature) |
| B. Diretrizes de modelo/custo/design codificadas | 10 | discard (done) — codificado em model-routing.json / SPEC-152 / D028 |
| C. Bugs GUI legado (jobs órfãos, anexo de screenshot) | 2 | 1 backlog · 1 discard (componente superado) |
| E. UX página de experimentos (paper IEEE) | 6 | discard (done) — 4f36439/28c73cb/289455a |
| G. Pings automáticos gov:flake-reopen / scenario-hot / gate-degraded | 6 | discard (artefato de tracker; 1 já done via SPEC-158/159/160) |
| H. Loop do artigo / research rounds / EXPs | 19 | discard (done) — rounds e planos já shipped |
| J. Meta de backlog/arquitetura/hooks | 8 | 6 discard (done) · 1 backlog · 1 keep→resolved(done) |
| K. Q&A puro respondido inline | 28 | discard |
| L. Smoke tests EXP-19 | 2 | discard (execution packet) |
| M. Naming (Tare) | 3 | discard (done) |
| N. OpenAI-compat taxonomia | 6 | discard (coberto por 5fa854d6e56d → spec) |

## 3. Ledger por entrada (115/115)

11d53f79b03e | C | **backlog** | `ui/src/domains/operations/QueueTab.tsx:16-36` — colunas 100% leitura, zero ação cancel/remove | jobs órfãos: capacidade de remoção realmente ausente na GUI nova
c1eb5b0da00c | C | discard | grep `image\|screenshot\|attachment` em `ui/src` = 0 hits; GUI legada (c709ec5) substituída pelo rewrite React (181cc38, b374081 "not a chat app") | componente com o bug não existe mais
e3bb6706717a | A | discard | steering de loop, executado nos 114 commits 7/18→7/21 | instrução, não ask
4ad512276c04 | K | discard | Q&A respondida inline na sessão
1003607a1556 | A | discard | steering ("bora implementar"), executado
efac4eecb022 | A | discard | refinamento de política de fan-out, inline
08e90016a038 | L | discard | pacote de execução (EXP-19 smoke test)
2fdd5659b036 | L | discard | pacote de execução (EXP-19 smoke v2)
9d5f94b0b687 | H | discard (done) | `docs/EXPERIMENT_METHODS.md` + `.harness/handoff/plan-l18-methods-library.md` | livraria de métodos já existe
ec0162f060b4 | H | discard (done) | mesmo cite acima
4b9124ebe416 | A | discard | steering, executado via backlog derivado do artigo
99c9fa77d924 | H | discard (done) | `docs/research/article-coverage-backlog.md` existe
e42eb7be898d | K | discard | Q&A inline
810e556717ac | A | discard | steering; múltiplos commits `research(...)` 7/18→7/21 confirmam execução sequencial nvidia
aacdd6c8f1e6 | A | discard | steering
624f7384084f | A | discard | steering
2ce880667e66 | K | discard | Q&A inline
aac78d4eef41 | A | discard | steering; priorização executada (a40f7f0 P1 deps-as-tags + Kahn topo)
dad29fc49b83 | A | discard | duplicata textual de aac78d4eef41
14992e4e1d35 | K | discard | Q&A inline
584fb0ea397b | G | discard | artefato de tracker gov:flake-reopen (precedente cluster G, round 2026-07-18)
377532570748 | G | discard | idem
e48c9000ace5 | A | discard | mensagem de erro de shell colada, não é ask de feature
a260418643b1 | H | discard (done) | 4 sub-itens shipped: WB4 approval card (7a13e21), N-TRUTHRECON (d96c1a1/6dd9472), E-3LANE race (0129a35), vendor-credit log (`docs/research/vendor-credit-tracking-log.md`)
9223637d4758 | H | discard (done) | corrida #4 done (0129a35); ideia /usage worker → vendor-credit-tracking-log.md
82142270705d | A | discard | steering de sequenciamento de research, executado
9233ce35abc2 | H | discard (done) | `docs/GUI_IMPLEMENTATION_PLAN.md` + série gui-f0..sh6 shipped
57ade99944a2 | A | discard | steering (loop opus+sonnet), executado
04f839ab0cc2 | G | discard (done) | SPEC-160 parallel scenarios (84b8d83) endereça latência de cenário quente
fc300581a1e9 | B | discard | política de detalhamento de plano pré-existente (planner/implementer split)
5bbdf3ce20bd | B | discard (done) | SIGNAL re-theme (f48b3df) já derruba "Inter+purple slop", D028 anti-slop
fa5f6cf792f2 | M | discard (done) | `docs/research/naming-round.md` — ideação NVIDIA+Sonnet convergida
c57d4eb308ad | M | discard (done) | naming-round.md registra checagem de disponibilidade
322e1a11baa6 | M | discard (done) | naming-round.md:68 Tare = candidato #1
e959873947be | B | discard (done) | 539f81f "SIGNAL rulebook = the UI law (D028)"
2bddbd8362b0 | H | discard (done) | c2f6097 research(compaction) round shipped
3bd8d40b4c86 | A | discard | steering; planos shipped (f1f3703 compaction plans)
8157aeab4c81 | H | discard (done) | bc09160 research(ptc) round shipped
eba20e22d13a | A | discard | steering; planos shipped (a21b2f3, e45fdef, 2370a34)
b23c08aa81fc | K | discard | Q&A inline
65ee7a252bff | A | discard | steering; planos RD-TAINT shipped (e45fdef)
85c6c21ff09e | B | discard (done) | c085ec1 SPEC-152 design-system-guard = hook amarrado aos workers
f16a959c2d86 | A | discard (done) | mesmo cite (SPEC-152 hook+gate entregues)
93300b515124 | K | discard | Q&A inline
f3f858715230 | K | discard | Q&A/steering inline
bd7bedd5cdff | J | **backlog** | grep vazio por "profile-\"plan\"" em CLAUDE.md/AGENTS.md/`.harness/prompts/*.md`; SPEC-153 spawn-economy-guard é adjacente mas não cobre este caso exato | footgun executor de wf profile-plan sem guard dedicado ainda
2af209cd2cd9 | K | discard | Q&A inline
f89d1ca01522 | K | discard | nota de preferência, não ask
180132204c4b | K | discard | Q&A de status
824d30a119a1 | A | discard | steering ("plano detalhado por retorno"), virou prática padrão (planos `plan-*.md` em toda rodada)
1b3b3877a86e | A | discard (done) | groom periódico já amarrado em `overseer-loop-playbook.md:265-268`
bdaf4b017759 | H | discard (done) | `docs/research/reckon-efficiency-round.md` (c491eb7) — paralelo + não-overlap
d232a7b9ba4e | G | discard (done) | SPEC-158/159 gate-perf observability+cache (8fa3570, 8b52920)
1ea00700ed85 | K | discard | Q&A ("travou?")
df9e2e99635d | J | discard (done) | SPEC-154 backlog-closure-guard (5486d3e) amarra commits ao fechamento de linha
61f81aa313de | K | discard | Q&A inline
48124e44b57c | A | discard | steering de priorização, executado
f084e67d9bef | K | discard | Q&A inline
8be52253dc99 | A | discard | steering
960d85703c9d | K | discard | pedido de auditoria respondido inline
f9b962c27918 | A | discard | steering
6d55def21ec6 | A | discard | steering
547614458cfc | K | discard | Q&A inline
a9a6cece16c4 | K | discard | Q&A inline
40dff4b33c03 | K | discard | Q&A inline
2895c0394215 | B | discard (done) | D038 lane-brief economy (6de64a9) — hook de reminder de spawn-site
85d8e2e3cfca | B | discard | nota de política, já seguida (planos detalhados pro implementador de UI nos rounds subsequentes)
ab4b56f75334 | B | discard (done) | SIGNAL re-theme (f48b3df) já anti-slop
1d812a0b9aa4 | K | discard | Q&A inline
4f22ce61eaf7 | K | discard (done) | backlog `playwright-headless-smoke` ✅ linha 41 — smoke sobe browser headless via Playwright, não abre navegador do owner
877f25df1a49 | A | discard | ack positivo, não é ask
8b7a3483a280 | K | discard | Q&A inline
75738729bae0 | A | discard | steering (flip SPEC-160), executado (commit 52298b4 citado no próprio b9fa04a7288b)
b9fa04a7288b | A | discard | dump de estado de loop
82db84a06fd5 | K | discard | Q&A inline
ee2c554837e0 | J | discard (done) | linha `process-anchoring-batch` do backlog (docs/IMPLEMENTATION_BACKLOG.md:59) enumera os 4 hooks/gates entregues
429759e6ed51 | J | discard (done) | mesma linha — verbo `gate-divergence` + passo de wind-down entregues
6cd84ccbed7b | K | discard | Q&A inline
24e24837ab78 | K | discard | nota de escopo de segurança, decisão do owner registrada
cc67e78e46d1 | K | discard | Q&A respondida em `ac8de72` docs(security) — modelo de ameaça explica por que não container/VM
da765b4bcc4d | A | discard | dump de estado de loop
ba731a61c52b | K | discard | nota de política (paridade multi-OS), refletida em D044 (linha resource-cap-posix-parity)
30a6f2435807 | A | discard | dump de estado de loop
39b84a5f1d3c | H | discard (done) | `docs/research/event-log-integrity-under-compaction.md` (8ec7625, 2026-07-21 13:14) cobre blockchain/Merkle/OTS para o mesmo problema
5c024dadf6db | K | discard | Q&A inline
9e7761436ee6 | A | discard | steering (parâmetros do 2º double-diamond)
e7ba30fbec44 | K | discard | Q&A inline
28e7214fe533 | K | discard (done) | `.harness/routing/model-routing.json:7-11` role overseer = fable/xhigh primary, sem opus
0c3d8fff6c71 | B | discard (done) | `model-routing.json:7-19` fallback do overseer = gpt-5.6-sol apenas, opus já não está lá
998cea541b2a | K | discard | Q&A/steering inline
045e814238e2 | A | discard | steering; double-diamond executado (w29 round)
fe533e4acf8a | K | discard (done) | mesmo doc event-log-integrity-under-compaction.md endereça perda de chave/ancoragem
7bacd7849e28 | J | discard (done) | D048 registrado no mesmo doc: "adopt before first public release"
1486491d41d4 | A | discard | steering
f6f1c1c17a9d | G | discard | artefato de tracker; `pw_ui_smoke` shipped no mesmo dia (backlog linhas 41-42)
50c659d874fe | E | discard (done) | página de experimentos IEEE-paper shipped (4f36439/28c73cb/289455a)
8a83c826e566 | E | discard | steering (loop de prints), superado pela feature já shipped
57db152b592f | E | discard (done) | 4f36439 IEEE-format + KaTeX
f73c8bd5b59a | E | discard (done) | `ui/src/domains/experiments/experiments.css:103-107` fix single-column citado inline como "owner review 2026-07-21"
d46f240a35c9 | E | discard (done) | 4f36439 "ratified structured metrics[] result schema"
2cc43f5e555e | E | discard (done) | `experiments.css:82-107` A4/single-column, mesmo cite "owner review 2026-07-21"
1ad55973bc91 | A | discard | ack, não é ask
9cf8cddc2106 | K | discard | Q&A inline
21e1a2a3f897 | H | discard (done) | `docs/research/w29-evidence-gated-assurance-round.md` + commits 3468f74/390d43d
cee6605aafba | H | discard (done) | mesmo round, redirecionado corretamente e shipped
00e92bfc98c6 | A | discard | steering (loop front-end), executado (7a90f20, 7a13e21)
16e130b48bdb | A | discard | dump de estado de loop
4349d862aa70 | N | discard | coberto por `5fa854d6e56d` → spec, one-pager `specs/40-features/compat-executor-routing.intake.md`
61648cd16aa1 | N | discard | idem
c67d603f0851 | N | discard | idem
f21eb8264b94 | N | discard | idem
4a1d1cd7ff40 | N | discard | idem
fdf274d919e1 | N | discard | idem
89f1dca1d5c1 | J | discard (done) | esta própria rodada + `overseer-loop-playbook.md:265-268`
c18b88939222 | J | discard (done) | idem — pedido literal desta task, respondido pela wiring já existente

## 4. Ranked top-10 promotions

Apenas 2 promoções nesta janela (a maioria do backlog real da semana já foi
absorvida por commits shipped ou pela spec `compat-executor-routing`):

1. **11d53f79b03e — backlog.** Jobs de workers agendados sem ação de
   remoção na GUI. Verificado ao vivo nesta rodada:
   `ui/src/domains/operations/QueueTab.tsx:16-36` só tem colunas de leitura
   (status/id/priority-dash/queued-dash/ttl-dash/group-dash/blocked-dash),
   nenhum cancel/remove renderizado em nenhum lugar do domínio `operations`.
   Resolve o pendente deliberado do round 2026-07-18 (era keep-pending; agora
   confirmado real e não fixado).
2. **bd7bedd5cdff — backlog.** Footgun: workflow run de perfil `"plan"` sem
   `--executor` cai no Fable xhigh (confirmado em
   `.harness/routing/model-routing.json:87-92`, role `plan` primary =
   fable/xhigh/claude). SPEC-153 (spawn-economy-guard) bloqueia spawns
   frontier-para-trabalho-simples mas não este caso específico de profile
   sem override; sem hook/gate dedicado ainda.

## 5. Errata honesta

- `c1eb5b0da00c` (screenshot) resolve o segundo pendente deliberado do round
  anterior, mas por via indireta: o componente de chat legado com o bug foi
  substituído pelo Workbench React (nenhum renderer de imagem/anexo existe
  hoje em `ui/src`). Isso é evidência de "bug moot" (componente sumiu), não
  de "bug corrigido" — se o owner ainda quer anexos de imagem no Workbench
  novo, é um ask NOVO, fora do escopo desta entrada.
- Vários itens do cluster K ("Q&A inline") não têm sha de resposta
  recuperável nesta sessão — a evidência é indireta (a pergunta some do
  contexto da conversa, não do repo). Marcados discard por padrão do round
  anterior (Q&A respondido = não persiste como ask), não por leitura de log
  de conversa que não tenho acesso.
- `39b84a5f1d3c` / `fe533e4acf8a` / `7bacd7849e28`: a correspondência com
  `event-log-integrity-under-compaction.md` é forte por timestamp (mesma
  janela, 7/21 13:09-13:14) e conteúdo (chave/blockchain/Merkle/adoção
  futura), mas não vi o texto integral da conversa que gerou o doc — marco
  "inferred" a correspondência exata pergunta→resposta, embora o conteúdo do
  doc bata linha a linha com as 3 perguntas.
- Não toquei `.harness/state/intake-queue.json` (somente leitura), nem
  `specs/`, `testing/`, arquivos protegidos.
