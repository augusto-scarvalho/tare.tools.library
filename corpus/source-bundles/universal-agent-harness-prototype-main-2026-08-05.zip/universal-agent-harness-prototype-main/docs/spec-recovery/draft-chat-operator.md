**DRAFT — NON-CANONICAL.** Recovered spec material for the chat operator (CLI +
GUI chat surface). Does not resolve to real checks yet. See `INDEX.md` for the
full gap matrix. Scenario/Gherkin ids use the fresh `rec-chat-` prefix.

# Recovered spec — chat operator gaps

Source scan: `scripts/harness_lib/chat_operator.py`, `chat_hud.py`,
`chat_engines.py`, `ui_chat_bridge.py`, cross-referenced against
`specs/40-features/chat-overlays.md`, `panel-chat-qol.md`,
`supervision-m5-interactive-panel.md`, and `testing/scenarios/cp_plan_hud.py`,
`ct_tool_chips.py`, `qol_panel_chat.py`.

## Goal

Recover the engine-contract acceptance rules (claude/codex/openai-compatible)
and the plan-HUD/approval-event rules that shipped but are only exercised at
the pure-function level (`gate_for`, `format_plan_rows`) rather than through
the actual stateful engine or REPL path — so a future engine change breaks
silently instead of failing a scenario.

## Applicability

`scripts/harness_lib/chat_engines.py` (all three engine classes' argv/gate
construction), `chat_operator.py` (REPL command handling, subject scoping,
hint suppression), `chat_hud.py` (`Hud.set_plan` stateful transitions),
`ui_chat_bridge.py` (replay cursor, session dimension). Does not cover the
plan/question event schema itself (already spec'd in `panel-chat-qol.md`
reqs 10-11) — only the engine-specific and REPL-stateful behaviors layered
on top of it.

## Requirements / invariants (numbered, testable — recovered)

1. **Codex sandbox mode mapping.** `chat_mode == "plan"` maps to Codex
   `--sandbox read-only`; `accept-edits`/`auto` map to `workspace-write`.
   Fresh `exec` passes `-s <mode>`; `resume` passes
   `-c sandbox_mode=<mode>` instead (different flag shape). Source:
   `chat_engines.py:300-324` (commit `2415ce7`).
2. **Codex effort flag.** Reasoning effort is passed as
   `-c model_reasoning_effort=<effort>`, never a `--effort` flag, on both
   fresh exec and resume. Source: `chat_engines.py:319-322`.
3. **Codex thread continuity.** The engine captures `thread_id` from the
   `thread.started` event and reuses it explicitly on the next turn, rather
   than depending on `codex resume --last` (which races against a parallel
   human `codex` session). A `thread.error` item is surfaced inline, never
   swallowed. Source: `chat_engines.py:357-379`.
4. **Claude explicit permission-mode.** The claude engine's `_argv` always
   passes an explicit `--permission-mode` (`plan`/`acceptEdits`/`default` for
   auto); `EnterPlanMode`/`ExitPlanMode` are in `disallowedTools` because a
   headless session cannot approve its own plan exit. Source:
   `chat_engines.py:152-163`; the disallow was added after a real incident
   (2026-07-10, referenced in the rationale of `panel-chat-qol.md`).
5. **accept-edits pre-approves harness mutations.** In `accept-edits` mode,
   the claude engine appends `Bash(...harness.py *)` to `allowedTools` — the
   PreToolUse hook remains the backstop, this is a pre-approval. Source:
   `chat_engines.py:174-177` (SPEC-111 R23).
6. **OpenAI-compatible agent-facing gate ladder.** For a proposed tool call:
   `human-only` mode → blocked message; `plan` mode → "propose instead of
   running" message; `confirm` mode → interactive y/N prompt, declines on
   anything but y; `accept-edits` → runs with an `[auto-approved]` echo.
   Source: `chat_engines.py:436-464` (SPEC-111 R23 ladder).
7. **OpenAI-only injection guard.** `triage_packet` is prepended to the
   prompt ONLY for the openai-compatible engine; claude and codex receive the
   same content via the UserPromptSubmit hook instead — prepending it twice
   would double-inject. Source: `chat_operator.py:751-755` (comment cites
   SPEC-117 invariant 4).
8. **Scoped bare `!escalations`.** Inside a `/repo`-scoped chat session, a
   bare `!escalations` command auto-appends `--target <subject>` unless the
   user explicitly passed `--target`; the startup nag for pending escalations
   also counts only the session's subject. Source:
   `chat_operator.py:294-310,725-727`.
9. **Finished-plan flush.** When a TodoWrite plan reaches all-completed, the
   HUD flushes it once as a checklist into scrollback and stops rendering the
   live HUD rows. Source: `chat_hud.py:333-345` (commit `2415ce7`).
10. **Non-HUD plan output is transition-only.** In a plain terminal (HUD not
    active, not the panel bridge), only step-transition lines print — never
    the full rewritten plan list. Source: `chat_operator.py:490-500`.
11. **Target-switch re-resolve gate.** Switching the active target rebuilds
    the chat engine only if routing actually changed AND the model/effort
    were not pinned by a flag or the session; a "FRESH vendor session, no
    memory" note is emitted when it rebuilds. Source:
    `chat_operator.py:327-336,604-625` (SPEC-114 R37).
12. **Cost ledger session dimension.** `HARNESS_CHAT_SESSION` env sets an
    additive `session` field on cost-turn records; the panel bridge sets one
    per session. Source: `ui_chat_bridge.py:100-101` (SPEC-133 ceiling note).
13. **Bridge lossless replay.** The chat bridge delivers history via a
    cursor; a stale cursor (`> total`) resets to a full replay instead of an
    empty/error response; the window caps at 400 items. Source:
    `ui_chat_bridge.py:49-82,144-156` (SPEC-114 v11 R24).
14. **Paste-mode hint suppression under the panel.** stderr hints for
    multi-line paste framing are suppressed when `HARNESS_CHAT_EVENTS=1`
    (i.e., running under the panel bridge, not a human terminal). Source:
    `chat_operator.py:104-127` (commit `9c50dbf`).
15. **Claude per-turn cost delta.** `total_cost_usd` from the claude CLI is
    cumulative across a `--resume` session; the engine reports a per-turn
    delta and falls back to the raw cumulative value if the delta goes
    negative (a resume edge case). Source: `chat_engines.py:243-248`.
16. **Claude turn watchdog.** A `TURN_TIMEOUT` env value kills the claude
    subprocess if a turn overruns; stderr is drained on a separate thread to
    avoid a pipe deadlock. Codex/openai engines return a timeout message
    instead of killing. Source: `chat_engines.py:203-227,338-339,432`.
17. **`plan-steps` and `plan` are distinct events.** The TodoWrite-driven HUD
    frame (`plan-steps`) is a different event from the SPEC-133 approval
    frame (`plan`); both can be emitted in the same turn. Source:
    `chat_operator.py:486` vs `771-772`.
18. **Emoji fallback.** Tool-chip icons and HUD glyphs degrade to
    `[tool]`/ASCII text when the console encoding rejects the emoji byte
    sequence (encode-probe at startup). Source: `chat_operator.py:348-352`,
    `chat_hud.py:41-49`.

## Gherkin scenarios

```gherkin
Feature: chat operator recovered acceptance rules (DRAFT, non-canonical)

  Scenario: [rec-chat-1] codex sandbox mode follows chat_mode
    Given chat_mode is "plan", "accept-edits", and "auto" in turn
    When CodexEngine builds its argv for a fresh exec and for a resume
    Then plan maps to read-only and the others to workspace-write, via -s on exec and -c sandbox_mode= on resume

  Scenario: [rec-chat-2] codex effort uses the -c flag form
    Given a routed effort value
    When CodexEngine builds argv
    Then it passes "-c model_reasoning_effort=<effort>" and never "--effort"

  Scenario: [rec-chat-3] codex thread continuity uses the captured thread_id
    Given a codex session that received a thread.started event
    When the next turn is sent
    Then it resumes that explicit thread_id rather than "resume --last"

  Scenario: [rec-chat-4] claude engine always passes an explicit permission-mode
    Given chat_mode plan, accept-edits, and auto
    When ClaudeEngine builds argv
    Then --permission-mode is present and EnterPlanMode/ExitPlanMode are in disallowedTools

  Scenario: [rec-chat-5] accept-edits pre-approves harness mutations
    Given chat_mode accept-edits
    When ClaudeEngine builds allowedTools
    Then "Bash(...harness.py *)" is present in the list

  Scenario: [rec-chat-6] openai engine gate ladder blocks, proposes, confirms, or auto-approves per mode
    Given a proposed tool call under each of human-only/plan/confirm/accept-edits
    When OpenAIEngine._run_tool_call handles it
    Then the outcome matches the mode's rule (blocked/proposed/y-N-gated/auto-approved)

  Scenario: [rec-chat-7] triage_packet is injected only for the openai engine
    Given the same turn sent to claude, codex, and openai engines
    When the outbound prompt is inspected
    Then only the openai prompt carries the prepended triage_packet

  Scenario: [rec-chat-8] scoped bare !escalations appends the session target
    Given a /repo-scoped chat session with no explicit --target
    When "!escalations" is run bare
    Then the resolved command includes --target <subject>

  Scenario: [rec-chat-9] a finished plan flushes once and clears the HUD
    Given a TodoWrite plan reaching all-completed
    When the HUD processes the final update
    Then a checklist is appended to scrollback exactly once and live HUD rows stop rendering

  Scenario: [rec-chat-12] session dimension appears on cost-turn records
    Given HARNESS_CHAT_SESSION set for a chat process
    When a turn is recorded
    Then the cost-turn record carries a session field matching the env value

  Scenario: [rec-chat-13] a stale bridge cursor triggers a full replay
    Given a chat bridge with N buffered items and a client cursor > N
    When the client polls with that cursor
    Then the response is a full replay, not an empty or error response

  Scenario: [rec-chat-18] emoji fallback degrades tool chips to ASCII
    Given a console whose encoding cannot represent the tool-chip emoji
    When a tool-call line is formatted
    Then it renders as "[tool]" or an ASCII equivalent instead of raising or mojibake
```

## Rationale & sources

| Rule cluster | Sources |
|---|---|
| Codex engine contract (1-3) | `chat_engines.py:300-379`; commit `2415ce7` "chat-plan-hud" description mentions Codex differences only in passing |
| Claude engine contract (4-5) | `chat_engines.py:152-177`; SPEC-111 R23; `panel-chat-qol.md` rationale row on plan/approval being derived because "`Enter/ExitPlanMode` disallowed" |
| OpenAI gate ladder (6-7) | `chat_engines.py:436-464`; `chat_operator.py:751-755` (SPEC-117 invariant 4 comment) |
| REPL scoping/hints (8,10,14) | `chat_operator.py:104-127,294-310,490-500,725-727` |
| Plan HUD stateful paths (9,17) | `chat_hud.py:333-345`; `chat_operator.py:486,771-772`; commit `2415ce7` |
| Bridge/session mechanics (11-13,15-16) | `chat_operator.py:327-336,604-625`; `ui_chat_bridge.py:49-101,144-156`; `chat_engines.py:203-248,338-339,432` |
| Emoji fallback (18) | `chat_operator.py:348-352`; `chat_hud.py:41-49` |

## Test strategy

- Behaviors to verify: argv/flag shape per engine per mode (1,2,4,5); explicit
  thread continuity (3); the full agent-facing gate ladder driven through the
  actual engine call path, not just `gate_for` (6); prompt-injection
  exclusivity across engines (7); REPL-level target scoping (8); the stateful
  `Hud` object's flush behavior (9); bridge cursor edge cases (13); console
  encode-probe fallback (18).
- Edge cases: codex resume vs fresh-exec flag shape differs (1); negative
  cost delta on `--resume` (15); stale cursor > total items (13).
- Regression risks: none of these are new behavior — all are already shipped;
  adding scenarios only prevents silent regression on the next chat_engines.py
  edit. `codex-stream-parity` (backlog, M/P2) will change engine internals for
  Codex and should re-run whichever scenario lands from rec-chat-1/2/3.
- Coverage impact: currently zero scenario drives an actual `CodexEngine` or
  `OpenAIEngine` instance through a live tool-call/gate decision; all
  visibility is at the pure-function (`gate_for`) or telemetry-mapping level.

## Validation

Not yet built. Consolidation path: extend `testing/scenarios/cp_plan_hud.py`
and `ct_tool_chips.py` with the Hud/bridge cases, and add a new
`testing/scenarios/ce_chat_engines.py` (or similar) driving each engine class
directly against a local HTTP/stdio stub — deterministic, no live LLM calls,
matching the existing `qol_panel_chat.py` pattern (real subprocess, stubbed
model backend).

## Amendments

(none — this is the initial recovery draft)
