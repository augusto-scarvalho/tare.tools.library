**DRAFT — NON-CANONICAL.** Recovered spec material for the supervision GUI panel.
Does not resolve to real checks yet. See `INDEX.md` for the full gap matrix and
priority ranking. Scenario/Gherkin ids below use the fresh `rec-gui-` prefix so
they never collide with a real spec's ids.

# Recovered spec — GUI supervision panel gaps

Source scan: `scripts/harness_ui.py`, `harness_ui_page.py`, `harness_lib/ui_actions.py`,
`ui_panel.py`, `ui_memory.py`, `ui_commits.py`, `ui_queue.py`, `ui_chat_bridge.py`,
`ui_composer.py`, cross-referenced against `specs/40-features/supervision-m5-interactive-panel.md`,
`panel-chat-qol.md`, `panel-memory-snapshot.md`, `panel-records-changelogs.md`,
`panel-work-queue.md`, `escalation-subject-scope.md`, and
`testing/scenarios/m5_ui_panel.py`, `qol_panel_chat.py`, `mem_snapshot_panel.py`,
`rec_changelog_panel.py`, `wq_queue_view.py`, `en_default_guard.py`.

## Goal

Recover the acceptance rules that shipped in the panel's action allowlist,
worker drill-in, discard/rerun flows, and EN-default strings but exist only in
source comments, commit messages, or as self-checks — never as a spec
invariant or a regression scenario check — so a future edit to these files
doesn't silently reintroduce a fixed bug (e.g. the drawer secret leak) or drift
further from the spec's own prose (e.g. the stale PT string).

## Applicability

`scripts/harness_lib/ui_actions.py` (action allowlist, gate rerun, discard
refusal), `ui_panel.py` (`worker_detail` drill-in drawer), and the front-end
render contract in `harness_ui_page.py` (branch chip, gitInfo). Does not cover
Memory/Commits/Queue views, which are already correctly spec'd and tested (see
INDEX.md "no gap" rows).

## Requirements / invariants (numbered, testable — recovered)

1. **Worker-drawer redaction.** `worker_detail`'s returned stdout/stderr tail
   MUST be passed through `secret_scan.redact_text` before reaching the
   `/api/worker` response, matching the redaction guarantee already given to
   Memory (`ui_memory.py:80`) and Commits (`ui_commits.py:45`). Source:
   `ui_actions.py:469-483` shows no redact call today. `inferred` — this is
   the missing counterpart to an existing pattern, not a rule stated anywhere.
2. **Gate rerun allowlist is closed.** `run_action`'s gate-rerun path only
   accepts `{smoke, spec-pack, scenarios}`; any other gate name is refused.
   Source: `ui_actions.py:32`, enforced at `ui_actions.py:232-235`.
3. **Discard-refusal string is EN, not the spec's PT text.** The shipped
   refusal message is `"workflow running — cancel it before discarding"`
   (tagged `# EN string (SPEC-122)` in a self-check at `ui_panel.py:742`).
   Source: `ui_actions.py:142`.
4. **Discard liveness check is PID-only.** `_wf_running` treats a workflow as
   "running" solely by OS PID liveness; a crashed run whose PID number was
   recycled by the OS will false-refuse a discard from the panel. The only
   escape hatch today is the CLI (`workflow scrub --force`). Source:
   `ui_actions.py:117-129` (ponytail ceiling comment marks this explicitly).
5. **Every panel action is bounded.** A `run_action` invocation times out at
   900s (surfacing as rc124) and caps captured output at 8000 chars. Source:
   `ui_actions.py:30-31,283-288`.
6. **Escalation resolve always forwards subject.** (Already spec'd and
   tested — `escalation-subject-scope.md` v2, `ehv_scoped_hitl.py` ehv-3.
   Listed here only as a paired contrast to rule 1: this view got the
   redaction/scoping discipline the worker drawer did not.)

## Gherkin scenarios

```gherkin
Feature: GUI panel recovered acceptance rules (DRAFT, non-canonical)

  Scenario: [rec-gui-1] worker drawer redacts secrets in stdout/stderr
    Given a worker run whose stdout contains a planted API-key-shaped string
    When the panel's worker drill-in drawer renders that worker's tail output
    Then the planted secret does not appear verbatim in the response

  Scenario: [rec-gui-2] gate rerun rejects an unlisted gate name
    Given the panel's run-action endpoint
    When a gate rerun is requested for a gate not in {smoke, spec-pack, scenarios}
    Then the action is refused with a "gate not allowed" message

  Scenario: [rec-gui-3] discard-refusal string matches the shipped EN text
    Given a running workflow
    When a discard is attempted from the panel
    Then the refusal message reads "workflow running — cancel it before discarding"

  Scenario: [rec-gui-4] a recycled PID does not still block discard forever
    Given a workflow whose lock file's PID has been reused by an unrelated process
    When a discard is attempted from the panel
    Then the panel does not indefinitely refuse the discard as "running"
    # ceiling: today this scenario would FAIL — recorded as a known gap, not a passing check

  Scenario: [rec-gui-5] a long-running action is capped
    Given an allowlisted action whose underlying command would run past 900s or emit past 8000 chars
    When the panel executes it
    Then it is terminated with rc124 past the timeout, or its captured output is capped at 8000 chars
```

## Rationale & sources

| Rule | Source |
|---|---|
| Worker drawer has no redaction call | `scripts/harness_lib/ui_actions.py:469-483`; contrast `ui_memory.py:80`, `ui_commits.py:45` |
| Gate rerun allowlist | `scripts/harness_lib/ui_actions.py:32,232-235` |
| Discard-refusal EN string vs spec's stale PT text | `scripts/harness_lib/ui_actions.py:142`; `specs/40-features/supervision-m5-interactive-panel.md` line 808 (still shows the old PT string) |
| PID-liveness-only discard check | `scripts/harness_lib/ui_actions.py:117-129` (ponytail comment names the ceiling) |
| Action timeout/output cap | `scripts/harness_lib/ui_actions.py:30-31,283-288` |
| SPEC-122 EN-default guard has no feature-spec file | commit `dc71cdd`-era work + `testing/scenarios/en_default_guard.py`; no `specs/40-features/en-default-guard.md` exists |

## Test strategy

- Behaviors to verify: redaction on the worker drawer (plant-a-secret test,
  mirroring the pattern Memory/Commits already use); gate-rerun allowlist
  refusal; discard-refusal string content; action timeout/cap constants.
- Edge cases: recycled PID (rec-gui-4) is a genuine unresolved ceiling, not a
  test gap — record it as a known limitation if fixing is out of scope for
  the immediate spec amendment.
- Regression risk: fixing rule 1 (redaction) must not change the drawer's
  byte-shape for non-secret output — reuse `secret_scan.redact_text`, the same
  function Memory/Commits already call, so behavior stays consistent across
  views.
- Coverage impact: none of rec-gui-1 through rec-gui-5 exist as checks today.

## Validation

Not yet built. Once consolidated into a real spec, the acceptance path is:
add the above checks to `testing/scenarios/m5_ui_panel.py`, then
`python testing/scenarios/m5_ui_panel.py` green + `spec-pack` conformance for
the amended spec.

## Amendments

(none — this is the initial recovery draft)
