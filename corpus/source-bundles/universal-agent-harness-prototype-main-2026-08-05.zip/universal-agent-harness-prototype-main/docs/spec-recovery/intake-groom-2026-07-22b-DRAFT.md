> DRAFT -- NON-CANONICAL -- miner output pending overseer audit

# Intake groom -- fila de intake, 2026-07-22 (rodada B)

Rodada queue-slice, wind-down do overseer-loop (playbook
`.harness/prompts/backlog-groom-playbook.md`, variante queue-slice). Miner
Sonnet 5 medium, report-only. Segunda rodada do dia -- a primeira
(`docs/spec-recovery/intake-groom-2026-07-22-DRAFT.md` / registro
`docs/research/backlog-groom-2026-07-22.md`) fechou 16 pendentes as
~06:00 (loop-6h); esta rodada cobre o exaustao de sessao gerada depois
disso. Taxonomia de clusters reusada de `docs/research/backlog-groom-2026-07-22.md`
(cluster A: steering/heartbeat/Q&A inline) + um cluster novo (D: decisao
pontual de experimento).

Nota de acesso: `.harness/state/intake-queue.json` nao existe na raiz no
momento desta leitura -- ha um gate-hold em curso (`.harness/runs/gate-hold/20260722T132454Z-20064/hold.json`).
Li a copia live da fila dentro do snapshot do hold
(`.harness/runs/gate-hold/20260722T132454Z-20064/e0/intake-queue.json`),
somente leitura, sem escrever em `.harness/`.

## Totais

- Pending (fila live sob o gate-hold em curso): **7**
- Proposto:
  - discard: 4
  - discard (done): 3
  - backlog: 0
  - spec: 0
  - keep-pending: 0

## Cluster table

| Cluster | N | Decisao dominante |
|---|---|---|
| A. Steering/heartbeat/Q&A inline | 4 | discard (sem ask persistente) |
| B. Steering executado (sha real) | 2 | discard (done) |
| D. Decisao pontual de experimento (EXP-29) | 1 | discard (done) |

## Ledger por entrada (7/7)

6946e0458d62 | D | discard (done) | pergunta 06:16 "shelve EXP-29 ou re-arma acumulando 20 runs?" -- resolvida como re-armar: `docs/IMPLEMENTATION_BACKLOG.md` linha m5-serial-order-flake ("Era o falseSkip unico do EXP-29 ... flip re-arma acumulando 20 runs estaveis"); implementado em 31222b2 `feat(SPEC-159/phase2): enforced cache-skips LIVE` e ae3e89a `feat(flakes): rt6 skip-guard keyed to the staged index + hunt ledger closed` | pergunta de decisao respondida e executada na mesma janela

e4608438d2ef | A | discard | fragmento de instrucao 06:26 ("1 explica duracao / 2 corrija / 3 P2"), sem feature isolavel -- nao consigo apontar um sha unico para os tres itens sem inferir de mais | instrucao terse, nao ask de feature nova

5d5ce096b788 | A | discard | pergunta 08:29 "computador ficou lento com o flakehunter, como funciona?" -- Q&A tecnica, sem artefato a produzir | pergunta respondida inline, nao ask

27c825380cad | B | discard (done) | steering 08:32 "bora agendar pra ele [flakehunter] rodar durante os loops afk" -- 36d6d00 `docs(process): load-heavy lanes are AFK work (owner 2026-07-22)`, commitado 08:32:45, minutos depois do ask | pedido de agendamento cumprido no mesmo minuto pelo proprio loop

0a0cffaadb2e | A | discard | pergunta 08:55 "temos tarefas boas para pegar de front end?" -- Q&A de priorizacao, sem ask isolavel | pergunta respondida inline (levou ao pacote de GUI que segue)

a362d4df30b0 | B | discard (done) | steering 08:56 "sua sugestao de pacote esta boa, manda ver" -- pacote de GUI executado em 59baf77 `feat(gui/phase5): research screen complete` (09:51) e b5519da `feat(gui/graphs): graphs screen ... (package close)` (10:18), ambos apos o ask | aprovacao de pacote, cumprida na mesma janela

48f9912ad45c | A | discard | pergunta 10:02 "vao ficar telas faltando depois disso? UI legado ja pode ser substituida por completo?" -- Q&A de escopo restante do pacote de GUI em andamento | pergunta respondida inline, nao ask de feature nova

## Top promotions

Nenhuma. Os 7 pendentes sao exaustao de sessao (steering, heartbeat,
Q&A respondida inline e uma decisao pontual de experimento) -- nenhum ask
de feature nova sobreviveu a janela.

## Errata honesta

- `e4608438d2ef`: os tres itens numerados ("explica duracao", "corrija",
  "P2") nao foram individualmente rastreados a um sha -- decisao por
  classificacao de forma (fragmento de instrucao terse), nao por
  verificacao item-a-item. Se o owner quer confirmacao de que os tres
  foram atendidos, e um ask novo.
- `27c825380cad` e `a362d4df30b0`: marcados done por correlacao temporal
  forte (commit minutos/horas depois, contexto compativel) -- nao abri o
  diff de 36d6d00/59baf77/b5519da linha a linha para confirmar que cobrem
  o pedido por completo, so o titulo/escopo do commit.
- Nao toquei `.harness/state/intake-queue.json` nem a copia sob
  `.harness/runs/gate-hold/` (somente leitura), nem `specs/`, `testing/`,
  arquivos protegidos. Nenhuma operacao de git executada.
