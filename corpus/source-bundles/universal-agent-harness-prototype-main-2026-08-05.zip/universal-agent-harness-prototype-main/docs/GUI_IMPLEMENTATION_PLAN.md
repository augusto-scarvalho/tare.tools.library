# GUI Implementation Plan — o painel do harness como "operating system for agentic engineering"

> Plano de implementação detalhado da visão visual do harness (ref.:
> `harness_web_gui_dark_references.md`, owner 2026-07-18). Escrito PARA implementadores
> chegarem e fazer: cada item é um card com fonte de dado real, arquivo/componente a tocar,
> tokens de design, e critério de aceite.
>
> **Decisão de stack (owner 2026-07-19): front-end novo em React/Vite/TS**, servido como
> **bundle pré-buildado e commitado** (`ui.bat` serve `dist/` offline — zero npm/env/download no
> clique do usuário; ver GUI-F0). O **backend `/api/*` fica intacto** (é framework-agnóstico e
> sólido) — o React consome os mesmos endpoints. Ou seja: **o backend/dados são reúso; a camada
> de RENDER migra de vanilla pra React.** Recomendação: front novo consumindo o `/api/*`
> existente, portando domínio-a-domínio, mantendo o painel vanilla alcançável até haver paridade
> (se preferir migração incremental in-place do painel vanilla, é só dizer).

## 0. Baseline de realidade (leia antes de tocar em qualquer coisa)

O que já existe hoje (mapeado por fan-out Sonnet 5, 2026-07-19):

- **GUI viva:** `python scripts/harness.py ui` → `scripts/harness_ui.py` (`serve()`,
  `ThreadingHTTPServer` em `127.0.0.1:8787`, token por sessão, abre o browser). Também
  `ui.bat`/`ui.sh`.
- **Front-end:** UM arquivo `scripts/harness_ui_page.py` — a string `PAGE` (~3670 linhas)
  com `<style>` inline (tokens CSS) + `<script>` vanilla (dezenas de `render*`) +
  `importmap` (CodeMirror + tree-sitter WASM servidos de `/vendor/`). Substituição de 3
  placeholders (`__HARNESS_TOKEN__`, `__HARNESS_REPO__`, `__HARNESS_ROOT__`) em
  `harness_ui.py:392`. **Vanilla puro. Sem React/Vue/build.**
- **Dados:** endpoints same-origin `/api/*` em `PanelHandler.do_GET` (`harness_ui.py:171`).
  Leitura = Python in-process lendo `.harness/` (`ui_panel.state_snapshot`). Escrita = UM
  caminho: `POST /api/action` → `ui_panel.run_action` → subprocess allowlistado pra
  `harness.py`. Chat = SSE (`/api/chat/stream` via `ChatBridge`).
- **Views que já existem:** Chat (SSE + IDE CodeMirror/tree-sitter), Config, Compose (DAG),
  Tasks (Kanban), Queue, Changelog, Memory, Specs, Research, Experiments, Metrics,
  Agents/worker drill-in, Evidence, Escalations, Capabilities.
- **Design system já existe** (`harness_ui_page.py:20-50`): `--bg-base`, `--surface-1/2/3`,
  `--border-*`, `--text-*`, `--accent`, `--stream`, `--success/warning/danger`, tokens de
  sintaxe, `--font-ui/mono`, spacing/radius. Dark-only.

### Invariantes que NENHUM item pode violar

1. **`GUI-writes-no-state` (SPEC-114):** a GUI é view + gatilho allowlistado. Todo botão
   que muta estado faz `POST /api/action` → subcomando `harness.py` existente. **Nunca**
   um segundo caminho de escrita, nunca escrever `.harness/` do handler.
2. **Zero-friction no runtime do usuário (o invariante REAL — owner 2026-07-19):** stack
   moderna É permitida (React/Vite/TS/Tailwind à vontade). O que NÃO pode: o usuário ter que
   rodar `npm install`, gerenciar env, ou baixar dependência pra abrir a GUI. Regra concreta:
   **`ui.bat` serve um bundle PRÉ-BUILDADO e vendorizado** (`dist/` commitado no repo, com JS/CSS/
   fontes/wasm embutidos) pelo mesmo `http.server` stdlib. `npm install`/`vite build` só rodam
   em DEV (quem MEXE na UI); o clique do usuário nunca toca a rede nem o npm. (Corrige a inferência
   "stdlib-only/no-build" que o scanner tirou do SPEC-114 — nunca foi a intenção.)
3. **Same-origin + token:** todo endpoint novo respeita o token de sessão e o allowlist.
4. **Sem telemetria virando conclusão:** logs/traces são evidência técnica, marcados como
   tal — nunca renderizados como veredito validado (antipadrão §13 da ref).

### Mapa de arquivos (onde cada coisa mora)

**Backend (REÚSO — fica igual, framework-agnóstico):**
| Arquivo | Papel |
|---|---|
| `scripts/harness_ui.py` | servidor, roteamento `/api/*`, allowlist de ação, SSE. Passa a servir `dist/` também. |
| `scripts/harness_lib/ui_panel.py` | `state_snapshot()` (leitura), `run_action()` (escrita allowlistada) |
| `scripts/harness_lib/ui_queue.py` | `queue_snapshot()` (Operations) |
| `scripts/harness_lib/ui_composer.py` | compose/DAG |
| `scripts/harness_lib/ui_chat_bridge.py` | ponte SSE do chat |
| `scripts/harness_lib/status_html.py` | página estática `status --html` (separada, mantida) |

**Front-end NOVO (React/Vite/TS — a criar em GUI-F0):**
| Caminho | Papel |
|---|---|
| `ui/` (ou `frontend/`) | projeto Vite: `package.json`, `vite.config.ts`, `src/`, `tsconfig` |
| `ui/src/theme/` | tokens de design (GUI-F1..F3) como CSS vars / tema |
| `ui/src/components/` | primitivos (GUI-F5): DataTable, Pill, Inspector, Drawer… |
| `ui/src/domains/<domain>/` | os 7 domínios (Workbench/Board/Research/…) |
| `ui/src/api/` | client dos `/api/*` (fetch + SSE), tipado |
| `ui/dist/` | **bundle buildado, COMMITADO** — o que o `ui.bat` serve offline |
| `scripts/harness_ui_page.py` | painel vanilla ATUAL — vira referência/interim até paridade; depois aposentado |

> **Mapeamento de "Toca" nos cards abaixo:** onde um card diz `harness_ui_page.py`/`PAGE`/`render*`,
> leia como "o componente React equivalente em `ui/src/domains/<domain>/`". As refs a `/api/*` e
> `harness_lib/ui_*.py` (backend) valem literalmente — não mudam.

---

## 1. Fundação de design (GUI-F) — o que torna "refinado", não genérico

> **⚠️ AESTHETIC = "SIGNAL" (D026, owner 2026-07-19) — SUPERSEDE a paleta/tipografia genérica abaixo.**
> A fundação Inter+accent-roxo (GUI-F1/F2 originais, committada em 9d5b188) era AI-slop. A
> linguagem canônica agora é **SIGNAL** — instrumento/mission-control pra agentes autônomos:
> **mono-forward (IBM Plex Mono dominante + Plex Sans só prosa; PROIBIDO Inter/Roboto/Space
> Grotesk)**, **warm-black olivado (#0A0B08) + accent DOMINANTE lime-fósforo #CBF23F + live teal
> #45E0C4**, **atmosfera de fundo (vinheta radial + scanlines de instrumento + ticks de medição +
> live-edge glow), NUNCA cor sólida chapada**, e **motion orquestrado (framer-motion: UM page-load
> em cascata staggered + pulse de sinal-vivo nos status live; respeita prefers-reduced-motion)**.
> Os valores EXATOS + a task de re-tema estão em `.harness/handoff/plan-gui-retheme-signal.md`.
> Onde GUI-F1/F2 abaixo listam #8B7CFF/Inter, leia os valores SIGNAL. Os componentes referenciam
> token por NOME (`--accent`,`--font-ui`), então adotam SIGNAL sozinhos quando os valores mudam.

Esta seção é o núcleo anti-genérico. Todo item de domínio consome estes primitivos; se a
fundação estiver certa, as telas herdam sofisticação. **Referências de aesthetic (SIGNAL):**
consoles de missão/telemetria, osciloscópios/instrumentos de bancada, terminais de phosphor,
drafting/engenharia — densidade técnica com um sinal vivo. (As refs de PADRÃO de UX — Linear/
Railway/Braintrust pra densidade/tabela/trace — seguem valendo; o que muda é a PELE.)

### GUI-F0 — Stack React/Vite/TS + pipeline zero-friction (`ui.bat` serve bundle commitado)
- **O quê:** montar o projeto front-end moderno E o pipeline que garante o invariante do owner:
  usuário clica `ui.bat` e roda, sem npm/env/download. Este é o ITEM 1 absoluto — habilita todos
  os outros.
- **Referência de setup:** Vite + React + TypeScript; Tailwind opcional (ou CSS vars puras pros
  tokens — ver GUI-F1). Fontes/wasm vendorizados (sem CDN — offline).
- **Estado hoje:** não existe (`ui/` a criar). O backend `/api/*` já existe e fica.
- **Toca:** novo `ui/` (Vite project); `scripts/harness_ui.py` (`serve()`) pra servir `ui/dist/`;
  `ui.bat`/`ui.sh`; `.gitignore` (NÃO ignorar `ui/dist/`); `package.json` scripts.
- **Design do pipeline (o coração do requisito):**
  1. **Dev:** `cd ui && npm install && npm run dev` (proxy `/api/*` → `127.0.0.1:8787`) OU
     `npm run build` → gera `ui/dist/`.
  2. **Commit do artefato:** `ui/dist/` (JS/CSS bundlados + fontes + wasm) é **COMMITADO** no repo.
     Trade-off aceito pelo owner: diff-noise/bloat em troca de "ui.bat só funciona". Alternativa
     (build em CI → release asset) documentada mas NÃO default.
  3. **Runtime do usuário:** `ui.bat` → `harness.py ui` → `http.server` stdlib serve `ui/dist/`
     estático + os `/api/*`. **Zero npm, zero rede, zero env** no clique.
  4. **Guard-rail:** se `ui/dist/` estiver ausente/desatualizado, cai no painel vanilla (fallback)
     e avisa — nunca quebra na cara do usuário.
- **Default de migração (D025, owner 2026-07-19):** durante o build, `/` = painel VANILLA maduro
  (default, sem regressão pro usuário); o React fica em **`/next`** (preview, provado o pipeline).
  Quando o React chegar em paridade, vira o `/` pra ele (mudança de 1 linha no `do_GET`). O
  `serve()` imprime a URL do `/next` quando o `dist/` existe. Isso mantém o E2E do painel vanilla
  verde (o `ui_e2e` bate no `/`).
- **Aceite:** num checkout limpo, SEM node instalado, `/next` serve a GUI React de `ui/dist/`
  (verificável: desligar a rede, apagar `node_modules`, abrir `/next` → funciona); `/` serve o
  vanilla. Um `npm run build` regenera `dist/` determinístico. O `/api/*` responde igual.
- **Dep:** nenhuma. **Tam:** M. **BLOQUEIA todos os outros GUI-*.**

### GUI-F1 — Rebase dos tokens de cor pra paleta canônica
- **O quê:** adotar a paleta exata da ref como valores canônicos dos tokens que já existem
  + adicionar os que faltam. Os NOMES já batem; é rebase de VALOR + preencher.
- **Referência:** Railway/Linear dark — sóbrio, sem preto puro, sem neon gamer.
- **Toca:** `harness_ui_page.py:20-50` (`:root`).
- **Design (valores canônicos):**
  `--bg-base:#090B0F` · `--surface-1:#10141A` · `--surface-2:#161B22` · `--surface-3:#1C232C`
  · `--surface-hover:#1C232C` · `--border-subtle:#1C232C` · `--border:#27303A` ·
  `--border-strong:#323C48` · `--text-primary:#EEF1F5` · `--text-secondary:#9AA5B2` ·
  `--text-muted:#687381` · `--text-disabled:#4A5563` · `--accent:#8B7CFF` (ação/seleção) ·
  `--stream:#5CCFE6` (execução/streaming — já existe como `--stream`) · `--success:#65C49A`
  · `--warning:#E0B66A` · `--danger:#E4777F`. Cada semântica ganha `-bg` (10-18% alpha) e
  `-border` (moderado). Ex.: `--success-bg:rgba(101,196,154,.12)`.
- **Aceite:** todos os componentes renderizam com a paleta nova; nenhum hex hardcoded fora do
  tema (grep por `#` no `src/` retorna só o arquivo de tokens); contraste texto/fundo ≥ AA
  (primary sobre surface-1).
- **Dep:** GUI-F0. **Tam:** S. **Primeiro item de design depois da stack.**

### GUI-F2 — Escala tipográfica + regra de monospace
- **O quê:** fixar a escala e a regra "mono só onde comunica estrutura técnica".
- **Referência:** Resend/Raycast (tipografia developer-first).
- **Toca:** `:root` (`--font-ui`, `--font-mono`, `--text-*`, `--line-*`), servir fontes de `/vendor/`.
- **Design:** UI = Inter (fallback system-ui neo-grotesco), servida local em `/vendor/fonts/`
  (sem Google Fonts — CSP/offline). Código/logs/IDs/tokens/SHAs/custos = JetBrains Mono.
  Escala: `--text-xs:11px` · `--text-sm:12px` · `--text-md:13px` (base UI) · `--text-lg:15px`
  · `--text-xl:18px`. `--line-ui:1.45`. Mono NUNCA em prosa/labels — só em valor técnico.
- **Aceite:** um card de task mostra título em Inter e o SHA/custo em mono; nenhuma fonte
  externa carregada (Network sem requests a fonts.googleapis).
- **Dep:** GUI-F1. **Tam:** S.

### GUI-F3 — Sistema de densidade e superfícies
- **O quê:** constantes de altura/espaçamento/raio + regras de superfície.
- **Referência:** Linear (densidade), Railway (superfícies planas).
- **Toca:** `:root` + classes utilitárias no `<style>`.
- **Design:** top bar global 52px · subnav 38px · rows operacionais 34px · padding de painel
  12-16px · radius 8-10px (`--radius-sm:8px`,`--radius-xs:6px`) · bordas 1px · sombras
  mínimas. Superfícies: sem preto puro, sem card-dentro-de-card (separar por borda +
  luminosidade), grid sutil só em canvas (Compose/graphs), **glow reservado a ativo/streaming**.
- **Aceite:** inspeção visual bate com as alturas; nenhum card aninhado > 1 nível; o único
  glow no produto é no chip de worker "Running"/stream.
- **Dep:** GUI-F1. **Tam:** S.

### GUI-F4 — Sistema de status (cor + ícone + texto + forma)
- **O quê:** um componente de status pill/dot único, usado em TODA tela. Cor nunca sozinha.
- **Referência:** Sentry/Linear (status semântico).
- **Toca:** novo `renderStatus(kind, label)` no `<script>`; classes `.pill.*` no `<style>`.
- **Design:** estados canônicos e seu par (cor + ícone + texto): `proposed`(muted ◇),
  `planned`(secondary ◇), `authorized`(accent ✓), `queued`(muted ⋯), `running`(stream ▶ +
  glow sutil), `reviewing`(warning ◐), `completed`(success ✓), `blocked`(warning ⛔),
  `failed`(danger ✕), `invalidated`(danger ⊘), `degraded`(warning △). Borda esquerda 2px na
  cor do status em rows (não fundo inteiro — antipadrão "cor no fundo").
- **Aceite:** daltônico consegue distinguir running/blocked/failed sem cor (ícone+texto
  bastam); a mesma pill aparece idêntica em Board, Queue e Activity.
- **Dep:** GUI-F1, F2. **Tam:** M. **Alta reutilização — priorizar.**

### GUI-F5 — Primitivos de componente (a biblioteca interna)
- **O quê:** o conjunto mínimo de componentes reusáveis que todas as telas montam.
- **Referência:** Attio (tabelas densas/records/inspectors), Linear (rows).
- **Toca:** `<style>` (classes) + helpers `render*` no `<script>`.
- **Design (primitivos):** (a) **DataTable** densa (row 34px, header sticky, sort, seleção,
  zebra por borda não por fundo); (b) **Row** com borda-esquerda de status; (c) **Pill/Chip**
  (GUI-F4); (d) **Inspector panel** (painel direito que troca por objeto — ver GUI-X4);
  (e) **KV list** (label mono-secondary : valor); (f) **Metric tile** (valor grande + delta
  colorido + label); (g) **Empty state** (ícone + 1 linha + ação); (h) **Toolbar** (filtro +
  busca + ações à direita); (i) **Drawer** (surface-2, slide da direita); (j) **Toast** de
  ação. Cada um documentado com exemplo no topo do `<style>`.
- **Aceite:** um "kitchen sink" oculto (`?debug=components`) renderiza todos os primitivos;
  cada domínio novo usa só estes, sem CSS ad-hoc.
- **Dep:** GUI-F1..F4. **Tam:** L. **Depois de F1-F4, é o maior alavancador.**

---

## 2. Shell (GUI-SH) — a moldura do app (Fase 1 da ref §16)

A moldura que segura tudo: menu superior de 7 domínios, subnav local, command palette,
inbox, environment/budget/health, layout de 3 painéis. Hoje a navegação é por
`view*`/toggle; isto reestrutura pra arquitetura de domínio da ref §2.

### GUI-SH1 — Top navigation global (7 domínios)
- **O quê:** barra superior `[Logo][Projeto ▾]  Workbench Board Research Experiments
  Operations Registry Activity   [⌘K][Environment ▾][Budget][Inbox][User]`.
- **Referência:** GitHub/Vercel (estrutura), Linear (densidade). Menu SUPERIOR (não lateral)
  porque as laterais são escassas (chat/arquivos + inspector) — ref §2.
- **Estado hoje:** views existem como toggles soltos; falta a hierarquia global→local.
- **Fonte de dado:** `/api/state` (projeto/health), `/api/metrics` (budget).
- **Toca:** `harness_ui_page.py` header (~700) + roteamento JS de view.
- **Design:** 52px, surface-1, borda inferior 1px. Domínio ativo com underline accent 2px.
  Reduz a ~15 views atuais aos 7 domínios (ver mapa GUI-SH2). Cada domínio abre sua subnav.
- **Aceite:** clicar um domínio troca a subnav e a área central; `⌘K` abre a palette;
  o domínio ativo é deep-linkável (`#/operations/queue`).
- **Dep:** GUI-F. **Tam:** M.

### GUI-SH2 — Mapa view-atual → domínio (a reestruturação)
- **O quê:** realocar as ~15 views existentes nos 7 domínios + subnav local.
- **Toca:** roteamento JS; renomear/agrupar seções do `PAGE`.
- **Design (mapa canônico):**
  | Domínio | Subnav local | Views existentes que absorvem |
  |---|---|---|
  | **Workbench** | Conversation · Code · Preview · Terminal · Changes · Artifacts | Chat, IDE, Compose(diff) |
  | **Board** | Board · Backlog · List · Timeline · Agent Tasks · Milestones | Tasks (Kanban) |
  | **Research** | Brief · Sources · Claims · Evidence · Consensus · Report | Research gallery |
  | **Experiments** | Overview · Runs · Compare · Metrics · Findings | Experiments board |
  | **Operations** | Overview · Queue · Workers · Workflows · Resources · Incidents | Queue, Agents/worker, Compose(DAG) |
  | **Registry** | Models · Providers · Routes · Fallbacks · Roles · Resources · Policies | Config, Capabilities |
  | **Activity** | Changelog · Releases · Decisions · Incidents · Audit | Changelog, Escalations, Evidence, Memory, Metrics |
  | **Specs** (utilitário) | — | Specs (fica como aba de Activity/Registry ou global secundário) |
- **Aceite:** toda view antiga é alcançável no novo IA; nenhuma órfã.
- **Dep:** GUI-SH1. **Tam:** M.

### GUI-SH3 — Command palette (⌘K)
- **O quê:** palette global (navegar, abrir task/run/worker/modelo, iniciar/pausar, aprovar,
  simular rota, comparar experimentos, buscar comando/doc).
- **Referência:** Raycast/Linear/Railway.
- **Fonte de dado:** `/api/state` + um índice leve de comandos (JS estático) + `/api/action`
  pros verbos.
- **Toca:** novo `renderPalette()`; atalho global `⌘K`/`Ctrl K`.
- **Design:** overlay surface-2, input mono, resultados agrupados (Go to / Actions / Search),
  navegação por teclado, cada ação tipada (command vs navigation). Ações mutantes passam
  pelo allowlist.
- **Aceite:** `⌘K` → digitar "queue" navega pra Operations/Queue; "pause wrk-17" chama a ação
  allowlistada; Esc fecha; 100% navegável por teclado.
- **Dep:** GUI-SH1, GUI-X6 (semântica de ação). **Tam:** M.

### GUI-SH4 — Inbox global de atenção
- **O quê:** uma inbox tipada: approvals, decisões bloqueantes, workers stalled, budget
  threshold, incidentes, experimentos aguardando promoção, pesquisas aguardando consenso.
- **Referência:** Linear inbox.
- **Fonte de dado:** `escalations` (pendentes), `decide --list --json`, `/api/queue`
  (stalled), `/api/metrics` (budget), `experiment list --json` (review-by vencido).
- **Toca:** ícone Inbox no top bar + drawer `renderInbox()`.
- **Design:** badge com contagem; itens tipados com ação direta inline (Approve/View/Rollback);
  bloqueios/aprovações em contraste maior que atividade normal.
- **Aceite:** uma escalation pendente aparece na inbox com botão que chama `decide`; o badge
  zera ao resolver.
- **Dep:** GUI-F4, GUI-SH1. **Tam:** M.

### GUI-SH5 — Environment + Budget + Health no top bar
- **O quê:** seletor de environment (local/sandbox/staging/production), indicador de
  custo/tokens do escopo, health geral do harness, identidade/permissão.
- **Referência:** Vercel (environment), Railway (health).
- **Fonte de dado:** `/api/metrics` (`cost_metrics.summarize`), `/api/state` (health), env do processo.
- **Toca:** top bar direito.
- **Design:** budget como tile compacto (gasto/limite + barra fina); health como dot+label
  (GUI-F4); environment com cor de borda distinta em production (danger-border) pra avisar.
- **Aceite:** o custo bate com `harness.py metrics`; em "production" a moldura ganha o aviso
  visual; o tile atualiza (resolve a queixa SPEC-133 de "session $ congelado").
- **Dep:** GUI-F. **Tam:** S.

### GUI-SH6 — Layout responsivo de 3 painéis
- **O quê:** o esqueleto central-esquerda-direita com colapso.
- **Referência:** v0/Replit (workbench de 3 zonas).
- **Toca:** grid CSS do `PAGE`.
- **Design:** esquerda (chat/arquivos, colapsável mantendo faixa persistente de
  agente/objetivo/estado), centro (IDE/diff/preview/conteúdo do domínio), direita (inspector
  contextual GUI-X4). Timeline de eventos recolhível no rodapé. Larguras arrastáveis, estado
  persistido em localStorage.
- **Aceite:** colapsar o chat mantém a faixa de contexto; o inspector direito acompanha a
  seleção; larguras sobrevivem a reload.
- **Dep:** GUI-F3, GUI-X4. **Tam:** M.

---

## 3. Padrões transversais (GUI-X) — aplicam-se a todos os domínios

### GUI-X1 — Progressive disclosure (4 níveis)
- **O quê:** todo objeto complexo expõe Outcome → Plan → Topology → Evidence, nessa ordem.
- **Referência:** Magentic-UI (co-planning), a fachada-central-responsável da ref §1.
- **Toca:** padrão de render aplicado em Workbench, Operations, Experiments.
- **Design:** nível 1 (o que foi pedido/obtido) sempre visível; 2-4 por expansão. Logs nunca
  dominam por padrão.
- **Aceite:** um workflow mostra outcome sem scroll; topology/evidence só sob clique.
- **Dep:** GUI-F5. **Tam:** M (é um padrão, não uma tela).

### GUI-X2 — Inbox item / notificação tipada
- (coberto por GUI-SH4; este item = a tipagem reusável do item de inbox como componente).
- **Dep:** GUI-SH4. **Tam:** S.

### GUI-X3 — Deep links estáveis
- **O quê:** URL estável pra task/run/trace/workflow-event/worker/claim/source/experiment-
  compare/model-version/policy-version/incident/changelog-entry.
- **Referência:** Linear/Sentry (tudo linkável).
- **Toca:** roteamento hash (`#/domain/view/id`) no JS + resolvedor que abre o objeto+inspector.
- **Design:** router client-side sobre hash; cada deep link reidrata a view + seleção +
  inspector. Botão "copy link" nos headers de detalhe.
- **Aceite:** colar `#/experiments/compare/EXP-22` abre a comparação direto; back/forward do
  browser funciona.
- **Dep:** GUI-SH1. **Tam:** M.

### GUI-X4 — Painel inspetor contextual
- **O quê:** o painel direito que troca de conteúdo conforme o objeto selecionado.
- **Referência:** Attio (record inspector), Braintrust (run detail).
- **Design:** task→plano/owner/risco/evidência · worker→contexto/tools/locks/budgets ·
  experiment run→params/scores/artifacts · source→metadata/claims/citações · model→
  capabilities/histórico/routes · policy→diff declared/effective.
- **Toca:** painel direito do GUI-SH6 + um `renderInspector(objType, id)`.
- **Aceite:** selecionar objetos de tipos diferentes troca o inspector sem recarregar a tela.
- **Dep:** GUI-SH6, GUI-F5. **Tam:** M.

### GUI-X5 — Semântica de ação (command/proposal/approval/execution/receipt/evidence/promotion)
- **O quê:** distinção visual e de estado entre os 7 tipos de ação (ref §12.6).
- **Referência:** o modelo de accountability da ref (fachada responsável).
- **Toca:** GUI-F4 (estados) + a camada de ação do `run_action`.
- **Design:** cada um tem tratamento visual próprio: proposal (tracejado, "aguarda
  autorização"), approval (accent, quem/quando), execution (stream), receipt (success +
  verificável), evidence (marcado como técnico, nunca conclusão), promotion (mudança
  persistente destacada). Casa com o D018 (cadeia de responsabilidade) e o EXP/promoção.
- **Aceite:** um plano proposto NÃO parece executado; uma promoção aparece com selo distinto
  no Activity.
- **Dep:** GUI-F4. **Tam:** M.

### GUI-X6 — Antipadrões (checklist de revisão, não uma tela)
- **O quê:** guardrails de review pra cada PR de GUI (ref §13). Um chat por worker (só
  diagnóstico), grafo pra tudo (não pra fallback/fila/tabela), card soup, cor por agente,
  excesso de real-time, telemetria virando conclusão, JSON como única interface.
- **Toca:** doc de review + um comentário no topo do `harness_ui_page.py`.
- **Aceite:** o checklist entra no template de review de itens GUI-*.
- **Shipped:** `docs/design/gui-review-checklist.md`; cited by GUI-* reckon prompts.
- **Dep:** —. **Tam:** S.

---

## 4. Domínio Workbench (GUI-WB) — Fase 2 da ref §16

A fachada central de criação: chat, plano, IDE, terminal, preview, diffs, aprovações. Já é a
view mais madura (SSE + CodeMirror); estes itens a elevam ao layout da ref §3.

### GUI-WB1 — Faixa persistente de agente responsável
- **O quê:** quando o chat é recolhido, uma faixa mostra agente responsável, objetivo, estado
  e próxima intervenção.
- **Referência:** Magentic-UI / a "fachada central responsável" (ref §1, §3).
- **Fonte de dado:** `/api/chat/*` (agente/estado atual), `/api/state`.
- **Toca:** `harness_ui_page.py` área de chat (700-735); GUI-SH6 (colapso).
- **Design:** faixa 34px surface-2 com role+ícone (não vendor), objetivo truncado, pill de
  estado (GUI-F4), botão "próxima intervenção".
- **Aceite:** recolher o chat mantém a faixa; ela reflete o agente ativo em tempo real.
- **Dep:** GUI-SH6, GUI-F4. **Tam:** S.

### GUI-WB2 — Diff sem perder a conversa
- **O quê:** abrir um diff a partir de uma mensagem sem sair da conversa que o originou.
- **Referência:** v0 (transição conversa↔código↔preview).
- **Fonte de dado:** `/api/commit` (git show redigido), o compose diff existente.
- **Toca:** centro (IDE/Diff/Preview) + link da mensagem→diff.
- **Design:** diff abre no painel central, conversa permanece na esquerda; tabs locais
  Conversation|Code|Preview|Terminal|Changes|Artifacts trocam o centro, não destroem o split.
- **Aceite:** clicar "ver diff" numa mensagem abre o diff mantendo a conversa visível.
- **Dep:** GUI-SH6. **Tam:** M.

### GUI-WB3 — Plano com etapas tipadas (humana/agêntica/bloqueada/replanejada)
- **O quê:** o plano mostra quais etapas são humanas, agênticas, bloqueadas ou replanejadas;
  editável antes de mudanças materiais (Plan Mode).
- **Referência:** Replit (Plan Mode), Magentic-UI (plano editável).
- **Fonte de dado:** `validate --check`/gate + o `#planCard` HUD já shipado (`chat-plan-hud`).
- **Toca:** `renderPlan` (1170+), o planCard existente.
- **Design:** cada etapa com ícone de tipo + pill de estado; etapas bloqueadas em contraste
  maior; ação "editar plano" antes de autorizar (proposal → approval, GUI-X5).
- **Aceite:** um plano com etapa humana e uma agêntica mostra os dois tipos distintos;
  bloqueio salta à vista.
- **Dep:** GUI-F4, GUI-X5. **Tam:** M.

### GUI-WB4 — Approval card no contexto da ação
- **O quê:** aprovações aparecem no contexto da ação (além da inbox global).
- **Referência:** Magentic-UI (action guards).
- **Fonte de dado:** `decide` (inbox de decisão), o C12 approval digest.
- **Toca:** área de chat + GUI-SH4 (inbox).
- **Design:** card inline surface-2 com o que será feito, risco/approval-tier, botões
  Approve/Reject que chamam `decide` (allowlist). Também entra na inbox.
- **Aceite:** uma ação que exige aprovação renderiza o card no ponto da conversa E na inbox;
  aprovar chama o verbo real.
- **Dep:** GUI-SH4, GUI-X5. **Tam:** M.

### GUI-WB5 — Timeline de eventos recolhível (transições determinísticas)
- **O quê:** timeline/logs/transições de estado no rodapé, recolhível, nunca dominante.
- **Referência:** Temporal (event history), v0 (feedback de ação).
- **Fonte de dado:** `workflow events` / `.harness/runs/events.jsonl` (hash-chained).
- **Toca:** rodapé do GUI-SH6.
- **Design:** faixa recolhível; expandida mostra transições determinísticas com parent-child;
  marcada como evidência técnica (GUI-X6), não conclusão.
- **Aceite:** logs ficam recolhidos por padrão; expandir mostra a cadeia de eventos com
  parentEventId (T-CAUSALPARENT).
- **Dep:** GUI-X1. **Tam:** M.

---

## 5. Domínio Board (GUI-BD) — Kanban de tarefas

A projeção de execução das tarefas. Já existe (Tasks read-only derivado, `tasks-board-read`
✅). Estes itens dão as múltiplas projeções + conteúdo rico de card (ref §4).

### GUI-BD1 — Colunas por ESTADO (não por agente)
- **O quê:** colunas = estados da tarefa: Proposed→Planned→Authorized→Queued→Running→
  Reviewing→Completed, com desvio Blocked/Failed/Invalidated.
- **Referência:** Linear/GitHub Projects. Antipadrão a evitar: coluna por agente.
- **Fonte de dado:** `tasks list --json` (`tasks_board.py`, lanes em `.harness/state/tasks.json`).
- **Toca:** `viewTasks` (787-802).
- **Design:** colunas neutras, WIP visível; card com borda-esquerda de status (GUI-F4). Mapear
  as lanes atuais (backlog/running/review/done) pros 7 estados canônicos.
- **Aceite:** as colunas são estados; um agente é responsável por um card, não define coluna.
- **Dep:** GUI-F4. **Tam:** M.

### GUI-BD2 — Card de tarefa rico
- **O quê:** título/objetivo, responsável (role+ícone, não vendor), estado do worker, risco/
  approval tier, branch/workspace, custo/tokens, experimento/evidência relacionada, bloqueios
  de recurso, tentativas, TTL/deadline, resultado esperado, indicador de mudança desde a
  última visualização.
- **Referência:** Linear card + a lista de campos da ref §4.
- **Fonte de dado:** `tasks list --json` (+ join com `/api/metrics` pra custo, `/api/queue`
  pro estado do worker).
- **Toca:** render de card em `viewTasks`.
- **Design:** card neutro, cor só no status; custo/tokens em mono; "novo desde última vista"
  como dot accent. Dependências sob demanda (não poluir).
- **Aceite:** um card mostra role+custo+estado+TTL; abrir revela dependências; o dot de
  "mudou" aparece após uma alteração.
- **Dep:** GUI-BD1, GUI-F5. **Tam:** M.

### GUI-BD3 — Projeções múltiplas (List/Timeline/Agent Tasks/Milestones)
- **O quê:** o mesmo conjunto de tarefas em Board, List/Table (filtro+edição em massa),
  Timeline (dependências), Agent Tasks (background/delegações), Milestones (outcomes).
- **Referência:** GitHub Projects (board/table/roadmap), Linear.
- **Fonte de dado:** `tasks list --json`.
- **Toca:** subnav local de Board (GUI-SH2) + renders por projeção.
- **Design:** List = DataTable (GUI-F5) com bulk-edit via ações allowlistadas; Timeline = barras
  de dependência; Agent Tasks = background com progresso resumido (não um chat por worker).
- **Aceite:** trocar de projeção mantém o mesmo dataset; bulk-edit na List chama verbos reais.
- **Dep:** GUI-BD2, GUI-F5. **Tam:** L.

---

## 6. Domínio Research (GUI-RS) — pesquisa federada

Já existe a Research gallery, mas `gui-research-screen` (SPEC-135/Q8) segue **OPEN** com plano
em `.harness/handoff/plan-q8-panel-research-screen.md`. Estes itens realizam a visão da ref §6
(lanes compactas, claim-evidence matrix, consenso) — casa direto com as rodadas que rodamos
(#3, RD-U/CRASH/TAINT).

### GUI-RS1 — Source lanes compactas (não um chat por pesquisador)
- **O quê:** os agentes de aquisição/validação aparecem como lanes compactas (ex.: `arXiv
  Agent  41 results — 6 retained`), não chats independentes.
- **Referência:** Perplexity (progresso resumido). Antipadrão: um chat por worker.
- **Fonte de dado:** `research show <slug> --json` (`research_admin.py`) — as waves/workers do
  round; a divergência (5 ideadores) vira 5 lanes.
- **Toca:** `viewResearch` (862-876).
- **Design:** lanes horizontais com contagem encontrado→deduplicado→retido; convergência
  para "Evidence normalization → Claims and consensus" (o pipeline da ref §6).
- **Aceite:** abrir o round #3 mostra 5 lanes (os ideadores) com contagens, não 5 chats.
- **Dep:** GUI-F5. **Tam:** M. **Fecha o `gui-research-screen` OPEN.**

### GUI-RS2 — Claim-evidence matrix
- **O quê:** tabela Claim × Supporting/Contradicting/Independent replications/Confidence.
- **Referência:** Scite (supporting/contrasting), Elicit (paper table).
- **Fonte de dado:** `research show --json` (findings/evidence do reduce; os `[web]/[repo]/
  [judgment]` prefixes viram a coluna de fonte).
- **Toca:** `viewResearch` — nova subtab Claims/Evidence.
- **Design:** DataTable (GUI-F5); confidence como pill (High/Contested/Preliminary); dissenting
  evidence visível, nunca escondida atrás de %.
- **Aceite:** um claim contestado mostra supporting E contradicting; a confiança não é só um número.
- **Dep:** GUI-F5, GUI-RS1. **Tam:** M.

### GUI-RS3 — Consenso calibrado + report sintetizado
- **O quê:** consenso = posição + qualidade/independência das fontes + dissenting + dependências
  comuns + confiança calibrada + data + agentes participantes + regra de parada. Report final.
- **Referência:** Consensus (síntese sobre corpus), Perplexity (síntese + refs verificáveis).
- **Fonte de dado:** `research show --json` (síntese do orquestrador + fontes).
- **Toca:** subtab Consensus/Report.
- **Design:** consenso NUNCA só %; report como prosa com refs clicáveis (deep link GUI-X3);
  separa fonte web (untrusted-até-verificar) de fonte interna (`[repo]`).
- **Aceite:** o consenso mostra dissenting + a regra de parada; o report linka cada conclusão à fonte.
- **Dep:** GUI-RS2. **Tam:** M.

### GUI-RS4 — Research run form (scaffold de nova rodada)
- **O quê:** form pra iniciar uma rodada (question/criteria/budget/width declarados — os campos
  do Phase 0 do research-playbook).
- **Referência:** o próprio research-playbook (D010 width, budget declarado).
- **Fonte de dado:** ação allowlistada → `workflow plan --profile research-divergence` etc.
- **Toca:** `viewResearch` + `run_action`.
- **Design:** form estruturado (não JSON cru — antipadrão §13) com validação; width-mode
  (focused/exploratory) com a justificativa obrigatória (D010).
- **Aceite:** preencher o form dispara a rodada via verbo real; width sem justificativa bloqueia.
- **Dep:** GUI-RS1, GUI-X5. **Tam:** M. **Fecha o `research-run-form` OPEN.**

---

## 7. Domínio Experiments (GUI-XP) — Fase 4 da ref §16

Já existe a Experiments board (SPEC-136, read-only). Estes itens dão a comparação
baseline/candidate + drill-down + promoção (ref §5). Casa com o registry EXP-* que já usamos.

### GUI-XP1 — Lista de runs + registro
- **O quê:** overview dos experimentos com estado (proposed/active/shipped/shelved), grade,
  reviewBy, métricas.
- **Referência:** MLflow (organização sóbria), W&B.
- **Fonte de dado:** `experiment list --json` (`.harness/state/experiments.json`).
- **Toca:** view Experiments existente.
- **Design:** DataTable densa; grade de evidência (1-4) como pill; reviewBy vencido em warning
  (alimenta a inbox GUI-SH4).
- **Aceite:** EXP-22 aparece active com grade 2 e as medições registradas; reviewBy vencido alerta.
- **Dep:** GUI-F5. **Tam:** S.

### GUI-XP2 — Compare baseline/candidate
- **O quê:** a tela de comparação da ref §5 (success rate, cost/task, latency P95, human review,
  regressions/improvements) com deltas.
- **Referência:** Braintrust (compare experiments, diff de outputs).
- **Fonte de dado:** `experiment show --json` (as measurements/evidence); onde faltar dado de
  run-a-run, marcar como gap (não fabricar — measure-honesty).
- **Toca:** nova subtab Compare.
- **Design:** duas colunas + coluna de delta colorido (success verde, custo/latência menor =
  verde); métrica em mono. Abrir regressão → drill-down (GUI-XP3).
- **Aceite:** comparar dois runs mostra deltas; métrica ausente aparece como "—" honesto.
- **Dep:** GUI-XP1, GUI-F5. **Tam:** M.

### GUI-XP3 — Drill-down de regressão + integração com métodos experimentais
- **O quê:** ao abrir uma regressão: variável alterada, modelo/provider/reasoning, rota/fallback
  usado, contexto, trace, output baseline vs candidato, scores auto + humano, significância/IC,
  evidência favorável + counterevidence, custo/tokens/latência por etapa. + os fatores DOE
  (controlados/variados/níveis/seeds/blocking/Taguchi/response/critérios promo-shadow-canary).
- **Referência:** Braintrust (regressão), Langfuse (trace↔custo↔avaliação).
- **Fonte de dado:** `experiment show --json` + `workflow events` (trace) + a carta de método
  (o advisory L18 corrigido em e5a1a4b — confidence-sequences etc.).
- **Toca:** inspector (GUI-X4) + subtab.
- **Design:** progressive disclosure (GUI-X1): outcome→trace→evidência; a carta de método
  (Taguchi/confidence-sequences/noise-floor) e o noise floor L13 explícitos.
- **Aceite:** abrir uma regressão mostra a rota real usada + o trace + a carta de método citada.
- **Dep:** GUI-X1, GUI-X4. **Tam:** L.

### GUI-XP4 — Promotion action (shadow/canary/rollback)
- **O quê:** ação de promoção com os critérios (shadow→canary→promotion, evidence grade,
  noise floor) — a promoção é uma mudança persistente destacada.
- **Referência:** Vercel (rollout), o modelo de promoção da ref §12.6.
- **Fonte de dado:** ação allowlistada → `experiment verdict` + a door SPEC-116.
- **Toca:** `run_action` + botão no detalhe.
- **Design:** promoção exige confirmatory-or-better + noise floor limpo (Evidence grades card);
  vira entrada de Activity (GUI-AC) com selo de promotion (GUI-X5).
- **Aceite:** promover um EXP chama `experiment verdict`, exige a grade, e aparece no Activity.
- **Dep:** GUI-X5, GUI-AC1. **Tam:** M.

---

## 8. Domínio Operations (GUI-OP) — Fase 3 da ref §16

Queue/workers/workflows/resources/incidents. Já existe Queue (`queue-view-live` ✅,
`queue-cancel-worker` ✅) e Agents/worker drill-in. Estes itens dão os 3 níveis da ref §7
(Queue/Workers/Workflow) + Temporal-grade workflow view.

### GUI-OP1 — Queue view (fila com effective priority)
- **O quê:** cada item: priority + effective priority, queue time, TTL, concurrency group,
  recursos aguardados, dependências incompletas, retry count, deadline, motivo de seleção do
  próximo worker, compatibilidade exigida (tools/contexto/modelo/região/confiança).
- **Referência:** Trigger.dev (concurrency/queues).
- **Fonte de dado:** `/api/queue` (`ui_queue.queue_snapshot`), `.harness/workflows/active/`.
- **Toca:** `viewQueue` (802-816).
- **Design:** DataTable; concurrency-group como chip; motivo de bloqueio explícito (não só
  "waiting"). Fila é LISTA priorizada, não grafo (antipadrão §13).
- **Aceite:** um item bloqueado mostra POR QUE (recurso/dependência) e a prioridade efetiva.
- **Dep:** GUI-F5. **Tam:** M.

### GUI-OP2 — Worker table + inspector
- **O quê:** tabela Worker|Role|Model|State|Task|Context%|Tokens|Resource-lock; inspector com
  identidade/role, vendor/modelo/reasoning, task atual, context manifest, tools montadas,
  filesystem/recursos permitidos, locks, budget, health/heartbeat, histórico, wait-reason, e
  ações pause/drain/terminate/reassign/inspect.
- **Referência:** Prefect (workers), Railway (health), a tabela da ref §7.
- **Fonte de dado:** `/api/worker`, `services --json`, `/api/queue`, route ledger.
- **Toca:** `renderAgents` (1248), `renderWorker` (1322).
- **Design:** row 34px; state como pill (GUI-F4); ações via `run_action` allowlistado
  (pause/drain/terminate = verbos reais); avatar = role+ícone, NÃO cor por vendor (antipadrão).
- **Aceite:** a tabela mostra os workers ativos; pausar chama o verbo real; o inspector abre o
  context manifest e os locks.
- **Dep:** GUI-X4, GUI-F4. **Tam:** M.

### GUI-OP3 — Workflow detail (Temporal-grade)
- **O quê:** event history, views Timeline/Compact/JSON, hierarquia pai-filho, atividades
  pendentes, workers associados, ações cancel/reset/terminate, estado reconstruível.
- **Referência:** Temporal Web UI (a referência-mãe pra workflow), Dagster (DAG/Gantt/logs).
- **Fonte de dado:** `workflow status <id>`, `workflow events`, `workflow state` (JSON default),
  `.harness/runs/events.jsonl` (hash-chain + parentEventId do T-CAUSALPARENT!).
- **Toca:** view Compose/DAG (`renderDag` 3433) + nova view Workflow.
- **Design:** timeline de eventos com parent-child (o T-CAUSALPARENT dá a DAG causal de graça);
  toggle Timeline/Compact/JSON; DAG só pra topologia (não pra fila/fallback). Verificabilidade:
  a hash-chain (T-HASHCHAIN) dá o selo de "estado íntegro".
- **Aceite:** abrir um workflow mostra o event history reconstruível com a árvore causal; o
  toggle JSON expõe o evento cru; cancel chama o verbo.
- **Dep:** GUI-OP1, GUI-X1. **Tam:** L.

### GUI-OP4 — Resource / lock view
- **O quê:** recursos reservados e locks adquiridos por worker (repo, APIs externas, sandbox).
- **Referência:** Railway (observability).
- **Fonte de dado:** `services`, route ledger, os locks do sandbox_spawn (SPEC-151).
- **Toca:** subtab Resources.
- **Design:** matriz recurso×worker; lock em contraste; conflitos de lock destacados.
- **Aceite:** um lock de repo aparece ligado ao worker que o segura.
- **Dep:** GUI-OP2. **Tam:** M.

### GUI-OP5 — Incidents
- **O quê:** incidentes de operação (breaker aberto, worker crash, gate-hold) com detalhe Sentry-like.
- **Referência:** Sentry (issue detail).
- **Fonte de dado:** `escalations`, breaker/circuit files (`executor-circuit-*.json`), events.
- **Toca:** subtab Incidents (compartilha componente com GUI-AC4).
- **Design:** resumo/impacto, timeline, breadcrumbs, trace, worker/modelo/commit suspeito,
  owner, mitigação/rollback, evidência de resolução.
- **Aceite:** um breaker aberto vira um incidente com o executor suspeito e a timeline.
- **Dep:** GUI-AC4. **Tam:** M.

---

## 9. Domínio Registry (GUI-RG) — Fase 6 da ref §16

Model cards, providers, routes, fallbacks, roles, resources, policies. Já existe Config +
Capabilities; `config-keys-gui` e `graphs-screen-gui` seguem OPEN. Estes itens dão a model card
do harness (4 camadas de evidência) + o editor de rota/fallback + a matriz de acesso (ref §8-9).

### GUI-RG1 — Model card do harness (4 camadas de evidência)
- **O quê:** card por modelo com Overview/Benchmarks/Experiments/Cost&Latency/Failures/
  Compatibility/Safety/Routing-history, e as 4 camadas: vendor-declared, external evidence,
  harness-measured, operational history.
- **Referência:** Hugging Face (model cards), Artificial Analysis (leaderboard).
- **Fonte de dado:** `models` verb + `.harness/routing/model-cards.json`; harness-measured vem
  do route ledger + delegation trends; accountingSemantics (T-ADAPTERCONF) marca token medido
  vs estimado.
- **Toca:** `viewConfig` (735-765) → nova view Models.
- **Design:** as 4 camadas visualmente separadas (declarado ≠ medido!); health como pill;
  "validated roles" com ✓/conditional. Cada medição com data+origem (proveniência).
- **Aceite:** a card do glm-5.2 mostra o que é declarado vs medido pelo harness; roles validados
  aparecem; nenhum número sem origem.
- **Dep:** GUI-F5. **Tam:** L.

### GUI-RG2 — Fallback como sequência vertical ordenada (NÃO grafo)
- **O quê:** PRIMARY→FALLBACK1→FALLBACK2→human-escalation, cada target com health/
  compatibilidade/qualidade-por-role/custo/latência/context-fit/tools/condição de entrada-saída.
- **Referência:** Portkey/OpenRouter (fallbacks). Antipadrão explícito: grafo livre pra fallback.
- **Fonte de dado:** `routing` verb + `model-routing.json`, `task-profiles.json`; health do ledger.
- **Toca:** nova view Fallbacks no Registry.
- **Design:** sequência vertical (ref §8) — cada nível com a condição de disparo ("on 429,
  timeout, tool incompatibility"); custo/latência em mono. Editor visual estruturado + diff +
  validação (não JSON cru — antipadrão §13).
- **Aceite:** a cadeia de fallback é uma sequência legível; editar dispara validação; salvar
  passa por ação allowlistada. **Fecha parte do `config-keys-gui`.**
- **Dep:** GUI-F5, GUI-X5. **Tam:** M.

### GUI-RG3 — Simulate route
- **O quê:** ação `Simulate route`: operador informa task class/role/context size/tools/budget/
  latency SLO/região/risk tier → a UI mostra qual modelo/provider seria escolhido e explica cada decisão.
- **Referência:** o "explain decision" de gateways (Portkey/LiteLLM).
- **Fonte de dado:** `route` verb (SPEC-144 classifier, `--triage-prompt`/`--verdict`) — já existe
  a plumbing de classificação!
- **Toca:** botão + `run_action` → `route`.
- **Design:** form estruturado → resultado com a rota escolhida + explicação por critério; casa
  com o U(rota) da rodada RD-U (D021) quando o regret/ECE existir.
- **Aceite:** simular uma task class retorna a rota + o porquê de cada decisão.
- **Dep:** GUI-RG2. **Tam:** M.

### GUI-RG4 — Matriz de acesso por role + role card
- **O quê:** matriz Role×(Repository/Shell/Web/External APIs/Secrets/Production) com estados
  ricos (allowed/denied/scoped/conditional/approval-required/inherited/temporarily-revoked/
  incident-override); + role card (allowed models, context budget, concurrency, tools, filesystem,
  evidence contract, approval threshold, fallback policy).
- **Referência:** a matriz da ref §9; casa com os trust tiers (executors.json) + GM-3 authority.
- **Fonte de dado:** `agents mcp --json`, `executors.json` (trustTier), `capabilities.json`,
  `agent_parity.py` (supportState).
- **Toca:** view Capabilities existente (`renderSkillsGrid` 2922) → Roles/Resources.
- **Design:** matriz densa; célula = estado rico (não allow/deny binário); separar declared vs
  effective policy (ver GUI-RG5). Cor semântica, não por vendor.
- **Aceite:** a matriz mostra "scoped"/"conditional", não só allow/deny; o role card do Researcher
  mostra o evidence contract.
- **Dep:** GUI-F5. **Tam:** M.

### GUI-RG5 — Declared vs effective policy inspector
- **O quê:** separar política declarada no role / herdada do projeto / restrição do environment /
  mudança temporária por incidente / política efetiva / justificativa+provenance.
- **Referência:** a ref §9 (declared vs effective).
- **Fonte de dado:** `.harness/routing/*.json` (declared) + a resolução efetiva (`model_routing.
  resolve_role`) + capabilities supportState.
- **Toca:** inspector (GUI-X4) pra objeto policy.
- **Design:** diff declared→effective com a razão de cada override (incident/environment); casa
  com a cadeia de responsabilidade D018.
- **Aceite:** um role com override de incidente mostra o valor declarado E o efetivo + a razão.
- **Dep:** GUI-X4, GUI-RG4. **Tam:** M.

### GUI-RG6 — Graphs screen (métricas + exploração + provider select)
- **O quê:** a tela de grafos (fecha `graphs-screen-gui` OPEN): métricas do grafo de código +
  exploração + seleção de provider (B1 backend já shipado, B2 CLI shipado).
- **Referência:** Dagster (DAG viz).
- **Fonte de dado:** `graphs-metrics-cli` (shipado) + o provider abstraction (`screen-graphs-providers.md`).
- **Toca:** nova view no Registry/utilitário.
- **Design:** grid sutil só neste canvas (GUI-F3); grafo pra topologia de código, tabela pra métricas.
- **Aceite:** a tela lista métricas do grafo + permite escolher provider. **Fecha `graphs-screen-gui`.**
- **Dep:** GUI-F. **Tam:** M.

---

## 10. Domínio Activity (GUI-AC) — Fase 7 da ref §16

Changelog, releases, decisions, incidents, audit. Já existe Changelog (commit timeline,
`M5.rec` ✅) + Escalations. Estes itens dão a entrada semântica de activity + audit trail (ref §10).

### GUI-AC1 — Entrada semântica de activity
- **O quê:** cada evento conecta quem/agente, policy/model/workflow afetado, antes→depois,
  evidência/experimento que justificou, approval, release resultante, impacto, opção de rollback.
- **Referência:** Linear changelog, Vercel deployments.
- **Fonte de dado:** `records recent --json` (worklog/validations/commits/specs), `.harness/runs/
  events.jsonl` (hash-chain), `escalations`, o D018 (cadeia de responsabilidade) pro "quem".
- **Toca:** `viewChangelog` (816-835).
- **Design:** entrada rica (ref §10 exemplo: "Routing policy v12 promoted · Evidence EXP-441 ·
  Approved by Maria · [View diff][View experiment][Rollback]"). Cada mudança linka evidência
  (deep link GUI-X3); promotion com selo (GUI-X5).
- **Aceite:** uma promoção de EXP aparece como entrada semântica com evidência + approval +
  botão de rollback.
- **Dep:** GUI-X3, GUI-X5. **Tam:** M.

### GUI-AC2 — Decisions view
- **O quê:** as decisões (D001..D023...) com trade-offs/reversibilidade/gatilhos e a cadeia de
  responsabilidade.
- **Referência:** o audit trail da ref §10; casa com o nosso `DECISIONS.md` + decision inbox.
- **Fonte de dado:** `records` (decisões) + o decision_inbox; a acceptanceAuthority (D018).
- **Toca:** `renderDecisions` (1509).
- **Design:** lista com quem-decidiu (actorType user/worker/overseer) + data + fontes; deep link.
- **Aceite:** D021 aparece com a fonte (rodada RD-U) e quem decidiu.
- **Dep:** GUI-AC1. **Tam:** S.

### GUI-AC3 — Audit trail (hash-chain verificável)
- **O quê:** o log de eventos como trilha de auditoria com integridade verificável.
- **Referência:** o modelo receipt/evidence da ref §12.6.
- **Fonte de dado:** `.harness/runs/events.jsonl` + `verify_event_chain` (T-HASHCHAIN) +
  parentEventId (T-CAUSALPARENT).
- **Toca:** subtab Audit.
- **Design:** eventos críticos com selo de hash-chain íntegra; um evento adulterado quebraria a
  verificação (mostrar o status da chain). Marcado como evidência técnica.
- **Aceite:** a trilha mostra o status "chain íntegra"; a árvore causal (parentEventId) é navegável.
- **Dep:** GUI-AC1. **Tam:** M.

### GUI-AC4 — Incident detail (Sentry-grade)
- **O quê:** resumo/impacto, frequência/afetados, timeline, breadcrumbs, trace, worker/modelo/
  commit suspeito, regressões/releases correlacionados, owner, comentários/decisões, mitigação/
  rollback, evidência de resolução.
- **Referência:** Sentry (issue details — a captura oficial da ref §10).
- **Fonte de dado:** `escalations`, breaker files, events, `records`.
- **Toca:** componente compartilhado com GUI-OP5.
- **Design:** progressive disclosure (GUI-X1): resumo→timeline→trace→evidência.
- **Aceite:** um incidente abre com timeline + trace + o commit/worker suspeito + a mitigação.
- **Dep:** GUI-X1. **Tam:** M.

---

## 11. Ordem de execução (fases) e dependências

Segue a ordem da ref §16, mas com a **Fundação (GUI-F) e o Shell (GUI-SH) primeiro** — sem eles,
todo domínio vira design ad-hoc (o que gera o "genérico" que o owner quer evitar).

| Fase | Itens | Porquê nesta ordem |
|---|---|---|
| **0 — Fundação** | **GUI-F0 (stack React/Vite + pipeline `ui.bat`→`dist/`)** → GUI-F1..F5 | F0 é o item 1 absoluto (habilita tudo + garante o zero-friction do owner); depois os tokens/primitivos. F5 (componentes) é o maior alavancador. |
| **1 — Shell** | GUI-SH1..SH6 + GUI-X1,X3,X4,X5,X6 | a moldura + os padrões transversais; reestrutura as 15 views nos 7 domínios. |
| **2 — Workbench** | GUI-WB1..WB5 | a fachada central, view mais madura — refino primeiro pra provar os padrões. |
| **3 — Operations** | GUI-OP1..OP5 | a dor operacional (workers/workflows/incidents); Temporal-grade. |
| **4 — Experiments** | GUI-XP1..XP4 | comparação+promoção; casa com o registry EXP-* que já existe. |
| **5 — Research** | GUI-RS1..RS4 | fecha o `gui-research-screen` OPEN + `research-run-form`. |
| **6 — Registry** | GUI-RG1..RG6 | model cards + fallback editor + matriz; fecha `config-keys-gui`, `graphs-screen-gui`. |
| **7 — Activity** | GUI-AC1..AC4 | changelog semântico + audit trail (usa a hash-chain que já temos). |

**Regra de dependência (não criar tela sem a fonte pronta):** todo item nomeia a fonte de dado
REAL acima. Onde a fonte não existe (ex.: "all active workflows" list, run-a-run compare de
experimentos), o item é marcado e o gap vira pré-requisito de backend — não se fabrica dado na UI
(measure-honesty). Itens que fecham OPEN existentes (gui-research-screen, config-keys-gui,
graphs-screen-gui, CAP.2, research-run-form, wiki-screen, flow-composer) herdam seus planos atuais.

## 12. Gaps de backend descobertos (pré-requisitos, não itens de UI)

Do fan-out de dados (Sonnet 5): (a) ~~não há verbo "listar todos os workflows ativos"~~ —
**DESATUALIZADO (verify-before-build 2026-07-20): `workflow list` JÁ EXISTE** (JSON com
type/status/phase/counts/token-audit por WF) — OP1/OP3 consomem direto. (b)
Experimentos não expõem compare run-a-run além dos campos do registry — GUI-XP2 precisa de um
gap de dado OU se limita ao que o registry tem. (c) Policies estão espalhadas em
`.harness/routing/*.json` sem um verbo único — GUI-RG5 lê os arquivos direto por ora.
(d) ~~events.jsonl sem API~~ — **FECHADO 2026-07-20**: `GET /api/events` (tail redigido,
filtros event/workflow; `ui_events.py`; amendment no spec m5) — WB5 pleno + OP3 drill
desbloqueados.

## 13. Rastreabilidade (visão → item → fonte → arquivo)

Cada card acima já traz: Referência (visão) → Fonte de dado (verbo/arquivo real) → Toca (arquivo
+ seção do PAGE) → Aceite. Os specs existentes (SPEC-104/114/133/134/135/136, panel-*) NÃO são
re-planejados: os itens que os tocam ESTENDEM o spec via SPEC-116 (door/amendment), nunca
reescrevem. Novos itens sem spec entram por SPEC-116 intake.

