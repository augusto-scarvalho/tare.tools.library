# Design System — SIGNAL (lei de UI)

> **Isto é LEI de UI, não sugestão.** Todo implementador que CRIA ou MODIFICA tela do harness segue
> este documento. Destilado dos padrões PROVADOS end-to-end (fundação F0-F5 + tema SIGNAL + shell
> SH1/SH6/SH3/SH4 + o exemplar Operations) — D024/D025/D026/D028. Onde este doc e o código divergem,
> o código canônico (`ui/src/theme/tokens.css`, `ui/src/components/`) vence e este doc se corrige.
>
> **Supersede** o design system do painel VANILLA (`scripts/harness_ui_page.py`), preservado em
> `docs/DESIGN_SYSTEM_LEGACY.md` — que ainda governa o `/` (fallback) até o React chegar em paridade
> (D025). Novas telas = React/SIGNAL (`ui/`, servido em `/next`). NÃO estilize telas novas pela lei legada.

## 0. As 5 leis inegociáveis
1. **Anti-slop (D026).** Nada "on distribution". PROIBIDO: Inter, Roboto, Arial, system-ui como fonte
   de marca, Space Grotesk, gradiente roxo-em-branco, layouts previsíveis, card-soup. Se parece com
   um dashboard genérico de IA, está errado.
2. **Token-driven.** Toda cor/fonte/tamanho vem de um TOKEN por NOME (`var(--accent)`). ZERO hex/px
   de cor fora de `tokens.css`. Um componente novo que precisa de um valor que não existe → ESCALE,
   não invente.
3. **Compõe primitivos, não escreve CSS.** Telas de domínio compõem os primitivos F5 + F4. CSS novo
   só pra LAYOUT de composição (flex/grid com tokens de espaço) — nunca cor/tamanho novo.
4. **GUI-writes-no-state.** A GUI é VIEW + gatilho ALLOWLISTADO. Todo botão que muta faz `POST`
   numa superfície de escrita SANCIONADA do servidor: `/api/action` (registry de verbos gated) ou
   `/api/chat/*` (os verbos do próprio chat runtime — send/stop/new/close, HITL-gated no servidor;
   sancionado 2026-07-20 com o primeiro chat React nativo, WB-α). Exceção READ-SHAPED: `/api/lint`
   e `/api/format` são POST por transporte (corpo grande) mas NÃO escrevem nada server-side
   (SPEC-147 inv 9/v3 — ruff sobre stdin, retorno puro; sancionado 2026-07-22 com o primeiro IDE
   React nativo, Onda 6). O princípio é "NUNCA um caminho de escrita inventado no browser", não
   "uma URL única". localStorage só pra estado de UI (largura de painel), try/caught.
5. **Zero-friction + offline.** `ui.bat` serve o `ui/dist/` PRÉ-BUILDADO commitado — sem npm/rede/env
   no clique do usuário. Nada de CDN/Google Fonts: tudo bundlado (fontes @fontsource, framer-motion).

## 1. A estética SIGNAL (o caráter)
Instrumento / mission-control pra agentes autônomos — osciloscópio, telemetria, phosphor, medição.
- **Warm-black + lime dominante.** Fundo near-black QUENTE olivado; accent DOMINANTE lime-fósforo;
  live/stream teal. Dominante-escuro + accent AFIADO, nunca paleta tímida distribuída.
- **Mono-forward.** IBM Plex Mono é a fonte de UI (dados/labels/nav/headings); IBM Plex Sans só prosa.
- **Atmosfera, não cor sólida.** Vinheta radial no body; scanlines de instrumento (`.atmo`) no canvas;
  ticks de medição; `.live-edge` (glow lime 1px) no painel/aba ATIVO.
- **Cada domínio tem UM momento-assinatura** (D028): um toque de instrumento distintivo, não só
  tabelas. Exemplos: Operations = a telemetry-strip de mission-control (feito); Research = as lanes
  como traços de osciloscópio; Experiments = a compare como leitura de bancada. Anti-slop é obrigação.

## 2. Tokens (a fonte da verdade: `ui/src/theme/tokens.css`)
NÃO redefinir aqui — consultar o `:root`. As famílias:
- **Superfícies (warm-dark):** `--bg-base #0A0B08` · `--surface-1/2/3` · `--surface-hover` ·
  `--border-subtle/border/-strong`.
- **Texto (warm paper):** `--text-primary #EDEEE1` · `--text-secondary` · `--text-muted` · `--text-disabled`.
- **Sinal:** `--accent #CBF23F` (lime — brand/active/selection) · `--stream #45E0C4` (teal —
  live/running) · `--success` · `--warning` · `--danger`. Cada um tem `-bg` (10-18% alpha) + `-border`.
- **Tipografia:** `--font-ui` (=Plex Mono) · `--font-mono` (=Plex Mono) · `--font-prose` (=Plex Sans) ·
  escala `--text-xs..xl` · `--line-ui`.
- **Densidade:** `--h-topbar:52` · `--h-subnav:38` · `--h-row:34` · `--radius-sm/xs` · `--space-1..4`.
- **Contraste:** text-primary sobre surface-1 ≥ AA (é ~15:1). Nunca abaixo.

## 3. Primitivos (a biblioteca: `ui/src/components/`) — COMPOR, não recriar
`Status` (F4: pill/dot/rail, 11 estados, cor+ícone+texto — nunca cor sozinha), `DataTable` (header
32px sticky, row 34px, zebra por BORDA, status-rail), `Row`, `Chip`, `Inspector` (320px, painel
direito por objeto), `KVList`, `MetricTile` (valor mono grande + `tone?` opcional + delta), `EmptyState`,
`Toolbar`, `Drawer` (surface-2, translateX), `Toast`. Kitchen-sinks: `?debug=status` / `?debug=components`.
- **Status:** cor NUNCA sozinha — sempre cor + ícone (forma) + texto (daltônico-safe). Rail = borda-
  esquerda 2px, não fundo. `running`/`stream` pulsa (signal-pulse).
- **MetricTile.tone:** tinta o valor num token semântico (stream/warning/…) — o padrão pra readouts
  de instrumento (a telemetry-strip). Reusar, não recriar.
- Um valor de layout que um primitivo não tem → ESCALE (adiciona ao primitivo numa fatia F5), não
  hardcode na tela.

## 4. Shell (a moldura: `ui/src/shell/`)
- **TopBar** (52px): logo SIGNAL (3 lanes lime/teal/secondary) + 7 domínios (Workbench/Board/Research/
  Experiments/Operations/Registry/Activity) com hash-routing (`#/`), ativo = underline accent inset
  (sem layout-shift) + `⌘K`/env/budget/inbox/avatar.
- **AppShell** (3 painéis): esquerda colapsável | centro (canvas do domínio, `.atmo`) | direita
  (Inspector, escondido sem seleção) + rodapé de eventos. Larguras arrastáveis persistidas.
- **CommandPalette** (⌘K) + **Inbox** (drawer): montam FORA do `<Reveal>` (não entram na cascata).
- **Subnav** (`ui/src/shell/Subnav.tsx`): a barra de subtabs por domínio; ativo = `.live-edge`.
- **Uma tela de domínio** = `App.tsx` roteia `active===<domain>` → `<DomainScreen/>` no `center` do
  AppShell, publica o Inspector no slot direito na seleção. Ver `domains/operations/` como o TEMPLATE.

## 5. Motion (framer-motion — `ui/src/shell/Reveal.tsx`)
- **UM momento orquestrado:** o page-load em cascata (logo → nav L→R → painel), `staggerChildren`.
  Não animar cada re-render depois.
- **Respeitar `prefers-reduced-motion`** SEMPRE (`useReducedMotion` no Reveal; o guard CSS em global.css).
- Overlays (palette/drawer/toast) montam FORA do Reveal. NÃO quebrar a cascata ao mexer no shell.
- **Tira que CORRE (marquee) — só quando não cabe (dono 2026-07-31).** Numa caixa de largura FIXA,
  conteúdo que transborda pode correr em laço contínuo em vez de ser cortado, sob quatro condições,
  todas obrigatórias: (1) **só corre quando a MEDIÇÃO diz que não cabe** — cabendo, zero animação e
  zero cópia no DOM; (2) o laço emenda com uma **cópia `aria-hidden`** (uma leitura só pra quem usa
  leitor de tela) e anda exatamente a largura de UMA lista, senão a emenda salta; (3) **hover pausa**
  — sem isso não dá pra parar num item pra ler o tooltip; (4) **`prefers-reduced-motion` desliga**, e
  aí o conteúdo inteiro continua alcançável PARADO em outro lugar (gaveta/tooltip), nunca só em
  movimento. A duração sai da largura MEDIDA (px/s), nunca de um número escolhido à mão.
- `running`/`stream` pulsa como sinal vivo. Glow só em ativo/stream, nunca decoração.

## 6. Dados & honestidade
- **Dado real ou `—`.** Toda métrica/célula vem de um GET REAL (`/api/state|queue|worker|metrics|
  experiments|…`); campo ausente = `—`. **ZERO número fabricado** (measure-honesty, o DNA do harness).
- **DERIVADO ≠ FABRICADO (v2, dono 2026-07-31).** Existe uma terceira categoria entre "o vendor
  disse" e "inventamos": um número CALCULADO a partir de duas medições reais. Ele é PERMITIDO —
  o gasômetro do codex precisa dele porque o vendor publica só a janela semanal — mas só sob as
  quatro condições abaixo, TODAS obrigatórias. Sem uma delas, é fabricação e volta a ser proibido:
  1. **marcado onde aparece** — asterisco (ou marca de atenção equivalente) colado ao número, em
     registro tipográfico distinto do dado publicado (itálico/`--text-muted`; NUNCA um token de
     cor ou tamanho novo — lei 2 continua valendo);
  2. **explicado no hover**, nunca em textão inline ao lado do dado: o tooltip carrega a fórmula
     COM os números que entraram nela e a premissa que a sustenta;
  3. **de que ele é fatia** fica dito — um derivado que não declara seu denominador é um número
     solto, e um rótulo tipo "5h 93% left" quando o vendor nunca declarou cota de 5h é MENTIRA,
     não aproximação;
  4. **perde para o real** — no instante em que o vendor publica a janela verdadeira daquela
     duração, o derivado some; não existe caminho de código onde os dois renderizam juntos.
  Um slot sem dado NÃO vira derivado por conveniência: ele é desenhado como lacuna explícita
  (`n/p`), visualmente distinta de `0%` — que lê como "esgotado" e seria a mentira oposta.
- **A LACUNA TAMBÉM É UMA AFIRMAÇÃO (dono 2026-07-31).** `n/p` diz "essa medição existe e o
  vendor não a publicou". Onde a medição NÃO EXISTE — uma API de inferência não tem janela de
  cota e nunca terá — desenhar a lacuna inventa uma ausência: lê como "ainda não disse" um fato
  que é "não há o que dizer". Ali o objeto não é medidor, é linha de ALCANCE (registro próprio +
  a frase do próprio probe). Padronizar forma só vale DENTRO da mesma classe de coisa medida, e
  a classe vem do transporte/origem do dado, nunca do nome do item.
- **Fetch resiliente:** `Promise.allSettled` — uma fonte que falha degrada pra vazio, não derruba a
  tela. Compartilhe fetches entre componentes (não double-fetch o mesmo endpoint no mesmo mount).
- **Ações:** só verbos ALLOWLISTADOS existentes (ex.: `workflow-cancel`); onde não há verbo →
  botão DESABILITADO + `TODO`, nunca inventar verbo nem número.
- **`/` = painel vanilla** até o React chegar em paridade (D025); o React fica em `/next`. Não regredir o `/`.

## 7. Checklist de PR (todo item GUI passa por isto)
- [ ] Só compõe F5/F4 + shell; CSS novo só layout com tokens (grep: nenhum hex/px de cor fora de
      tokens.css/status.css/components.css).
- [ ] Dado real ou `—`; zero fabricação; ações só allowlisted (ou disabled+TODO).
- [ ] GUI-writes-no-state (nenhum caminho de escrita novo); `/` segue vanilla.
- [ ] SIGNAL Reveal preservado; `prefers-reduced-motion` respeitado; overlays fora do Reveal.
- [ ] Offline: `grep -rIE "googleapis|gstatic|cdn" ui/dist` vazio; sem deps de rede em runtime.
- [ ] Build `npm run build` (tsc+vite) DETERMINÍSTICO (2 builds = hashes idênticos); `ui/dist/` commitado.
- [ ] Mojibake sweep limpo; footprint só em `ui/` (backend `/api/*` inalterado).
- [ ] Servido de verdade (`.venv` harness_ui) — a tela renderiza, `/next` React, `/` vanilla.
- [ ] O domínio tem seu momento-assinatura (D028); não é card-soup genérico.
- [ ] Peças interativas (roteamento/palette/inbox/ações) ou de risco → reckon Sonnet consolidado.

## 8. Processo (como o loop de GUI opera)
Overseer desenha o spec pixel-preciso (zero latitude estética — o Opus transcreve); implantador Opus
xhigh implementa (não commita); overseer faz own-review + reckon Sonnet nas peças de risco; gate
`validate --staged`; overseer commita. Cada tela cita a fonte de dado real + passa o checklist §7.

## Referências
Plano completo: `docs/GUI_IMPLEMENTATION_PLAN.md`. Specs pixel-precisos: `.harness/handoff/plan-gui-*.md`.
Estética: `docs/research/sources/harness_web_gui_dark_references.md` + D026. Legado (painel vanilla `/`):
`docs/DESIGN_SYSTEM_LEGACY.md`. Decisões: D024 (stack React/Vite + ui.bat), D025 (`/` vanilla até
paridade), D026 (SIGNAL), D028 (este rulebook).
