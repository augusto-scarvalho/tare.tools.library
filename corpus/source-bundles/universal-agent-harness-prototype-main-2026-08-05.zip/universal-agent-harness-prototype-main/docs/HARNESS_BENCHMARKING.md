# Harness benchmarking plan

The reusable template declares benchmark metrics but does not ship provider-specific benchmark scores. Scores are only meaningful in the adopting repository with its provider credentials, project tests, representative tasks, and cost model.

## Core metrics

- success rate by workflow type;
- p50/p95 latency;
- total and per-stage token use;
- retry rate;
- rate-limit/auth/quota failure rate;
- coordination failure rate;
- reducer quality and conflict count;
- generated task/action acceptance rate;
- rollback and cleanup success rate.

## Baseline runs

Start with local fixtures only:

```bash
python scripts/harness-test.py --fixture token-budget
python scripts/harness-test.py --fixture workflow-soak
python scripts/harness-test.py --fixture provider-canary
```

Then add provider-backed benchmarks as separate downstream jobs once live provider canaries are stable.
