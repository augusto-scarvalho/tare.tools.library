# Draft upstream issue — openai/codex

**Title:** `codex exec --json`: include file-change content (unified diff) in `file_change` items, behind an opt-in flag

## Summary

The experimental JSONL surface (`codex exec --json`) reports `file_change` items
as `{changes: [{path, kind}], status}` only. The underlying protocol already
carries the full payload — `FileChange::Add{content}`, `Delete{content}`,
`Update{unified_diff, move_path}` on `PatchApplyBegin/End` — but the exec event
processor drops it:

- `codex-rs/exec/src/exec_events.rs` — `FileUpdateChange { path, kind }`
- `codex-rs/exec/src/event_processor_with_jsonl_output.rs` — maps
  `PatchChangeKind::Update { .. }` discarding the diff

## Why it matters

Headless integrations that render agent activity (dashboards, chat panels, CI
summaries) need to show the user *what changed* as it happens. Today they must
re-derive diffs out-of-band (snapshot + difflib, or `git diff`), which races the
apply and duplicates work the CLI has already done. The app-server surface
exposes the payload (v2 `FileUpdateChange.diff`, `turn/diff/updated`), but that
transport is a much heavier client contract than consuming exec JSONL.

## Proposal

An opt-in flag (e.g. `--include-file-change-details`) or config key that makes
exec's `file_change` items carry the per-change payload the protocol already
has: `diff` for updates, `content` for add/delete. Default output stays
byte-identical.

## Environment

codex-cli 0.144.4 (Windows), reproduced against `main` sources on 2026-07-17.
