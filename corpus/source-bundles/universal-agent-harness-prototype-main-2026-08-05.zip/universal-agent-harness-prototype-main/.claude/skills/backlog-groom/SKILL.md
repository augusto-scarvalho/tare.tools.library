---
name: backlog-groom
description: Periodic backlog/spec archaeology — mine code/chats/plans with cheap workers, audit their claims, triage escapes into the intake queue, consolidate into specs+checks. Use for "penteada no backlog", pre/post-sprint grooming, or "o que escapou das specs?".
---

Follow the canonical playbook at `.harness/prompts/backlog-groom-playbook.md`.

Summary of the flow (the playbook is authoritative):
1. **Mine** — background Sonnet-class docs-writer per corpus slice (code/git,
   conversations, plans) writing DRAFT reports to `docs/spec-recovery/`.
2. **Audit** — mandatory orchestrator pass: verify every H/M claim against
   primary sources; live-code-behavior claims are untrusted until read.
3. **Triage** — walk the audited top-10 with the owner via
   `harness.py intake add` / `intake decide`.
4. **Consolidate** — SPEC-116 doors + scenario checks in bounded batches;
   annotate the CLOSED log in `docs/spec-recovery/INDEX.md`.
