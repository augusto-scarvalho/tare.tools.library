---
name: research
description: >
  Evidence-driven Double Diamond research for the harness: prospecting options,
  investigating trade-offs, running an ideation round, or a "what should we adopt
  from X" study. Use when the user says pesquisar, prospectar, investigar opções,
  rodada de ideação, deep research, ou "o que devemos adotar de". Diverge before
  converge, separate generation from critique from decision, never fabricate a
  source.
---

# Research skill (Double Diamond orchestrator)

Read the canonical playbook `.harness/prompts/research-playbook.md` and follow it
exactly. You are the ORCHESTRATOR, not a worker: you frame the question, drive the
harness fork-join/map-reduce waves, and synthesize — you never fabricate a source
(claim -> source + date + confidence; unverifiable = `judgment`).
