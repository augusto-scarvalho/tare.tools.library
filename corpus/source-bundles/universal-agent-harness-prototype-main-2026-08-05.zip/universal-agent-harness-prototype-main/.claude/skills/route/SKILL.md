---
name: route
description: Opt-in /route dispatcher (SPEC-144) -- classify ONE demand with the cheap router (single-demand form is read-only classify + brief + spawn command), or drive the conductor-B loop (--loop, owner-tokened) that EXECUTES the route -- dynamic fan-out, analysis lane, or the confined write choreography -- through the apply-merge + SPEC-137 gates. Use when the owner wants to triage or dispatch demands through the two-tier router.
---

Opt-in surface for the two-tier router (SPEC-144). It is ADDITIVE and reversible:
not calling `/route` leaves today's inline flow byte-identical (invariant 1).

Run: `python scripts/harness.py route "<demand>"` (or `--task "<demand>"`).

What the single-demand form does (read-only):
1. **Deterministic floor** -- reuse `intake_triage`/`classify` for profile + risk
   flags + covered-doc handles (no heavy file reads).
2. **Route decision** -- exactly one of `dynamic-workflow | pre-defined-profile |
   inline` + an inline-vs-delegate hint + escalation. A security/risk flag forces
   escalation regardless of the triage verdict; ambiguous triage escalates rather
   than guessing (invariant 2). The loop's live triage runs the `router` role
   (Sonnet 5 high, dieted session); the single-demand form uses the placeholder.
3. **Compact brief** -- demand + chosen route + covered-doc HANDLES + inline hint,
   NO file-content dumps (invariant 5).
4. **Dispatch command** -- the specialized-overseer spawn command via
   `spawn_command`, PRODUCED not executed (conductor A). `inline` -> no spawn.
   Add `--dispatch` to EXECUTE it DETACHED (log under `.harness/runs/`, pid
   printed; the routed profile is honored, the generic stub refused, escalations
   withheld to the decision inbox) -- owner decision 2026-07-15; `--loop` ignores it.

## Phase 3 (opt-in): `--loop` + `--heartbeat`

`--loop` runs the non-interactive conductor-B driver -- it drains the intake feed
(`intake list`) one demand at a time and, per demand: live-triages via the `router`
role, then EXECUTES the route (SPEC-144 v3):

- `dynamic-workflow`: the plan-worker may return a `branches` decomposition; when it
  passes the deterministic branch gate (2..4, disjoint modify, inside the union
  footprint) the implement stage fans out N confined workers in ONE feature-delivery
  workflow; otherwise single-worker fallback.
- `pre-defined-profile` naming a read-only profile: the ANALYSIS lane runs that
  workflow (findings, never writes); reduce done advances the queue.
- `inline` / everything else: read-only plan-worker -> deterministic footprint gate ->
  confined implement-worker -> apply-merge (gates `scenarios` + `spec-pack`, both
  rollback flags HARD-CODED) -> commit through the SPEC-137 stamp gate.

```
python scripts/harness.py route --loop --dry-run                       # read-only rehearsal (no model/writes)
python scripts/harness.py route --loop --approve-writes <TOKEN> --max-demands 1   # owner-gated, one demand
python scripts/harness.py route --loop --only <entryId> --approve-writes <TOKEN>  # ONE targeted demand
```

- **Token**: writes need `--approve-writes <TOKEN>`; the driver has NO default token.
  Omit it (or pass `--dry-run`) for a read-only run.
- **Bounds**: `--max-demands` (default 5), `--max-failures` (default 2, consecutive
  dispatch failures), the stop sentinel `.harness/state/route-loop.stop` (checked
  between demands), and an empty actionable feed. The loop SKIPS the SPEC-116
  "no behavior change -> no artifact" class (model triage `skip:true` -> `intake
  decide <id> discard`).
- **Safety**: the confined worker never commits; the driver asserts a clean
  `git status --porcelain` before Stage I and before apply-merge; a footprint that
  touches protected files / `.harness/state` / `.git` / `tools/git-hooks` or exceeds
  20 paths is refused and escalated, independent of any model verdict; a gate
  rollback means no commit and a clean tree.

`--heartbeat` prints `{shouldResume, pendingActionable, stopRequested, loopRunning}`
and NEVER spawns -- it only tells the session agent whether to re-invoke `--loop`
once. Resume is true only when the feed is actionable AND no stop sentinel AND no
live loop lock (`.harness/state/route-loop.lock`).

The model-driven router follows `.harness/prompts/router-playbook.md` (its rulebook).

See `.harness/handoff/plan-route-phase3.md` and `specs/40-features/route-dispatcher.md`
(SPEC-144) for the full plan.
