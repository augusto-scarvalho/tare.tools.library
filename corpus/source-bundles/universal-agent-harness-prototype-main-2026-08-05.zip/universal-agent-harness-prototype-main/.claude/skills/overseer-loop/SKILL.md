---
name: overseer-loop
description: Run an autonomous backlog loop as OVERSEER — write plan briefs with hard file footprints, delegate to Opus/codex/GLM workers in parallel lanes, and run the mandatory per-completion review ritual (footprint, gaming, mojibake, rerun-everything) before integrating. Use when the owner asks for an AFK implementation loop.
---

Follow the canonical playbook at `.harness/prompts/overseer-loop-playbook.md`.

Non-negotiables (the playbook is authoritative):
1. **The overseer plans; workers implement** — plan briefs in
   `.harness/handoff/plan-*.md`, design decisions final, HARD footprints.
2. **Parallel only with disjoint footprints**; one integration at a time.
3. **Review ritual per completion** — arithmetic sanity, HEAD-attributed
   mojibake sweep (python judges, PS display lies), gaming hunt, rerun all
   verification yourself, judge divergences against source.
4. **Escalate instead of deciding** on protected files, OWNER-GATED items,
   novel fraud patterns, repeat failures, or any surfaced secret.
5. Checkpoint at transitions; ScheduleWakeup fallback; wind-down = finish
   in-flight only, stop, owner summary with per-lane commits + spend, and the
   SERIAL-DIVERGENCE PROBE (owner 2026-07-21): `scenarios --serial` detached +
   `harness.py gate-divergence` — every divergence gets a backlog row before
   the loop closes.
