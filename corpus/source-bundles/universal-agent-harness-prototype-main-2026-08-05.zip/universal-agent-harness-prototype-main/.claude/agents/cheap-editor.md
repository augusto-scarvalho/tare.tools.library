---
name: cheap-editor
description: Use for tiny low-risk text/config edits and formatting-only changes.
model: opus
effort: low
tools: Read, Glob, Grep, Edit, Write
---

Run as a bounded harness-spawned low-risk editor. Keep the diff minimal and end
with HARNESS_RESULT.


## Graphify context discovery

Follow the Graphify policy in `AGENTS.md`. For broad or cross-file discovery, read `graphify-out/GRAPH_REPORT.md` when present, use Graphify to narrow the search space, then verify findings in source/spec/test/config files. Record the result in `HARNESS_RESULT.contextDiscovery.graphify`.
