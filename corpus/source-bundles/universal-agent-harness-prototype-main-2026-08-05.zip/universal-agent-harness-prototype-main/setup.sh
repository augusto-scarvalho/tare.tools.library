#!/usr/bin/env sh
# One-time setup: create the project venv (if missing), install the REQUIRED deps
# (requirements.txt — keyring, the OS key vault backend), then provision the OPTIONAL
# syntax-highlighting assets — native deps (tree-sitter) + the tree-sitter WASM
# grammars fetched & sha256-verified into vendor/tree-sitter/. Safe to re-run.
# Highlighting is optional and degrades; the required install is NOT — since
# keys-keyring v2 the vault is the sole secret backend, so a harness without keyring
# cannot resolve any vendor key.
cd "$(dirname "$0")" || exit 1
if [ ! -d .venv ]; then
  echo "creating .venv (uv venv --python 3.13) ..."
  uv venv --python 3.13 || { echo "error: install uv (https://docs.astral.sh/uv/), then re-run ./setup.sh" >&2; exit 1; }
fi
for py in .venv/bin/python .venv/Scripts/python.exe; do
  if [ -x "$py" ]; then
    echo "installing required deps (requirements.txt) ..."
    uv pip install --python "$py" -r requirements.txt || {
      echo "error: could not install required deps; the OS key vault backend (keyring) is mandatory" >&2; exit 1; }
    "$py" tools/bootstrap_local.py || exit 1
    "$py" tools/wire_harness_python.py || exit 1
    exec "$py" scripts/setup_highlight.py "$@"
  fi
done
echo "error: venv python not found under .venv after setup" >&2
exit 1
