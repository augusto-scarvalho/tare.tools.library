#!/usr/bin/env sh
# Start the harness operator chat REPL (menu appears if no --engine given).
# SPEC-147 zero-touch (extended to chat, keys-keyring v2): a missing venv OR a
# missing REQUIRED dep runs setup first. The dep probe is `import keyring` — the
# sole entry in requirements.txt since the OS vault became the only secret
# backend. Widen the probe if requirements.txt grows.
cd "$(dirname "$0")" || exit 1
_ready=0
for py in .venv/bin/python .venv/Scripts/python.exe; do
  if [ -x "$py" ] && "$py" -c "import keyring" >/dev/null 2>&1; then _ready=1; break; fi
done
if [ "$_ready" -eq 0 ]; then
  echo "[chat] venv or required deps missing — running ./setup.sh first (one-time)" >&2
  sh ./setup.sh || exit 1
fi
for py in .venv/bin/python .venv/Scripts/python.exe; do
  if [ -x "$py" ]; then exec "$py" scripts/harness.py chat "$@"; fi
done
echo "error: project venv still missing after setup; see setup output above" >&2
exit 1
