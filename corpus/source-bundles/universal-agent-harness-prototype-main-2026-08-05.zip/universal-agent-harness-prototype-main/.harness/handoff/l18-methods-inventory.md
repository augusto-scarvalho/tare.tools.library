# L18 — inventário de métodos do manuscrito (miner Sonnet, 2026-07-18)

Fonte: docs/research/sources/adaptive-project-oriented-multi-agent-harness-architectures.md
(linhas citadas por método). Bibliografia verbatim no report do miner; refs [N] abaixo.

## DESIGN

| Método | Linhas | Framing do manuscrito | Uso | Refs |
|---|---|---|---|---|
| Taguchi robust parameter design (controle×ruído, R(θ)) | 1178-1185, 1662, 1671, 2018 | separação de fatores controláveis vs ruído; busca por baixa sensibilidade (não exige S/N ratio) | configs insensíveis a regimes de ruído registrados | [138-146; 140 Box/Bisgaard/Fung 1988 QREI] |
| Robust loss R(θ)=E[L]+κ√Var | 1180-1185 | perda esperada + instabilidade | otimização robusta | — |
| Fatoriais completos/fracionados | 1660-1670, 1959, 2016, 2020 | OFAT não estima interações | efeitos principais + interações | [138; 139 Box&Wilson 1951 JRSS-B; 141] |
| Plackett-Burman screening | 1660, 1669, 2620 | screening econômico de efeitos principais | muitos fatores sob budget | [138 Plackett&Burman 1946 Biometrika] |
| Definitive Screening Designs | 1660-1663, 1669, 2623 | 3 níveis separam 2ª ordem | screening + curvatura | [141 Jones&Nachtsheim 2011 JQT] |
| Response-surface | 1661, 1669 | modelar região local promissora | refino em região qualificada | [139] |
| Split-plot / blocked factorial | 1663, 1681, 1758 | fator caro de trocar = whole-plot | provider/model snapshot | [142 Jones&Nachtsheim 2009 JQT] |
| Morris screening (elementary effects) | 1675, 1777, 2625 | sensibilidade global barata | pré-triagem | [143 Morris 1991 Technometrics] |
| Sobol / variance-based sensitivity | 1675, 1777, 2626-2627 | índices de variância sob distribuição registrada | sensibilidade em surrogate | [144 Sobol 2001; 145 Saltelli 2010] |
| CALIBRA (fracionado + busca local) | 1198, 1671, 2628 | Taguchi-style + local search | tuning de algoritmo | [146 Adenso-Díaz&Laguna 2006 OR] |
| Covering arrays / AETG t-way | 1156, 1664, 1673, 1871, 2629 | tuplas cobertas + suspeitos reproduzíveis | interações combinatórias (não causal) | [147 Cohen et al. 1997 IEEE TSE] |
| Auto algorithm configuration (ParamILS, irace, OpenTuner, Hyperband/BOHB, Vizier, Ax, CherryPick, SelfTune, OPPerTune) | 1198, 1665, 2630-2640 | busca em espaços categóricos/condicionais/caros | estágio refine/optimize | [148-158] |
| Safe/constrained Bayesian optimization | 1200, 1666, 2647-2649 | exploração dentro de região viável determinística | R0/R1 + canários R2 | [165 SafeOpt ICML15; 166 Berkenkamp ML23; 167 Gelbart UAI14] |
| Racing (irace-style) | 1157, 1192, 1665 | alocar avaliações a promissores | refino | [150] |
| Randomização/blocos/réplicas | 1679, 1683, 1758, 1954 | run order/caches/warm-up = proveniência 1ª classe | integridade confirmatória | [173 Mytkowicz ASPLOS09; 174 Kalibera&Jones ISMM13; 175 Duplyakin ATC23] |
| Matched-budget/token controls | 319, 490, 1603, 2668 | claim multi-agente exige baseline single igual-budget | anti-confound de compute | [186 arXiv:2604.02460] |
| Não-inferioridade (margens δ_Q) | 1230, 1974, 1996, 2012-2033 | bound de não-regressão de qualidade | série H de hipóteses | — |
| Self-driving lab loop | 1877, 2658-2660 | hipótese→experimento→medição→decisão governada | analogia do EDC | [176-178] |

## INFERÊNCIA / MEDIÇÃO

| Método | Linhas | Uso | Refs |
|---|---|---|---|
| Modelos hierárquicos/mixed-effects (GLMM) | 1751-1758 | efeitos task/projeto/época | — |
| Logístico/beta-binomial; survival; ordinal; multivariado/Pareto | 1758-1773, 1856-1859 | endpoints por tipo | — |
| Nested/crossed random-effects (cross-vendor) | 1762-1769 | comparação vendor×harness | [180, 195-201] |
| Bootstrap CIs; Wilcoxon pareado; Mann-Whitney; ANOVA | 1773, 1969 | suporte inferencial | [159] |
| ECE (calibração ≤0.05) | 1085, 1222, 1773 | gate de calibração de router | — |
| Confidence sequences time-uniform / alpha-spending | 1237, 1781, 1870, 2650 | monitoramento anytime-valid de canary/shadow | [168 Howard et al. AoS21; 169 Johari et al. OR22] |
| Estimadores adaptativos/off-policy | 1781, 1833, 2652-2654 | logs de bandit/racing/BO | [170 Hadad PNAS21; 172 Karampatziakis ICML21] |
| HCOPE | 1092, 1828 | avaliação offline de routing | [83 Thomas&Brunskill ICML16] |
| Contextual bandits | 341, 1065, 2564, 2582 | política de routing por projeto | [82 Li WWW10; 100 AAAI26] |
| Reusable holdout / adaptive data analysis | 1210, 1677, 1833, 2653 | separação descoberta/confirmação | [171 Dwork Science15] |
| Pré-registro | 73, 640, 1783, 2570 | predição vs postdição | [88 Nosek PNAS18] |
| MDE / power por simulação (80%) | 1679, 1683, 2115 | tamanho de amostra | — |
| Partições discovery/confirmation/promotion + sealed holdouts | 1170, 1210, 1677, 2062 | governança anti-overfitting | [171] |
| Graus de evidência exploratory/attributive/confirmatory/promotion-qualified | 3046-3053 | força de evidência p/ promoção | — |
| Confirmation gap G_conf = Δ_discovery − Δ_sealed | 1743-1747 | overfitting adaptativo detectado | — |
| Route regret; CTS; TCO decomposto | 1710-1720, 1839-1844 | métricas econômicas | — |
| OracleRecall/CoFailure/Δ_m/Shapley aprox.; β_C | 386-392, 1722-1737, 2036 | valor de diversidade paralela; teto de ensemble | [101 arXiv:2606.27288] |
| Regra lexicográfica / otimização robusta restrita | 1848-1859 | decisão de promoção do EDC | — |
| Estimandos causais/ATE; graus de replay (causal/off-policy/diagnóstico) | 1815-1831 | o que conta como evidência causal | [83, 172] |
| Noise floor de infraestrutura (controles pinados repetidos) | 1789, 2008, 2614 | variância baseline | [132 Anthropic 2026] |
| A_ctx/D_ctx/used-context ratio | 988-1011 | economia de contexto | [181-186, 205, 207] |

## QUALIDADE DE JUIZ / REVIEW

| Método | Linhas | Uso | Refs |
|---|---|---|---|
| Oracle tiers O1-O5 (testes, verificação formal, expert cego, painel de rubrica cego, judge calibrado) | 1797-1811 | governança de validadores | — |
| Auditoria de viés de LLM-judge (posição/verbosidade/auto-preferência) | 1809-1811, 2395 | O5 auditado vs O3/O4 | [130 AACL-IJCNLP25] |
| Acordo inter-avaliador (kappa/alpha/ICC ≥0.70) | 1809, 2202 | confiabilidade humana/rubrica | — |
| agent_reported vs oracle_observed (desacordo é métrica) | 1811, 2010, 2114 | anti-auto-relato | [126-131] |
| Grading do estado final do ambiente | 1811, 2013 | avaliação de agentes | [131 Anthropic 2026] |
| Policy mutation testing | 1341 | enforcement de propriedades formais | — |
| Model-based testing / BMC / fault injection (DGIOTS) | 1331, 1888-1897, 2060 | conformance do kernel | [222-232] |

## ARQUITETURA / PROCESSO

| Método | Linhas | Uso | Refs |
|---|---|---|---|
| Kitchenham&Charters SLR; Wohlin snowballing; PRISMA 2020; multivocal A-E | 79-105, 2331 | metodologia da síntese | [9, 10, 11] |
| DSR Hevner + processo Peffers | 83 | eixo de construção | [7, 8] |
| ATAM (24 cenários) | 83, 2147-2176 | trade-offs de arquitetura | [13 SEI] |
| GQM | 83, 2393 | objetivos→questões→métricas | [12 Basili 1994] |
| Maturity assessment (Becker; scoring 0-3; M0-M7 cumulativo) | 2178-2202 | modelo de maturidade | [90 Becker 2009 BISE] |
| Human studies counterbalanced within/between | 1760, 1885 | Study H (AHHI) | — |
| Crash/fault injection em toda fronteira | 805, 1339, 2378 | runtime durável | — |
| Refinement checking (soundness/obligation coverage) | 1331, 1899 | Study L formal | [222-232] |
| Threat modeling data-centric; SLSA; in-toto | 1387, 1401 | segurança/supply chain | [85, 86, 87] |

## NOT FOUND (checado pelo miner)

- median/MAD nomeados (robust stats clássica) — o manuscrito usa "robust design"
  no sentido Taguchi; nosso noise floor usa MAD por escolha própria.
- dual screening aplicado — citado só como limitação disclosed (l.85).
- algoritmo de Shapley detalhado — só "approximate ... when economically
  feasible" (l.1737).
