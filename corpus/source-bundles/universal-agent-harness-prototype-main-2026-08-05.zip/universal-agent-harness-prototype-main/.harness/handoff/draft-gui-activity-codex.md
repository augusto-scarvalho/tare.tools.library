# Rascunho de plano — visibilidade de atividade da GUI

**Status:** D1 completo; D2 v1 deliberadamente limitado aos processos observáveis no stream do chat. **Discordo da formulação “todo processo em voo” para v1:** o stream prova chamadas de tool, mas não prova o ciclo de vida de todo worker de workflow nem inventaria processos destacados; prometer isso com backend congelado violaria a lei de honestidade.

## Contrato de aceitação proposto

1. A linha imediatamente acima do textarea mostra uma entre `Thinking`, `Writing`, `Running <tool>`, `Waiting for you`, `Idle`, `Session dead` e `Connection lost`, mais a disponibilidade correspondente.
2. O rail lista cada tool do chat em ordem de início, distingue execução de conclusão por um marco explícito, preserva o transcript e retém conclusões pelo prazo configurado.
3. O rail não chama uma tool de “test” ou “worker” por heurística; exibe somente nome/argumento reais e assume explicitamente os pontos cegos.
4. O rail não cria fetch, endpoint, dependência npm nem escrita de estado do harness; a única configuração persiste como estado de UI em `localStorage`.
5. Reducer self-check, build e dentes Playwright cobrem transições, conclusão, expiração, ordem e sinal colapsado.

## Base verificada e correções do contexto

- O cliente tem um único `EventSource`, com a URL e o parse dos frames concentrados em `openStream`; o reducer puro consome os eventos em `reduce` (`ui/src/api/chat.ts:87-90`, `ui/src/api/chat.ts:133-156`, `ui/src/api/chat.ts:225-318`).
- `question` é emitido imediatamente após uma tool real `AskUserQuestion`; portanto “Waiting for you” é fato de protocolo, não palpite (`scripts/harness_lib/chat_operator.py:790-794`).
- Correção: `Status` aceita somente `pill|dot`; “rail” é a classe CSS `.row-rail`, não uma variante React (`ui/src/components/Status.tsx:37-48`, `ui/src/components/status.css:38-44`).
- Correção: não existe `Row.tsx`; o primitivo disponível é a classe `.row` (`ui/src/components/components.css:30-33`). O plano usa essas superfícies reais.
- O relatório Graphify presente indexa AST Python, não TS/TSX; por isso ele foi lido como índice e todas as decisões de UI abaixo foram verificadas diretamente no source (`graphify-out/GRAPH_REPORT.md:1-9`).

## 1. Derivação de fase

**Decisão.** Adicionar ao `TapeState` um `phase: ActivityPhase`; `waiting-user` guarda o `toolId` da última `AskUserQuestion` aberta e `tool` guarda `name` e quantidade de tools abertas. `ready` já é o marcador de ociosidade emitido após cada caminho do loop (`scripts/harness_lib/chat_operator.py:976-980`).

| Entrada/condição | Próxima fase | Texto EN da linha |
|---|---|---|
| estado inicial ou `ready` | `idle` | `Idle · ready` |
| `turn-start` | `thinking` | `Thinking · cannot reply yet` |
| `usage`, `plan`, `plan-steps`, `turn-diff` | sem mudança | mantém a leitura anterior |
| `text`, linha normal ou `err`, sem tool aberta | `writing` | `Writing · cannot reply yet` |
| `tool(name,id)` | `tool(name, openCount)` | `Running <name> · cannot reply yet` |
| `tool-delta(id)` | mantém `tool`; **não conclui** | mantém `Running <name>` |
| `text` enquanto há tool aberta | mantém `tool` | a tool aberta vence `Writing` |
| `question` | `waiting-user(latest AskUserQuestion id)` | `Waiting for you` |
| `tool-result(id)` da pergunta | tool aberta mais recente, senão `thinking` | `Running …` ou `Thinking …` |
| outro `tool-result(id)` enquanto espera pergunta | mantém `waiting-user` | `Waiting for you` |
| `tool-result(id)` normal | tool aberta mais recente, senão `thinking` | `Running …` ou `Thinking …` |
| `turn-end` | `writing` | `Writing · cannot reply yet` enquanto o flush final chega |
| `exit` | `dead` | `Session dead · unavailable` |

Prioridade quando fatos coexistem: `dead > waiting-user > tool aberta > writing > thinking > idle`. O flush após `turn-end` existe como frames de linha normal, então `writing` até o `ready` é coerente com o transporte (`ui/src/api/chat.ts:237-240`, `scripts/harness_lib/chat_operator.py:1265-1270`).

**Custo.** Mais um campo tipado no estado e um helper pequeno para achar tools sem `doneAt`; nenhum novo protocolo.

## 2. Limite de honestidade

**Decisão.** Não classificar `Bash + /pytest|vitest|gate/` como teste nem `Task/Agent` como worker aguardado. Nome e argumento provam uma chamada; não provam o propósito, o subprocesso real ou sua vida inteira. A linha mostra `Running Bash`; o rail mostra o argumento verbatim (`ui/src/api/chat.ts:268-275`).

`Waiting for you` é permitido porque há evento dedicado; “waiting for agents” só entra numa fase futura baseada em estado real de worker. O `/api/queue` real e seu cliente tipado existem, mas não pertencem ao stream do chat (`scripts/harness_ui.py:1294-1295`, `ui/src/api/operations.ts:30-67`).

**Custo.** A v1 não usa os rótulos desejados “Running tests”/“Waiting for agents” quando eles não são demonstráveis; ganha precisão e perde categorização amigável.

## 3. Dono do estado de fase

**Decisão.** `ui/src/api/chat.ts` possui `ActivityPhase` e atualiza `TapeState.phase` dentro de `reduce`. A view não reconstrói a fase de `blocks`: `question`, `ready`, `turn-start` e `exit` não são todos blocos, e hoje `question` cai no default (`ui/src/api/chat.ts:243-317`).

`WorkbenchScreen` aplica somente fatos que não vêm do reducer: sessão ausente, `alive === false` e erro SSE já existem ali (`ui/src/domains/workbench/WorkbenchScreen.tsx:39-43`, `ui/src/domains/workbench/WorkbenchScreen.tsx:89-94`).

**Custo.** `phase` passa por `WorkbenchScreen → ConversationScreen → Composer`; em troca há uma máquina de estados única e testável.

## 4. Posicionamento e DOM

**Decisão.** A linha vive **dentro** de `.wb-composer`, como primeiro filho de `.wb-composer-input`, imediatamente antes do `<textarea>`. Ela ocupa fluxo normal e empurra o composer; nunca sobrepõe o texto (`ui/src/domains/workbench/Composer.tsx:82-94`, `ui/src/domains/workbench/Composer.tsx:114-135`).

```tsx
<div className="wb-composer-input">
  <div className="wb-phase" role="status" aria-live="polite" aria-atomic="true">
    <Status kind={phaseStatus} variant="dot" label={phaseLabel} />
  </div>
  <textarea className="wb-input" ... />
  <div className="wb-upload-status" aria-live={uploadError ? 'assertive' : 'polite'}>...</div>
</div>
```

```css
.wb-phase{ display:flex; align-items:center; min-height:var(--space-3); }
```

A fase é `polite`: atividade frequente não interrompe digitação/leitura. Não duplica `.wb-upload-status`, que anuncia exclusivamente upload/erro e permanece assertiva só no erro (`ui/src/domains/workbench/Composer.tsx:135-142`). `Status` reutiliza cor + forma + texto e o pulse existente (`ui/src/components/Status.tsx:37-54`, `ui/src/components/status.css:26-36`).

Mapeamento do primitive: `thinking|writing|tool → running`, `waiting-user → blocked`, `idle|no-session → planned`, `dead|connection-lost → failed`. O label customizado mantém a frase de disponibilidade; o kind fornece forma/tom sem criar vocabulário visual.

**Custo.** Uma linha vertical permanente no composer; nenhuma animação ou cor nova.

## 5. Fonte de dados do rail

**Decisão.** V1 deriva **somente** dos `TapeBlock` de kind `tool`, já recebidos pelo único SSE. `WorkbenchScreen` já mantém o tape e não faz poll de queue (`ui/src/domains/workbench/WorkbenchScreen.tsx:41-76`).

Fase posterior, separada: se “todos os workers de workflow” continuar requisito, reutilizar `fetchQueue()` em vez de criar outro cliente; processos destacados ainda exigiriam inventário/backend e ficam fora até haver fonte real (`ui/src/api/operations.ts:65-72`).

**Custo.** V1 mostra tools do chat; não promete workflow workers externos, shells iniciados fora desse chat nem detached spawns.

## 6. Modelo de item do rail

**Decisão.** Acrescentar apenas `doneAt?: number` e `failed?: boolean` ao bloco `tool`; acrescentar `isError?: boolean` a `EvtData`. `tool-result` grava `doneAt = Date.now()` e o erro real; `tool-delta` só concatena output (`ui/src/api/chat.ts:171-175`, `ui/src/api/chat.ts:277-287`, `scripts/harness_lib/chat_operator.py:796-811`).

```ts
type ToolBlock = {
  id: string; kind: 'tool'; ts: number; toolId?: string;
  name: string; arg?: string; input?: string; output?: string;
  doneAt?: number; failed?: boolean;
}
```

Cada row usa `id`, ordinal, `name`, `arg`, `input`, `output`, `ts`, `doneAt`, `failed`; status = `running` sem `doneAt`, senão `failed|completed`. A ordem é a ordem de **início**/inserção no array, nunca a ordem de término.

`output === undefined` é rejeitado como discriminador: um `tool-delta` já torna `output` definido antes da conclusão (`ui/src/api/chat.ts:279-285`). `ts/doneAt` são horários de observação no cliente, não timestamps alegadamente emitidos pelo servidor.

**Custo.** Replays antigos reaparecem pelo grace period contado da recepção do replay; a UI não finge conhecer o instante histórico de término.

## 7. Expiração

**Decisão.** `ProcessRail` arma **um único `setTimeout` para a próxima expiração**; ao disparar, atualiza um tick local, filtra por `Date.now() < doneAt + graceMs` e agenda o próximo. Running nunca expira; não há timer por item nem intervalo ocioso.

Painel rolado ou colapsado não muda a regra: `.shell-left-body` fica montado e só recebe `display:none`, logo o timer continua; se o browser o atrasar, o próximo render filtra pelo relógio atual (`ui/src/shell/AppShell.tsx:80-101`, `ui/src/shell/appshell.css:17-25`).

A expiração remove somente a row derivada do rail. Nunca remove `TapeBlock`: o transcript continua sendo renderizado por `SessionTape` a partir do mesmo array (`ui/src/domains/workbench/ConversationScreen.tsx:27-38`).

**Custo.** Um timer React ativo apenas enquanto existir conclusão visível; nenhum histórico separado do tape.

## 8. Onde “configurável” vive

**Decisão.** `localStorage['harness.workbench.processGraceSeconds']`, default `30`, faixa `5..300`, passo `5`. Controle nativo no cabeçalho: `<input type="number" min={5} max={300} step={5}>` com label visível `Keep finished` e sufixo `s`.

Extrair o corpo numérico de `usePersistentWidth` para `usePersistentNumber` no mesmo arquivo e fazer `usePersistentWidth` delegar a ele; preserva clamp e try/catch já provados (`ui/src/shell/usePersistentWidth.ts:9-40`). Não haverá hook/config framework novo.

**Custo.** Preferência local por browser, sem sync, presets por processo ou escrita server-side; isso está dentro da exceção de estado de UI (`docs/DESIGN_SYSTEM.md:21-30`).

## 9. Rail morto, domínios e colapso

**Decisão.** V1 fica no Workbench conversation/changes. `App` passa `left={wbLeft}` somente quando `route.domain === 'workbench'`, igual ao `leftTop` atual; `hasLeft` continua omitindo aside+gutter sem conteúdo (`ui/src/App.tsx:888-919`, `ui/src/shell/AppShell.tsx:34-40`, `ui/src/shell/AppShell.tsx:75-105`).

Com zero tools, o rail mostra cabeçalho/controle + `<Status kind="planned" variant="dot" label="No recent chat processes" />`; não usa o EmptyState grande. A coluna não é morta porque o `AgentChannelStrip` já ocupa `leftTop` no Workbench (`ui/src/domains/workbench/WorkbenchScreen.tsx:95-115`).

Colapsado, o body some, mas o mini strip já sobrevive por CSS; passar `activeCount` faz o dot pulsante exibir a contagem real (`1`, `2`, …) enquanto há tool aberta (`ui/src/domains/workbench/AgentChannelStrip.tsx:12-40`, `ui/src/domains/workbench/workbench.css:43-48`). Expandir revela nomes/output.

**Custo.** Trocar de domínio esconde e desmonta essa telemetria; fazê-la seguir o owner exigiria elevar sessão/SSE/tape para `App`, refatoração recusada em v1 para não ressuscitar rails vazios.

## 10. Relação entre D1 e D2

**D1:** uma leitura única da fase e disponibilidade **agora**, sem histórico nem detalhe operacional.

**D2:** um registro causal ordenado das tools observadas, com evidência expansível e retenção temporária após conclusão.

**Custo.** Há coerência visual, mas não duplicação: D1 resume o turno; D2 inspeciona processos.

## 11. Anti-slop / momento-assinatura

**Decisão.** O rail é um **traço de execução**, não cards/toasts: ordinal mono + hora observada + `.row-rail`; a cabeça viva usa `Status running`/`--stream`, a cauda assentada usa `completed|failed`, e `<details>` nativo abre input/output. É leitura de instrumento em sequência, sem spinner ornamental (`docs/DESIGN_SYSTEM.md:32-41`, `ui/src/components/status.css:26-44`).

CSS novo limita-se a flex/grid/gaps com `--space-*`, tipografia existente e truncamento; sem nova cor, glow ou keyframe, conforme lei de composição (`docs/DESIGN_SYSTEM.md:16-20`, `docs/DESIGN_SYSTEM.md:78-91`).

**Custo.** Aparência deliberadamente densa/monoespaçada; saída extensa permanece no tape, e o rail mostra apenas o digest já recebido.

## 12. Verificação

**Decisão — `chat.ts:selfCheck()`.** Acrescentar asserts para: `ready→idle`; `turn-start→thinking`; `text→writing`; `tool→running`; `tool-delta` acumula output sem `doneAt`; texto com tool aberta continua `running`; `question→waiting-user`; resultado não relacionado não limpa a espera; resultado correto grava `doneAt/failed`; `turn-end→writing`; `ready→idle`; `exit→dead`. O self-check atual já exercita reducer e tool-result (`ui/src/api/chat.ts:352-393`).

**Decisão — dentes `pw_ui_smoke`.** Adicionar ao driver, seguindo `PWCHECK <id> PASS|FAIL` (`ui/tests/pw-smoke.mjs:34-43`):

- `activity-phase-line`: `role=status`, texto, ordem DOM imediatamente antes do textarea e ausência de overlay.
- `activity-process-rail`: running + completed/failed, ordem de início e disclosure do digest.
- `activity-process-expiry`: TTL mínimo via localStorage; conclusão some e running permanece.
- `activity-collapsed-signal`: mini strip mostra pulse + contagem enquanto o body está oculto.

Adicionar os quatro ids à lista de teeth obrigatórios de `testing/scenarios/pw_ui_smoke.py`, pois hoje ela detecta check apagado do `.mjs` (`testing/scenarios/pw_ui_smoke.py:144-153`). Rodar `npm run build` e `python testing/scenarios/pw_ui_smoke.py`; o design system também exige build determinístico e `/next` real (`docs/DESIGN_SYSTEM.md:124-134`).

**Mutação obrigatória.** Apagar somente `doneAt: Date.now()` do branch `tool-result`: `selfCheck()` deve falhar e `activity-process-rail`/`activity-process-expiry` devem ficar vermelhos. Se não ficarem, o oráculo não protege o contrato.

**Custo.** Cerca de um segundo extra no Playwright para provar expiração; nenhuma suite ou dependência nova.

## 13. O que cortar

**Decisão.** Cortar de v1: poll de `/api/queue`, `/api/worker`, `/api/events`, inventário de detached spawns, regex “pytest = tests”, estado global cross-domain, timers por row, toast, barra de progresso e TTL por tipo. O degrau abaixo que segura é o reducer existente + slot `left` já existente + primitives/CSS existentes + um timer e uma preferência local.

Não corto validação, erro real, acessibilidade, reduced motion ou a distinção `doneAt`: são o piso de honestidade. Também não afirmo que o corte cumpre “todo worker/processo”; essa parte permanece explicitamente **não atendida em v1** até uma fonte unificada existir.

**Custo.** A entrega é a menor versão honesta e útil, não a visão global completa pedida na frase inicial.

## Footprint de implementação proposto

- Estado/prova: `ui/src/api/chat.ts`.
- D1: `ui/src/domains/workbench/Composer.tsx`, `ConversationScreen.tsx`, `WorkbenchScreen.tsx`, `workbench.css`.
- D2: novo `ui/src/domains/workbench/ProcessRail.tsx`, mais `WorkbenchScreen.tsx`, `AgentChannelStrip.tsx`, `ui/src/App.tsx`; `AppShell.tsx` já aceita `left` e não precisa mudar (`ui/src/shell/AppShell.tsx:19-27`, `ui/src/shell/AppShell.tsx:80-101`).
- Preferência: `ui/src/shell/usePersistentWidth.ts`.
- Provas: `ui/tests/pw-smoke.mjs`, `testing/scenarios/pw_ui_smoke.py`.
- Backend, vanilla panel, package manifest e dependências: **inalterados**.
