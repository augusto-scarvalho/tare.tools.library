# DRAFT REQUEST — GUI activity visibility (overseer-owned, plan-role drafted)

You are drafting a PLAN, not writing code. Do NOT edit any file. Output ONE markdown
document to the result path named at the bottom. The overseer arbitrates between your
draft and a second, independent draft, then writes the final brief. Disagree with the
owner's framing where you have evidence; say so explicitly.

## The owner's demand (verbatim, Portuguese)

> nao temos visibilidade de quando o modelo esta pensando, escrevendo, rodando testes,
> esperando agentes. toda a secao "shell-left-body" que hoje esta meio largada poderia
> ajudar a dar melhor visibilidade pra algumas dessas coisas.
> Modelo pensando / executando alguma acao e nao pode te responder no momento, dar
> visibilidade logo acima da caixa de text-area do input do usuario.
> worker rodando, shell rodando, comando em execucao, fica no shell-left-body, por ordem
> de execucao. uma vez que o processo se encerra, a gente da um tempo pro usuario
> inspecionar e depois vai limpando (cada item tem data de expiracao depois que morre na
> gui, configuravel)

Two deliverables, one surface:

- **D1 — PHASE LINE.** Directly above the composer textarea: what is the agent doing
  RIGHT NOW and can it answer. States at least: thinking / writing / running <tool> /
  waiting on you / idle / session dead.
- **D2 — PROCESS RAIL.** In `shell-left-body`: every process in flight (worker, shell,
  command), in execution order. When one finishes it STAYS for a configurable grace
  period so the owner can inspect it, then disappears.

## Pre-assembled context (verified 2026-07-31 by read-only scanners; anchors are real)

### The transport already carries everything

`ui/src/api/chat.ts` — ONE `EventSource` at `GET /api/chat/stream?session=&token=`,
frames `{stream, line, data}`, `stream in 'evt'|'err'|'you'|''`. For `evt`,
`data.event` in:

    ready | turn-start | usage | text | tool | tool-result | tool-delta |
    turn-diff | turn-end | plan | plan-steps | question | exit

The pure reducer `reduce(s: TapeState, f: ChatFrame): TapeState` (chat.ts:226-318) ALREADY
switches on all of these. Current `TapeState` (chat.ts:189-199):

    export interface TapeState {
      blocks: TapeBlock[]
      streaming: boolean
      role?: string
      readyIdentity?: TurnIdentity
      turnIdentity?: TurnIdentity
      turnStart?: number
      closed?: boolean
      plan?: PlanStep[]
    }

Current tool block (chat.ts:174):

    | { id: string; kind: 'tool'; ts: number; toolId?: string; name: string; arg?: string;
        input?: string; output?: string }

Reducer handling of tools (chat.ts:268-288), verbatim:

    case 'tool':
      return { ...s, blocks: [...s.blocks, { id: nid(), kind: 'tool', ts: Date.now(),
        toolId: d.id, name: d.name || '?', arg: d.arg,
        input: d.code || d.diff || d.inputDigest || '' }] }
    case 'tool-result':
    case 'tool-delta': {
      const chunk = d.event === 'tool-delta' ? (d.chunk || '') : (d.digest || d.diff || '')
      let hit = false
      const blocks = s.blocks.map((b) => {
        if (hit || b.kind !== 'tool' || b.toolId !== d.id) return b
        hit = true
        const out = d.event === 'tool-delta' ? (b.output || '') + chunk : chunk
        return { ...b, output: out }
      })
      return hit ? { ...s, blocks } : s
    }

`turn-start` sets `streaming: true`; `ready` and `exit` set it false; `question` currently
falls through `default: return s` (chat.ts:315-316, comment: "usage/turn-diff/plan/question
— not tape blocks"). `selfCheck()` (chat.ts:355-477) is the assert-based test for this
reducer and MUST be extended by whatever you propose.

### Where the phase line goes

`ui/src/domains/workbench/Composer.tsx` — presentational, props
`{ streaming, hasSession, onSend, onStop, onNew }`. Renders `.wb-composer` >
`span.wb-prompt` (gets `.wb-prompt--live` = `signal-pulse` animation while streaming) +
attach button + `.wb-composer-input` > `textarea.wb-input` + `.wb-upload-status`
(an aria-live region already using `<Status kind="running" variant="dot" …>`) +
Send/Stop/new-session button. CSS: `ui/src/domains/workbench/workbench.css:172-198`.

State owner: `ui/src/domains/workbench/WorkbenchScreen.tsx` — holds `tape` (the reducer
state), `sseError`, derives `stateKind` = `(tape.closed || sseError || closed) ? 'failed'
: tape.streaming ? 'running' : 'planned'`, and passes `streaming` down. It also builds the
left column node and hands it up via `onLeftTop(...)`.

### Where the process rail goes

`ui/src/shell/AppShell.tsx:80-101`:

    <aside className="shell-left" data-collapsed={collapsed ? '1':'0'} style={{width:`${leftW}px`}}>
      {p.leftTop}
      <div className="shell-left-body">
        <button className="shell-collapse" aria-label="collapse context" …>&laquo;</button>
        {p.left ?? 'Context'}
      </div>
      <button className="shell-persist" aria-label="agent context" …>Context</button>
    </aside>

`p.left` is passed by NOBODY today (single call site `ui/src/App.tsx:907-919`), so the
body literally renders the string `Context`. That is the "meio largada" the owner names.
`leftTop` is passed for the workbench only: `<AgentChannelStrip>` (role glyph + objective +
Status pill + inbox count; has a `.wb-strip-mini` collapsed variant) plus, on the `changes`
section only, a compact `<SessionTape>`.

Left column CSS, `ui/src/shell/appshell.css:17-25` verbatim:

    .shell-left{ flex:none; min-width:0; background:var(--surface-1);
      border-right:1px solid var(--border); display:flex; flex-direction:column; overflow:hidden; }
    .shell-left[data-collapsed="1"]{ width:44px !important; }
    .shell-left-body{ flex:1; overflow:auto; padding:12px; }
    .shell-left[data-collapsed="1"] .shell-left-body{ display:none; }
    .shell-persist{ display:none; }
    .shell-left[data-collapsed="1"] .shell-persist{ display:flex; writing-mode:vertical-rl; … }

Width persists via `usePersistentWidth('harness.shell.leftW', 260, 200, 420)`; collapse via
`usePersistentBool('harness.shell.leftCollapsed', false)` — both in
`ui/src/shell/usePersistentWidth.ts`, both localStorage-backed with try/catch.

IMPORTANT SHELL FACT: `hasLeft = p.leftTop != null || p.left != null` (AppShell.tsx:40) —
if no left content, the whole aside AND its gutter are omitted. Deviation D3 of
`gui-fix-ops-wb` put that there on purpose: every non-workbench domain had a dead rail
with a floating glyph. Anything you propose must not resurrect a dead rail.

### What the backend has that the client does NOT get today

- `GET /api/queue` -> `ui_queue.queue_snapshot` — harness WORKFLOW workers (per-worker
  status, phase), read from `.harness/workflows/active/WF-*/workflow.json` +
  `async/tasks/*.json` (pid, startedAt, stdout/stderr paths).
- `GET /api/worker?wf=&worker=&lines=` — live tail of one workflow worker's output.
- `GET /api/events` -> tail of `.harness/runs/events.jsonl`.
- Detached spawns (`gate-staged`, `scenario --detach`, `lane schedule`) write a log + a
  completion marker under `.harness/runs/` and have NO listing endpoint.
- The chat subprocess itself: `ChatSessions.list()` -> `/api/chat/sessions`, rows
  `{id,label,alive,engine,createdAt}`; `alive` = `proc.poll() is None`.

### Existing primitives you MUST compose, never recreate

- `ui/src/components/Status.tsx` — `Status` with `StatusKind` (11 states incl. `running`),
  variants `pill` / `dot` / `rail`. Colour is NEVER alone: colour + shape + text.
- `ui/src/components/status.css` — `@keyframes signal-pulse`, `--stream` tone.
- `ui/src/theme/tokens.css` — `--accent #CBF23F`, `--stream #45E0C4`, `--success`,
  `--warning`, `--danger`, each with `-bg`/`-border`; `--surface-1/2/3`, `--border*`,
  `--text-primary/secondary/muted/disabled`, `--font-ui` (IBM Plex Mono), `--text-xs..xl`,
  `--space-1..4`, `--radius-sm/xs`, `--h-row:34`.
- `EmptyState`, `Row`, `Chip`, `KVList`, `MetricTile`, `Toolbar`, `Drawer`, `Inspector`.

### The UI law you are drafting UNDER (docs/DESIGN_SYSTEM.md — read it, it is 146 lines)

Non-negotiable, quoted:

1. Anti-slop: nothing "on distribution"; if it looks like a generic AI dashboard it is wrong.
2. Token-driven: zero hex/px colour outside `tokens.css`. Need a value that does not
   exist -> ESCALATE, do not invent.
3. Compose F5/F4 primitives; new CSS only for composition LAYOUT.
4. GUI-writes-no-state: every mutating button POSTs an allowlisted verb (`/api/action` or
   `/api/chat/*`). localStorage only for UI state, try/caught.
5. Offline: no CDN, no network deps.
6. "Dado real ou `—`" — ZERO fabricated numbers. A gap is itself an assertion: `n/p`
   means "this measurement exists and the vendor did not publish it"; where the
   measurement DOES NOT EXIST, drawing a gap invents an absence (owner law 2026-07-31).
7. Motion: one orchestrated page-load cascade; `prefers-reduced-motion` respected ALWAYS;
   `running`/`stream` pulses; glow only on active/stream, never decoration.

## Questions your draft MUST answer (numbered, decisions not options)

For every one: pick ONE, justify in <=3 lines, name what it costs.

1. **Phase derivation.** Exactly which frame sequence maps to which phase, as a state
   machine over the EXISTING event vocabulary. Where does `question` fit (it is currently
   dropped)? What does the phase read when a tool is open AND text is streaming? Give the
   transition table.
2. **Honesty boundary.** "Rodando testes" and "esperando agentes" are in the owner's
   demand. Can the stream PROVE either? A `tool` frame carries `name` + `arg`. Is
   classifying "Bash + arg matches pytest" as "running tests" a derived fact or a
   fabricated one under law 6? Decide, and say what the phase line shows when it cannot
   prove the category.
3. **Where the phase state lives.** In the reducer as a derived `TapeState` field, or
   computed in the view from `blocks`? Which file owns it, and why the other is worse.
4. **Placement + DOM.** Exact DOM for the phase line: element, class names, aria
   semantics (it is a live region above an input — `aria-live` politeness, and does it
   duplicate `.wb-upload-status` which is already a live region?). Does it live inside
   `.wb-composer` or above it? Does it push layout or overlay? Give the CSS with token
   names only.
5. **The rail's data source.** For v1: derived from tool blocks in the tape, or a new
   poll of `/api/queue`, or both? Note the ladder — the tape frames are ALREADY in the
   client, `/api/queue` is a new fetch loop. If you propose both, justify the second one
   as a separate later phase, not v1.
6. **Rail item model.** The fields per row, the ordering rule (execution order — of start
   or of finish?), the running/finished discriminator (today: `output === undefined`),
   and where the finish TIMESTAMP comes from — the reducer has no `doneAt` today. What
   exactly gets added to `TapeBlock`?
7. **Expiry.** The mechanic for "stays a while, then disappears": what clock drives it
   (interval tick? render-time filter? timeout per item?), what happens to an item whose
   TTL elapses while the rail is scrolled or the panel is collapsed, and whether expiry
   removes it from the RAIL only or from the tape too (the tape is the transcript — think
   hard before deleting from it).
8. **"Configuravel" — where.** The setting's storage, default value, allowed range, and
   the CONTROL the owner uses to change it. Cheapest thing that is honest. Justify
   against `usePersistentWidth`/`usePersistentBool`, which already exist.
9. **The dead-rail problem.** The rail lives in `shell-left-body`, which only mounts for
   the workbench. Is that correct, or should the rail follow the owner across domains?
   If it should follow, say exactly how without resurrecting the empty rail D3 removed.
   Also: what does the rail show with zero processes (EmptyState? nothing? does the whole
   left column disappear again?), and what does the COLLAPSED 44px rail show while
   something is running — the owner must not lose the signal by collapsing the panel.
10. **The relationship between D1 and D2.** They both say "something is running". State
    the division of labour in one sentence each so they are not two renderings of the
    same fact.
11. **Anti-slop / signature moment.** Per DESIGN_SYSTEM §1, what makes this an INSTRUMENT
    rather than a spinner-and-toast dashboard. One concrete idea, described in tokens.
12. **Verification.** Name the exact checks: which asserts get added to
    `chat.ts:selfCheck()`, which Playwright ids in the ui smoke suite (existing suite:
    `pw_ui_smoke`, 63 checks today — find its file and follow its id convention), and the
    ONE mutation that must turn a check red if the feature is silently broken.
13. **What you would cut.** The laziest version of this that still satisfies the owner.
    If any part of the demand is over-built as stated, say so and name the rung below.

## Constraints on the draft

- Surface: `ui/src/` (React, served at `/next`). The vanilla panel
  `scripts/harness_ui_page.py` is READ-ONLY reference — do not propose changes there.
- Backend `/api/*` must stay UNCHANGED for v1. If you believe a backend change is
  unavoidable, that is a finding to argue, not a thing to assume.
- No new npm dependency. Ever.
- Portuguese is the owner's language; the CODE and UI strings are EN-only.
- Cite `file:line` for every claim about existing code. If you cannot verify a claim from
  source, mark it UNVERIFIED rather than asserting it.
- Length ceiling: 400 lines. Decisions, not essays.
