# Brief — DD-mechanization P0 (research-round tooling)

Owner: overseer (opus-4-8). Plan authors (dual, independent): **codex gpt-5.6-sol @ high**
(the design study `.harness/handoff/design-dd-mechanization.md` already covers P0 at §4/§8)
and **kimi k3 @ high** (this brief → `plan-ddmech-p0-kimi.md`). Implementation: overseer
inline. Implementation audit (dual): **sonnet-5 @ high + opus-5 @ high**, fix-first, per task.
Decisions here are FINAL; a plan that diverges returns the divergence TYPED under
`planDeviations`, never improvises.

Scope: TWO latent bugs in the async workflow machinery surfaced by the codex design study.
No new CLI verb, no new dependency, stdlib-only, EN-only. This is the enqueued "P0/P1
mecanização" — P0 only (P1 spawn-pin is the next task, not this one).

## P0a — clamp `minSuccess` to the runnable group

Anchors (verify before trusting):
- `scripts/harness_lib/async_state.py:271-297` `workflow_effective_await_policy` — builds the
  policy, floors `minSuccess` at `max(1, …)` (:294), but NEVER clamps to the group size.
- `scripts/harness_lib/async_runtime.py:827` policy computed; `:837` `runnable` computed;
  `:266-271` the quorum check reads `policy.get("minSuccess")`; `:1013-1018` `workflow_await`
  RE-derives the policy via `workflow_effective_await_policy`.

Bug: a profile whose `minSuccess` exceeds the actual worker count (e.g. `research-divergence`
`minSuccess=3` run as a homogeneous 2-worker group — the exact shape the DD round produces)
can NEVER reach quorum (3 of 2) → the group hangs or reports quorum-impossible on a healthy run.

Fix direction (codex §4/§8 P0): clamp `minSuccess` to `len(runnable)` in `workflow_start`
after `:837`.

LOAD-BEARING SUBTLETY (the plan MUST resolve this, it is where codex↔kimi may diverge): the
clamp must SURVIVE re-derivation. `workflow_await` (:1018) and the quorum predicate (:266) read
a policy; if `await` re-calls `effective_await_policy`, it re-inflates `minSuccess` back to the
profile value and the clamp is lost. Choose ONE seam that holds on BOTH the start and the
await/quorum paths, with the smallest surface:
  (a) persist the clamped `minSuccess` into the async group state at start, and have
      await/quorum read the GROUP's policy instead of re-deriving; or
  (b) clamp inside `effective_await_policy` itself, given the group's runnable/worker count
      threaded in (a new optional arg).
State which and why, and prove the losing path can't re-inflate.

## P0b — validate `repoAccess` by each worker's EFFECTIVE executor

Anchors:
- `scripts/harness_lib/workflow_reduce.py:98-153` `workflow_validate_results` — loops workers;
  `:145` validates EVERY worker with `repo_access = executor_repo_access(ROOT,
  workflow.get("executor"))` — ONE workflow-level executor class for all workers.
- `scripts/harness_lib/async_runtime.py:647` `run_one_worker` ALREADY validates the live async
  result per-worker with `executor_name`. So the async LIVE path is correct; the gap is the
  REDUCE-time re-validation only.

Bug: in a heterogeneous group (the whole point of the DD mixed fleet — sonnet workers + nvidia
http workers in one logical wave), a worker that actually ran on `repoAccess:none` (nvidia http)
is re-validated at reduce against the workflow executor's class (or vice-versa) → wrong
access-class contract.

Fix direction (codex §4): stamp the EFFECTIVE executor onto each worker at spawn time — on BOTH
the blocking `workflow run` path AND the async `workflow start` path (each worker's executor is
resolved there) — then in `workflow_validate_results` read
`worker.get("resolvedExecutor") or workflow.get("executor")`. The fallback preserves today's
behavior for unwired/homogeneous workflows (byte-identical).

The plan MUST: (1) confirm whether a per-worker executor field already exists anywhere on the
worker dict; (2) name the EXACT stamp sites on both paths; (3) keep the fallback so a
homogeneous workflow's validation is unchanged.

## Acceptance (teeth that go RED on the bug)

- minSuccess: a scenario with a runnable group of 2 and a profile `minSuccess=3` → quorum
  reached at 2 (not "quorum impossible", not a hang), AND the clamp survives an `await`
  re-derivation. Mutant: delete the clamp → RED.
- repoAccess: a scenario with a mixed group (one worker stamped `repoAccess:repo`, one
  `repoAccess:none`) → at reduce each is judged by its OWN class; the none-access worker's
  out-of-scope claim is caught while the repo worker's identical claim is allowed. Mutant:
  revert `:145` to `workflow.get("executor")` → the mixed case mis-validates → RED.
- Prefer extending `testing/scenarios/rs_research_skill.py` (the research-round scenario the
  design names) or the async-workflow scenario — CONFIRM the right host; a new file only if
  clearly cheaper, with a one-line justification.

## Constraints (violate none)

- stdlib-only, NO new dependency (python or npm). EN-only in code/comments/tests; mojibake
  sweep stays clean; no whitespace/re-encode churn on touched files.
- harness.py NET-ZERO: P0 touches `harness_lib` only (`async_state.py`, `async_runtime.py`,
  `workflow_reduce.py`, and the blocking-path spawn site). No new CLI verb. Confirm zero
  harness.py delta.
- SDD (SPEC-116): P0 is a bug-fix on the workflow async contract → SPEC-119 versioned
  amendment (the design names SPEC-119). Name the exact spec file + the amendment text.
- Prefer the shared seam over per-call-site patches.
- Every guard leaves ONE runnable check (a scenario tooth + a shown-RED mutant). A guard with
  no tooth is unfinished.
- NO git, NO source edits. Your only write is the plan document.

## Deliverable

An independent, step-ordered P0 implementation plan (P0a then P0b), each naming exact
files+functions, the seam decision (esp. the minSuccess re-derivation subtlety and the
per-worker executor stamp sites), the scenario/mutant that PINS the behavior, the SPEC-119
amendment text, and the harness.py net-zero confirmation. Flag any place this brief is wrong or
under-specified as a TYPED `planDeviations[]` entry — do not silently widen scope. Write the
plan to `.harness/handoff/plan-ddmech-p0-kimi.md`. End with the `HARNESS_RESULT` JSON block per
`.harness/prompts/subagent-contract.md`: `status: blocked`, `requiresEscalation: true`
(planning only — the overseer approves and implements).
