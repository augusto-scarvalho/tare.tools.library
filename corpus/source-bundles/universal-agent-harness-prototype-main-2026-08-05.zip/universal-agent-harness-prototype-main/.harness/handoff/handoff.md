
# Agent Handoff

## Project

- Project: universal-agent-harness
- Project type: generic
- Active task: bootstrap — Adopt the Universal Agent Harness
- Current status: workflow_partial
- Last commit: 34292b5
- Working tree changed files: 22

## Next task

Gate Phase-2 safety theory (audit 2026-07-20). THEME 1 safe-skip (SPEC-159 Phase 2): under what conditions is skipping a cached, unaffected scenario PROVABLY safe? Propose: verdict-cache semantics (skip/pass/fail/flake; a real falseSkip happened when self-skips were cached as passes), the enablement rule (falseSkip==0 over N runs - what N, what statistical framing e.g. confidence sequences; what events INVALIDATE accumulated evidence: gate-version bump, graph rebuild, flaky scenario, key-scheme change), and how to model the import-graph subprocess blind spot beyond a hardcoded _GLOBAL_TRIGGERS allowlist (e.g. subprocess-edge extraction, dynamic tracing, taint of harness.py CLI surface). THEME 2 default-flip (SPEC-160): a verifiable protocol proving parallel==serial over the REAL 150-scenario battery (not fixtures): how many paired runs, how to compare (verdict maps, durations, flake handling), what a HEAD-faithful worker copy must contain (.git, HEAD .harness state) and how to VERIFY faithfulness itself; when the SPEC-159 shadow may be re-included in the worker path without poisoning the verdict cache. THEME 3 cleanliness contract: scenarios that drive the real machinery inside the gate hold currently discover harness-regenerated docs (handoff/context/quality-state) by archaeology; propose a declared CONTRACT (e.g. a harness-exported REGEN registry scenarios import, an isolation-layer porcelain-delta API, or write-suppression inside scenarios) - who owns it, how it is tested. Every proposal: named failure conditions + invalidation triggers + a maturity class; novelty and maturity are separate axes.

## Routing recommendation

- Task profile: `review`
- Risk: `high`
- Active executor: `generic`

The harness chooses profiles by spawning a new bounded execution. The current agent must not mutate its own model or reasoning level.

## Structural discovery

- Required skill: `graphify`
- Policy: `graphify-code-ast-first-source-verified`
- Graph status: `not_available`
- Report path: `graphify-out/GRAPH_REPORT.md`

Use Graphify before broad repository search when applicable, then verify graph-derived findings in source/spec/test/config files. Record usage in `HARNESS_RESULT.contextDiscovery.graphify`.

## Last workflow

- Workflow ID: `WF-20260720-175712-339749`
- Type: `fork-join`
- Status: `partial`
- Summary: Re-reduced 2 valid worker result(s) (worker-001, worker-002; 2 of 4 expected ideators returned invalid/missing results, so 4-way convergence cannot be assessed) into 6 concepts spanning THEME1 safe-skip (CONCEPT-002 enablement+invalidation, CONCEPT-003 subprocess blind spot), THEME2 default-flip (CONCEPT-004 parallel==serial protocol, CONCEPT-005 shadow re-inclusion), THEME3 cleanliness contract (CONCEPT-006 regen-manifest), and one cross-theme meta-proposal (CONCEPT-001 unified gate-state manifest, worker-001 only). Convergence highlights: (a) both ideators independently proposed a declared regen manifest listing harness-regenerated paths for THEME3 (CONCEPT-006) -- the cleanest agreement in the wave; (b) both independently proposed content-hashing .git HEAD / .harness state for worker-copy faithfulness verification in THEME2 (CONCEPT-004); (c) both enumerated an overlapping invalidation-event core (gate-version bump, graph rebuild, flaky scenario, key-scheme change) for THEME1 (CONCEPT-002). Four explicit design-level conflicts are recorded (CONFLICT-001..004): in every theme, worker-001 proposed a lighter-weight/deterministic counter-design to worker-002's heavier statistical or layered-machinery proposal covering the same sub-problem. No blockers were raised by either worker beyond the sub-conditions already named inside CONCEPT-005 (shadow-cache-poisoning blockers). 0 top-level blockers, 4 top-level conflicts (new this pass; the deterministic reduce had recorded 0 by treating same-topic alternative designs as independent findings rather than surfacing the tension).
- Review required: `False`
- Security review required: `False`
- Reducer result: `.harness/workflows/active/WF-20260720-175712-339749/reduce/reducer.result.json`
- Harness result: `.harness/workflows/active/WF-20260720-175712-339749/reduce/harness-result.json`

## Required reads

Minimal-first startup set: 14515 bytes, approximately 4683 tokens.

- `.harness/context/CONTEXT.md`
- `.harness/context/STATE.md`
- `.harness/context/NEXT_STEPS.md`
- `.harness/state/task-state.json`
- `.harness/state/quality-state.json`

Budget-demoted to verify-on-demand pointers (open when the task needs them): `.harness/prompts/subagent-contract.md`, `AGENTS.md`, `specs/00-universal/code-quality.md`, `specs/00-universal/testing-and-quality-gates.md`, `specs/00-universal/coverage-and-regression.md`, `specs/00-universal/dependency-and-supply-chain.md`.

## Conditional reads

Load these only when the task scope requires deeper baseline/spec context or when escalation changes the profile.

- `specs/00-universal/structural-discovery.md`
- `specs/00-universal/UNIVERSAL_BASELINE.md`
- `.harness/prompts/subagent-contract.md`
- `AGENTS.md`
- `specs/00-universal/code-quality.md`
- `specs/00-universal/testing-and-quality-gates.md`
- `specs/00-universal/coverage-and-regression.md`
- `specs/00-universal/dependency-and-supply-chain.md`
- `specs/MANIFEST.yaml`

Conditional pack: 52056 bytes, approximately 16793 tokens.

## Universal baseline guidance

Apply the relevant files under `specs/00-universal/` to non-trivial changes. Use `specs/00-universal/structural-discovery.md` for repository search/impact mapping. Escalate to `review` or `security` when universal specs indicate higher risk.

## Guardrails

- Keep the diff minimal and scoped to the task.
- Do not load long historical files unless explicitly needed.
- Do not store canonical state in agent-specific directories.
- Return `HARNESS_RESULT` when done, partial, blocked, or failed.
- If scope/risk increases, request escalation instead of silently expanding work.

## Changed files from Git status

- `claude/settings.json`
- `.harness/context/NEXT_STEPS.md`
- `.harness/handoff/handoff.json`
- `.harness/handoff/handoff.md`
- `.harness/handoff/next-agent-prompt.md`
- `.harness/state/security-exemptions.json`
- `docs/IMPLEMENTATION_BACKLOG.md`
- `scripts/harness_lib/gate_affected.py`
- `scripts/harness_lib/gate_checks_policy.py`
- `scripts/harness_lib/gate_parallel.py`
- `scripts/harness_lib/mutation_probe.py`
- `scripts/harness_lib/scenario_isolation.py`
- `scripts/spec_test_gate.py`
- `specs/40-features/gate-hold-guard.md`
- `specs/40-features/parallel-scenarios.md`
- `specs/40-features/parallel-verify-heartbeat.md`
- `testing/scenarios/ghg_gate_hold_guard.py`
- `testing/scenarios/gps_gate_parallel_scenarios.py`
- `testing/scenarios/pvr_parallel_verify.py`
- `testing/scenarios/rt6_route_writechain.py`
- `tools/hooks/gate_hold_guard.py`
- `docs/research/gate-phase2-safety-round.md`
