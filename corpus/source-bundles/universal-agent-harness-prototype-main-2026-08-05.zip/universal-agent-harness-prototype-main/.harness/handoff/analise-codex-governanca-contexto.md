# Análise do estudo de governança de contexto — lente eficiência/operação

## 1. Top desperdícios de contexto do harness hoje

1. **[judgment] Resultados de workers são pagos e depois descartados integralmente.**
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/reduce/validation.json:3-10` registra 3 workers esperados, 0 válidos e 3 inválidos.
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/reduce/validation.json:24-39` mostra que os três capsules excederam `maxWorkerOutputChars`; um deles também violou o teto de `frictionObservations`.
   - [repo] Medição dos três `run-logs/worker-*.stdout.log` desse workflow: 133.234 caracteres no total, ou **~42.979 tokens estimados** a 3,1 chars/token; medição dos três `workers/*.result.json`: 43.788 caracteres, ou **~14.125 tokens estimados**, sem um único capsule aceito.
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/reduce/token-audit.md:44-50` ainda registrava os resultados como ausentes, enquanto a validação posterior os classificou como inválidos; a fotografia de custo não acompanha sozinha o desfecho.
   - [judgment] Este é o desperdício prioritário: não é “contexto talvez redundante”, é geração já consumida com valor operacional final zero.

2. **[judgment] O digest é compartilhado no disco, mas continua duplicado na janela de cada worker.**
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/reduce/token-audit.md:11-22` mede **14.997 tokens de required reads** numa onda de 3 workers mesmo com digest; sem digest seriam 43.152, portanto o mecanismo atual corta 65,2%, mas não elimina a repetição entre workers.
   - [repo] Medição de `.harness/workflows/active/WF-20260727-010246-293733/context-digest.md`: 15.855 caracteres, ou **~5.115 tokens por worker**; três leituras custam ~15.345 tokens pela mesma calibração, coerentes em ordem de grandeza com o audit.
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/context-digest.md:17-280` inclui cinco fontes comuns para todas as funções: `AGENTS.md`, `WORKFLOWS.md`, contrato de subagente e dois specs universais.
   - [judgment] O custo bruto repetido é ~15 mil tokens nessa onda; a fração realmente removível é **sem estimativa**, porque cada worker ainda precisa de um núcleo de autoridade.

3. **[judgment] O parent task e o seed inteiro são copiados para cada branch, mesmo quando a crítica é role-specific.**
   - [repo] `scripts/harness_lib/worker_prompt.py:60-75` injeta `workflow['task']` integralmente em todo packet.
   - [repo] Medição de `workers/worker-001.prompt.md:14-111` no workflow citado: parent task + seed ocupam 8.209 caracteres, ou ~2.648 tokens; repetidos nos 3 prompts, são **~7.944 tokens de carga comum** antes da instrução específica da branch.
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/reduce/token-audit.md:38-42` confirma prompts quase idênticos de 3.514–3.519 tokens por worker.
   - [judgment] Nem todo esse bloco pode sumir, mas entregar a cada crítico o briefing inteiro em vez de um núcleo comum curto + perguntas da sua lente é uma meia-solução cara; economia removível **sem estimativa**.

4. **[judgment] O digest entrega contratos que o worker não pode produzir.**
   - [repo] `.harness/workflows/active/WF-20260727-010246-293733/context-digest.md:132-223` carrega todo o `subagent-contract`, incluindo `HARNESS_RESULT`, `WORKER_RESULT`, `REDUCE_RESULT`, `REVIEWER_RESULT`, controlled-write, política de implementadores e veredictos especializados.
   - [repo] Medição desse trecho: 4.910 caracteres (~1.584 tokens); somente `WORKER_RESULT` em `context-digest.md:152-196` ocupa 1.945 caracteres (~627 tokens).
   - [repo] A parte anterior e posterior que um worker read-only comum não retorna soma 2.963 caracteres, ou **~956 tokens por worker / ~2.868 tokens na onda de 3**.
   - [repo] `.harness/prompts/subagent-contract.md:105-113` já limita o worker ao packet, a modo read-only, a referências em vez de conteúdo colado e ao teto configurado.
   - [judgment] Um digest por papel deveria materializar somente autoridade comum + o contrato consumível por aquele papel.

5. **[judgment] O `NEXT_STEPS.md` virou log histórico apesar de declarar que deve ser compacto.**
   - [repo] `.harness/context/NEXT_STEPS.md:3` manda manter o arquivo compacto.
   - [repo] Medição atual de `.harness/context/NEXT_STEPS.md`: 12.756 caracteres, ou **~4.115 tokens**.
   - [repo] `.harness/context/NEXT_STEPS.md:24-29` contém seis entradas de trail que somam 10.633 caracteres, ou **~3.430 tokens**; as cinco entradas anteriores à mais nova somam 7.877 caracteres, ou **~2.541 tokens potencialmente foldáveis por startup**.
   - [repo] `scripts/harness_lib/context_checkpoint.py:45-54` fixa `TRAIL_MAX = 6`, limita a renderização do bloco a 1.300 bytes e reconhece que o trail é história, mas `AGENTS.md:23-32` ainda exige a leitura do arquivo integral.
   - [repo] `.harness/context/NEXT_STEPS.md:10` acrescenta mais 1.607 caracteres (~518 tokens) de summary de workflow já representado no handoff.
   - [judgment] O cap de reinjeção protege um canal, mas não resolve o custo da leitura canônica obrigatória; é uma meia-solução local.

6. **[judgment] A sessão proprietária recebe hidratação fixa e depois é instruída a reler a mesma família de estado.**
   - [repo] `tools/hooks/reload_context_after_compact.py:2-17` registra reinjeção em todo `SessionStart` — startup, resume, clear, compact e fork — e adiciona estado, warm-up e cadeia de role.
   - [repo] Medição read-only do hook no estado atual, com `HARNESS_SKIP_REINJECT` removido apenas do processo de medição: 9.935 caracteres de stdout, ou **~3.205 tokens estimados por disparo**.
   - [repo] `AGENTS.md:23-32` exige depois seis leituras; medição atual desses seis arquivos: 26.087 caracteres, ou **~8.415 tokens estimados**. Só `CONTEXT.md`, `STATE.md` e `NEXT_STEPS.md`, também presentes na reinjeção por `context_checkpoint.py:37-43`, somam 14.727 caracteres, ou ~4.751 tokens em forma integral.
   - [repo] `tools/hooks/reload_context_after_compact.py:53-60` evita a reinjeção em workers/routers quando `HARNESS_SKIP_REINJECT=1`, portanto o desperdício aqui se concentra na sessão proprietária e em qualquer spawn que não receba a dieta.
   - [judgment] A sobreposição exata entre texto capped e leitura integral é **sem estimativa**, mas o custo bruto por início de sessão é hoje ~11,6 mil tokens estimados entre os dois canais.

7. **[judgment] A dieta de contexto não corta schemas de tools no caminho Codex.**
   - [repo] `scripts/harness_lib/context_diet.py:14-16` registra, em probes Claude/Haiku deste repo, 7 mil tokens de schemas de tools e redução de 40.264 para 16.520 tokens/turno com dieta completa.
   - [repo] `scripts/harness_lib/context_diet.py:73-76` implementa para Codex apenas `project_doc_max_bytes=0` e declara que não há knob conhecido para `keepTools`.
   - [repo] `scripts/harness_lib/context_diet.py:163-170` mostra que a dieta default de worker read-only é efetiva em Claude e no-op em Codex.
   - [judgment] Não é válido transportar os 7 mil tokens medidos em Claude para Codex; o desperdício Codex fica **sem estimativa**, mas a lacuna operacional está explícita no código.

## 2. Ranking de adoções do estudo por ganho/esforço

1. **[judgment] GC determinístico do trail e de summaries superseded.**
   - [estudo] §4, linhas 1528-1580, prefere offloading/GC determinístico antes de folding, compactação e reset.
   - [estudo] §8.3 e §8.12, linhas 2351-2373 e 2572-2588, mandam remover duplicatas/superseded e fazer minor GC sem LLM.
   - [repo] Seam: `scripts/harness_lib/context_checkpoint.py:45-54` e `:81-110`.
   - [judgment] Ganho esperado: **~2.541 tokens por leitura obrigatória no estado atual** ao externalizar as cinco entradas antigas e manter somente a última + ponteiro; esforço **S**.

2. **[judgment] Digest por papel, não digest universal da onda.**
   - [estudo] §6.3, linhas 1918-1956, define hidratação mínima e proíbe carregar todos os playbooks e todo o histórico.
   - [estudo] §9.3 e §9.10, linhas 2710-2759 e 2992-3018, definem estado essencial diferente para pesquisa, review e overseer.
   - [repo] Seams: `scripts/harness_lib/context_digest.py`, `scripts/harness_lib/worker_prompt.py:91-130` e `.harness/workflows/workflow-profiles.json:414-476`.
   - [judgment] Ganho esperado mínimo observável: **~956 tokens por worker / ~2.868 na onda de 3** removendo apenas contratos incompatíveis com o papel; ganhos adicionais em `AGENTS.md`/`WORKFLOWS.md` ficam sem estimativa; esforço **S/M**.

3. **[judgment] Capsule “finding-only” com offload de payload antes da validação.**
   - [estudo] §7.1 e §7.4, linhas 2028-2035 e 2126-2164, separam transcript do capsule tipado e mantêm a trajetória fora do pai.
   - [estudo] §10.8, linhas 3166-3186, recomenda objetos estruturados + resumo curto, não um parágrafo/transcript extenso.
   - [repo] Seams: `scripts/harness_lib/result_contracts.py:188-242` para campos soft, `:268-306` para normalização no ingest, `:429-439` para o teto total, `schemas/worker-result.schema.json:17-35` e `.harness/prompts/subagent-contract.md:70-113`.
   - [judgment] Ganho esperado: evita repetir o caso medido de **~42.979 tokens estimados de stdout para 0 capsules válidos**; a redução por execução futura é sem estimativa porque depende da geração do modelo; esforço **S/M**.

4. **[judgment] Uma única autoridade de hidratação na sessão proprietária.**
   - [estudo] §6.3, linhas 1918-1956, pede contexto inicial mínimo; §11.5, linhas 3320-3352, separa seleção de ordenação.
   - [repo] Seams: `tools/hooks/reload_context_after_compact.py:53-99`, `scripts/harness_lib/context_checkpoint.py:189-216` e a regra de startup em `AGENTS.md:23-32`.
   - [judgment] Ganho bruto disponível: escolher entre reinjeção capped (~3.205 tokens medidos) e releitura integral seletiva (~8.415 tokens no conjunto atual), em vez de pagar ambos; economia exata sem estimativa por causa da sobreposição parcial; esforço **M** por exigir paridade entre vendors e preservar `/clear`.

5. **[judgment] Briefing branch-specific em vez de parent task + seed integral.**
   - [estudo] §9.2, linhas 2700-2708, orienta a seleção pela próxima decisão; §10.2, linhas 3064-3081, define folding em fronteira causal.
   - [repo] Seam: `scripts/harness_lib/worker_prompt.py:60-88`; o ponto caro é a interpolação integral de `workflow['task']` em `:73-75`.
   - [judgment] Ganho bruto endereçável na onda medida: **~7.944 tokens repetidos**; a economia líquida é sem estimativa porque cada branch ainda precisa do núcleo da proposta; esforço **M**.

6. **[judgment] Telemetria final de custo-to-valid-capsule.**
   - [estudo] §16.8, linhas 4396-4450, lista re-read, total input, tool output, latência, cost-to-success, duplicação cross-agent e suficiência do capsule.
   - [estudo] §19 Fase 0, linhas 4870-4878, coloca telemetria antes de estado, GC, packing e perfis.
   - [repo] Seams: `scripts/harness_lib/workflow_token_audit.py`, `reduce/token-audit.json` e `reduce/validation.json`; o caso medido mostra audit com resultados `0` em `token-audit.md:18-20` e desfecho posterior 0/3 válido em `validation.json:3-10`.
   - [judgment] Ganho direto: nenhum; ganho operacional: impede investimento baseado em fotografia pré-run ou teto configurado; esforço **S/M**.

7. **[judgment] Reset físico por backlog item, preservando o overseer lógico.**
   - [estudo] §6.1, linhas 1857-1890, recomenda contexto novo por item; §10.4, linhas 3094-3118, prefere reset quando muda radicalmente o working set e exige término da sessão no fim da tarefa.
   - [repo] Seams: `scripts/harness_lib/context_checkpoint.py` para checkpoint/reidratação e adapters de sessão que já disparam `SessionStart`.
   - [judgment] Ganho esperado: menos mistura cross-task e menos necessidade de carregar trail histórico; **sem estimativa** até medir sessões multi-item; esforço **M**.

8. **[judgment] Packing posicional determinístico dentro do reinjetor existente.**
   - [estudo] §11.1 e §11.5, linhas 3191-3259 e 3320-3352, colocam autoridade/objetivo no início, evidências no corpo e estado corrente/próxima ação no fim.
   - [repo] Seam: `scripts/harness_lib/context_checkpoint.py:37-54` e `:189-216`; a ordem atual é uma tupla fixa de arquivos, não uma montagem por fase.
   - [judgment] Ganho esperado é de utilização/menos re-read, não de tokens brutos; **sem estimativa**; esforço **S/M** se restrito a reordenação e índices, sem criar registry novo.

## 3. O que não adotar agora

1. **[judgment] Context Control Plane completo com 13 componentes.**
   - [estudo] §14, linhas 3831-3863, propõe telemetry, budget controller, object registry, dependency graph, stores, GC, retrieval, packer, curator, folding, compiler, integrity gate e reset.
   - [estudo] §18.1 e §18.11, linhas 4767-4774 e 4852-4859, admite que o plano completo pode custar mais do que economiza e prescreve progressão por porte da tarefa.
   - [judgment] Não adotar como bloco: o harness já tem ganhos S mensuráveis em trail, digest e output contract; duplicar tudo num control plane antes da baseline adicionaria muitas novas superfícies de falha sem economia demonstrada.

2. **[judgment] Perfis aprendidos, RL e curator on-the-fly.**
   - [estudo] §9.5, linhas 2770-2780, classifica os métodos como bleeding edge e não substitutos da validação determinística.
   - [estudo] §19 Fases 8–9, linhas 4965-4985, coloca adaptive layer e learned policies por último.
   - [judgment] Não adotar: esforço **L/XL**, necessidade de corpus/replay e risco de overfitting para um problema cujo desperdício maior atual é validação pós-geração e texto duplicado, ambos resolvíveis sem ML.

3. **[judgment] Compactação semântica frequente com validator semântico independente.**
   - [estudo] §4, linhas 1571-1586, coloca compactação depois de offload, GC, retrieval e folding por ser mais custosa e arriscada.
   - [estudo] §8.13, linhas 2620-2638, exige que o ganho supere collector, quebra de cache, recuperação e risco.
   - [judgment] Não adotar agora: dois modelos — compressor e validator — podem gastar mais tokens do que os ~2,5 mil removíveis deterministicamente do trail; promoção só após uma comparação pareada.

4. **[judgment] Object registry + dependency graph para GC de contexto já na primeira fase.**
   - [estudo] §8.5, linhas 2422-2457, descreve mark-and-sweep por dependências; §9.8, linhas 2924-2934, reconhece que abordagens causais exigem anotações/dependency graph.
   - [repo] `.harness/handoff/handoff.json` registra Graphify `status: not_available`; a política existe, mas o índice estrutural não está disponível nesta execução.
   - [judgment] Não criar um segundo grafo dedicado a contexto enquanto deduplicação por hash, latest-only e pointers ainda não foram esgotados; esforço **L**, retorno atual sem estimativa.

## 4. Tensões entre o estudo e o design atual

1. [estudo] §6.1 recomenda uma sessão física nova por backlog item. [repo] `tools/hooks/reload_context_after_compact.py:2-17` foi desenhado para manter uma sessão física atravessando startup, resume, clear e compact por reinjeção. [judgment] O harness investe em tornar a sessão longa sobrevivente; o estudo trata a sessão como descartável.

2. [estudo] §6.3 recomenda hidratação mínima e rejeita todos os playbooks/histórico por default. [repo] `AGENTS.md:23-32` exige seis arquivos em toda inicialização, enquanto `reload_context_after_compact.py:88-99` injeta novamente estado, warm-up e cadeia do papel. [judgment] A política atual combina push fixo + pull obrigatório, não seleção mínima.

3. [estudo] §9.3/§9.10 define perfis por papel. [repo] O mesmo `context-digest.md:17-280` é entregue a críticos de arquitetura, custo e segurança no workflow medido. [judgment] O harness tem perfis de execução, mas o payload comum ainda é quase role-agnostic.

4. [estudo] §8.11, linhas 2549-2567, rejeita trimming cronológico e exige objetos vivos/recuperáveis. [repo] `context_checkpoint.py:137-174` mantém head+tail por cap de bytes e corta o meio. [judgment] O cap evita overflow, mas não sabe se o meio removido continha a evidência ainda viva.

5. [estudo] §7.4 e §10.8 mantêm transcript fora do pai e retornam capsule tipado curto. [repo] `result_contracts.py:429-439` rejeita apenas depois de o modelo produzir o JSON inteiro; o workflow medido perdeu os três resultados acima do teto. [judgment] O contrato atual é um gate de descarte, não um mecanismo de folding/offload.

6. [estudo] §8.9/§8.13 exige economia cache-aware antes de coletar. [repo] `reload_context_after_compact.py:41-50` otimiza para o teto inline de 10 mil caracteres, não para prompt-cache hit/miss ou chamadas futuras. [judgment] O limite de transporte está medido; a economia de cache ainda não.

7. [estudo] §11.1/§11.5 reconstrói o contexto por fase e coloca próxima ação na borda final. [repo] `context_checkpoint.py:40-43` usa ordem fixa de cinco arquivos e `reload_context_after_compact.py:93-99` acrescenta warm-up/cadeia depois do estado. [judgment] Há proteção de tail, mas não packing orientado à próxima decisão.

## 5. Baseline antes de implementar

- [judgment] Medir **tokens estimados gastos por WORKER_RESULT válido** por workflow.
- [estudo] §16.8, linhas 4410-4450, combina economia, cost-to-success, duplicação cross-agent e capsule sufficiency; essa métrica reduz essas dimensões a uma unidade operacional verificável.
- [repo] Fórmula barata: `(workerPromptTokens + requiredReads.waveWithDigest + reducerPromptTokens + soma(chars dos worker stdout)/3,1) / workersValid`.
- [repo] Fontes já existentes: `reduce/token-audit.json`, `reduce/token-audit.md`, `run-logs/worker-*.stdout.log` e `reduce/validation.json`; nenhuma nova chamada de modelo é necessária.
- [repo] Regra para denominador zero: registrar o numerador e `custoPorCapsuleValido = indefinido`, sem dividir nem esconder a rodada.
- [repo] Baseline demonstrativa no workflow `WF-20260727-010246-293733`: `workersValid = 0` em `validation.json:3-10`, portanto o custo por capsule válido é indefinido apesar de haver prompts, required reads e stdout pagos.
- [judgment] Só promover uma mudança se, em workflows pareados da mesma classe, ela reduzir essa métrica sem aumentar `workersInvalid`, reabertura ou perda de findings; qualquer arquitetura que não mova essa baseline não se pagou.

ANALISE-COMPLETA
