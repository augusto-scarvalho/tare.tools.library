# Playbook pin-audit queue (owner order 2026-07-23: "ver se não tem pataquada salva")

Every EMPIRICAL claim pinned in `.harness/prompts/overseer-loop-playbook.md`,
queued for independent re-verification. Context: THREE pins were owner-challenged
and corrected TODAY (claude `/usage` "interactive-only" → MSYS mangle; codex
"cannot spawn browser" → workspace-write flag; codex "no network" → cmd `^`
quoting mangle). The shared failure mode: generalizing from ONE symptom without
isolating the shell/sandbox variable. This queue hunts the remaining pins.

Legend: risk = what routes/costs wrongly if the pin is false.
Already probe-proven TODAY (skip): browser EPERM pair, npm/network pair,
haiku /usage panel + cost.

| # | pin (playbook line ~) | claim | testable how (cheap) | risk if wrong |
|---|---|---|---|---|
| P1 | L144 | `< /dev/null` (aka `$null \|`) is MANDATORY — an open stdin hangs `codex exec` forever | spawn `codex exec` on terra WITH open stdin + 60s timeout; observe hang vs exit | lanes over-ceremonialized; or (if still true) accidental hangs when recipe is skipped |
| P2 | executors.json (codex desc) | codex >=0.144 IGNORES project-local `.codex/config.toml` profiles — `--profile` pinning silently no-ops (found 2026-07-13) | write a temp profile with a distinctive setting, run terra with `--profile`, check applied vs ignored (codex may have fixed since 0.144) | model/effort pinning silently wrong on every codex lane |
| P3 | L222-228 | `fuel probe` on the haiku pin bills ≈$0 and the panel is CLI-rendered (model-independent) | re-run probe, read cost_usd from the JSON; compare panel content hash vs a fable-run sample (owner-gated: skip the fable half, expensive) | fuel cadence advice wrong → hidden spend |
| P4 | L238-239 | `codex login status` is FREE (~0.2s, no model turn) — the pinned codex gauge surface | time it; confirm no token usage appears in codex accounting output | gauge probe silently billing |
| P5 | L130 | a worker must NEVER open a browser; plain HTTP GET + kill is the sanctioned check | policy pin, not empirical — VERIFY the pw_ui_smoke wrapper actually kills the server (no orphan node/chrome after run) | orphaned processes accumulating |
| P6 | L175 | GLM/nvidia packet worker: key from .env NEVER echoed | grep tools/openai_worker.py for key handling; run with a FAKE key env and assert absent from stdout/logs | key leak in worker logs |
| P7 | gate sections | `validate --staged` takes 7-15 min foreground (the reason for detached-only) | read the last 10 gate-perf durations — is 7-15min still true or has it drifted (today's gates ran 3-12min)? | over/under-waiting; stale cost model |
| P8 | L93-94 | D038 lesson: cost-outlier audits mandatory for D039 briefs | prose/policy — check the last 5 briefs actually carried footprints (sample) | drift back to unbounded briefs |
| P9 | routing section | overseer pin fable/high; sol fallback xhigh (owner 2026-07-23) | read model-routing.json — confirm no drift since f69e9fb | wrong-tier sessions |
| P10 | L321 | [QUEUE PARAPHRASE CORRECTED post-audit: the playbook's actual claim is `route --heartbeat` never spawns — Conductor A explicitly spawns twice; my original paraphrase misattributed] | grep the route dispatcher for the guard (mechanism vs prose) — CONFIRMED | double-spawn cost |

## Audit outcome (2026-07-23, Sonnet worker — result-playbook-pin-audit.md)

9/10 CONFIRMED, 1 REFUTED: P7 (gate 7-15min → real ~5-6min typical since the
D041 parallel flip, outliers ~21.5min; CLAUDE.md corrected via sanctioned edit).
Meta-lesson landed: the worker's naive shell probes reproduced BOTH trap classes
(stdin-already-EOF false negative on P1; live MSYS /usage mangle on P3) and
flipped to correct verdicts via subprocess list-args isolation — the discipline
this queue was built to enforce.

Worker contract: test P1-P7 empirically where marked (terra/haiku only — NEVER
fable/opus/sol probes; skip anything that would bill >$0.05 and mark
OWNER-GATED), P8-P10 by source inspection. Verdict per pin:
CONFIRMED / REFUTED (with verbatim evidence) / UNTESTABLE-cheaply. Findings
land in `.harness/handoff/result-playbook-pin-audit.md`; REFUTED pins become
overseer fixes in the same family as today's three corrections.
