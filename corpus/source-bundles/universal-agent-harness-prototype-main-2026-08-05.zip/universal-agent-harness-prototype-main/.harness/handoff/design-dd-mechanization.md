# Design study — Double Diamond mechanization (codex gpt-5.6-sol xhigh, 2026-08-01)

> Read-only design study delegated during a live DD round (docs/research/defect-decide-materialize-bridge.md).
> Author: codex gpt-5.6-sol @ xhigh. Verify [repo] path:line before implementing; [judgment] = author reasoning.

## Decisão arquitetural

[judgment] O menor desenho coerente não quebra `one-run-one-executor` na primeira versão. Ele introduz uma **onda lógica** que o novo `research round` compila deterministicamente em WFs filhos homogêneos por executor/modelo:

```text
Develop lógico
  ├─ WF Claude/Sonnet
  └─ WF NVIDIA/GLM

Refine lógico — cruzado
  ├─ WF NVIDIA/GLM  --seed WF-Claude
  └─ WF Claude/Sonnet --seed WF-NVIDIA
```

Isso elimina a montagem manual, preserva o runtime, o scheduler, o circuit breaker, o isolamento de env e o `repoAccess` atuais. Um único WF fisicamente heterogêneo deve ser um upgrade posterior, não pré-requisito.

O resultado é:

- o overseer declara fleet, perspectivas, lentes, largura, orçamento e política de seed uma vez;
- o compilador agrupa os assentos por executor/modelo;
- cada grupo usa `workflow plan → start/await → collect → reduce`;
- a crítica cruzada usa o `--seed` singular atual, uma aresta por WF filho;
- Phase 2 continua sendo aprovação humana;
- `WORKER_RESULT` e `REDUCE_RESULT` permanecem intactos.

## 1. Fatos confirmados no repositório

### Contrato Double Diamond

- [repo] `.harness/prompts/research-playbook.md:48-64` define Phase 0–5, exige um novo `workflow plan` por onda e limita `--seed` a convergência.
- [repo] `.harness/prompts/research-playbook.md:68-98` exige pergunta, critérios, orçamento, largura e, quando aplicável, desenho experimental.
- [repo] `.harness/prompts/research-playbook.md:120-127` faz da Phase 2 um gate humano obrigatório.
- [repo] `.harness/prompts/research-playbook.md:129-166` separa geração independente de crítica/convergência.
- [repo] `.harness/prompts/research-playbook.md:168-179` deixa portfolio, decisões, experimentos e promoção na Phase 5.
- [repo] `.harness/prompts/research-playbook.md:208-220` afirma que o caminho bloqueante pode resolver executor por `taskProfile`, mas o async ainda é group-level.

### Perfis e largura

- [repo] `.harness/workflows/workflow-profiles.json:344-412` fixa `research-divergence` em cinco branches `plan`, `minSuccess: 3`, `seedForbidden: true`.
- [repo] `.harness/workflows/workflow-profiles.json:414-477` fixa quatro lentes em `research-critique`, com `minSuccess: 2`.
- [repo] `scripts/harness_lib/workflow_plan.py:93-105` exige declaração de largura apenas quando as branches default são usadas.
- [repo] `scripts/harness_lib/workflow_plan.py:263-268` considera uma lista explícita de branches como largura declarada, mas não ajusta `minSuccess`.

### Roteamento e escolha de modelo

- [repo] `.harness/routing/model-routing.json:107-143,183-214,240-252` roteia `plan`, `review`, `scan`, `security` e `ui-validation` primariamente para Claude; nenhum desses papéis baseline aponta para `nvidia-compat`.
- [repo] `.harness/routing/task-profiles.json:204-223` mapeia `ui-validation.claude → sonnet`.
- [repo] `.harness/routing/task-profiles.json:321-340` mapeia `plan.claude → fable` e `plan.nvidia-compat → z-ai/glm-5.2`.
- [repo] `.harness/routing/executors.json:66-121` define o adapter Claude com `--model`/`--effort`.
- [repo] `.harness/routing/executors.json:220-273` define NVIDIA como HTTP/OpenAI-compatible, concorrência 4 e `repoAccess: none`.

Logo, o uso de `ui-validation` para obter Sonnet foi um hack de roteamento: misturou a semântica da tarefa com a escolha do assento.

### Branches e execução

- [repo] `scripts/harness.py:1183-1215` aceita apenas `title`, `taskProfile`, `workerRole` e `paths`; outros campos da branch não chegam ao worker.
- [repo] `scripts/harness_lib/worker_prompt.py:174-194` materializa o worker sem executor/modelo.
- [repo] `scripts/harness.py:1792-1807` dá precedência a `--executor`; sem ele, resolve por `taskProfile`.
- [repo] `scripts/harness.py:1850-1860` já calcula um executor por worker no caminho bloqueante.
- [repo] `scripts/harness.py:1828-1831` limita concorrência apenas pelo executor do run, não por cada executor resolvido.
- [repo] `scripts/harness_lib/async_runtime.py:814-826,894-936` materializa um único executor no grupo async e em todas as tasks.
- [repo] `scripts/harness_lib/workflow_spawn.py:38-53` já possui o seam necessário para override uniforme de `model`/`effort`; ele não precisa ser reinventado.

### Seed e contratos tipados

- [repo] `scripts/harness.py:1344-1385` aceita um único WF, extrai até 12 findings e copia um digest `untrusted-derived`.
- [repo] `.harness/prompts/subagent-contract.md:70-140` fixa `WORKER_RESULT` e `REDUCE_RESULT`; nenhum dos dois precisa mudar.
- [repo] `scripts/harness_lib/workflow_reduce.py:341-364` preserva `sourceWorkerIds`.
- [repo] `scripts/harness_lib/workflow_reduce.py:137-145` valida `repoAccess` usando `workflow.get("executor")`, embora o executor efetivo esteja hoje no histórico do round. Isso precisa ser corrigido mesmo no desenho homogêneo.

### DAG e estado existentes

- [repo] `schemas/workflow.schema.json:61-71` reserva `slots` e `dependsOn`, mas declara que `dependsOn` ainda não é consumido.
- [repo] `docs/FLOW_COMPOSER.md:3-10` deixa claro que o DAG atual é uma visualização derivada de um WF, não um scheduler arbitrário multi-WF.
- [repo] `scripts/harness_lib/research_admin.py:1-12,127-166` já possui o verbo `research`.
- [repo] `scripts/harness_lib/research_index.py:2-14,72-97,118-157` já trata `docs/research/<slug>.md` como fonte canônica e extrai phases, budget e WFs de forma derivada.

Portanto, não se deve fingir que `workflow.json.dependsOn` já executa o round inteiro. O novo verbo deve ser um compilador/driver restrito, não um novo DAG engine.

### Evidência da rodada atual

A árvore atual confirma o workaround:

- [repo] `.harness/workflows/active/WF-20260801-123446-938803/workflow.json:5,38,151,206-238` contém duas branches Sonnet, obtidas via `ui-validation`, executadas em Claude, mas ainda com `minSuccess: 3`.
- [repo] `.harness/workflows/active/WF-20260801-123459-163649/workflow.json:5,38,151,206-246` contém duas branches `plan` executadas em NVIDIA, também com `minSuccess: 3`.
- [repo] `.harness/workflows/active/WF-20260801-130056-123665/workflow.json:5-12,41` é uma crítica NVIDIA semeada somente do WF Claude.
- [repo] `.harness/workflows/active/WF-20260801-130057-824937/workflow.json:5-12,41` é a crítica inversa, Claude semeada somente do WF NVIDIA.

Assim, a afirmação “a crítica foi pulada” descreve um ponto anterior da sessão; no estado lido agora, ela foi posteriormente montada como **dois WFs cruzados**. A fricção permanece: o overseer ainda precisou construir manualmente quatro WFs físicos.

## 2. Round spec parametrizado

[judgment] O round doc canônico ganha um bloco JSON estrito. O restante do Markdown continua livre para evidências, briefs, operações e portfolio.

```json
{
  "schemaVersion": "1.0",
  "slug": "intake-materialization",
  "question": "Como ligar intake decide a uma consequência durável sem gerar lixo?",
  "successCriteria": [
    "idempotente",
    "gate-hold-safe",
    "sem artefato órfão",
    "reusa estado e verbos existentes"
  ],
  "experimentDesign": {
    "card": "matched-budget",
    "why": "comparação entre fornecedores"
  },
  "budget": {
    "roundMaxPlannedTokens": 64000,
    "developStopRatio": 0.60
  },
  "discover": {
    "flows": ["repo", "web"],
    "evidenceSection": "Phase 1 — Evidence matrix"
  },
  "define": {
    "briefs": [
      {
        "id": "B1",
        "problem": "Decisions become invisible after intake decide",
        "actors": ["owner", "overseer"],
        "constraints": ["SPEC-112", "idempotency", "gate hold"],
        "successCriteria": ["durable intent", "no automatic speculative spec"]
      }
    ],
    "humanApprovalRequired": true
  },
  "develop": {
    "profile": "research-divergence",
    "briefs": ["B1"],
    "width": {
      "mode": "exploratory",
      "count": 4,
      "why": "four independent mechanisms are materially distinct"
    },
    "budget": {"maxPlannedTokens": 32000},
    "assignment": "zip",
    "fleet": [
      {
        "id": "sonnet",
        "executor": "claude",
        "model": "sonnet",
        "effort": "high",
        "count": 2
      },
      {
        "id": "glm",
        "executor": "nvidia-compat",
        "model": "z-ai/glm-5.2",
        "effort": "high",
        "count": 2
      }
    ],
    "perspectives": [
      {"id": "simplicity", "taskProfile": "plan", "title": "Simplicity and deletion"},
      {"id": "reliability", "taskProfile": "plan", "title": "Reliability and recovery"},
      {"id": "analogy", "taskProfile": "plan", "title": "Cross-domain analogy"},
      {"id": "trust", "taskProfile": "plan", "title": "Trust boundary and privacy"}
    ]
  },
  "refine": {
    "profile": "research-critique",
    "width": {
      "mode": "custom",
      "count": 4,
      "why": "one critic per fixed lens"
    },
    "budget": {"maxPlannedTokens": 32000},
    "fleet": [
      {
        "id": "glm",
        "executor": "nvidia-compat",
        "model": "z-ai/glm-5.2",
        "effort": "high",
        "count": 2
      },
      {
        "id": "sonnet",
        "executor": "claude",
        "model": "sonnet",
        "effort": "high",
        "count": 2
      }
    ],
    "lenses": [
      {"id": "validity", "taskProfile": "review"},
      {"id": "architecture", "taskProfile": "review"},
      {"id": "cost", "taskProfile": "scan"},
      {"id": "security", "taskProfile": "security"}
    ],
    "seedPolicy": {
      "mode": "cross-vendor",
      "coverage": "balanced",
      "excludeSameExecutor": true,
      "maxFindingsPerSource": 12
    }
  },
  "deliver": {
    "requireOneOperationPerConcept": true,
    "requireExactlyOnePortfolioBucket": true,
    "autoPromote": false
  }
}
```

Regras de compilação:

1. `sum(fleet.count) == width.count`.
2. Número de perspectivas/lentes deve ser igual à largura no modo `zip`.
3. Cada tuple executor/modelo deve existir nas configurações vivas; o compilador não mantém uma tabela paralela.
4. Um budget lógico é a soma dos token audits dos WFs filhos.
5. `minSuccessEffective = min(profile.minSuccess, childWorkerCount)`.
6. A Phase 3 nunca recebe seed.
7. Em Phase 4, toda aresta deve satisfazer `source.executor != critic.executor`.
8. Se não houver matching cruzado para algum source cohort, compile falha antes de gastar tokens.

## 3. Compilação para os primitives atuais

Para o exemplo acima, Develop vira dois WFs:

```json
[
  {
    "title": "Simplicity and deletion",
    "taskProfile": "plan",
    "workerRole": "ideator-simplicity"
  },
  {
    "title": "Reliability and recovery",
    "taskProfile": "plan",
    "workerRole": "ideator-reliability"
  }
]
```

```bash
workflow plan --profile research-divergence --branch-json '<above>'
workflow start WF-A --executor claude --model sonnet --effort high --min-success 2
```

O segundo child recebe analogy/trust e roda com:

```bash
workflow start WF-B --executor nvidia-compat --model z-ai/glm-5.2 \
  --effort high --min-success 2
```

`--model`/`--effort` são a pequena extensão proposta; `taskProfile` volta a expressar capacidade/contrato, não um truque para selecionar modelo.

A crítica lógica `balanced` produz duas arestas:

```bash
workflow plan --profile research-critique --seed WF-A \
  --branch-json '<validity+architecture>'
workflow start WF-QA --executor nvidia-compat --model z-ai/glm-5.2 \
  --effort high --min-success 2

workflow plan --profile research-critique --seed WF-B \
  --branch-json '<cost+security>'
workflow start WF-QB --executor claude --model sonnet \
  --effort high --min-success 2
```

O driver executa `await → collect → reduce` em cada filho e agrega apenas status/handles no estado lógico. Ele não concatena findings nem substitui a decisão da Phase 5.

[judgment] Com dois fornecedores e quatro críticos totais, é matematicamente impossível dar as quatro lentes a cada source cohort mantendo a restrição cross-vendor: isso exigiria oito críticos. `coverage: balanced` dá duas lentes a cada cohort; um futuro `coverage: full` pode expandir para oito, sujeito ao budget.

## 4. Primitives mínimos

| Mudança | Tipo | Footprint |
|---|---|---|
| Override uniforme `--model/--effort` em `workflow run/start` | extend-existing | `scripts/harness_lib/cli_workflow_tree.py`; `scripts/harness.py::workflow_run`, `run_one_worker`, `cmd_workflow_run`; `scripts/harness_lib/async_runtime.py::workflow_start`; reutiliza `workflow_spawn.resolved_spawn` |
| Modelo exato participa do spawn-economy guard | extend-existing | `scripts/harness_lib/spawn_guard.py::first_denied_worker`; o pin deve ser avaliado, não o model default do profile |
| Executor efetivo por worker para `repoAccess` | correção existente | carimbar `resolvedExecutor`/`actualExecutor` nos caminhos bloqueante e async; `scripts/harness_lib/workflow_reduce.py::workflow_validate_results` valida por worker, não por `workflow.get("executor")` |
| Clamp de `minSuccess` ao número de tasks do grupo | correção existente | `scripts/harness_lib/async_runtime.py::workflow_start`, logo após calcular `runnable`; uma onda de dois nunca mantém quorum três |
| `research round` compiler/driver | nova action de verbo existente | `scripts/harness_lib/cli_registry.py`, `research_admin.py::cmd_research`, novo módulo pequeno `research_round.py`, `research_index.py::parse_round` |
| Bloco spec/state no round doc | extend-existing | `docs/research/<slug>.md` continua canônico; `research_index` lê blocos exatos, e `research_admin` já encontra WFIDs para inventário/delete |
| Contrato do round | novo schema pequeno | `schemas/research-round.schema.json`; valores de executor/modelo continuam derivados das configurações vivas |

O CLI proposto:

```bash
python scripts/harness.py research round <slug> compile
python scripts/harness.py research round <slug> advance
python scripts/harness.py research round <slug> approve --brief B1
python scripts/harness.py research show <slug>
```

- `compile`: zero materialização; compila todos os children possíveis via `validate_workflow_plan`.
- `advance`: cria/inicia apenas nós ready, ou retoma os WFs já registrados.
- `approve`: registra a decisão humana no bloco gerado de estado.
- `show`: continua sendo a visão derivada existente.

## 5. Upgrade opcional: um único WF heterogêneo

[judgment] Só construir se o requisito for literalmente “um único `workflow.json`”, não apenas “uma onda lógica declarada uma vez”.

A branch futura seria:

```json
{
  "title": "Simplicity and deletion",
  "taskProfile": "plan",
  "workerRole": "ideator-simplicity",
  "spawn": {
    "executor": "claude",
    "model": "sonnet",
    "effort": "high"
  }
}
```

Precedência:

```text
--executor/--model explícitos no run
  > branch.spawn
  > model-routing ativo
  > executor default
```

Isso toca `default_fork_branches`, `write_worker_prompt`, `resolve_worker_executor`, `run_one_worker`, `workflow_start`, `first_denied_worker`, o scheduler por-executor, `spawn-commands`, reducer `repoAccess` e o composer. No async, rompe deliberadamente o invariant group-level e exige semáforos por executor; portanto não é uma “mudança de duas linhas”.

Um `--seed` repetível também fica fora do MVP. A onda lógica cruzada já usa o `--seed` singular atual em cada aresta. Só adicionar multi-seed se um futuro único WF crítico precisar consumir vários WFs fonte. Nesse caso:

- extensão de `cli_workflow_tree.py`, `cmd_workflow_plan`, `build_seed_context` e `_compile_workflow_plan`;
- cap global de 12 findings, distribuído round-robin entre fontes;
- profundidade `max(source.depth)+1`;
- seed continua proibido em divergence;
- selectors por branch devem impedir que um critic veja material do próprio executor.

## 6. Phases como nós resumíveis versus julgamento

| Phase | Nó | Mecanizado | Continua humano |
|---|---|---|---|
| 0 Prep | `declaration-check` | schema, fleet, width, budget, design card, configs vivas | pergunta, critérios e justificativas |
| 1 Discover | `manual-evidence` | presença/formato do register e handles | busca, qualidade da fonte, incerteza |
| 2 Define | `human-gate` | briefs completos; estado `waiting-approval` | enquadramento do problema e aprovação |
| 3 Develop | `workflow-group` | plan/start/await/collect/reduce, resume e budget agregado | decidir se uma onda extra vale o custo |
| 4 Refine | `crossed-workflow-group` | matching cross-vendor, seeds, critics e status | operação final por conceito e set convergence |
| 5 Deliver | `delivery-gate` | validar operação, bucket, experimento registrado e traceabilidade | portfolio, decisão, SPEC-116 e promoção |

O gate humano não deve virar um score automático. O harness verifica completude e bloqueia avanço; ele não declara um brief “bom”.

## 7. Documentação e drift

O único runbook continua sendo `.harness/prompts/research-playbook.md`. Ele deve ganhar:

- o bloco JSON mínimo;
- os quatro comandos `research round`;
- a explicação “onda lógica → WFs filhos”;
- a regra de crossing;
- um link para o round doc atual.

Não copiar tabelas de modelos para o playbook. `research round catalog` deve derivar executor/modelo/effort de `model-routing.json`, `task-profiles.json` e `executors.json`.

A proteção contra drift fica em `testing/scenarios/rs_research_skill.py`: compilar o exemplo do playbook, provar que as tuples ainda existem, que nenhum seed entra em divergence e que toda aresta crítica é cross-vendor. `ra_research_admin.py`, `ri_research_index.py` e `wf_failover.py` cobrem o restante.

## 8. Ladder de implementação, menor primeiro

1. **P0 — corrigir `minSuccess` e `repoAccess`.** Clamp ao grupo runnable; validar cada result pelo executor efetivo do worker. Amendment SPEC-119, cenário `rs_research_skill.py`.
2. **P1 — spawn pin uniforme.** Adicionar `--model/--effort` a `workflow run/start`, usando o `spawn_override` existente; pin exato sem fallback no MVP.
3. **P2 — compilar round spec.** Estender o verbo `research` com `round compile`, usando o round doc canônico e `validate_workflow_plan`; nenhum worker roda ainda.
4. **P3 — advance/resume.** Materializar WFs filhos homogêneos, registrar WFIDs no bloco gerado, start/await/collect/reduce e retomar somente children incompletos.
5. **P4 — crítica cruzada.** Matching bipartido `source.executor != critic.executor`, um `--seed` existente por aresta; provar ausência de divergence→divergence.
6. **P5 — gate/deliver.** Aprovação humana explícita, validação de operações/buckets/experimentos; promoção continua opt-in.
7. **P6 — somente se exigido:** `branch.spawn`, scheduler per-executor e multi-seed para um único WF físico heterogêneo.

A cobertura existente torna isto provavelmente a porta **COVERED** do SPEC-116: começar com `records search`/`doc-find`, recapitular SPEC-119 e produzir amendment versionado; async mixed-executor, se promovido, também amenda o contrato de routing/runtime correspondente.
