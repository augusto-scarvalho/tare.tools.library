# DRAFT — GUI activity visibility (plan-role drafter: kimi)

Result of the draft request `.harness/handoff/context-gui-activity-visibility.md`
(the request says "result path named at the bottom"; the bottom names none — the
spawning instruction named this path). Plan only: no code was written. Every code
claim below was re-verified against source on 2026-07-31; unverifiable claims are
marked UNVERIFIED.

## 0. Verification ledger

VERIFIED (spot-checked verbatim against source):

- SSE + frame vocabulary: `ui/src/api/chat.ts:137-157` (one EventSource,
  `/api/chat/stream?session=&token=`), frames `{stream,line,data}` (`chat.ts:121`),
  event names listed at `chat.ts:87-90`.
- `reduce` at `chat.ts:226-318`; `TapeState` at `chat.ts:189-199` (verbatim match);
  tool block at `chat.ts:174`; tool handling at `chat.ts:268-288` (verbatim match);
  `turn-start`→`streaming:true` (`chat.ts:244-251`); `ready`/`exit`→false
  (`chat.ts:252-263,313-314`); `question` dropped in `default` (`chat.ts:315-316`);
  `selfCheck()` at `chat.ts:355-477`.
- `Composer.tsx` presentational, props `{streaming,hasSession,onSend,onStop,onNew}`
  (`Composer.tsx:21-27`); DOM: `.wb-composer` > `.wb-prompt` (+`--live`,
  `Composer.tsx:94`), `.wb-composer-input` > `textarea.wb-input` +
  `.wb-upload-status` aria-live with `<Status kind="running" variant="dot">`
  (`Composer.tsx:114-142`); composer CSS `workbench.css:171-198`;
  `.wb-prompt--live` = signal-pulse (`workbench.css:178-180`).
- `WorkbenchScreen.tsx`: holds `tape` (`:41`), `sseError` (`:42`), `stateKind`
  derivation verbatim at `:93`; publishes leftTop node `{strip}{compactTape}` at
  `:99-115`; passes `streaming` down at `:141`.
- `AppShell.tsx:80-101` (verbatim); `hasLeft = p.leftTop != null || p.left != null`
  at `:40` with the D3 rationale at `:35-39`; `{p.left ?? 'Context'}` at `:91`.
- `App.tsx`: the single AppShell call site is `:907-920` (request said 907-919 —
  the element closes on `:920`; immaterial); `left` passed by nobody; `leftTop`
  gated to workbench at `:908`. `DomainView` forwards `onLeftTop` to
  `WorkbenchScreen` at `App.tsx:782-802` (the wiring pattern any `onLeft` copies).
- `appshell.css:17-25` verbatim. `usePersistentWidth.ts:31-53`, try/catch storage
  at `:9-24`.
- `tokens.css`: every token the request lists exists (`--accent`:31, `--stream`:32,
  `--success/--warning/--danger`:33-35, `-bg/-border` pairs:38-49,
  surfaces:14-16, borders:19-21, text:23-29, `--font-ui`:52, `--text-xs..xl`:56-60,
  `--space-1..4`:71-74, `--radius-sm/xs`:68-69, `--h-row:34px`:66).
- `status.css`: `@keyframes signal-pulse` at `:35`; `.row-rail` at `:39-44`.
- `docs/DESIGN_SYSTEM.md` is 146 lines; the seven quoted laws verify (§0 laws 1-5,
  §5 motion, §6 data honesty incl. DERIVADO ≠ FABRICADO `:96-111` and the lacuna
  law `:112-117`).
- Backend endpoints exist: `/api/queue` (`scripts/harness_ui.py:1294`),
  `/api/events` (`:1298`), `/api/worker` (`:1374`), `/api/chat/sessions` (`:1403`).
  `queue_snapshot` carries per-worker `status`+`taskProfile`
  (`scripts/harness_lib/ui_queue.py:81-85`) and per-workflow `phase`/`phaseLabel`
  (`:88-92`). Sessions rows `{id,label,alive,engine,createdAt}` with
  `alive = proc.poll() is None` (`scripts/harness_lib/ui_chat_bridge.py:93,283-287`).
- `question` semantics: legacy `handleEvt` routes it to `askQuestions(d.questions)`
  (`scripts/harness_ui_page.py:2539`) — it is the HITL ask = "waiting on you".
- `pw_ui_smoke`, "63 checks today": VERIFIED EXACTLY — 45 named + 7 `route-*` in
  `ui/tests/pw-smoke.mjs` + `pw-server-ready` + 10 named in `ui/tests/pw-interact.mjs`
  = 63. Id convention: kebab-case, `PWCHECK <name> PASS|FAIL — detail`
  (`pw-smoke.mjs:9,40-43`), mapped 1:1 to scenario checks
  (`testing/scenarios/pw_ui_smoke.py:132-138`); spec-named tooth guard at
  `pw_ui_smoke.py:148-153`. Workbench teeth drive the `&debug=workbench` fixture
  (e.g. `pw-smoke.mjs:861`).

CORRECTIONS to the pre-assembled context (evidence, not preference):

1. "Status with StatusKind (11 states)" — STALE: 12 kinds today (`Status.tsx:9-12`;
  `needs-revision` added at `:31`).
2. "variants pill / dot / rail" — WRONG: the component takes only `'pill' | 'dot'`
  (`Status.tsx:39`); rail is CSS-only `.row-rail` + `data-status`, explicitly "not a
  component" (`Status.tsx:4-6`; `status.css:39-44`).
3. "What the backend has that the client does NOT get today" — OVERSTATED: the React
  client already fetches `/api/queue` (`ui/src/api/operations.ts:66-68`,
  `ui/src/api/inbox.ts:126`), `/api/worker` (`operations.ts:70-73`) and `/api/events`
  (`ui/src/api/events.ts:38,45`). True statement: the WORKBENCH surface never
  touches queue/worker. Matters for Q5: the typed reader already exists; rung 2 is
  wiring, not a new client.

UNVERIFIED (not load-bearing for v1):

- Detached spawns "have NO listing endpoint" — not checked; excluded from v1 anyway.
- `async/tasks/*.json` carrying stdout/stderr paths — `pid`/`startedAt` verify via
  `WorkerDetail.task` (`operations.ts:56-60`); stdout/stderr path fields not seen.
- Whether every `tool-delta` sequence terminates in a `tool-result` — unknown;
  neutralized by the turn-end sweep in A6, so no design risk.
- Whether `question` frames render anywhere in the React workbench today — verified
  only that the reducer drops them (`chat.ts:315-316`) and `ConversationScreen`
  takes no question prop (`ConversationScreen.tsx:13-25`): the wait is invisible
  today beyond `streaming` staying true.

## 1. Where I disagree with the owner's framing

- "shell-left-body … meio largada" reads as neglect. It is a DELIBERATE D3
  deviation (`AppShell.tsx:35-39`): the body renders the string `Context` because
  nobody passes `left`, and the aside exists at all only because workbench passes
  `leftTop`. The fix is not cleanup — it is becoming the first real `left` caller,
  which the D3 comment explicitly anticipated (`AppShell.tsx:39`).
- "esperando agentes" is not provable from the stream (A2). I will not put a label
  on the phase line that the wire cannot pay for.

## 2. The thirteen answers

### A1 — Phase derivation (state machine over the existing vocabulary)

DECISION: six phases — `idle | thinking | writing | running <tool> | waiting | dead`
— derived in the reducer; latest observable verb wins.

| frame | → phase |
|---|---|
| (reset / `emptyTape`) | `idle` |
| `you` (optimistic send echo, `WorkbenchScreen.tsx:81`) | `thinking` |
| `turn-start` | `thinking` |
| `text` | `writing` |
| `tool` | `running`, payload `{name, arg one-line}` |
| `tool-delta` | unchanged (still `running` that tool) |
| `tool-result` | `running <next open tool>` if any tool block since `turnStart` lacks `doneAt`, else `thinking` |
| `question` | `waiting` (reducer gains this case; dropped today at `chat.ts:315-316`) |
| `turn-end` | unchanged — the turn-end→ready gap is sub-second; a 7th state buys nothing |
| `ready` | `idle` |
| `exit` | `dead` |
| sseError / sessions-poll `alive===false` | `dead` — view-side override in `WorkbenchScreen`, the SAME inputs as `stateKind` (`WorkbenchScreen.tsx:92-93`) |

`question` fits as the only owner-action phase; the wire proves it
(`harness_ui_page.py:2539`). Tool open AND text streaming: latest frame wins —
`text` after `tool` reads `writing`; the still-open tool remains visible in the D2
rail (that is the D1/D2 division, A10). Justification: the phase line reports the
most recent observable fact; a priority lattice would invent certainty the stream
does not carry. Cost: a background long-running tool leaves D1 while the model
narrates — accepted, D2 covers it.

### A2 — Honesty boundary ("rodando testes" / "esperando agentes")

DECISION: zero classification. The line shows the FACT: `running Bash · pytest -x`
— name + first line of `arg`, verbatim from the frame (`EvtData.name/.arg`,
`chat.ts:99-100`). Classifying "Bash + arg matches pytest" as "running tests" is a
DERIVED category; under law 6 (`DESIGN_SYSTEM.md:94-117`) a category the transport
does not carry is fabrication, and the raw arg already tells the owner it is tests.
"Esperando agentes" the stream cannot prove at all — no frame names a subagent
wait; when a spawn tool call exists it arrives as a `tool` frame and shows as
`running <name> · <arg>`. When the line cannot prove a category it shows the raw
name/arg — which is precisely the visibility demanded. Cost: no semantic badges;
the owner reads args (mono, one line, ellipsis).

### A3 — Where the phase state lives

DECISION: in the reducer, as `phase` + `phaseTool?: {name, arg}` on `TapeState`
(`chat.ts:189-199`), owned by `ui/src/api/chat.ts`. View-computed-from-`blocks` is
strictly worse: the decisive frames leave NO blocks — `question` (dropped),
`turn-start`, the tool-result→thinking transition — so the view cannot reconstruct
`waiting` at all. Reducer residence also makes the machine assertable in
`selfCheck()` (`chat.ts:355-477`), which the request mandates extending. Cost:
`TapeState` grows two fields; every frame recomputes phase (trivial); consumers
re-render exactly as they do for `streaming` today.

### A4 — Placement + DOM for the phase line

DECISION: inside `.wb-composer-input` (`Composer.tsx:114`) as its FIRST child —
directly above `textarea.wb-input` (`Composer.tsx:115-134`), left-aligned with it,
literally "logo acima da caixa de text-area". Not a sibling above `.wb-composer`:
that is the PlanRail slot (`ConversationScreen.tsx:31`, `workbench.css:258`) and
stacking a second pinned bar there is card-soup.

DOM:

    <div className="wb-phase" role="status" aria-live="polite">
      <Status kind={phaseKind} variant="dot" label={phaseLabel} />
      {phaseTool && <span className="wb-phase-arg">{phaseTool.name} · {phaseTool.arg}</span>}
    </div>

Aria: ONE polite live region, disjoint from `.wb-upload-status`
(`Composer.tsx:135`) which announces upload lifecycle and escalates to `assertive`
only on error — different facts, no duplication; the phase line never asserts.
Phase text changes only on TRANSITIONS (a hundred `text` frames all set
`writing`), so no announcement spam. Layout: reserved `min-height` — pushes
nothing, idle renders the word "idle" muted, the line never collapses (mirrors
`.wb-upload-status{min-height:12px}`, `workbench.css:190`).

CSS (layout only, tokens only, law 2/3):

    .wb-phase{ display:flex; align-items:center; gap:var(--space-2); min-height:12px;
      font:var(--text-xs)/1 var(--font-mono); }
    .wb-phase-arg{ min-width:0; overflow:hidden; text-overflow:ellipsis;
      white-space:nowrap; color:var(--text-muted); }

Kind map (existing tones only; label override is the sanctioned mechanism,
`Status.tsx:40`): thinking/writing/running → `running` (stream tone, pulses —
glow only on active, `DESIGN_SYSTEM.md:91`); waiting → `reviewing` (warning =
owner action needed); idle → `planned`; dead → `failed`. Cost: `Composer` gains a
`phase` prop; `ConversationScreen` pipes it like `streaming`
(`ConversationScreen.tsx:33-38`).

### A5 — The rail's data source (v1)

DECISION: v1 derives the rail from tape tool blocks ONLY. The frames are already in
the client (`chat.ts:268-288`); zero new fetch, backend untouched (hard
constraint). The owner's three examples — worker/shell/command — are chat tool
frames of the session being watched. `/api/queue` is rung 2, argued separately:
harness workflow workers never appear in the chat stream (different source,
`ui_queue.py:70`), and when rung 2 lands it REUSES `fetchQueue()`
(`operations.ts:66-68`) plus the established 10s+focus poll
(`WorkbenchScreen.tsx:46-59`) — wiring, not a new client. Cost of deferring:
harness-level workers stay out of the rail — but they are already visible in
Operations Queue/Workers tabs and the inbox stalled fan-in (`inbox.ts:117-126`),
so there is no visibility vacuum.

### A6 — Rail item model

DECISION: item = projection of a tool `TapeBlock`: `{id, toolId, name, arg,
startedAt: block.ts, doneAt?, output?}`. Ordering: execution-START order = tape
append order (`chat.ts:268-276`) — stable, no sort, replay-consistent.
Discriminator: TODAY openness is `output === undefined`; AFTER: `doneAt ===
undefined` — a delta-streaming tool has output yet still runs, so `doneAt` is
strictly more honest. Finish timestamp: the reducer stamps `doneAt: Date.now()` on
the `tool-result` hit, and `turn-end`/`ready`/`exit` SWEEP every still-open tool
block to `doneAt` — the turn/session boundary is a real wire fact; a tool
outliving its turn is not observable (this also neutralizes the UNVERIFIED
delta-without-result case). Exactly ONE field is added to the tool `TapeBlock`:
`doneAt?: number` (`chat.ts:174`). Cost: on SSE reconnect the server replays and
re-stamps `doneAt ≈ replay time`, so replayed tools re-enter the grace window once
— real tools, re-graced; accepted (tape `ts` already behaves this way).

### A7 — Expiry mechanic

DECISION: one `setInterval(1000)` inside `ProcessRail`, mounted ONLY while a
running item exists or a finished item is younger than TTL; the tick refreshes a
`now` state and the render filters `running || now - doneAt < ttlMs`. The filter
lives in a pure exported `railItems(blocks, now, ttlMs)` so `selfCheck` can assert
it with a synthetic clock. TTL elapsing while scrolled: the row leaves on the next
tick regardless of scroll — the grace was served; no pinning, no toast. While
collapsed: the body is `display:none` (`appshell.css:21`) but the projection is
stateless — nothing accumulates, expand shows current truth. Expiry removes from
the RAIL ONLY: `tape.blocks` is never mutated — the tape is the transcript, the
tool blocks are its evidence, and `selfCheck`'s kind-order assert
(`chat.ts:416-417`) depends on it. Cost: a 1 Hz re-render of a ≤N-row list while
active; zero cost idle (interval unmounted).

### A8 — "Configuravel": storage, default, control

DECISION: three chips in the rail header — `10s 30s 60s` — default 30s, persisted
to localStorage key `harness.wb.railGraceS` via a NEW `usePersistentNumber` hook in
`ui/src/shell/usePersistentWidth.ts` (same try/catch `read`/`write` helpers,
`:9-24`; same clamp idiom as the width hook, `:26-40`). Range by construction
{10,30,60} — no free input to validate. Default 30s matches the existing "fresh"
vocabulary (`FRESH_MS = 30000`, `EventFooter.tsx:20`). Chips reuse the existing
`Chip` primitive (`ui/src/components/Chip.tsx`, used e.g. `EventFooter.tsx:11`).
Justified against `usePersistentWidth`/`usePersistentBool`: identical storage law
(localStorage UI-state only, try/caught — `DESIGN_SYSTEM.md:28`); a cycle-button
would be one control but opaque at a glance; three chips self-document inside the
200px minimum rail width. Cost: a ~10-line hook + one header row.

### A9 — The dead-rail problem

DECISION: workbench-only is CORRECT for v1 — the rail lists THIS chat session's
tool processes; other domains have no tape. Following the owner across domains
means mounting an aside where there is no content — exactly the dead rail D3
removed (`AppShell.tsx:35-40`); rejected. Harness-worker cross-domain visibility
already exists (Operations tabs; `inbox.ts:117-126`). Zero processes: the rail
renders an `EmptyState` ("no processes this session yet") — and the aside does NOT
disappear, because `hasLeft` stays true via `leftTop` (`AppShell.tsx:40`).
Collapsed 44px: the body hides (`appshell.css:21`), so the signal moves INTO the
leftTop node, which survives collapse (`AppShell.tsx:21-22,81`): `WorkbenchScreen`
already composes `{strip}{compactTape}` there (`WorkbenchScreen.tsx:101-113`) and
adds a `.wb-rail-mini` — one running-tone Status dot per running process (cap 3,
then `+N`), rendering nothing when zero. Re-expand via the existing
`.shell-persist` button (`AppShell.tsx:93-100`). Cost: leftTop gains a third
child; mini is display-only.

### A10 — D1 vs D2 division of labour

D1 (phase line): the agent's current VERB — one line, one instant: what the model
is doing right now and whether it can answer. D2 (process rail): the LEDGER —
every process spawned, in start order, with outcome and a visible grace countdown.
D1 answers "now"; D2 answers "what is in flight and what just landed".

### A11 — Anti-slop / signature moment

DECISION: VISIBLE DECAY. Finished rail rows carry a live countdown in mono muted —
`done 12s · clears in 18s` — and running rows tick elapsed — `▶ 01:34` in
`--stream`. Expiry becomes MEASUREMENT, not disappearance-magic: the oscilloscope
afterglow rendered as text. Tokens: `--text-xs`, `--font-mono`, `--text-muted`,
`--stream`; the 1 Hz tick already exists for expiry (A7), so the readout costs
nothing. No fade-out animation, no toast — motion law allows pulses only on live
things (`DESIGN_SYSTEM.md:91`); a fade on death is decoration.

### A12 — Verification

`chat.ts:selfCheck()` gains (driving frames in the existing style):
- (a) `turn-start` → `phase==='thinking'` (extends the `missing` chain,
  `chat.ts:427-432`);
- (b) `tool` → `phase==='running'` and `phaseTool.name==='Bash'`;
- (c) `tool-result` → block `doneAt` is a number; phase returns to `thinking` when
  no tool stays open;
- (d) `text` while a second tool is open → `phase==='writing'` (latest-verb
  precedence, A1);
- (e) `question` → `phase==='waiting'` AND `blocks.length` unchanged (no tape
  block invented);
- (f) `ready` → `idle`; `exit` → `dead`;
- (g) `turn-end` sweeps `doneAt` onto a still-open tool block;
- (h) `railItems` with a synthetic `now`: 3 tools (running / in-grace / expired) →
  2 rows in start order, expired dropped.

Playwright teeth, following the kebab-case convention and the `&debug=workbench`
fixture seam (`pw-smoke.mjs:861`; fixture lives behind `App.tsx:335,758`):
- `phase-line-states` — fixture with streaming tool call → line reads
  `running Bash · …` in stream tone; goes `idle` after;
- `phase-line-waiting` — fixture `question` frame → `waiting on you`,
  `role="status" aria-live="polite"` present;
- `process-rail-order` — rows match fixture tool start order; finished row shows
  `/clears in \d+s/`;
- `process-rail-mini` — collapse the panel → mini dot count == running count.
If a spec cites them, add the ids to the tooth guard (`pw_ui_smoke.py:148-153`).

THE ONE mutation that must go red: delete the `doneAt` stamp in the `tool-result`
case → selfCheck assert (c) fails AND pw `process-rail-order` never leaves the
running tone. Twin coverage, one mutation.

### A13 — What I would cut

Nothing in the D1/D2 core is over-built; the fat is all in the ladder: (1)
`/api/queue` merge — rung 2, not v1 (A5); (2) cross-domain rail — rejected (A9);
(3) detached-spawn visibility — no listing endpoint (UNVERIFIED) and out of scope;
(4) `.wb-rail-mini` could degrade to "the strip dot already pulses"
(`AgentChannelStrip.tsx:37-40`) if contested — the rung below, but the owner
explicitly feared losing the signal on collapse, so I keep the mini. Laziest
owner-satisfying version: phase line (A1-A4) + tape-derived rail with chips and
countdown (A6-A8). If forced to ONE deliverable: D1 — it answers the demand's
first sentence (pensando / escrevendo / esperando) for a fraction of the surface.

## 3. Change surface (implementation footprint — NOT done here)

1. `ui/src/api/chat.ts` — `phase`/`phaseTool` on `TapeState`, `doneAt` on the tool
   `TapeBlock`, reducer cases (`question`, result/turn-end sweeps), `railItems`
   projection, `selfCheck` asserts (A12).
2. `ui/src/domains/workbench/Composer.tsx` — `phase` prop + the A4 DOM.
3. `ui/src/domains/workbench/ConversationScreen.tsx` — pipe `phase`.
4. `ui/src/domains/workbench/WorkbenchScreen.tsx` — dead-override, publish
   `ProcessRail` via a new `onLeft`, `.wb-rail-mini` into leftTop.
5. `ui/src/domains/workbench/ProcessRail.tsx` — NEW (rail + chips + tick).
6. `ui/src/domains/workbench/workbench.css` — `.wb-phase`, `.wb-rail*` layout,
   tokens only.
7. `ui/src/shell/usePersistentWidth.ts` — `usePersistentNumber`.
8. `ui/src/App.tsx` — `wbLeft` state + `left=` wiring through `DomainView`
   (copies the `onLeftTop` path, `App.tsx:782-802,891,908-913`) + new
   `?debug=workbench` fixture frames.
9. `ui/tests/pw-smoke.mjs` — the four teeth (A12).
10. `testing/scenarios/pw_ui_smoke.py` — tooth guard, only if a spec names them.

Backend `/api/*`: UNCHANGED. New npm dependencies: NONE. UI strings: EN-only.
