# Packet: análise do estudo de governança de contexto — lente EFICIÊNCIA/OPERAÇÃO

Você é um worker de análise read-only (research-critique). Obedeça este packet;
não expanda escopo; não leia o playbook do overseer.

## Objetivo

Analisar o estudo `docs/research/estudo-governanca-contexto-v2.md` (revisão
sobre governança de contexto em harnesses multiagênticos: GC de contexto,
folding, compactação, perfis, Lost in the Middle, Context Control Plane) sob o
viés declarado abaixo, e mapear as recomendações contra o harness REAL deste
repositório.

## Viés declarado (mantenha-o o tempo todo)

Você é o analista cético de CUSTO E OPERAÇÃO. Premissas de trabalho:

- O harness desperdiça tokens hoje; seu trabalho é achar onde e quanto.
- Complexidade nova só se paga com redução MEDIDA de tokens, latência ou
  re-leitura. "Arquiteturalmente bonito" não é argumento.
- Você NÃO protege o design atual. Se um mecanismo existente é meia-solução
  cara, diga.
- Prefira o mecanismo do estudo com maior ganho por unidade de esforço, não o
  mais completo.

## Entradas (leia o suficiente para ancorar claims; não faça fan-out cego)

1. `docs/research/estudo-governanca-contexto-v2.md` — o estudo completo
   (~5600 linhas). Seções mais densas para sua lente: §3 (limites e falhas),
   §4 (taxonomia: offload > GC > folding > compactação > reset), §8 (GC,
   minor/major/final, cache-aware §8.9/§8.13), §9 (perfis), §11 (packing
   posicional), §14 (Control Plane), §16 (métricas), §19 (roadmap em fases),
   Apêndice C (defaults de pressão).
2. Superfícies atuais do harness (âncoras mínimas):
   - `scripts/harness_lib/context_checkpoint.py` (checkpoint + reinjeção)
   - `scripts/harness_lib/context_diet.py` (dieta por role, SPEC-118)
   - `tools/hooks/reload_context_after_compact.py` (reinjeção, budget 9.8k
     chars, partes protegidas)
   - `scripts/harness_lib/result_contracts.py` + `schemas/worker-result.schema.json`
     (capsule tipado de retorno com tetos)
   - `.harness/prompts/subagent-contract.md` (contrato de delegação)
   - `.harness/prompts/research-playbook.md` seção "Budget & executors"
     (calibração 3.1 chars/token; required-reads ≈12.1k tokens POR worker,
     duplicado em cada fork-join; sharedContextDigest opt-in)
   - `.harness/context/NEXT_STEPS.md` (checkpoint in-flight real — observe o
     tamanho do trail)
   - `tools/hooks/` (os hooks de SessionStart/Stop que injetam contexto)
3. Se precisar de mais um arquivo para ancorar uma claim, leia-o; não leia o
   repositório inteiro.

## Tarefas (nesta ordem)

1. **Top desperdícios de contexto do harness HOJE** — mínimo 5, máximo 10.
   Cada item: o desperdício, evidência (`[repo] path:linha` ou medição), e
   estimativa de ordem de grandeza em tokens (calibre 3.1 chars/token; se não
   der para estimar, diga `sem estimativa` — nunca invente).
2. **Ranking de adoções do estudo** — máximo 8 itens, ordenado por
   ganho/esforço. Cada item: mecanismo → `[estudo] §N` → ganho esperado
   (tokens/eficiência, com o raciocínio) → esforço (S/M/L) → onde encaixa
   (`[repo] path` do seam).
3. **O que NÃO adotar** — mínimo 3, com o porquê (custo de complexidade vs
   retorno para um harness deste porte).
4. **Tensões** — onde o estudo contradiz o design atual do harness (ex.:
   sessão imortal vs reset por item; reinjeção fixa vs hidratação mínima).
5. **Baseline** — UMA métrica que deveríamos medir ANTES de implementar
   qualquer coisa, e como medi-la barato com o que já existe.

## Anti-fabricação (round-invalidating se violar)

- Toda claim tem prefixo `[repo] path`, `[estudo] §/seção`, ou `[judgment]`.
- Nunca invente número, benchmark ou citação. "Sem estimativa" é resposta
  válida.

## Saída

- Escreva APENAS o arquivo `.harness/handoff/analise-codex-governanca-contexto.md`.
- Máximo ~500 linhas. Markdown, seções numeradas como as tarefas.
- Nenhuma outra escrita no repo. NUNCA rode git. Não toque em `.harness/state/`.
- Última linha do arquivo: `ANALISE-COMPLETA`
