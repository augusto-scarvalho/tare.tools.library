# Workflow Packets

This directory defines large-task workflows for the Universal Agent Harness. Workflows are used when a normal bounded subagent would exceed the context window, require repeated broad search, or benefit from independent perspectives.

## Supported workflow types

- `map-reduce`: many similar shards, same worker contract, reducer synthesis.
- `fork-join`: multiple specialized branches, join synthesis.

## Current implementation level

The harness now supports a conservative operational runner:

- workflow profiles in `.harness/workflows/workflow-profiles.json`;
- split strategies: `roots`, `changed-files`, `graphify`, `explicit`, `specs-tasks-docs`;
- worker lifecycle states: `pending`, `queued`, `running`, `done`, `partial`, `blocked`, `failed`, `missing`, `skipped`;
- `workflow run` with configurable concurrency and timeout;
- stdout/stderr capture under each workflow runtime directory;
- parsing of worker JSON returned through stdout when the worker did not write the result file directly;
- validation, reducer synthesis, finalize, retry, mark and promote commands.

## Default safety policy

- Workflows are read-only by default.
- Parallel writes are disabled.
- Concurrency controls worker execution only; it does not grant write access.
- Workers must return `WORKER_RESULT`, not full `HARNESS_RESULT`.
- Reducers must return `REDUCE_RESULT`.
- Graphify is used for structural partitioning/discovery when applicable.
- Source files, specs, tests, Git, and `.harness/state/` remain authoritative.

## Directory layout

```text
.harness/workflows/
  WORKFLOWS.md
  workflow-profiles.json
  active/
    WF-*/
      workflow.json
      plan.json
      shards.json | branches.json
      parent-task.md
      workers/
        worker-001.prompt.md
        worker-001.result.json
      run-logs/
        worker-001.stdout.log
        worker-001.stderr.log
      reduce/
        validation.json
        reducer.prompt.md
        reducer.result.json
        reducer.result.md
```

Runtime workflow artifacts under `active/` are ignored by Git by default. Commit a workflow only when it becomes a deliberate project artifact.

## Parent-task pointer in packets

When a wave renders at least 2 worker packets and the parent task is longer than 2400 characters, the plan writes the verbatim task once to `active/WF-*/parent-task.md`, stamps `slots.parentTaskPointer` in `workflow.json`, and each packet's `## Parent task` section carries only a deterministic 1200-character head plus a pointer to that file (and to `seed-context.md` when the wave was seeded). Below either bound the task stays inline and no pointer file is written, so short or single-branch waves are byte-identical to the pre-pointer format. Workers with a filesystem open the pointed-at file only when the head plus their branch scope is insufficient; the HTTP worker (`tools/openai_worker.py`) has no filesystem on the model side, so it re-inlines the file host-side before the request. `parent-task.md` is part of the plan-time secret-scan surface, exactly like the worker prompts and the context digest.

## Recommended lifecycle

1. `python scripts/harness.py workflow plan --profile diff-review --type map-reduce --task "Review current diff"`
2. Inspect the generated `workflow.json`, shard/branch file, and worker prompts.
3. Run workers conservatively with `python scripts/harness.py workflow run <workflow-id> --executor <executor> --concurrency 1`.
4. Validate outputs with `python scripts/harness.py workflow validate-results <workflow-id>`.
5. Reduce findings with `python scripts/harness.py workflow reduce <workflow-id>`.
6. Finalize canonical state with `python scripts/harness.py workflow finalize <workflow-id>`.
7. Optionally promote recommended tasks with `python scripts/harness.py workflow promote <workflow-id>`.

## Concurrency policy

Use `--concurrency N` only when workers are independent. Keep `N=1` until the target executor and project environment are known to handle concurrent sessions safely. Write workflows require `--write-allowed`, `workflow prepare-write`, file-disjoint locks, isolated workspaces, `workflow merge-plan`, approval-gated `workflow apply-merge`, and validation gates.

## When not to use workflows

Avoid workflows for small edits, direct bug fixes, one-file documentation changes, or tasks where the user expects immediate single-step implementation. Workflows add overhead and should only be used to preserve quality and context efficiency for large or multi-perspective tasks.

## Operational guarantees added by the runner

The runner is a controlled read-only workflow runtime, not a free-form multi-agent swarm. A workflow profile may infer `map-reduce` or `fork-join`; the harness creates scoped worker packets and enforces prompt/result budgets. During execution the harness caps concurrency by executor, writes a `.run.lock`, records worker lifecycle events, truncates oversized logs, extracts `WORKER_RESULT` from stdout when needed, and refuses to reduce while workers are still queued/running unless `--allow-partial` is explicitly provided.

`WORKER_RESULT.status` is semantically meaningful. `failed`, `blocked`, and `partial` workers affect `REDUCE_RESULT.status`; they are not treated as successful merely because the JSON is valid. `workflow finalize` writes `reduce/harness-result.json`, updates compact state/context, and regenerates handoff by default.

Use `workflow execute` only when the executor is real and configured. The `generic` executor remains a non-runnable placeholder unless `--allow-placeholder` is used for tests.

## Review policies

Workflow profiles may define `reviewPolicy`. High-risk profiles can require a valid `REVIEWER_RESULT` before `workflow finalize` completes.

Typical enforced review flow:

```bash
python scripts/harness.py workflow reduce WF-...
python scripts/harness.py workflow review-reduce WF-... --executor claude
# save reduce/reviewer.result.json from the reviewer packet
python scripts/harness.py workflow review-reduce WF-... --validate-existing
python scripts/harness.py workflow finalize WF-...
```

Use `--skip-review` only after explicit human approval.

## Executor validation and fallback spawn

Project adopters can add executors in `.harness/routing/executors.json`. Executors may define `defaultSpawn` so every task profile does not need an executor-specific spawn block.

Validate adapter coverage before using a new executor:

```bash
python scripts/harness.py executor validate
python scripts/harness.py executor validate <executor>
```

## Shard balancing

Path-list shards from `changed-files`, `graphify`, or explicit input are balanced by `workflows.shardBalancing.maxPathsPerShard` before worker prompts are generated. This reduces context bloat and keeps worker packets bounded.

## Token-budget audit

Each planned workflow now records deterministic token estimates for worker prompts, reducer/reviewer prompts, and planned worker-output budgets. Run this before expensive workflows:

```bash
python scripts/harness.py workflow token-audit WF-...
python scripts/harness.py workflow token-audit        # aggregate active workflows by type
```

The report is written to `reduce/token-audit.json` and `reduce/token-audit.md`. It includes planned prompt/output budgets plus observed result-payload tokens when `WORKER_RESULT` or reducer outputs exist. Profile-level budgets live in `.harness/workflows/workflow-profiles.json`; global estimator defaults live in `.harness/project.json` under `workflows.budgets.tokenBudget`.

## Async-await workflow commands

The harness supports a durable async orchestration path in addition to blocking `workflow run`.

Recommended sequence:

```bash
python scripts/harness.py workflow start WF-... --executor claude --concurrency 4 --mode all-settled
python scripts/harness.py workflow async-status WF-...
python scripts/harness.py workflow watch WF-... --follow
python scripts/harness.py workflow await WF-... --mode all-settled
python scripts/harness.py workflow collect WF-... --recover
python scripts/harness.py workflow reduce WF-... --allow-partial
```

`workflow start` creates `.harness/workflows/active/<WF>/async/`, materializes async task records, launches a detached supervisor, writes `.run.lock` with the supervisor PID, and returns immediately. `workflow await` polls durable state instead of relying on in-memory futures, so a later terminal/session can await the same group.

Supported await modes are `all`, `all-settled`, `race`, `first-success`, and `quorum`. `workflow cancel` records a durable cancellation request and signals running worker PIDs when available. `workflow async-recover` reconciles orphaned task records after process interruption.

### Diagnose-only triage: `workflow doctor`

```bash
python scripts/harness.py workflow doctor WF-...
```

`workflow doctor` is a **read-only** triage verb: it returns ONE verdict about a workflow's health and **names the single recovery command to run — it never executes it** (doctor consolidates existing read-only helpers, it does not accrete new state). It composes `workflow async-status` (with `recover=False`, so no writes) with the would-orphan predicate read out of the recovery path, and prints a JSON verdict: `{workflowId, groupStatus, supervisor, tasks:{total,running,wouldOrphan,stuckPending,counts}, stalledSeconds, verdict, suggestedCommand, healthy}`.

It picks the single highest-priority issue (never a list of five):

| Condition | verdict | suggestedCommand |
| --- | --- | --- |
| supervisor dead + running task(s) with dead pids | "supervisor dead, N running task(s) would orphan" | `workflow async-recover <WF>` |
| stale lock (lock pid dead) + no live supervisor | "stale lock held by a dead pid, no live supervisor" | `workflow unlock <WF> --stale-only` |
| task(s) stuck scheduled/pending + dead supervisor | "N task(s) stuck ... with a dead supervisor" | `workflow resume <WF>` |
| all settled / in-flight and fine | "healthy" | `null` |

`suggestedCommand` is a string the operator runs; doctor writes no `workflow.json` / async / lock / event state. Acceptance: `testing/scenarios/wd_workflow_doctor.py` (diagnoses-orphan, read-only hash before/after, healthy, and never-executes — the orphan-candidate task stays `running`, never rewritten to `orphaned`).


## StateStore mirror

Inspect the workflow state-store mirror and recovery metadata with:

```bash
python scripts/harness.py workflow state <WF>
```

The workflow packet files remain the canonical human-readable state, while the state-store mirror provides a local recovery boundary.
