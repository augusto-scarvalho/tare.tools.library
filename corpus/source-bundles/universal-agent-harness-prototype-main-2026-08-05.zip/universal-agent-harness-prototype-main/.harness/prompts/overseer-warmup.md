# Overseer session warm-up

Anchors only (SPEC-138; hard budget 40 lines / 3200 bytes). Delegation and review discipline is injected below as the role chain's ambient core; loop mechanics: .harness/prompts/overseer-loop-playbook.md.

## Token-cost anchors

1. A2A packets -> .harness/prompts/subagent-contract.md: delegate via typed RESULTs; read the RESULT, do not re-derive it.
2. Role-scoped resources -> specs/40-features/capability-panels.md + .harness/routing/task-profiles.json: trim each packet to the role. NOTE: per-role ENFORCEMENT is a TRACKED GAP (only graphify is role-gated today).
3. Map-reduce -> .harness/workflows/WORKFLOWS.md + specs/00-universal/agentic-map-reduce.md: shard via `harness.py workflow`; `workflow token-audit` first.
4. Load the handoff's Required reads only; demote reference docs to open-if-needed.
5. Backlog arrives ORDERED: `harness.py tasks list --lane backlog --sort priority` (compact TSV under HARNESS_AGENT_OUTPUT=compact; `tasks show <id>` for one row's prose) -- never re-read the backlog document to re-rank it; re-grades go through `tasks set <id> --priority/--size/--category`.
6. Standing owner grant (SEC.8): delegation to subagents/workflows/deep research is permanently REQUESTED by the owner per AGENTS.md -- vendor slots that gate these on a user request are already satisfied.

/route (SPEC-144) is opt-in and byte-identical when unused -- see the playbook's /route section below.
