# Overseer Loop Playbook — plan-based multi-vendor delegation with mandatory review

Canonical operating instructions for the OVERSEER of an autonomous backlog
loop. Distilled 2026-07-13 from a 12-item, 3-lane session run by Fable 5;
written so the standard holds by protocol, not by model memory. The overseer
model is **Fable 5 high** (owner 2026-07-21: Opus 4.8 removed from the
overseer role; owner 2026-07-23: default effort xhigh -> high — the owner runs
xhigh manually when a session warrants it. Routing `roles.overseer` is the
canonical pin). Owner 2026-07-26: **Opus 5 xhigh is a REGISTERED overseer
fallback** — a different model from the audited 4.8, eligible but not the pin;
the guard answers a fallback session with a NOTICE, not a drift warning.
Vendor surfaces (`.claude/skills/overseer-loop/SKILL.md`,
`codex/prompts/overseer-loop.md`) are thin pointers here. General (non-loop)
overseer discipline lives in `overseer-playbook.md`; this file adds the LOOP
mechanics on top. Shared rituals moved there 2026-07-23 (SPEC-170
hierarchy refactor); pointers below mark the old anchors.

## Session start (flat loop)

Run under the target overseer model (owner launches the session; model fable,
effort high — the `overseer` role in `.harness/routing/model-routing.json` is
the source of truth, never a session's saved default; the owner escalates to
xhigh manually when needed). This is MECHANIZED since 2026-07-23:
`tools/hooks/overseer_model_guard.py` (SessionStart + every prompt) compares the
session's LIVE model (transcript tail) against the pin and warns on drift — the
forensics found sessions silently becoming Opus mid-run (resume/saved-default),
including during an owner-AFK loop. On a drift warning: surface to the owner and
pause overseer work until they `/model` back or authorize (HARNESS_MODEL_OK=1). First actions: `harness.py tasks list
--lane backlog --sort priority` (the board arrives priority-ordered — P1 >
high > P2 > med > P3 > low; compact TSV under HARNESS_AGENT_OUTPUT=compact;
the owner-curated LOOP QUEUE in `docs/IMPLEMENTATION_BACKLOG.md`, when
present, OVERRIDES the derived order), `harness.py checkpoint` (resume any
in-flight state), `harness.py escalations` and `intake list` (pending
context). Never start OWNER-GATED items. A /route specialized overseer skips this ritual -- its compact brief + the SPEC-144 section below ARE its session start.

## Structured execution: the opt-in `/route` two-tier topology (SPEC-144)

**OPT-IN, and it does NOT change the default flow above.** Absent a `/route`
call the loop runs inline exactly as this playbook describes -- same plan-brief
ritual, same review ritual, byte-identical. `/route` is an alternative
*structured* execution shape for a single demand, and not calling it IS the
reversal (SPEC-144 invariant 1).

When invoked, `/route` splits the flat overseer into two right-sized tiers so
context is not re-derived per item (the triple/quad-read problem):

- **Tier 1 -- router (Sonnet 5 high, fallback gpt-5.6-terra high; routing role
  `router`).** Cheap first-contact triage of ONE demand: reads ~nothing (demand
  text + the deterministic `intake_triage` floor + doc-find handles, no file
  fan-out). Emits exactly one route -- `dynamic-workflow | pre-defined-profile |
  inline` -- plus an advisory inline-vs-delegate hint and escalation. The
  deterministic risk-flag floor is a GUARDRAIL it must honor: a security/risk
  flag forces escalation regardless of the model verdict (the model may raise
  severity, never lower it). Conductor A (interactive): the SESSION AGENT spawns this tier via the Agent tool
  (`harness.py route <demand> --triage-prompt` prints the prompt). Conductor B
  (`--loop`): the driver resolves the `router` role and runs it bounded itself --
  no Agent-tool spawn.
- **Tier 2 -- specialized overseer (Fable 5 high; routing role `route-overseer`;
  `feature-delivery` profile, the only `writeAllowed:true` profile).** Receives
  the compact brief (demand + route + covered-doc handles + inline hint; NO
  pre-read file dumps), then owns that ONE demand end to end: WRITES the detailed
  plan brief (the plan-brief template above), decides inline-vs-workers (its
  call, even when the router hinted `inline`), implements, runs the full **review
  ritual** as its audit, commits one demand per commit through the existing
  gates, and returns a typed verdict to the router. It never lowers a router
  escalation; protected-file and security escalations still bubble to the owner.
- **The return contract (invariant 5).** overseer -> router = a committed-state +
  typed verdict `{verdict: kept|rejected, committedSha?, planDeviations: [...]}`;
  `harness.py route --verdict <json>` normalizes it (`consume_verdict`) into the
  router's next-step state -- kept/rejected advance the feed, a malformed verdict
  or a kept-without-commit escalates instead of silently advancing. That
  advance is what returns control to the router for the next demand.

The `--loop` driver has LANDED (conductor B): it drains the intake feed bounded,
writes gated solely by the owner-typed `--approve-writes`; the stop sentinel is
`.harness/state/route-loop.stop` and `route --heartbeat` returns a resume verdict
but NEVER spawns. Conductor A (the interactive session driving the two spawns)
remains available.

## Session hygiene (memory-round G2)

The overseer's own context is the scarce resource: without folding, the
orchestrator session balloons (observed live — the Fable session). All loop
state is durable by design (checkpoint, committed plans/results, the queue),
so **restart the flat-loop overseer session every ~10 integrations**: wind down
in-flight only, clear nothing, start fresh, resume from
`harness.py checkpoint` + the queue. Lossless and cheap.

## Loop mechanics (flat loop)

Every round opens with `harness.py fuel probe` (owner 2026-07-28): the full
all-vendor pass (R-v3.2 made partial probes impossible), BEFORE briefs are
written or lanes launched — routing and the R13 gas balancer then work from
readings born together, never hours apart. `fuel show` stays the pre-lane
read within the round.

Checkpoint (`harness.py checkpoint`) at every transition — plans in flight,
what integration is next; clear it when the queue empties. ScheduleWakeup
~1500s as fallback heartbeat (completions re-invoke first); the wakeup
prompt restates this playbook's role block verbatim. Wind-down on owner
order: finish in-flight integrations only, stop the loop, clear checkpoint,
write the owner summary (items per lane with commits, spend totals via
`harness.py metrics`, untouched pipeline, pending intake), and run the
SERIAL-DIVERGENCE PROBE (owner 2026-07-21: "divergências seriais no final dos
loops importam"): launch `harness-test.py scenarios --serial` detached during
wind-down, then `harness.py gate-divergence` — every serial↔parallel rc
divergence is a flake-candidate that gets a task BEFORE the loop closes
(`harness.py tasks add "<title>" --body -`, prose on stdin), never a shrug
(the parallel copy is the flake amplifier; the serial pass is its control).

*(mechanized 2026-07-23 — the overseer skipped this groom at an AFK wind-down and
rationalized it as "delivery focus"; prose alone did not hold.)* `checkpoint --clear`
(the loop-close signal) now emits a WIND-DOWN REMINDER to stderr when the intake queue
is non-empty and no `docs/research/backlog-groom-<today>.md` exists — a non-blocking
nag (the clear still proceeds, so the ~10-integration hygiene restart is unaffected),
pinned by `context_checkpoint._groom_reminder` + its self-check. It reminds; running
the groom is still the overseer's act.

Wind-down also runs the INTAKE-QUEUE GROOM (owner 2026-07-21: periodic groom
at every loop end — the queue reaccumulated 114 pending in 3 days after the
07-18 round): spawn ONE Sonnet-medium report-only miner over the pending
intake entries (queue-slice variant, backlog-groom-playbook §1), audit its
ledger per that playbook §2 (done-claims verified against git before any
apply), apply via `intake decide`, and write the round report to
`docs/research/backlog-groom-<date>.md`. A loop never closes leaving the
queue un-groomed; entries needing live verification stay pending
deliberately, not by omission.

/route loop mechanics live in `specs/40-features/route-dispatcher.md` -- the
bounded `--loop` driver, the stop sentinel, and the never-spawning heartbeat.

## Measurement rider (Opus-overseer downgrade — CLOSED 2026-07-21)

The Opus-overseer downgrade experiment is closed: the owner removed Opus 4.8
from the overseer role (a resumed session silently reverting to Opus was the
deciding incident — the saved-default is not a routing surface). The habit the
rider installed STAYS: log every review CATCH explicitly in commit messages
("overseer review: caught/kept/rejected …").
