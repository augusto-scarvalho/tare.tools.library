# Testing playbook — how to write a check that actually SEES

For any role that writes or judges a check: `implementer`, `review`, and the
overseer running the review ritual. Everything here was paid for by a real
defect; nothing is generic testing advice.

Gate tiers, evidence and adoption live in `testing/QUALITY_GATES.md` and
`docs/AGENT_TESTING_STRATEGY.md`. This file is about ONE question those do not
answer: **does your check fail when the thing it names breaks?**

## The law

**A check that passes for the wrong reason is worse than no check**, because it
buys confidence without paying for it. A missing check is a known gap; a
toothless one is a gap that reports green.

You cannot tell the two apart by reading. You have to break the code and watch.

## The ritual: falsify before you believe

Before claiming a check works, mutate the thing it guards and confirm it goes
RED. Then restore and confirm GREEN.

```
python scripts/harness.py oracle mutate --scenario testing/scenarios/<yours>.py
```

**Run it BEFORE the commit.** It plants mutants in *diff-changed* functions
against `--diff HEAD`, so after committing there is no diff and it reports
`nothing to probe` — which reads exactly like a clean run. On 2026-07-27 an
overseer ran it post-commit, saw no complaint, and shipped; re-running with
`--diff HEAD~1` then produced a real survivor. The R7 reminder fires at commit
time, which is already too late to obey it.

A **SURVIVED** mutant means the scenario cannot see the changed behavior. It is
not a formality — send it back, or measure why it survived (see *Equivalent
mutants*). It also finds what hand-written mutants miss: the same day, six
hand-rolled mutants all went red while `oracle mutate` surfaced an untested
production transport nobody had thought to break.

For a targeted check, the hand recipe is a temp-mutate / run / restore in one
command, so an interrupt can never leave the tree edited:

```python
orig = p.read_text(encoding="utf-8")
try:
    p.write_text(orig.replace(ANCHOR, MUTANT), encoding="utf-8")
    print("mutant ->", "RED (good)" if run() != 0 else "GREEN (TOOTHLESS!)")
finally:
    p.write_text(orig, encoding="utf-8")
```

Assert the anchor exists before replacing. A silent no-op replace reports GREEN
and looks like a surviving mutant that isn't one.

## The three ways a check passes for the wrong reason

All three were measured on 2026-07-27, in one session, in checks written by an
agent that believed they had teeth.

**1. It proves a NEIGHBOURING mechanism.** `gps-10` was written to prove a
completeness assertion. Its sabotage dropped a row — but a dropped row was
already caught downstream by a name-keyed reorder raising `KeyError`. Deleting
the assertion entirely left the check green. The fix was to find the case only
the assertion owns (a DUPLICATE row, which collapses in the dict and silently
overwrites a verdict) and sabotage THAT.
→ *Ask: if I delete the exact line I am testing, does this go red? If another
mechanism catches my sabotage first, I am testing that other mechanism.*

**2. It never checks the WIRING.** A declaration was stamped correctly by the
library and asserted correctly by the scenario — but nothing asserted that the
caller still PASSED the argument. Deleting `mode="async"` at the call site left
every assertion green and the manifest silently unclaimed.
→ *Ask: does my check fail if someone deletes the call, not just the callee?*

This one repeats, so it earns a second entry. Later the same day, a library
function's default was changed to derive a list itself, and the CLI verb kept
passing the old explicit argument. **The feature shipped DEAD** — the verb went
on doing the old thing — and the entire scenario stayed green, because every
check called the library and none called the verb. It was caught by running the
real command and noticing the output was wrong, not by any check. The commit
message claimed a capability the code did not have.

→ *A changed default is a wiring change.* When you alter what a function does
when an argument is omitted, every caller that still passes that argument
explicitly is now stale. Grep the call sites; assert on one of them. The cheap
form is to monkeypatch the callee, invoke the CALLER, and assert the argument it
passed — that is what makes deleting the call-site change go red.

**3. It asserts the exception TYPE, not the reason.** `rc-4` asserted that an
unconfirmed apply raises `HarnessError`. With the confirm gate removed, execution
ran on and blew up deeper for an unrelated reason — with the same exception type
— and the check read that crash as a refusal.
→ *Assert the message, or a discriminating field. `except SomeError: pass` is a
check that the code failed SOMEHOW, which is almost never what you meant.*

**4. It ran somewhere the defect cannot appear.** Measured 2026-07-27. `hsb-14` asserted
that a denied Job-Object breakaway logs a retry line. It was GREEN run one way and RED
run another, on the same machine, same commit. The variable was the INTERPRETER:
`.venv/Scripts/python.exe` — the declared `HARNESS_PYTHON`, so the one the gate uses — is
a launcher stub that respawns the real interpreter inside a nested job carrying
`SILENT_BREAKAWAY_OK`, which swallows the denial the check was keyed on. An overseer
reviewing the work ran it with the system python by accident, saw green, and nearly
overruled a worker who had correctly reported it blocked.
→ *Before you believe a colour, know what produced it: which interpreter, which shell,
which parent process. "It passes for me" is not a result until you can say where.* When
a check is only falsifiable in some environments, have it MEASURE which one it is in and
say so in its own output — `hsb-14` now reads its own immediate job flags and reports
`silentBreakawayInterpreter=`, so a reader can never mistake an excused arm for a proven
one. An excuse decided by measurement at run time beats an excuse written in a comment.

## The tool that probes your diff is not probing all of it

`oracle mutate` plants ONE mutant per changed function — the first mutable site — so a
function with several operators gets its first one probed and the rest ignored. On
2026-07-27 the site it picked in a 200-line function was a pre-existing line far from the
diff, while the line the commit actually added (`if timed_out and async_job:`) was never
touched. Mutating that line by hand found a real hole: widened to `or`, the cage sweep
fired on NORMAL exit, killing a detached gate runner that must survive its parent's clean
exit — and every check stayed green.

Read a survivor before believing it, and read a GREEN oracle run the same way: it means
one site per function held, not that your change is covered. Mutate the line you wrote.
Row: `oracle-mutate-probes-one-site-per-change`.

## Equivalent mutants: measure, do not assume

A survivor is not automatically a hole. On a host where the mutated branch has no
observable difference, the mutant is EQUIVALENT and the check is fine.

But "equivalent" is a claim, so **measure it**. Two survivors in `processes.py`
looked like coverage holes; the actual cause was that Git's `ps.exe` is on PATH
here but rejects `-axo`, so with or without the Windows early return the
observable was the same empty map. That was verified by running the command, not
by reasoning about it.

Record the verdict either way. "Equivalent on this host, real teeth land on the
Linux/macOS CI legs" is an honest, reusable finding. "Probably fine" is not.

## Ship the detector WITHOUT the fix when the defect is SUSPECTED

If you are not certain a defect is real, a fix landing in the same commit as its
detector makes the suspicion **permanently unfalsifiable** — the check goes green
and nobody ever learns whether it was ever red.

Land the measurement alone, let the environment that can answer it answer, and
fix in the next commit. This is the same measure-before-control law the
experiment methodology applies to behavior changes, applied to your own beliefs.

Corollary: a check whose falsifiability is OS-gated (red only on nt, or only on
the macOS CI leg) must say so in its own comment. A reader on the green OS
otherwise concludes it is a strong check.

**And verify that the answering environment EXISTS.** Deferring an answer to
"the CI leg" is only honest if that leg runs. On 2026-07-27 it was discovered
that this repo's CI matrix — which names ubuntu, windows and macos — has NEVER
executed, because there is no git remote to push to. Every check that degraded
politely to "the POSIX legs cover this arm" was covered by nothing, and a
suspicion deliberately shipped without its fix was not pending but parked
forever. A claim about a verification surface deserves the same falsification as
a claim about code: before you write "the CI leg answers this", check that
something answers.

**The linux half of that is now runnable, locally, for free — use it.** This
machine has WSL2 with Ubuntu and python3. Clone INTO the WSL filesystem rather
than running over `/mnt/c`, so scenarios can never write to the live Windows
`.harness/`:

```
wsl -d Ubuntu -e bash -lc "rm -rf ~/harness-posix && \
  git clone -q /mnt/c/projects/universal-agent-harness-prototype ~/harness-posix && \
  cd ~/harness-posix && HARNESS_QUIET=1 python3 testing/scenarios/<name>.py"
```

It is a local clone: nothing is published, nothing needs configuring. The first
run it ever did found a real defect (`exp21-5-encodes-an-nt-shaped-assumption-`),
so treat "green on nt" as half an answer whenever a check reasons about process
groups, sessions, signals or procfs.

**WSL is NOT the darwin leg.** `/proc` exists there, so `_kill_platform()` returns
`"linux"` and every darwin-discriminated arm stays unexercised — the two darwin
suspicions remain parked with no answering environment. Do not write "the POSIX
legs cover this" and consider yourself done; say WHICH leg, and check that leg
can run.

## Do not weaken a check to make it pass

When a new assertion turns an existing test red, the default assumption is that
the assertion found something. On 2026-07-27 a completeness assertion broke a
module self-check whose fixture declared ZERO scenarios while returning three
rows — harmless before, a dropped-scenario bug after. **The fixture was wrong,
not the assertion.**

If you do change a fixture, write WHY in place, so the next reader can tell a
corrected fixture from a loosened one. If you cannot articulate why the old
fixture was wrong, you are loosening it.

## Where a check goes

- One falsifiable check per behavior, in the scenario the spec already names as
  its acceptance file. Scenarios are glob-discovered — a new check in an existing
  file costs ZERO lines against the `spec_test_gate.py` ratchet.
- Hermetic: temp roots, injected runners, canned fixtures. Never mutate the live
  registry or the real `.harness/` — a scenario that writes real state has
  already failed, whatever it asserts.
- A pure function is testable on every OS; an exec is testable only where it
  runs. Split them, and let the CI matrix cover the half you cannot run.
- Degrade honestly off-platform: state in the comment which arm is falsifiable
  where, rather than letting a skipped arm read as a pass.

## What NOT to test

Trivial one-liners. Generated output that already has a schema. A guard whose
only sabotage is "delete the guard" AND which no caller can reach. YAGNI applies
to checks: the cost of a check nobody can falsify is the false confidence it
sells, forever.
