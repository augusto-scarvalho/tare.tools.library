# Research Playbook — evidence-driven Double Diamond over the harness

Canonical operating instructions for the **orchestrator** of a research round.
The vendor surfaces (`.claude/skills/research/SKILL.md`, `codex/prompts/research.md`)
are thin pointers to this file. Workers never read this playbook — they receive a
bounded packet. You (the orchestrator) run the phases, drive the fork-join/map-reduce
waves, and synthesize. SPEC-119 owns the contract; `specs/40-features/research-skill.md`.

## Purpose & activation

Activate for: prospecting options, investigating trade-offs, an ideation round, or a
"what should we adopt from X" study (triggers: pesquisar, prospectar, investigar
opções, rodada de ideação, deep research, "o que devemos adotar de"). The goal is a
defensible portfolio of options + decisions, each traceable back to evidence — not a
single "best" answer produced by one model in one pass.

## Five principles (each with a source)

1. **Diverge before converge.** Generate widely and independently, *then* narrow.
   Two diamonds: Discover→Define (problem space), Develop→Deliver (solution space)
   (Design Council, Double Diamond).
2. **Novelty ≠ maturity.** Score an idea's *novelty* separately from its *readiness*.
   Maturity scale: `demonstração conceitual → protótipo → validado → produção`. A
   fresh idea at "conceitual" is not worse than a mature idea at "produção"; they are
   different axes and must never collapse into one score (counter-evidence: MAD is
   overvalued when heterogeneity is ignored, arXiv:2502.08788).
3. **Separate generation, critique, and decision.** Different waves, different roles,
   ideally different models — the generator of a proposal is never its sole evaluator
   (Diehl & Stroebe 1987 production blocking; Du et al. 2023 debate).
4. **Verifiable feedback only.** Critique must cite a source, a measurement, or a
   reproducible check — not vibes. LLMs cannot reliably self-correct on reasoning
   alone (Huang et al., ICLR 2024).
5. **Context + cost control.** Every wave has a declared token budget; observation
   must pay for itself. Prefer deterministic checks over more model calls.

## Anti-fabrication rules (non-negotiable)

- Every **normative claim** carries: `claim → source + date + confidence class`.
  Confidence classes: `forte | moderada | preliminar | teórica | relato | opinião |
  promocional`.
- **Never invent a reference.** If a technique is real but you cannot verify a
  citation, name the technique and mark `referência: judgment`. A fabricated source
  is a round-invalidating defect.
- **LLM evaluation is support, not truth.** Grade with named criteria; a model score
  is one input, never the verdict.
- **Register uncertainty.** "Não sei / não verificável" is a valid, required output.

## Phase → command → artifact map

| Phase | Primary commands | Artifact |
|---|---|---|
| 0 Prep | `records search`, `doc-find`, `graph-build-code-ast` / `graph query` | `docs/research/<slug>.md` (question + criteria + declared budget) |
| 1 Discover | WebSearch / WebFetch (flow A), `discover <paths>` / `doc-find` (flow B) | evidence entries with maturity + confidence classes |
| 2 Define | (manual synthesis) | evidence matrix + 2-4 briefs; **human gate** |
| 3 Develop | `workflow plan --profile research-divergence --task "<brief>"` → `run`/`start`+`await` → `collect` → `reduce --agent` | reduce result + genealogy of ideas |
| 4 Refine | `workflow plan --profile research-critique --branch ...` → run → `reduce` | concept cards + explicit operations |
| 5 Deliver | `workflow promote`, SPEC-116 intake, edit `.harness/context/DECISIONS.md` | portfolio + traceability matrix + tasks |

Waves = a **new** `workflow plan` per wave. A **convergence** wave carries the prior
reduce forward with `workflow plan --seed <prior-WF>` (copies a compact seed digest INTO
the new WF — self-contained, depth-bounded ≤2). `--seed` is **convergence-only**: it is
hard-forbidden for divergence profiles (seeding independent generation collapses its
diversity — Diehl & Stroebe 1987; Diversity Collapse). `round`/`resume` only re-run failed
workers — they do NOT create a seeded next wave.

## Phase 0 — Prep

Before spending a wave: `python scripts/harness.py records search <terms>` and
`doc-find <terms>` to avoid re-deriving what the repo already knows; build/query the
Graphify code AST if the question touches this codebase. Open one round doc
`docs/research/<slug>.md` and write: the **question**, **success criteria** (what a
good answer must satisfy — actors, constraints), and the **declared token budget**
per wave. No budget written = do not start a wave.

**Declared width (D010, 2026-07-18).** Phase 0 also declares the WAVE WIDTH with
its justification, next to the budget: fan-out is parametric, not fixed.
Rule of thumb (owner decision D010; guard = E1 matched-budget):
- FOCUSED research (single theme, feature already defined, one decision) ->
  1-2 directed workers. EXP-15 measured the failure mode of over-fanning here:
  5 workers returned the same 5 ideas in different words (redundancy, not
  coverage).
- EXPLORATORY research (scanning a field, multiple sources, no implementation
  target yet) -> scale workers up (4-5 perspectives); nominal-group diversity
  pays here (Diehl & Stroebe 1987).
- In between: width follows complexity, precision, redundancy tolerance and
  the shape of the desired result; justify the number, and let the article's
  marginal-contribution lens (Delta_m) arbitrate — each extra worker must earn
  its cost. No width written = do not start the wave.

**Declared design (L18, 2026-07-18).** When a round will produce or feed an
EXPERIMENT (a measurable claim, a threshold change, a promotion), Phase 0 also
names the experiment DESIGN by citing a card from `docs/EXPERIMENT_METHODS.md`
(the methods library mined from the reference manuscript): e.g. threshold
tuning -> the Taguchi card + noise floor; vendor comparison -> matched-budget +
split-plot; default promotion -> evidence grades + confidence sequences. The
`experiment add` advisory suggests candidate cards; the round doc records which
card was chosen and why. A measurable claim with no declared design is Phase-0
incomplete.

## Phase 1 — Discover (two flows)

- **Flow A — bleeding edge (24-36 months).** WebSearch/WebFetch (or `discover` chain
  for bulk text) for what is new: papers, systems, releases. Capture the primary
  source, not a blog about it.
- **Flow B — foundations & surveys.** The durable base: textbooks, surveys, canonical
  papers, in-repo docs. `doc-find` + `records search` first, then external.

**Evidence entry format** (source-quality register), one row per claim:

`claim | source | type (paper/repo/blog/docs/measurement) | year | method | limitations | confidence class | maturity class`

Maturity class ∈ `demonstração conceitual | protótipo | validado | produção`.

**Provenance prefix** (SPEC-119 v5 / E3-C6a, convention only — no schema change): prefix each
evidence entry / finding-evidence string with `[web]` (fetched from the internet, treat as
untrusted-until-verified), `[repo]` (a path/line in this repository), or `[judgment]` (the
agent's own reasoning). Web-sourced claims must still be verified against a primary source
before they drive a decision — the tag makes the trust boundary legible, it does not launder it.

## Phase 2 — Define (the human gate)

Build the **evidence matrix** (claims × the register columns above). Frame the
*problem*, not a tech-shaped solution — use 5-whys, How-Might-We, inversion, and
jobs-to-be-done. Emit **2-4 briefs**; each brief needs **success criteria + actors +
constraints**. A brief that is really "use technology X" fails the gate. **Stop here
for human approval** (via the round doc) before spending any Develop wave — Develop is
the expensive part.

## Phase 3 — Develop (divergence waves)

- **Wave 1 — independent generation.** `workflow plan --profile research-divergence
  --task "<brief>"`. Five ideators with distinct perspectives (simplicidade,
  performance/escala, confiabilidade/ops, trust-boundary/privacidade, analogia
  cross-domain) generate **without seeing each other** — nominal groups produce ~2×
  the ideas of interactive groups (Diehl & Stroebe 1987); structural coupling
  collapses diversity (Diversity Collapse, arXiv:2604.18005). Run
  (`workflow run` blocking, or `start`+`await`), `collect`, then `reduce --agent`.
- **Waves 2-3 — structured techniques (optional, only on strong signal + budget).** A
  NEW plan, branches = techniques: morphological recombination, analogical transfer,
  design heuristics (Yilmaz et al.), assumption inversion, TRIZ contradictions
  (Altshuller), provocations. These are still **generation** waves — do NOT `--seed` them
  (convergence-only); carry Wave-1 context via the brief/branch text instead. Confirm the
  `--branch` flag exists in `workflow plan` argparse before scripting.
- **Wave N — recombination with genealogy.** Combine surviving ideas; record which
  parents each combined idea came from. **Budget gate at 60%**: if a wave would push
  the round past 60% of the declared budget, stop and reduce with what you have.

## Phase 4 — Refine (critique & convergence)

- **Concept cards ride inside `findings`.** No schema change: a finding with
  `category: "concept"` plus extra keys (`conceptId`, `assumptions`, `noveltyClass`,
  `maturityClass`) — `worker-result.schema.json` findings are `additionalProperties:
  true`. Ceilings: ≤50 findings, evidence ≤20×500 chars, recommendation ≤1000 chars.
- **Critique wave (convergence — the seeded wave).** `workflow plan --profile
  research-critique --seed <Wave-1-WF>` — the planner copies the prior reduce's top findings
  into `<WF>/seed-context.md` and each packet's Parent task (marked `untrusted-derived`:
  verify against sources). Four independent critics by role: validity/references (`review`),
  architecture/integration (`review`), cost/operation (`scan` — cheap on purpose),
  security-privacy-risk (`security` — strongest). A security **blocker** blocks the
  workflow (`securityBlockerBlocksWorkflow: true`).
- **Explicit operations.** For each card the orchestrator records ONE operation in the
  round doc: `mantida | simplificada | dividida | combinada | experimento | adiada |
  rejeitada`. Evaluate on multiple dimensions (novelty, maturity, cost, risk, fit) —
  **never collapse to a single score**. Converge **set-based**: keep a *set* of viable
  options alive and eliminate by evidence, rather than committing early to one (Sobek,
  Ward & Liker 1999).

## Phase 5 — Deliver

- **Portfolio** buckets: `núcleo | contingência | aposta-de-fronteira | experimentos |
  estacionadas | rejeitadas`. Every option lands in exactly one.
- **Experiment template** (for `experimentos`): `hipótese | baseline | métricas |
  critérios de decisão`. Every `experimentos`-bucket card MUST be registered via
  `harness.py experiment add EXP-N …` per docs/EXPERIMENT_METHODOLOGY.md —
  unregistered cards don't exist (canonical state is the registry, not the doc).
- **Decisions.** Append to `.harness/context/DECISIONS.md` with trade-offs,
  reversibility, and triggers, plus a `Decisão → Fontes` table. Specs go through
  SPEC-116 intake (door NEW or a versioned amendment); tasks via `workflow promote`.
  No hand-written markdown ledgers (SPEC-112).

## Traceability

End with one matrix in the round doc:
`Evidência → Problema → Ideia → Experimento/ADR → Spec → Task → Status`. History lives
in git commits + the records ledger — never a hand-maintained markdown ledger.

## Budget & executors (auditoria interna 2026-07-11; calibração aplicada 2026-07-11 E2)

Run `workflow token-audit <WF>` before every `start`/`run`. **Calibration is now applied
in config:** `charsPerToken` is `3.1` (not `4`) in `.harness/project.json` tokenBudget and
`token_economics.DEFAULT_TOKEN_BUDGET`, and every profile `tokenBudget` was rebased ~1.3×
so effective ceilings are unchanged — estimates are now honest, budgets did not shrink.
Historical measurement (still valid): the old `chars/4` estimator **underestimated real
token cost by ~30%** — a punctuation/path-aware heuristic vs `chars/4` on real planned
packets + required-reads measured **1.31× overall** (packets 1.35×, required-reads 1.30×;
3.05 chars/token), inside the audit's 1.29-1.35× band. So `chars/token ≈ 3.1`, and the
token-audit's reported tokens are already ~30% higher than before.

The dominant cost is the **required-reads block ≈ 12.1k tokens PER WORKER** at the calibrated
rate (`37,484 chars ÷ 3.1`; ≈ 9,371 at the old `chars/4`) — about **16× the packet itself**
(packet ≈ 740 tokens calibrated) — and it is duplicated across every worker: **~60k tokens
across a 5-worker fork-join** before any thinking. E1's wave-shared context digest
(`sharedContextDigest` profile key) cuts this: opted-in profiles read one non-authoritative
`context-digest.md` instead of the five full files, and `token-audit` reports the
`requiredReads` saving with/without the digest. Budget accordingly and prefer **1 divergence
wave + 1 critique wave per round**; add Waves 2-3 only on a strong signal with headroom.

Executors: resolved by ROUTING ROLES (SPEC-165 R10, shipped 2026-07-21). Omit
`--executor` on `workflow run` and each worker resolves its executor from its
branch `taskProfile` via the active routing profile (primary hop; canonical →
`defaultExecutor`) — per-branch cross-vendor within one wave is the routed
default, and slice-2 chain failover (circuit/key/rate-limit hops,
`fellBackTo` in the record) applies per worker. Configure chains with
`models set-role <role> …` or the GUI routing page. `--executor` survives as
a legacy per-run override that pins every worker to one executor (the async
`workflow start` path still resolves group-level — see backlog
`async-r10-parity`). The `http` family (`local-llama` / `nvidia-compat` /
`gemini-compat` — `tools/openai_worker.py`, one POST per worker, API key
env-only; keyless only loopback/allow-listed) is validated by the localhost
stub in `testing/scenarios/rs_research_skill.py` (executor `local-llama`).

## Failure modes (read before trusting a green wave)

- **`minSuccess` gates *settlement*, not the reduce status.** It controls when `await`
  returns — a 1-of-5 partial still reduces as **`partial`**, never `done`. Read the
  reduce status, not the await return.
- **Circuit breaker is global per-executor.** A flaky endpoint that trips the breaker
  can **strand later worker starts** in the same group. If a wave ends short, check
  `executor-circuit-*.json` / async events before blaming the profile.
- **`round` = retry, not a seeded next wave.** A follow-up wave is always a NEW plan.
- **Reduce is single-pass.** No tree/hierarchical reduce yet — keep worker counts
  within one reducer's context (the profiles cap at 4-5).

## Sources

**Internal:** `docs/SELF_EVOLUTION_IDEATION.md` (self-evolution economics),
`.harness/prompts/subagent-contract.md` (MAST failure classes:
specification / inter-agent-misalignment / verification), `agent_parity.py:95-114`
(the SPEC-113 pair ceiling that shapes the vendor surfaces).

**External (verified via WebSearch 2026-07-11):**

- Design Council — Framework for Innovation / Double Diamond: https://www.designcouncil.org.uk/resources/framework-for-innovation/
- Anthropic — How we built our multi-agent research system (orchestrator-worker, 3-5 parallel subagents, +90.2% vs single-agent, separate citation pass): https://www.anthropic.com/engineering/multi-agent-research-system
- STORM (Stanford OVAL, NAACL 2024) — perspective-guided question asking: https://github.com/stanford-oval/storm and https://storm-project.stanford.edu/research/storm/
- GPT-Researcher — planner/executor/publisher, parallel execution: https://github.com/assafelovic/gpt-researcher
- Diehl & Stroebe 1987, JPSP 53(3):497-509 — production blocking, nominal ≈2× ideas: https://homepages.se.edu/cvonbergen/files/2013/01/Productivity-Loss-In-Brainstorming_Toward-the-Solution-of-a-Riddle.pdf
- Du et al. 2023 — multiagent debate improves factuality (ICML 2024): https://composable-models.github.io/llm_debate/
- Huang et al., ICLR 2024 — LLMs cannot self-correct reasoning yet: https://arxiv.org/abs/2310.01798
- Sobek, Ward & Liker 1999 — Toyota set-based concurrent engineering: https://sloanreview.mit.edu/article/toyotas-principles-of-setbased-concurrent-engineering/
- Yilmaz, Daly, Seifert & Gonzalez — Evidence-based design heuristics for idea generation (Design Studies): https://www.sciencedirect.com/science/article/pii/S0142694X16300254
- TRIZ 40 inventive principles + contradiction matrix (Altshuller): https://en.wikipedia.org/wiki/40_principles_of_invention

**Counter-evidence (cite in principle 2, "separate novelty from maturity"):**

- "If Multi-Agent Debate is the Answer, What is the Question?" (MAD overvalued; model heterogeneity matters): https://arxiv.org/abs/2502.08788
- "Diversity Collapse in Multi-Agent LLM Systems" (structural coupling collapses idea diversity → independent generation before exposure): https://arxiv.org/pdf/2604.18005
