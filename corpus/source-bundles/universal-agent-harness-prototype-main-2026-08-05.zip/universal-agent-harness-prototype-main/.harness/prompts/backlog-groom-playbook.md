# Backlog Groom Playbook — periodic spec/backlog archaeology over cheap miners

Canonical operating instructions for the **orchestrator** of a grooming round
("a penteada"). Vendor surfaces (`.claude/skills/backlog-groom/SKILL.md`,
`codex/prompts/backlog-groom.md`) are thin pointers here. Validated end-to-end
2026-07-13 (3 mining phases, 60+8+159 items, 21 consolidations same day);
miner reliability audited same day — see §4 for the verdict that shapes §3.

## Purpose & activation

Activate for: "dar uma penteada no backlog", pre/pós-sprint grooming, "o que
escapou das specs?", suspicion that acceptance criteria live only in history.
Cadence: monthly, or after any multi-day autonomous burst; additionally the
light QUEUE-SLICE round runs at every overseer-loop wind-down (owner
2026-07-21 — see overseer-loop-playbook.md loop mechanics). The intake queue
(`harness.py intake list`) captures asks as they happen; this routine catches
what capture misses and reconciles plans vs reality.

## 1. Mine (background, cheap model)

Spawn ONE docs-writer worker per corpus slice (Sonnet-class; ~90-155k tokens
each, minutes not hours). Never the frontier model — the audit pass covers its
weaknesses at a fraction of the cost. Three proven slice templates:

- **Code/git slice**: shipped behavior (commit messages, backlog shipped-notes,
  source) × canonical specs × real scenario `check()`s. GAP = rule in (a)
  absent from (b) or untested in (c).
- **Conversation slice**: session transcripts (`~/.claude/projects/<dir>/*.jsonl`),
  pre-digested by script (user turns + assistant commitments only, secrets
  redacted, mojibake-fixed) then keyword-swept for requirement language.
- **Plan slice**: every intent-to-build doc (PLAN.md, roadmaps, ideations,
  research portfolios, DECISIONS, intake OPEN slices) classified
  landed / landed-but-diverges / tracked / ESCAPED / superseded.
- **Queue slice (light round)**: ONE miner over the intake queue's pending
  entries only — clusters them, proposes one decision per entry
  (discard / discard-done-with-sha / backlog / spec / experiment /
  keep-pending) in a per-entry ledger; the orchestrator audits done-claims
  against git, then applies via `intake decide` and writes the round report
  to `docs/research/backlog-groom-<date>.md`. Validated 2026-07-18; runs at
  every overseer-loop wind-down.

Standing rules for every miner prompt: output to `docs/spec-recovery/`
(DRAFT — NON-CANONICAL header), never touch `specs/`/`testing/`/protected
files, no git ops, cite every claim (sha, file:line, session+date), mark
inferences `inferred`, cross-check prior spec-recovery files to avoid
duplicates, end with a ranked top-10 for the owner.

## 2. Audit (orchestrator, mandatory — never skip)

The measured miner error profile (2026-07-13 audit, n≈18 verified claims):
existence/absence claims (cites, ESCAPED, untested) ≈ **100% precision**;
LIVE-CODE-BEHAVIOR claims ≈ **75%** — misread flows, same-day staleness,
shipped-vs-diverges depth. Zero fabrication observed. Therefore:

- Sample every H/M claim + every claim that would trigger work; verify each
  against the primary source (read the cited lines yourself).
- Treat any live-behavior claim ("X still does Y") as UNVERIFIED until you
  read the current code — that is where the misses live.
- Beware your own tooling: one "wrong cite" in the audit was the auditor's
  200-char read truncation, not the miner. Read whole lines.
- Thresholds: any fabricated citation = discard the deliverable and re-run;
  false-landed in sample = re-run that slice; status-call errors = correct
  inline and note (normal, expected class).

## 3. Triage together (owner + orchestrator)

Walk the audited top-10: each item becomes intake-queue decision material —
`harness.py intake add` the keepers, then `intake decide <id>
spec|backlog|discard --note`. Doctor nags anything left pending >7 days.
Never consolidate unaudited claims.

## 4. Consolidate (bounded batches)

Per decision, the standard doors: SPEC-116 NEW slice or versioned amendment +
scenario `check()`s; commit per area batch; annotate the spec-recovery INDEX
with a CLOSED log (date + commit refs) so the next round never re-mines
closed ground. Prefer fixes at shared seams; prefer making an existing
ratchet/gate the permanent net over one-off checks.

## Sources / provenance

Built from the 2026-07-13 archaeology: `docs/spec-recovery/INDEX.md`
(+CLOSED log), `chat-mined.md`, `plan-mined.md`; audit evidence in commit
messages of that day. Cost profile: 3 miners ≈ 400k Sonnet tokens total;
orchestrator audit ≈ 10 min per slice.
