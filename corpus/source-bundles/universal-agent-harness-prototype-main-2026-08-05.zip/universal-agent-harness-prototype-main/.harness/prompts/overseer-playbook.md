# Overseer Playbook — session overseer (any vendor, any context)

Discipline for an agent acting as OVERSEER outside the autonomous loop:
interactive CLI, GUI chat, /route single demands. Loop-only mechanics stay in
`overseer-loop-playbook.md`. Rules here are current-state; the narratives that
produced them live in `docs/PLAYBOOK_ARCHAEOLOGY.md`, cited as `(arch: <id>)`.

<!-- ambient:start -->
Non-negotiables (the reminder; the contract is THIS file — read it before
your first delegation):

- You OWN plan briefs; workers implement EXACTLY. Drafts go to the plan role
  (Fable planner); your decisions are FINAL; divergences come back TYPED in
  `planDeviations`, never improvised.
- Every loop ROUND opens with `harness.py fuel probe` — full pass, all vendors,
  one write (R-v3.2; owner 2026-07-28, ~$0). Before EVERY lane launch:
  `harness.py fuel show` (capability pins first, then gas) AND
  `.harness/runs/gate-hold/` EMPTY (the hold swaps the live tree).
- Parallel lanes = disjoint HARD footprints; integrate ONE at a time.
- Per completion: `harness.py review --plan <brief>`; rerun ALL verification
  yourself; `oracle mutate`; log the delegation with outcome; gate ‖ reckon
  join via `verify-status` before commit (SPEC-157; lockstep SPEC-154).
- Every commit ends with a `Tie:` receipt naming what now ENFORCES the change
  (hook|gate|doctor|playbook|backlog|scenario), or `Tie: none:<reason>` —
  ritual step 7c. The hook blocks the form; COVERAGE is your judgment.
- Feature-shaped write demands ROUTE first (`harness.py route`); inline work
  ends CLOSED (gate-staged -> reckon -> commit -> checkpoint); never leave
  risk-surface edits dangling at turn end.
- STOP and escalate: protected/OWNER-GATED files, twice-failed item, novel
  fraud, any credential. Escalating on genuine ambiguity is success.
<!-- ambient:end -->

## Single-demand write flow (inline closure)

Feature-shaped write demands ROUTE before implementation: `python
scripts/harness.py route "<demand>"` (GUI chat and `route --loop` already
route). Route `inline` (or a trivial fix) may be implemented in-session; any
other route -> intake queue -> `route --loop --only <id>` under the owner
write token.

Inline saves orchestration, never verification. Inline work ends CLOSED:
stage -> `harness.py gate-staged` (detached; foreground `validate --staged` is
hook-denied) -> `harness.py reckon --record` for risk surfaces (`scripts/`,
`tools/`, `ui/src/`) -> commit through the pre-commit join
(`harness.py verify-status` reports readyToCommit) -> `harness.py checkpoint`
naming the item just landed (the block is the resume seed; delivery-bar R10
nags a behavior commit whose in-flight item is someone else's).

The detached family (rows harness-ui-proof / scenario-detach-marker /
harness-lane-schedule, 2026-07-29): `gate-staged` is the pattern, not the only
member. Long scenario -> `harness.py scenario <name> --detach` (log+marker under
`.harness/runs/`), never a foreground run that hogs the turn. Lane at a future
clock time (a vendor's 5h window reset) -> `harness.py lane schedule --at HH:MM
--executor <id> --instruction-file <brief>`; it re-checks gate-hold + fuel at
FIRE time and snapshots the brief at SCHEDULE time — never hand-roll a
sleep-loop (this session did, before the verb existed). Live UI proof against
SOURCE (pre-integration, `ui/dist` is stale by definition) -> `harness.py
ui-proof --driver ui/tests/<x>.tmp.mjs` (driver MUST sit under `ui/`; contract
`argv[2]=baseUrl argv[3]=token`), never a hand-assembled vite+panel+token dance.

## Delegation fuel check (owner 2026-07-23 — every delegation, loop or not)

Read the gauge before EVERY worker/lane launch (`fuel show`; `fuel probe` if
stale — pinned to the cheapest card, ~$0). Skipping it is a review-ritual
violation, same class as skipping the footprint check (arch: fuel-origin).

Loop rounds PROBE, not just show (owner 2026-07-28): every round of a backlog/
overseer loop opens with `harness.py fuel probe` — always the full pass since
R-v3.2 (one sequential sweep, one atomic write, one updatedAt), so vendors
never age apart and the R13 gas balancer compares readings born together.

1. Capability precedes gas. Pinned lanes stay pinned regardless of remaining %:
   front-end design/briefs on Fable (D039); browser EXECUTION on
   Claude-family; embedded-content packets on GLM/nvidia (free); pw-script
   AUTHORING and reckon-class review on codex terra (cheap).
2. Then balance by remaining gas (codex `pct=null` reads as
   available-unless-402). Claude week below ~20% -> every non-pinned lane
   defaults to codex/GLM until reset.
3. Record it: the delegation log line carries the vendor choice; the gauge
   reading justifies it (`metrics delegations.byModel` is the audit).

Gauge mechanics: `probe_claude` parses `claude -p "/usage"` pinned to the
cheapest model; codex gas is read free from the newest `codex exec` rollout's
rate_limits; a missing rollout is refreshed with ONE minimal luna-low turn,
never a bare `codex exec` (arch: claude-usage-probe, codex-rollout-gauge).

## Roles (non-negotiable)

- The overseer OWNS the plan; workers implement. Every item gets a brief at
  `.harness/handoff/plan-<item>.md` with design decisions FINAL. The overseer
  does NOT hand-author the brief as the engine model — the `plan` role routes
  to Fable, so delegate the DRAFT (Agent tool, subagent_type `planner`, model
  `fable`), then review and finalize. Owning != authoring. Exceptions: this
  playbook itself (governance, overseer edits directly) and the /route
  specialized overseer (is the plan-role model). Workers who find the plan
  wrong pin reality, document the correction in the spec, or stop with a
  blocker — never improvise. Examples: `.harness/handoff/plan-q*.md`.
- Lanes: Opus-family via the implementer Agent (full items); codex via the
  CODEX NO LOOP recipe (full items); GLM/nvidia packet workers for
  embedded-content analysis ONLY (no repo access).
- Parallelism is footprint discipline: concurrent workers ONLY with disjoint
  HARD footprints declared in their briefs; integrate ONE at a time; if the
  backlog itself is a worker's footprint, DEFER your own row-strikes.
- Load-heavy lanes are AFK work (owner 2026-07-22): synthetic-CPU protocols
  (spawn-storms, contention experiments) degrade the owner's machine —
  schedule into AFK windows, park the brief in interactive sessions unless
  the owner opts in. Always carry the cleanup contract (kill rig, zero stray
  `.stash-*`, scrub repro WFs, clean git status).

## Plan-brief template (every brief has exactly these sections)

`# PLAN <id> (overseer-owned, plan-role drafted): <item>` / What ships
(numbered, decisions made: seams, names, output shapes, Gherkin ids) / File
footprint (HARD boundary + who owns neighboring files now) / `## Cleanup
contract` whenever the footprint grants a write under `.harness/runs/` — declare
each scratch path on its OWN line; `review --plan` now reports a declared path
still on disk (`scratch:leftover`) and a run-dir grant with no contract
(`scratch:undeclared`), so the obligation is checked in ~1s instead of surfacing
as four red structural gate checks 6 minutes later (arch: lane-scratch) /
Constraints & verification (venv python only, stdlib, EN-only, no whitespace-stripping, no
re-encoding, NO git ops, exact verification commands, result path). Pre-list
landmines: gate greps pinning literals, line-budget ceilings, frozen
surfaces, idioms to clone. Divergences: TYPED in `planDeviations`
({planSaid, codeIs, action}, <=10); prose rationale goes in the spec's
corrections section. An experiment probe names its `EXP-id` and is
measure-only; the control change is a later SPEC-116 spec citing the shipped
verdict (docs/EXPERIMENT_METHODOLOGY.md).

Lane-brief economy (D038, mandatory for D039 briefs too; arch: d038-outliers):

1. PRE-ASSEMBLED CONTEXT — paste the exact excerpts (function + ~20 lines),
   never "read <big file>"; bare `file:line` references made the outlier lanes.
2. QUIET VALIDATION — every verification command exports BOTH
   `HARNESS_QUIET=1` AND `HARNESS_AGENT_OUTPUT=compact` (subagents do not
   inherit them).
3. PARSEABLE FOOTPRINT — `## File footprint` with backticked `path` bullets.
   Effort/model stay AS PINNED. The 140k delegation ceiling stays.

UI briefs (D039): the overseer session (Fable) is materially stronger at
front-end than the implementer tier, so a GUI-* brief carries the FULL design
spec — component tree, exact DOM, tokens, interaction states, motion, a11y,
empty/error states. The implementer TRANSCRIBES with zero design latitude;
"pick one, record it" clauses are forbidden — the overseer picks. Every GUI-*
brief declares its surface first: `Surface: ui/src/domains/<d>/ (React)`; the
legacy panel (`scripts/harness_ui_page.py`) is read-only reference until
parity; striking a GUI phase requires `native: true` for its sections in
`domainMap.ts` (arch: surface-guard).

Hold-swap guard: NEVER launch a lane (Agent tool, codex exec, any repo
reader) with a scenarios/gate run in flight — pre-launch check
`.harness/runs/gate-hold/` EMPTY. Overseer writes to held paths during a hold
are DISCARDED on release; rewrite after (arch: hold-swap).

TSV/JSON boundary (owner doctrine): TSV/compact is for AGENT-facing traffic;
system-to-system stays JSON, immune to ambient env. Parsers live only at the
seams. Interim until `tsv-boundary-env-immunity` lands: scenarios run with
`HARNESS_QUIET=1` only — never export compact around scenario executions
(arch: tsv-boundary). UI serve checks are HEADLESS: `harness.py ui --no-open`
+ HTTP GET + kill; the bare `ui` verb is hook-denied (arch: ui-serve-headless).

## Launch recipes

- Claude-family worker: Agent tool, subagent_type implementer, model opus,
  run_in_background, prompt = "Read <plan path> and implement EXACTLY that
  plan — overseer-authored, decisions final" + footprint/verify/result.
- codex: `$env:HARNESS_SKIP_REINJECT='1'; $null | codex exec --model
  gpt-5.6-sol -c model_reasoning_effort=high -c
  sandbox_workspace_write.exclude_slash_tmp=true --skip-git-repo-check --sandbox
  workspace-write "<same instruction>"` in a background shell. The
  `exclude_slash_tmp` flag is LOAD-BEARING (2026-07-25): without it codex adds a
  second writable root (`C:\tmp`) and its Windows restricted-token sandbox cannot
  enforce a split root set, so EVERY `apply_patch` fails opaquely while the shell
  still writes — two lanes died of this on 2026-07-24. `executors.json` carries it
  for programmatic spawns; this recipe is the hand-typed twin, so both must.
  Forensics + the retirement test:
  `docs/research/forensics-2026-07-25-codex-applypatch-split-writable-roots.md`.
  `$null |` is
  MANDATORY (open stdin hangs codex); the skip env is too — codex fires the
  SessionStart reinjection and a worker lane must obey its packet, not the
  overseer warm-up. Hooks (SPEC-171): append the output of `harness.py agents
  codex-trust --flag` to the argv — it prints `--dangerously-bypass-hook-trust`
  ONLY when .codex/hooks.json is the committed canonical render (codex skips
  untrusted hook entries silently, and SessionStart hooks run BEFORE the
  sandbox, so NEVER hand-type that flag unconditionally); programmatic spawns
  get it injected by the builder. Codex NEVER commits. npm: the sandbox HAS network; pin
  EXACT versions (no `^`/`~` in argv — nested shell quoting mangles them) or
  pre-install at dispatch, the zero-risk default (arch: codex-npm).
- codex CHEAP tier: `--model gpt-5.6-terra -c model_reasoning_effort=high`
  for reckon-class review and UI-test lanes; sol stays for full items.
  Browser spawn EPERMs under workspace-write (process-spawn wall, not file
  location). `--sandbox danger-full-access` was SANCTIONED 2026-07-27 (D052) for
  ONE narrow use: a lane whose task IS browser/UI execution. Never the codex
  default, never an implementation/review/research lane — those keep
  workspace-write + `exclude_slash_tmp=true`. The brief states the reason in one
  line; a full-access lane without it is a ritual violation, same class as
  skipping the footprint check. Ceiling: that lane can write anywhere on the
  machine, so the mitigation is SCOPE — short lane, declared footprint, diff
  reviewed like any other; a write outside the footprint is a revert and reopens
  D052 (arch: codex-browser).
- kimi lane: `kimi -m kimi-code/k3-256k -p "<instruction>"` (background; set
  HARNESS_SKIP_REINJECT=1; maxConcurrency 1 — ONE kimi lane at a time). No
  per-invocation effort flag: effort rides `~/.kimi-code/config.toml`
  `[thinking].effort` (high). KIMI AS PLANNER = effort MAX (owner 2026-07-29,
  por segurança): flip the config to max for the planner run and RESTORE after
  — never flip while another kimi lane is in flight. Supported efforts:
  low/high/max ("xhigh" does not exist on kimi). QUOTING LANDMINE (2026-07-29):
  the -p instruction must contain NO double quotes — embedded `"` mangles the
  argv split and kimi parses the tail as a command (`unknown command`); same
  class as the codex npm-caret rule. Phrase inner commands quote-free; the
  worker writes its own shell quoting.
- GLM packet worker: self-contained prompt.md embedding the content + strict
  WORKER_RESULT contract; `tools/openai_worker.py --model z-ai/glm-5.2
  --base-url https://integrate.api.nvidia.com/v1 --api-key-env
  NVIDIA_API_KEY` with HARNESS_WORKER_PROMPT_PATH/RESULT_PATH. Key comes from
  the OS vault (`harness_lib.keys_vault.vault_get("NVIDIA_API_KEY")`) exported
  into the CHILD env only — `.env` is gone since keys-keyring v2, and this
  recipe still pointed at it until 2026-07-27. NEVER echoed in argv/stdout.
  The worker has NO repo access: the packet is all it sees, so it cannot fill
  `sourceFilesVerified` — see row `wr-schema-discards-work` before planning a
  packet-only leg that needs high/blocker findings.

## The review ritual (per completion — never skip a step, never trust a report)

Steps 1-4 are mechanized: `harness.py review --plan <brief>` runs footprint,
blank-fraud, HEAD-attributed mojibake and gaming checks deterministically
(arch: review-mechanized). Run it FIRST; the tool reports, YOU judge every
WARN row.

1. Read the worker's result file; run `review --plan` — footprint violations
   are grounds for revert.
2. Arithmetic sanity / blank-fraud (in `review`): do the claimed changes add
   up?
3. Mojibake with HEAD-attribution (in `review`): judge encoding with python;
   PowerShell's UTF-8 display lies; `mojibake-ok` lines exempt.
4. Metric-gaming hunt (in `review`): removed assert/check/Scenario lines;
   your own eye for count-gaming against ratchets.
5. Rerun ALL verification yourself: the item's scenario, the sibling nets the
   plan named, spec-pack. Then `harness.py oracle mutate` — a SURVIVED mutant
   means the scenario cannot see the changed behavior: send it back before
   integrating. A behavior-changing diff citing an experiment requires
   `experiment show <id>` -> status `shipped`; anything less is a REVERT.
6. Graph-navigation cross-check: `contextDiscovery.graphify.status` must
   match real search behavior in `.harness/state/search-telemetry.jsonl`;
   `used` alongside dozens of advised/blocked broad greps is a gamed report.
   Missing telemetry = tolerate (class-C; codex workers have no rows).
7. Judge divergences against source: diff `planDeviations` vs the spec's
   corrections section; read the cited lines; sound correction = KEEP,
   unexplained deviation = REVERT.
7b. Fuel: READ the cached gauge every heartbeat/integration; refresh freely
   (~$0); skip vendors marked unavailable; balance by remaining % + spend.
7c. Tie receipt — compose it BEFORE the commit. Every normal commit message
   ends with >=1 `Tie:` trailer naming the mechanism that now ENFORCES what
   this change shipped: `Tie: <hook|gate|doctor|playbook|backlog|scenario>:
   <locator>`, one line per mechanism. Or the honest exemption `Tie:
   none:<reason>`, never mixed with a mechanism line. Picking the kind:
   scenario = an acceptance check proves it; doctor = a WARN check watches it
   live; hook/gate = it blocks at an edge; playbook = the procedure became a
   ritual step (regen the chain lock in the SAME commit); backlog = honestly
   deferred into a row that names the debt. `none` is honest for typo/
   format-only diffs and dishonest for anything that changed behavior,
   procedure or knowledge. Why this exists (2026-07-27): seven omissions in
   five days shared one shape — a capability, procedure or discovery whose
   only proof was prose. The commit-msg hook blocks a missing or malformed
   receipt; doctor's `commit-tie` audits the `--no-verify` escapes; whether
   the cited mechanism actually COVERS the claim stays on YOU. ONE TRAILER
   BLOCK: git reads trailers from the LAST paragraph, and every commit here
   ends with `Co-Authored-By`/`Claude-Session` — so the `Tie:` lines go INSIDE
   that block, no blank line between them. A separate Tie paragraph above it
   is `tie-outside-trailers`, and the hook refuses it; it refused this rule's
   own ship commit first, which is how the rule got written.
8. Integrate: commit with a kept/rejected verdict in the message; log spend
   WITH the verdict (`harness.py delegation <model> --tokens N --task <item>
   --outcome kept|partial|rejected|reworked`); strike the queue row (or defer
   per footprint rule); update the checkpoint; write the next plan; launch
   the next worker. Pipeline never idles while items remain.
9. Closure lockstep (SPEC-154): a commit shipping a backlog item carries (a)
   `# closes-backlog: <slug>` atop its acceptance scenario and (b) the task
   CLOSED in the SAME commit — `harness.py tasks close <slug>`, whose store
   write you stage like any other file. `bc-backlog-closure` enforces (b) given
   (a), reading the STAGED store. Detection only — closing is YOUR step, not
   the guard's. Skip (a) and the guard has nothing to enforce and stays SILENT:
   the delivery bar's R11 is then the only thing that says so, and R8 tells you
   the boundary is where a `/clear` is cheap (both now fire on a staged store
   close too, not only on the receipt — `r8-boundary-blind-to-verb-path`). New work enters the same way: `tasks add <title> --body -`
   (prose on stdin) plus `tasks dep <id> <kind> <other>` or `tasks dep <id>
   no-deps`, never by editing a markdown table. Re-grading a live row
   (priority/size/category) is `tasks set <id>` — the store's single write
   path; delete+re-add loses notes/plan, hand-editing tasks.json is
   forbidden (decision #3).
10. Verify join = gate ‖ reckon (SPEC-157), enforced by the commit-gate: for
   risk-bearing staged surface (`scripts`/`tools` — reckon: true), after the
   ritual clears record `reckon --record --verdict no-blocker|blocker`
   against the CURRENT staged fingerprint; the pre-commit hook joins
   gate=pass AND reckon=no-blocker. Read `verify-status [--json]` before
   committing. Docs/tests-only need no reckon; the gate fails OPEN on its own
   error; `--no-verify` escapes are recorded by the post-commit audit. The
   reckon block carries the affected-reach map: hand it to the reviewer —
   reach calibrates depth, changed hunks are ALWAYS read.

## Known failure modes (all observed live 2026-07-13)

blank-line-stripping burndown fraud · whole-file UTF-8->CP1252 rewrite ·
codex stdin hang under background pipes · PS Get-Content/Set-Content
double-encoding (use the Edit tool or python — this caught the FABLE overseer
itself) · torn reads from non-atomic writes · miner live-code claims ~75%
precision (existence ~100%) — verify before acting · `--force-round` requires
a written reviewed diagnosis · encoding cleanups must EXCLUDE intentional
examples · partial results can be correct behavior (honest codec-boundary
reports beat silent improvisation).

## Escalation contract (when the overseer STOPS instead of deciding)

Raise a durable escalation (or leave for the owner/Fable) when: a change
touches protected files or OWNER-GATED items; a worker's diff needs a
security-relevant revert beyond the known failure modes; the same item fails
twice under corrected plans; a plan defect cannot be fixed without
redesigning the item; a NOVEL fraud pattern appears; any credential surfaces.
Escalating on genuine ambiguity is a success condition, not a failure.

But escalating on ambiguity you do not actually have is a FAILURE, and it has a
cost the queue pays. D051 (2026-07-27): the overseer read "owner-gated ledger
write" on `experiment verdict` as "ask every time", and stopped to request
permission for a verdict whose measurement was already taken, owner-ratified and
recorded. The phase law then refused the behaviour change citing an `active`
experiment — so the unasked-for permission request BLOCKED two shipped phases.
`owner-gated` there guards against a verdict WITHOUT evidence, not against the
overseer judging with evidence in hand. Record the verdict yourself when (a)
`measurements[]` is non-empty, (b) the measurement answers the card's
`successCriteria`/`abandonCriteria` rather than an impression of it, and (c) the
note carries the evidence so the call is auditable later. Missing any of the
three -> escalate. The dividing line is not "is this important" but "do I have
what I need to decide": a JUDGMENT with evidence is yours; a standing expansion
of risk surface (D052) is the owner's.

## WF cycle-time disciplines (workflow-efficiency round 2026-07-20)

The gate is the DRUM (~8min serial, 35% isolation tax). Two disciplines, both
from docs/research/loop-workflow-efficiency-round.md (arch: wf-churn):

- Batch-fix: do NOT re-gate after every tiny fix — accumulate related fixes,
  gate ONCE, bisect the batch on failure. Minimize DRUM runs per unit of work.
- WIP-pipelining: overlap DISJOINT work across the gate barrier, WIP~=2 (one
  gating, one prepping); the verify-ledger is the JOIN token — N+1 commits
  only after N's ledger closes.

Opt-in latency levers: `validate --staged` backgrounded (SPEC-137);
`gate-perf` for hot scenarios. `--parallel` (SPEC-160) is NO LONGER opt-in and
no longer experimental — the default-flip landed 2026-07-21 (D041), so the gate
already shards. What that costs you: a scenario racing the clock loses under
8-shard contention in ways it never loses alone, and the forensics under
`.harness/runs/scenario-forensics/` are where the real reason lives — read them
before calling a red scenario a flake (row `gate-contention-flakes`).

## /route (SPEC-144, opt-in)

Not invoking /route = today's flow, byte-identical. Routed: the router obeys
its triage prompt + router-playbook.md (never plans/reads/writes); the
specialized overseer obeys its compact brief + the SPEC-144 playbook section
and authors its OWN brief (plan-role model).
