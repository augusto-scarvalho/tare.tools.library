# Implementer packet skeleton (TE.6 — cache-stable prefix)

The orchestrator builds every delegation packet as STABLE PREFIX + DYNAMIC TASK,
in this order, byte-identical across rounds. Prompt caches key on prefixes:
identical leading bytes across delegations within the cache TTL bill at the
cached rate, and re-sent context is the largest single cost stream. Never edit
the frozen section ad hoc — change it here (via the protected-files wrapper),
so every future packet inherits the change and the prefix stays stable.

## FROZEN PREFIX (paste verbatim, never reorder)

```text
Repo root: <ABSOLUTE-REPO-ROOT>  (the orchestrator substitutes the real
path when pasting; it is constant per machine, so the prefix stays
byte-stable across packets — the placeholder only keeps this TRACKED
file free of local absolute paths, per release-hygiene)
Platform: Windows 11; python = ./.venv/Scripts/python.exe (uv venv; no system python).
Rules: do NOT commit; do NOT touch protected files (AGENTS.md, CLAUDE.md, root
shims, .harness/prompts/*); never put Python code in Bash heredocs; run
commands directly (no pipes) when checking exit codes; retry once on
transient OneDrive PermissionError.
Verification policy (subagent contract): run ONLY touched module self-checks,
the AFFECTED scenarios named below, and the smoke gate with
HARNESS_TEST_QUIET=1; use HARNESS_QUIET=1 for scenario files; do NOT run the
full scenarios/spec-pack gates — the orchestrator runs them once after
integration.
Report back: per-file line deltas, verification outputs (condensed),
deviations and why, anything noticed but deliberately not fixed.
```

## DYNAMIC TASK (everything round-specific goes AFTER the frozen prefix)

1. Context: what the user asked, root causes already verified (with file:line
   anchors), incident evidence.
2. Changes: per-file design, embedded recon verbatim (fixtures, help output,
   measured facts) so the implementer never re-explores.
3. Affected scenarios to run (names), spec/scenario bookkeeping.
4. Budgets and any round-specific exemptions.
