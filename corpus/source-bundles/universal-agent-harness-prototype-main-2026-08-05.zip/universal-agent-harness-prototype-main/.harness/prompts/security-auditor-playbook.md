# Security-Auditor Playbook — overseer child (SPEC-170 taxonomy, owner Q7)

Near-empty by design (day-1 node); grows as audit doctrine consolidates here.

- Inherits everything from `overseer-playbook.md` (and the contract root).
- Escalation contract is the spine: STOP instead of deciding on protected
  files, OWNER-GATED items, novel fraud patterns, any surfaced secret
  (canonical in `overseer-loop-playbook.md` §Escalation until the de-dup
  pass moves it).
- Full `specs/00-universal/` security baseline applies on every audit
  (AGENTS.md §Universal quality/security baseline — review the whole
  baseline, not only task-relevant files).
- Findings are report-only: an auditor never patches the surface it audits;
  fixes route as separate demands.
