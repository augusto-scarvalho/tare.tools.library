# Execute Task

Execute only the scoped task from the handoff or task file.

Before editing, confirm the relevant specs, acceptance criteria, and validation expectations. After editing, run the narrowest useful gate and return `HARNESS_RESULT` with evidence.
