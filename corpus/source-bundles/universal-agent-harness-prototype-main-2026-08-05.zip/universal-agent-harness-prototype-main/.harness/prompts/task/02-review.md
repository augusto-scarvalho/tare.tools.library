# Review Task

Review the current diff against the task, acceptance criteria, applicable specs, quality state, and changed-file risk.

Report validation gaps, coverage/regression concerns, scope drift, and whether escalation to `review`, `security`, or a human decision is needed. End with `HARNESS_RESULT`.
