# Start Here

Read `AGENTS.md`, `.harness/handoff/handoff.md`, and the files listed under the handoff required reads.

Do not restart work from scratch. Continue from the canonical harness state and keep the task scope bounded.
