# UI-Overseer Playbook — overseer child (SPEC-170 taxonomy, owner Q7)

Near-empty by design (day-1 node); grows as UI doctrine consolidates here.

- Inherits everything from `overseer-playbook.md` (and the contract root).
- UI briefs carry the FULL design spec — component tree, DOM, tokens,
  states, motion, a11y; implementers transcribe with zero design latitude
  (D039, canonical in `overseer-loop-playbook.md` §Plan-brief until the
  de-dup pass moves it).
- Every GUI-* brief declares its surface first: `Surface: ui/src/...`
  (React). The legacy panel is read-only reference (v4 surface guard).
- UI serve checks are HEADLESS (`ui --no-open` + HTTP GET); a worker never
  opens a browser.
