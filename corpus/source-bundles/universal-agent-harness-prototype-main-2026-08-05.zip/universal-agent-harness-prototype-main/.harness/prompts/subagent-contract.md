# Subagent Contract

Every non-trivial single-task agent execution must end with a structured result.

Use this exact shape near the end of your response:

````markdown
## HARNESS_RESULT

```json
{
  "taskId": "optional-task-id",
  "subtaskId": "optional-subtask-id",
  "status": "done|partial|blocked|failed",
  "summary": "What changed or what was learned.",
  "filesChanged": [],
  "testsRun": [],
  "failedTests": [],
  "coverage": {
    "status": "not_applicable|not_configured|not_run|manual|pass|fail",
    "summary": "Coverage or regression evidence, if applicable."
  },
  "contextDiscovery": {
    "graphify": {
      "status": "used|not_available|stale|not_applicable|skipped",
      "reportRead": false,
      "queries": [],
      "sourceFilesVerified": [],
      "reason": null
    }
  },
  "nextStep": "Recommended next step.",
  "riskSignals": [],
  "universalSpecsApplied": [],
  "universalSpecDeviations": [],
  "requiresReview": false,
  "requiresSecurityReview": false,
  "requiresEscalation": false,
  "suggestedProfile": null,
  "failureClass": null,
  "acceptanceCriteria": null,
  "frictionObservations": [],
  "reason": null
}
```
````

The agent may request escalation, but the harness decides whether to spawn another profile.

## Universal baseline expectations

For non-trivial work, include the relevant files from `specs/00-universal/` in `universalSpecsApplied`. For behavior, test, bugfix, release, or validation work, include `specs/00-universal/testing-and-quality-gates.md`; include `specs/00-universal/coverage-and-regression.md` when regression or coverage evidence is relevant.

Use `universalSpecDeviations` for intentional deviations, incomplete validation, missing regression coverage, unavailable coverage tooling, or risks that could not be resolved within the current task.

If a universal spec triggers escalation, set `requiresEscalation: true` and provide `suggestedProfile` such as `review` or `security`. When status is blocked or failed, optionally set `failureClass` to one of `specification | inter-agent-misalignment | verification` (MAST root-cause classes) so escalations and gate failures can be grouped by cause.

## Friction observations (self-evolution input)

When a task forced you into a repeated manual dance, a repeated search, or a workaround, record it in `frictionObservations` (at most 10 short strings, <=200 chars each) - e.g. `"grepped 4 times to locate the reduce validator"`. The harness self-review aggregates recurrences into tooling proposals (friction twice = a missing tool); observations are telemetry, never an excuse to widen scope.

## Pre-implementation acceptance contracts

For medium-and-higher-risk task profiles the spawn prompt requires a pre-implementation contract: propose acceptance criteria as the FIRST deliverable, obtain approval (human or reviewer) before implementing, and record the round-trip in `acceptanceCriteria`: `{"proposed": ["..."], "approvedBy": "human|reviewer", "graded": [{"criterion": "...", "verdict": "pass|fail"}]}`. A result cannot claim `done` with a failed or ungraded criterion - use `partial`/`blocked` and escalate; waiving is a human decision. Low-risk profiles skip this step; the field stays `null`.

## Context discovery evidence

For non-trivial repository search or cross-file reasoning, report Graphify/Graphify code AST usage in `contextDiscovery.graphify`. Prefer Graphify code AST-first structural discovery before external/API-assisted discovery. Use `not_applicable` for tiny single-file edits that did not require structural discovery. Use `not_available` or `stale` when the graph cannot safely guide the work. Gemini API assistance is opt-in/free-tier-only and never authoritative. Always verify graph-derived findings in source/spec/test/config files before editing or finalizing.

## WORKER_RESULT for workflow workers

When executing a workflow worker packet, return a compact JSON object saved to the requested result path. If the executor cannot write files directly, return exactly one JSON object in stdout; `workflow run` will try to capture and save it. Do not use full `HARNESS_RESULT` for each worker.

```json
{
  "workflowId": "WF-YYYYMMDD-HHMMSS",
  "workerId": "worker-001",
  "shardId": "shard-001",
  "branchId": null,
  "workerRole": "map-worker",
  "status": "done|partial|blocked|failed",
  "failureClass": null,
  "frictionObservations": [],
  "summary": "Concise shard result. Keep under 1000 characters.",
  "itemsAnalyzed": [],
  "findings": [
    {
      "severity": "blocker|high|medium|low|info",
      "category": "quality|security|tests|docs|architecture|dependency|workflow|other",
      "title": "Short finding title.",
      "evidence": ["path/or/spec-id plus short reason"],
      "recommendation": "Bounded next action."
    }
  ],
  "sourceFilesVerified": [],
  "graphify": {
    "status": "used|not_available|stale|not_applicable|skipped",
    "queries": [],
    "reason": "Why Graphify was or was not used."
  },
  "nextStep": null
}
```

Worker constraints:

- stay inside the worker packet scope;
- remain read-only unless the workflow explicitly allows writes;
- keep output under the configured `maxWorkerOutputChars`;
- use evidence references instead of pasted content;
- if Graphify status is `used`, include at least one source file verified.

A worker that ran a QA oracle MAY attach an optional `oracleEvidence` capsule to its WORKER_RESULT (SPEC-121): `{"oracle": "...", "exitClass": "passed|failed|error|timeout|skipped", "artifactPath": "relative/handle", "rerunCmd": "..."}`. It is a handle to pre-scrubbed evidence so reviewers verify the capsule instead of re-running the oracle; `artifactPath` must be relative (no absolute paths, no `..`) and `rerunCmd` at most 400 chars.

## REDUCE_RESULT for reducers

Reducers synthesize worker outputs into one compact result. They must deduplicate repeated findings, preserve conflicts, rank by severity, and recommend next bounded tasks.

```json
{
  "workflowId": "WF-YYYYMMDD-HHMMSS",
  "status": "done|partial|blocked|failed",
  "summary": "Concise synthesis.",
  "workersCompleted": 0,
  "workersFailed": 0,
  "dedupedFindings": [],
  "conflicts": [],
  "blockers": [],
  "recommendedTasks": [
    {
      "title": "Bounded task title",
      "priority": "blocker|high|medium|low|info",
      "sourceFindings": [],
      "recommendation": "Actionable next step."
    }
  ],
  "requiresReview": false,
  "requiresSecurityReview": false
}
```

## REVIEWER_RESULT for post-reduce reviewers

Reviewer agents validate reducer output before finalization for high-risk workflows. Return one compact JSON object saved to `reduce/reviewer.result.json` when requested.

```json
{
  "workflowId": "WF-YYYYMMDD-HHMMSS",
  "status": "approved|approved_with_notes|changes_requested|blocked",
  "summary": "Concise review conclusion.",
  "reviewFindings": [
    {
      "severity": "blocker|high|medium|low|info",
      "title": "Reviewer finding title.",
      "evidence": ["path/or/reducer finding id"],
      "recommendation": "What must change before finalization.",
      "blocksApproval": true,
      "whyNotBlocking": null
    }
  ],
  "criteria": [
    {"name": "correctness-of-claims", "verdict": "pass|fail", "evidence": "One line of evidence."}
  ],
  "approvedForFinalize": false,
  "requiresHumanReview": true,
  "reviewedReduceResultPath": ".harness/workflows/active/WF-YYYYMMDD-HHMMSS/reduce/reducer.result.json",
  "notes": null
}
```

Set `approvedForFinalize: true` only when blocker/high findings, failed workers, conflicts, and recommended tasks have been reviewed and the reducer result is acceptable for handoff/finalization. Grade the named criteria (correctness-of-claims, test-evidence, security-and-secrets, scope-conformance, regression-risk) pass|fail in `criteria`; one failed criterion means the review cannot approve. No self-waiver: a reviewer may not waive a blocker or failed criterion it identified - waiving is a human decision, so set `changes_requested`/`blocked` with `requiresHumanReview: true` instead. The harness rejects reviewer results that approve past a failed criterion or an unresolved blocker.

## Controlled write workflow overlay

If a workflow worker packet says `writeAllowed: true`, it is still bounded by harness-controlled write safety:

- Write only inside the isolated workspace exposed by `HARNESS_WORKER_WORKSPACE`.
- Modify only files listed in the worker packet's locked path list or scope file.
- Save `WORKER_RESULT` to `HARNESS_WORKER_RESULT_PATH`.
- Do not merge changes into the main working tree.
- Do not edit files owned by another worker.
- Do not remove harness locks, backups, merge plans, or workflow runtime files.

The harness, not the worker, creates `locks.json`, `merge-plan.json`, backups, rollback data, and approved merge application.

## TSV/JSON boundary (owner 2026-07-22)

Format belongs to the CONSUMER; parsers live only at the seams:

- **You read harness data**: export `HARNESS_AGENT_OUTPUT=compact` on direct
  harness.py CLI calls you consume — tabular payloads arrive as TSV, the rest
  as compact JSON.
- **Agent-to-agent tabular data** (brief tables, pasted excerpts, result tables):
  TSV directly, no conversion.
- **You hand tabular data to the application**: TSV where the seam declares an
  ingest parser (`harness_lib.common.from_tsv` is canonical). Live seams:
  `WORKER_RESULT.findings` and `REVIEWER_RESULT.reviewFindings` MAY each be one
  TSV table string (header row = the field names; `evidence` cell = a
  compact-JSON array) — parsed at validation, identical to the JSON form. The
  envelopes themselves (HARNESS_RESULT / WORKER_RESULT / REDUCE_RESULT) stay
  JSON — they are system-ingested contracts, not tables.
- **Never around scenario executions**: scenarios are app-to-app consumers and
  scrub the env themselves; exporting compact there buys nothing. Scenarios
  run with `HARNESS_QUIET=1` only.

## Verification policy for implementers (token economy)

Verification is layered so the expensive implementer context never pays for
success noise or duplicate full-gate runs:

- Run ONLY: the module self-checks you touched, the AFFECTED scenarios (those
  your packet names, plus any whose subject files you changed), and the smoke
  gate in quiet mode (`--quiet` or `HARNESS_TEST_QUIET=1`).
- Do NOT run the full `scenarios`/`spec-pack` gates unless your packet
  explicitly asks for them: the orchestrator runs the full gates exactly once
  after integrating your work.
- Prefer quiet modes everywhere (`HARNESS_QUIET=1` for scenario files): your
  context should consume failures and summaries, never per-check success lines.
- Report the exact commands you ran and their summaries; the orchestrator's
  independent re-run of affected scenarios is part of the design, not distrust.

## Resource allowlist grading (SPEC-143)

When your spawn prompt carries a `Resources for this role: skills=[...]; mcp=[...]`
line (the s2 `tokenEconomy` allowlist), you MUST return `resourcesRespected` in
HARNESS_RESULT: `{"respected": true, "loadedOutsideAllowlist": []}` when you stayed
inside the allowlist. If you needed a skill or MCP outside it, set `respected` to
`false` and list the offending items in `loadedOutsideAllowlist` (non-empty when
`respected` is false) so the overseer grades the escape instead of discovering it.
Absent the allowlist line the field is ungraded - omit it (back-compat).

## Specialized overseer verdict (SPEC-144)

The `/route` specialized overseer -- the `feature-delivery` writeAllowed profile, Fable 5 high;
opt-in, conductor A -- returns a TYPED verdict to the router when it finishes a demand:

    {"verdict": "kept" | "rejected", "committedSha": "<sha|null>", "planDeviations": [ ... ]}

- `verdict` MUST be `kept` or `rejected`. An unknown/absent verdict makes the router escalate and
  NOT advance the feed (the return-side ambiguity floor).
- A `kept` verdict MUST carry `committedSha` -- a kept demand must show its commit -- or the router
  escalates.
- `rejected` means the overseer discarded its own work after its audit; the demand is still handled,
  so the router advances.
- `planDeviations` reuses the typed-deviation shape from HARNESS_RESULT above.

The router normalizes this via `route_dispatcher.consume_verdict` into
`{verdict, committedSha, planDeviations, advance, escalate, reason}`. It is deterministic plumbing
(the overseer->router return half of the SPEC-144 compact handoff contract), never a model judgement.

## Long-running commands: wait discipline (stall class, 2026-07-15)

A background job you launch does NOT re-invoke you after your turn ends: the
wakeup does not survive a delegated agent's turn boundary, and nobody else is
notified either. Ending your turn "waiting for the gate/job notification" is a
guaranteed permanent stall until a coordinator manually pings you — observed
repeatedly with `validate --staged` / scenarios-gate runs (~7-15 min, longer
than the foreground command cap).

Rule: NEVER end your turn while a job you must react to is still running.
Keep the turn alive until the job settles, using whichever your tooling has:
a Monitor/until-condition wait, or an in-turn poll loop on the job's output
file or a completion sentinel (e.g. `.harness/runs/validation-results.jsonl`
mtime advancing past your gate start; process-gone). Report results only after
you observed them — "the job will notify me" is a contract violation.
