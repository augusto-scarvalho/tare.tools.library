# Harness State

Status: active development — self-hosted SDD loop (SPEC-116 two-door law).

## Current work

- Task state: `docs/IMPLEMENTATION_BACKLOG.md` (queue tables) and
  `python scripts/harness.py tasks list` (derived board).
- Pending owner reviews: `python scripts/harness.py escalations`.

## Continuity

- In-flight work state lives in the checkpoint block of
  `.harness/context/NEXT_STEPS.md` — maintained with
  `python scripts/harness.py checkpoint` (see docs/CONTEXT_CHECKPOINT.md).
- Workflow handoffs: `.harness/handoff/handoff.md` + `.harness/handoff/handoff.json`.
