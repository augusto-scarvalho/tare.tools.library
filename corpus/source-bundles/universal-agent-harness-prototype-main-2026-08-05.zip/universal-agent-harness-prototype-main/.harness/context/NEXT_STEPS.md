# Next Steps

Current dynamic next-step context for any agent. Keep this file compact.

## Last workflow

- Workflow: `WF-20260720-175712-339749` (fork-join, `partial`) — CLOSED 2026-07-29.
  Reducer output was consumed on 2026-07-20: decisions in DECISIONS.md D036 (skip-condition/
  enablement split, shadow exclusion until EXP-30, regen-manifest direction); shipped tasks
  `wf-regen-manifest` and `W29.N2`. The 2/4 invalid-ideator cause was fixed by
  `wr-schema-discards-work`. Workflow dir was deleted (untracked); reducer paths in
  workflow-state.json are dangling — historical only.
- NOTE: `WF-20260727-*` dirs in `active/` are EXP-21 crash-injection canaries, deliberately
  left mid-flight — do not reduce or finalize them.

## Recommended action

None from workflows. Pick next item from the backlog (`harness.py tasks list --lane backlog --sort priority`).

<!-- inflight:start -->
## In-flight checkpoint (updated 2026-08-05T03:12-03:00)

- Item: rt6-posix-writechain-deeper-than-git-ide
- Phase: teardown-fixed-exp21-5-rt6-nested-git-remains
- Verify: gh run view 30979698668 && git log --oneline -5

Trail: 199 older entries in .harness/context/checkpoint-trail.md
  - 2026-08-05T03:12-03:00 [teardown-fixed-exp21-5-rt6-nested-git-remains] SESSION: 3 debts attacked. d010 (8023e9e) + size-budget (afe51de) DONE+closed+pushed. rt6/exp21 teardown reorder (a60c133) PUSHED + CI-verified: GREENED exp21-5 (bonus, real win) with NO windows regression, but rt6-committed/rt6-gate-fail-rollback STILL RED on POSIX = they are the 'nested-git class', NOT the teardown race my reorder fixed. rt6 task STAYS OPEN with CI evidence; next step = diagnose the nested-git angle (needs POSIX host or more CI rounds). exp21-5 effectively resolved by a60c133 (exp21-10 residual = separate path). a60c133 is net-positive (fixed exp21-5, no regression, stands). Pre-existing residuals still red on POSIX: kg_kill_guard, ux chat-operator-self-check. Follow-up test-debt filed: width-stamp-declaredwidth-coverage-gap.
<!-- inflight:end -->
