# Harness Context

This is the canonical, agent-agnostic context for the project.

Keep this file short. It should describe only information that any coding agent must know before working on the repository.

## Project

- Name: update `.harness/project.json`
- Type: generic software project
- Current phase: bootstrap / adoption

## Universal rules

- `.harness/` is the canonical harness layer.
- Agent-specific directories such as `.codex/`, `codex/`, and `.claude/` are adapters only.
- Do not store canonical state in an agent-specific directory.
- Git is the source of truth for code.
- The harness is the source of truth for task state, continuity, routing, and handoff.
- Agents must not change their own model or reasoning level. They may request escalation; the harness decides and spawns a new execution/profile.

## Context budget policy

Read only the files required for the active task. Avoid loading historical summaries unless the handoff or task explicitly requests them.


## Universal baseline

All projects using this harness inherit the universal quality/security/testing specs in `specs/00-universal/`.

Agents should apply the relevant baseline checks to every non-trivial change and request escalation when a task touches security, privacy, dependencies, configuration, infrastructure, public interfaces, test policy, coverage, or agent safety boundaries.

