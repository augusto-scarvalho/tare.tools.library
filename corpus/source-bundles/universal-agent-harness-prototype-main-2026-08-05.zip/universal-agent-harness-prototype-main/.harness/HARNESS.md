# Harness Directory

`.harness/` is the canonical, agent-agnostic control layer for the repository.

It stores the compact state that lets any supported executor continue work without relying on prior chat context.

## Subdirectories

- `.harness/context/` — short, reusable context files for current project/harness state.
- `.harness/state/` — structured workflow, task, and quality state.
- `.harness/handoff/` — generated continuity package for the next bounded execution.
- `.harness/routing/` — task profiles and executor mappings.
- `.harness/prompts/` — reusable contracts and task prompts.
- `.harness/runs/` — ignored runtime event/validation logs.
- `.harness/runtime/` — ignored local runtime selection and executor state.

## Rules

- Canonical state belongs here, not in `codex/`, `.claude/`, `.codex/`, or other executor-specific adapters.
- Runtime logs and local executor choices must remain ignored by Git.
- Keep context compact. Move long history, generated evidence, or project-specific detail to appropriate docs, specs, tasks, or ignored run artifacts.
