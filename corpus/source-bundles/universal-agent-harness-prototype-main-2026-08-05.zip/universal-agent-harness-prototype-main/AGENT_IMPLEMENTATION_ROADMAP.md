# Agent Implementation Roadmap

Project-specific roadmap and active work should live in `tasks/`, `specs/`, and `.harness/context/NEXT_STEPS.md`.

This root-level file is only a compatibility entry point for agents that look for a roadmap near the repository root. Do not duplicate backlog, status, or long plans here.
